# Controlled Testing Backlog - Survivor v15 / Live 10.2.0

These questions are **quarantined uncertainty**, not permission to guess. The frozen mechanics file remains authoritative until a controlled test justifies a future r3 mechanics revision.

| Priority | Perk / system | Question | Editorial impact |
|---|---|---|---|
| High | Road Life | Real injured-generator time to the Tier III Token threshold; Token persistence through interruptions/other healing; repeat acquisition edge cases | Could move provisional #65 materially within its #45–95 range |
| High | Do No Harm | Does “+5% Skill Check odds per Hook State” behave as percentage points or relative increase? | Mainly refines #56 and skill-ceiling text |
| High | Boon: Illumination | After a Killer snuffs the Boon, is the next bless base speed or accelerated? | Global #142 holds under current text; favorable behavior raises package/global ceiling |
| High | Dark Sense | Wasted-trigger frequency while hooked/in chase; clustered-generator behavior; final-generator edge behavior | Determines whether #40 remains A-boundary or falls into B |
| High | Spine Chill | Trigger reliability at chase start; practical 12s vault conversion; interaction with stealth/Undetectable and Diminishing Returns | Could move provisional #47 within #40–65 |
| Medium | Stake Out | Exact “hiding” qualification, interruption behavior, and whether non-generator basic Skill Checks consume Tokens | Refines #118 and anti-synergy wording |
| Medium | Premonition | Cone/line-of-sight edge behavior | Refines specialist information guidance |
| Medium | Down to the Last | Exact timing/stacking around gate completion and last-Survivor transition | Refines endgame guidance |
| Medium | Borrowed Time + basekit Elusive | Confirm overlap/timing under live rescue conditions | Refines counter/overlap language, not the rank core |
| Medium | Teamwork: Throw Down | Aura-reveal behavior and range/details around the stun/blind trigger | Refines SWF package value |
| Medium | Slippery Meat + No One Left Behind/Babysitter | Practical Haste stacking under Diminishing Returns and Hex: Under Your Thumb; rescue-time conversion in endgame | Decides whether reopened package ceiling deserves a stronger archetype grade/global rerank |
| Low | Open-Handed + Small Game / Windows / Dark Sense | Which Survivor-centered Aura ranges actually extend | Synergy text only unless effect is unexpectedly large |

## Change-control rule

Do not edit `survivor-mechanics.json` in place. A confirmed behavior change becomes a new mechanics revision with a changelog, then editorial is revalidated against it.
