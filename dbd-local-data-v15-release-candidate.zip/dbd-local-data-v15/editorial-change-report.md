# Survivor Editorial v15 - Final Change Summary

## What v15 changes from v14

- Replaces the v14 ranking with the latest defended 1–176 order, including the precision challenge's Road Life #65 correction.
- Preserves publication by the exact 10 v14 perk IDs instead of rank position.
- Uses frozen live-10.2 mechanics as a separate authority layer.
- Replaces 109 free-form role labels with a controlled 22-role vocabulary plus detailed tags.
- Re-rates all 176 Solo Q/SWF values on an explicit absolute 1–5 scale. 137 ratings changed from v14.
- Separates global rank from specialized package ceilings with `archetypeRatings`.
- Converts perk synergies to stable IDs and adds explicit anti-synergies.
- Deprecates editable `metaStatus`; v15 derives it from tier.
- Rewrites the known stale 10.2 editorial fields and removes the obsolete Stake Out/Hyperfocus family of relationships.
- Keeps uncertain mechanics and post-patch performance questions visible through `rankStatus`, `rankRange`, `rankConfidence`, `evidenceStatus`, and the controlled-testing backlog.

## Important provisional/reopened calls

- Road Life: #65 B, provisional, wide #45–95 range.
- Dark Sense: #40 A boundary, provisional.
- Spine Chill: #47 B, provisional.
- Do No Harm: #56 B, controlled-testing dependent.
- Boon: Illumination: #142 C globally, much higher Steadfast-relocation package ceiling.
- Slippery Meat: #161 D globally, **reopened** for coordinated endgame-rescue package value after later live gameplay evidence.

## Publication rule

The website/publication layer must use `publication.publishedPerkIds` or each record's `publicationStatus`. It must never infer published state from rank.
