# Dead by Daylight Survivor Local Data v15 - Release Candidate

This package is the editorial v15 release candidate for live patch 10.2.0.

Files:
- `survivor-mechanics.json` - frozen factual mechanics authority.
- `survivor-editorial.json` - 176-record editorial/ranking layer.
- `glossary.json` - glossary carried forward from v14.
- `validation-report.json` - structural and fidelity validation.
- `implementation-fidelity-audit.md` - implementation check against the original publication blockers.
- `editorial-change-report.md` - major v14 -> v15 changes.
- `controlled-testing-backlog.md` - unresolved questions intentionally quarantined from facts.
- `survivor-editorial-v15.schema.json` - editorial validation schema.

Nothing in this package changes the website automatically. Publication identity remains the same ten perk IDs that were live in v14 until explicitly changed.
