# Killer Meta Research

This folder contains the canonical Killer Meta research pipeline for **Dead by Daylight**, organized by live patch baseline and research revision.

## Current Baseline

**Patch:** 10.2.0  
**Research Revision:** 10.2.0-r1  
**Research Cutoff:** October 7, 2026  
**Side:** Killer

The Killer Meta project is designed to identify, classify, rank, preserve, and publish Killer strategies separately from individual Killer character strength.

It treats Killer strategy as a persistent match-plan identity rather than reducing the meta to either:

- the strongest Killer characters
- the strongest perks
- one exact four-perk build
- isolated tactics
- add-on combinations without a broader strategic plan

The project preserves both current competitive evaluations and historical strategy evolution without overwriting prior research.

---

# Current Folder Structure

```text
killer-meta
├── README.md
└── 10.2.0-r1
    ├── archives
    ├── k0
    ├── k1
    ├── k2
    ├── k3a
    └── k3b
```

The `archives` folder contains frozen release packages for the structured and publication stages.

---

# Research Pipeline

The Killer Meta research process currently contains **five major stages**:

```text
K0
Research Design, Ontology, and Ranking Environment Audit

        ↓

K1
Comprehensive Discovery and Taxonomy

        ↓

K2
Adversarial Verification, Classification Resolution, and Ranking

        ↓

K3A
Canonical Database and Final Rankings

        ↓

K3B
Strategy Encyclopedia and Publication Layer
```

Each stage serves a different purpose.

K0 defines the research system.

K1 discovers the strategic ecosystem.

K2 challenges, resolves, and ranks that ecosystem.

K3A freezes the resulting canonical structured database.

K3B transforms that canonical database into publication-ready encyclopedia content.

---

## Stage K0: Research Design, Ontology, and Ranking Environment Audit

K0 establishes the research architecture used by the Killer Meta project before full strategy discovery begins.

The current K0 artifact is:

```text
stage-k0-research-design-ontology-ranking-environment-audit.md
```

K0 defines the conceptual boundaries required for later research to remain internally consistent.

Its purpose includes defining:

- what qualifies as a Killer Strategy
- what should instead be classified as a Tactic
- how Killer character strength differs from Strategy strength
- persistent Strategy identity
- StrategyPatchSnapshot architecture
- BuildImplementation architecture
- Parent Strategy Families
- Strategic Modules
- Mechanic-Centered Builds
- applicability scope
- Killer-specific compatibility
- ranking environments
- Killer-specific Power-model requirements
- Meta Stability
- strategic diagnostics
- dependency types
- Killer Power dependencies
- add-on dependencies
- Survivor-composition dependencies
- target-state dependencies
- add-on influence on Strategy identity
- offering and map considerations
- Legacy preservation
- future patch and historical-snapshot behavior

K0 does not attempt to discover or rank the complete live Strategy ecosystem.

Instead, it establishes the rules that later stages use when deciding what a Strategy is and how it should be represented.

### Killer Character Strength vs Strategy Strength

K0 establishes that Killer character strength and Killer Strategy strength are separate concepts.

A strong Killer can execute a weak Strategy.

A weaker Killer may have unusually strong compatibility with a particular Strategy.

The project should therefore preserve separate concepts for:

```text
Killer Character Strength
Killer Strategy Strength
```

They may be linked, but should not be collapsed into a single score.

### Strategy vs Tactic

K0 also establishes the distinction between a persistent Strategy and a local Tactic.

A Strategy represents a recognizable match plan affecting several areas of decision-making over meaningful portions of a Trial.

A Tactic represents a more local maneuver or decision that may support several Strategies.

This distinction becomes important during K1 discovery and K2 classification resolution.

### Ranking Environments

K0 defines two Killer ranking environments:

```text
KILLER_GENERAL_MATCHMAKING
KILLER_VS_COORDINATED_SWF
```

These environments allow a Strategy to be evaluated differently against ordinary matchmaking and organized Survivor teams.

### Shared Meta Architecture

K0 aligns Killer Meta with the broader persistent research structure:

```text
Strategy
→ StrategyPatchSnapshot
→ BuildImplementation
```

This architecture is intended to support long-term patch history without forcing a new Strategy identity every time perks, add-ons, or representative builds change.

---

## Stage K1: Comprehensive Discovery and Taxonomy

K1 performs broad discovery of the Killer strategy ecosystem.

Its purpose is to identify and distinguish:

- major current strategies
- parent strategy families
- meta subtypes
- strategic modules
- mechanic-centered builds
- niche strategies
- Killer-specific strategies
- tactics
- historical or Legacy strategies
- emerging strategic frameworks

K1 is intentionally high-recall.

The goal is to capture meaningful strategic identities before aggressive ranking or consolidation removes useful distinctions.

K1 also establishes preliminary relationships among:

- Killer Powers
- perks
- add-ons
- target-selection patterns
- hook pressure
- generator pressure
- injury pressure
- map control
- chase conversion
- mobility
- resource denial
- snowball potential

K1 does not treat every recurring gameplay action as an independent Strategy.

Some concepts are later moved into the separate Tactic layer.

---

## Stage K2: Adversarial Verification, Classification Resolution, and Ranking

K2 challenges the K1 catalog.

Its purpose is to determine which discovered concepts truly qualify as independent Killer strategies and which should instead be:

- merged
- reclassified
- treated as Parent Strategy Families
- treated as Strategic Modules
- moved to the Tactic layer
- marked Legacy
- split into multiple canonical concepts

K2 also performs competitive evaluation.

Strategies are evaluated independently in two environments:

```text
KILLER_GENERAL_MATCHMAKING
KILLER_VS_COORDINATED_SWF
```

K2 evaluates factors such as:

- current Power
- Tier
- Consistency
- Ceiling
- Agency
- Power Integration
- Matchup Coverage
- Map Coverage
- Tempo Efficiency
- Slot Efficiency
- Recovery
- Snowball
- Counterplay Resilience
- Execution Reliability
- Meta Stability
- evidence confidence
- prevalence
- compatibility
- add-on influence
- representative implementations

K2 is the analytical authority for the competitive conclusions later canonicalized in K3A.

---

## Stage K3A: Canonical Database and Final Rankings

K3A converts the verified K1/K2 research into the canonical machine-readable Killer Meta database.

K3A is the authoritative structured research layer.

The current 10.2.0-r1 K3A release contains:

- **71 Strategy-layer objects**
- **24 current independent Strategies**
- **4 Parent Strategy Families**
- **30 current Strategic Modules**
- **7 current Mechanic-Centered Builds**
- **6 Legacy objects**
- **14 Tactics**
- **44 verified live-playable Killers**
- **85 total canonical objects**

Current independent Strategy ranking coverage:

- **20 RANKED**
- **3 PROVISIONAL**
- **1 UNRANKED**

K3A validation completed with:

- **34 checks passed**
- **0 failed checks**
- **0 warnings**

No Power, Tier, Stability, or Ranking Index corrections were required during K3A canonicalization.

---

# Canonical K3A Files

The K3A folder contains:

```text
canonicalization-map.json
killer-characters.json
killer-meta-methodology.json
killer-strategies.json
killer-strategy-snapshots.json
killer-tactics.json
stage-k3a-report.md
validation.json
```

## killer-characters.json

Defines canonical Killer identities separately from Strategy identities.

Killer character strength should not be confused with Killer Strategy strength.

## killer-strategies.json

Contains persistent Strategy-layer identities.

Canonical Strategy IDs use the form:

```text
KSTR-001
KSTR-002
...
KSTR-071
```

IDs do not encode:

- Power
- Tier
- status
- ranking
- classification

## killer-strategy-snapshots.json

Contains patch-specific evaluations of Strategy-layer objects.

Snapshots may include:

- environment-specific rankings
- Power
- Tier
- Ranking Status
- Meta Stability
- Stability components
- current status
- trend
- confidence
- dependencies
- compatibility
- representative implementations
- research debt

## killer-tactics.json

Contains tactical gameplay concepts intentionally separated from Strategy rankings.

Canonical Tactic IDs use the form:

```text
KTAC-001
KTAC-002
...
KTAC-014
```

Tactics do not receive:

- Power
- Tier
- Ranking Index
- Meta Stability

unless the research model is explicitly changed in a future revision.

## killer-meta-methodology.json

Defines the methodology and scoring framework used by the canonical Killer Meta system.

## canonicalization-map.json

Maps earlier K1/K2 research identities into persistent K3A canonical IDs and records normalization decisions.

---

# Strategy vs Tactic

The Killer Meta project deliberately separates Strategies from Tactics.

## Strategy

A Strategy represents a persistent match plan that meaningfully affects several areas of Killer decision-making over the course of a Trial.

Examples of affected decisions may include:

- target selection
- chase persistence
- hook sequencing
- generator prioritization
- injury distribution
- map movement
- resource management
- Killer Power usage
- pressure conversion
- snowball creation

## Tactic

A Tactic is a more local maneuver or decision.

Examples may include:

- leaving a chase
- returning to hook
- temporary slugging
- defending a critical generator
- delaying pickup
- forcing a trade
- bodyblocking an escape route
- zoning a Survivor

Tactics may support multiple Strategies without becoming independent ranked Strategies themselves.

---

# Structural Classification

Current Killer Strategy-layer classifications include:

```text
META
META SUBTYPE
PARENT STRATEGY FAMILY
STRATEGIC MODULE
NICHE STRATEGY
MECHANIC-CENTERED BUILD
```

Classification describes what kind of strategic object something is.

It does not directly determine competitive strength.

---

# Parent Strategy Families

Parent Strategy Families organize related strategic concepts that are too internally diverse to receive one honest aggregate score.

The current canonical database contains:

**4 Parent Strategy Families**

Parent Families use:

```text
NOT_APPLICABLE
```

for ranking environments rather than receiving fabricated aggregate Power or Tier values.

Their child strategies are evaluated independently.

---

# Strategic Modules

Strategic Modules are reusable pressure or utility components that support broader match plans.

The current canonical database contains:

**30 current Strategic Modules**

Modules are published and preserved but generally do not receive independent Power or Tier values.

A Strategic Module may still be highly important to the meta even when it is not independently rankable.

---

# Mechanic-Centered Builds

Mechanic-Centered Builds represent recognizable frameworks organized around a particular mechanic, perk interaction, Power behavior, or resource system.

The current canonical database contains:

**7 current Mechanic-Centered Builds**

These remain strategic frameworks or support objects.

They should not be converted into fabricated four-perk builds merely to fill a page.

---

# Legacy Strategies

Legacy objects preserve historically meaningful Killer strategies or implementations whose defining competitive form is no longer current.

The current canonical release contains:

**6 Legacy objects**

Legacy entries remain in the encyclopedia for:

- historical explanation
- terminology continuity
- patch comparison
- strategy evolution
- interpretation of older guides and discussions

Legacy entries use:

```text
NOT_CURRENT
```

and do not participate in current tier lists.

Legacy does not mean deleted.

---

# Ranking Environments

Current Killer strategies are evaluated independently for:

## General Matchmaking

```text
KILLER_GENERAL_MATCHMAKING
```

Represents ordinary live matchmaking conditions across the broader Survivor population.

## Coordinated SWF

```text
KILLER_VS_COORDINATED_SWF
```

Represents organized Survivor teams capable of stronger communication, information sharing, role coordination, and strategic response.

A Strategy may receive different:

- Power
- Tier
- Ranking Status
- confidence

in each environment.

---

# Ranking Status

Supported ranking states are:

```text
RANKED
PROVISIONAL
UNRANKED
NOT_APPLICABLE
NOT_CURRENT
```

## RANKED

Enough evidence exists for a defensible current competitive placement.

## PROVISIONAL

A numerical estimate is defensible, but meaningful research uncertainty remains.

Provisional Strategies retain their current estimated Power and Tier.

## UNRANKED

The Strategy is current and strategically meaningful, but the evidence does not justify assigning a responsible Power or Tier.

The current 10.2.0-r1 release contains one current independent UNRANKED Strategy:

**Active Hex Defense**

Its Power and Tier remain null.

## NOT_APPLICABLE

Used when an independent competitive score is conceptually inappropriate.

Examples include:

- Parent Strategy Families
- Strategic Modules
- Mechanic-Centered Builds

## NOT_CURRENT

Used for Legacy objects.

---

# Killer Power Model

The current Killer competitive model is versioned as:

```text
KILLER_POWER_V1
```

The model evaluates Killer Strategy strength using dimensions including:

- Consistency
- Ceiling
- Agency
- Power Integration
- Matchup Coverage
- Map Coverage
- Tempo Efficiency
- Slot Efficiency
- Recovery
- Snowball
- Counterplay Resilience
- Execution Reliability

The KILLER_POWER_V1 weights sum to 100.

Power measures the current strength of the Strategy.

It does not measure Killer character tier.

---

# Killer Character Strength vs Strategy Strength

Killer character strength and Killer Strategy strength are deliberately separate.

A powerful Killer can execute a weaker Strategy.

A lower-tier Killer may have exceptional compatibility with a specific Strategy.

The project should therefore maintain separate concepts for:

```text
Killer Character Strength
Killer Strategy Strength
```

They may be linked, but should not be collapsed into a single score.

---

# Applicability Scope

Killer Strategies may describe how broadly they apply across the roster.

Possible scopes include:

```text
BROAD_ROSTER
POWER_FAMILY
KILLER_SPECIFIC
```

## BROAD_ROSTER

Usable by a broad portion of the Killer roster.

## POWER_FAMILY

Primarily applicable to Killers sharing related Power characteristics.

## KILLER_SPECIFIC

Meaningfully dependent on one Killer's unique Power or mechanics.

Applicability does not determine Power.

A Killer-specific Strategy can still be extremely strong.

---

# Killer Compatibility

K3A may preserve evaluated Killer-to-Strategy compatibility.

Compatibility should be interpreted only where explicitly researched.

Absence of a compatibility record means:

```text
NOT_EVALUATED
```

It does not automatically mean incompatible.

The canonical validation confirms all Killer compatibility references resolve correctly.

---

# Representative Implementations

Some Strategies contain canonical representative implementations.

A Killer implementation may reference:

- Killer
- perks
- add-ons
- environment
- build rationale
- confidence

Not every Strategy has a canonical build.

This is intentional.

A missing build means the research did not establish one strongly enough to canonize.

Do not invent perk or add-on packages merely to make every Strategy page visually complete.

---

# Strategy Identity

A Killer Strategy is not defined by one exact four-perk loadout.

A persistent Strategy represents a broader strategic plan.

Perks, add-ons, and Killer choice may change while the underlying Strategy remains recognizable.

A different loadout does not automatically require a new Strategy ID.

A new Strategy identity should generally be created only when the underlying match plan materially changes.

---

# Meta Stability

Meta Stability is separate from current Power.

Power answers:

> How strong is this Strategy right now?

Meta Stability answers:

> How structurally likely is this Strategy to remain relevant through reasonable balance changes and surrounding meta shifts?

Meta Stability preserves dimensions such as:

- Structural Independence
- Core Mechanic Durability
- Replacement Depth
- Environmental Breadth
- Counter-Meta Independence
- Patch Durability

High Stability does not automatically mean high current Power.

Current Tier remains based on current Power.

---

# Stage K3B: Strategy Encyclopedia and Publication Layer

K3B projects the frozen K3A canonical database into player-facing publication content.

K3B performs:

- no new gameplay research
- no reranking
- no rescoring
- no ontology changes

K3B is downstream of K3A.

K3A remains the structured research authority.

The current K3B publication contains:

- **71 Strategy-layer pages**
- **24 current independent Strategy pages**
- **4 Parent Family pages**
- **30 Strategic Module pages**
- **7 Mechanic-Centered Build pages**
- **6 Legacy pages**
- **14 Tactic pages**
- **6 index/methodology pages**
- **85 total canonical publication-object pages**

K3B validation reports:

- **PASS**
- **0 errors**
- **0 warnings**
- **71/71 Strategy pages generated**
- **14/14 Tactic pages generated**
- **85/85 publication objects represented**

---

# K3B Encyclopedia Structure

The publication layer contains:

```text
killer-strategy-encyclopedia
├── README.md
├── stage-k3b-report.md
├── data
│   ├── publication-issues.json
│   └── publication-manifest.json
├── indexes
│   ├── killer-compatibility.md
│   ├── killer-strategies.md
│   ├── killer-tactics.md
│   ├── legacy.md
│   ├── methodology.md
│   └── strategy-families.md
├── strategies
│   └── 71 Strategy-layer pages
└── tactics
    └── 14 Tactic pages
```

The publication manifest is the authoritative K3B routing/index record for player-facing pages.

---

# Known Publication Issues

The frozen 10.2.0-r1 publication layer records two low-severity downstream issues.

## KSTR-057

**Axe-Impale Attrition Module**

Canonical `relatedStrategyIds` contains a self-reference.

K3B suppresses the self-link in rendered Related Strategies while leaving frozen K3A unchanged.

## KSTR-058

**Security-Door Rotation / Ambush Module**

Canonical `relatedStrategyIds` contains a self-reference.

K3B suppresses the self-link in rendered Related Strategies while leaving frozen K3A unchanged.

These are publication rendering issues, not gameplay ranking failures.

Recommended handling:

- preserve 10.2.0-r1 unchanged
- remove the self-references only if the canonical database is reopened in a future research revision

Do not silently edit the frozen K3A release.

---

# Historical Preservation

Research releases are patch-versioned and revision-versioned.

Do not overwrite completed historical baselines when the game changes.

Future examples might look like:

```text
killer-meta
├── 10.2.0-r1
├── 10.3.0-r1
└── 10.3.0-r2
```

A Strategy may retain its canonical identity across patches while its:

- Power
- Tier
- Status
- Trend
- Stability
- compatibility
- prevalence
- implementation
- perks
- add-ons
- counters
- evidence confidence

change over time.

Historical StrategyPatchSnapshots should remain available for comparison.

---

# Revision Policy

Completed research releases should be treated as frozen.

Do not silently modify historical artifacts.

If a correction is needed:

1. create a new research revision
2. document the change
3. preserve the previous revision
4. record what the new revision supersedes

Example:

```text
10.2.0-r1
10.2.0-r2
```

Historical reproducibility is more important than cosmetically rewriting an old release.

---

# Frozen Archives

The `archives` folder contains frozen release packages associated with the current research baseline.

Current archived packages include:

```text
dead-by-daylight-killer-meta-k3a-10.2.0-r1.zip
dbd-killer-meta-stage3b-10.2.0-r1.zip
```

These packages act as release artifacts for their respective stages.

The extracted directories are kept for:

- review
- searching
- Git diffs
- automated ingestion
- website generation

The ZIP files preserve the frozen release artifact.

---

# Source Provenance

The K3A validation record preserves an important provenance warning.

The supplied K2 handoff JSON identifies itself as:

```text
RECONSTRUCTED_FROM_REPORT_NOT_ORIGINAL
```

The original external K2 handoff artifact was not recovered.

K3A preserves this provenance rather than falsely representing the reconstructed ledger as the original external artifact.

The supplied structured handoff was treated as the primary K2 handoff source, cross-checked against the available K2 report and workbook.

No competing analytical values were introduced during K3A canonicalization.

---

# Canonicalization

K3A converts research Candidate IDs into persistent canonical identities.

Canonical Strategy IDs:

```text
KSTR-001 through KSTR-071
```

Canonical Tactic IDs:

```text
KTAC-001 through KTAC-014
```

Canonical Killer IDs:

```text
KILL-001 through KILL-044
```

Earlier research Candidate IDs remain provenance only.

Canonical IDs should remain stable across future patches whenever strategic identity remains continuous.

---

# Animatronic Split

One K2 source object was intentionally split during K3A canonicalization.

The source concept:

```text
Axe-Impale + Security-Door Modules
```

was normalized into:

```text
KSTR-057
Axe-Impale Attrition Module

KSTR-058
Security-Door Rotation / Ambush Module
```

K2 explicitly determined that these mechanics were separable.

The split creates two support-level modules without changing the locked competitive Strategy universe or Power conclusions.

---

# Website Use

The future Killer Meta website should consume:

## K3A

For:

- canonical identities
- rankings
- Power
- Tier
- Status
- Stability
- compatibility
- relationships
- Killer references
- representative implementations
- historical patch snapshots

## K3B

For:

- encyclopedia prose
- player-facing explanations
- index pages
- Strategy pages
- Tactic pages
- methodology presentation
- publication navigation

The website presentation layer may create controlled UI filters and derived display fields.

It should not rewrite K3A merely for UI convenience.

The intended hierarchy is:

```text
RESEARCH TRUTH
K3A Canonical Database

        ↓

PUBLICATION TRUTH
K3B Encyclopedia

        ↓

SITE PRESENTATION
Runtime Data
Filters
Search
Navigation
UI
```

Downstream layers must not silently override upstream research.

---

# Relationship to Survivor Meta

Survivor Meta and Killer Meta remain separate competitive systems.

They may share a broader technical architecture such as:

```text
Strategy
→ StrategyPatchSnapshot
→ BuildImplementation
```

They may also share concepts such as:

- Ranking Status
- Meta Stability
- confidence
- dependencies
- historical snapshots
- persistent Strategy identity

However, Survivor and Killer use different competitive environments and side-specific Power models.

Survivor and Killer rankings should never be merged into one combined tier list.

---

# Future Updates

When a new Dead by Daylight patch releases:

1. identify materially affected Killer Strategies
2. identify affected Killer characters, Powers, perks, and add-ons
3. determine whether each Strategy requires:
   - no update
   - targeted update
   - full re-research
4. preserve canonical Strategy identity where the strategic plan remains intact
5. create new patch-specific snapshots where required
6. re-evaluate affected Power, Tier, Stability, compatibility, trend, and implementations
7. preserve previous snapshots
8. regenerate current rankings
9. regenerate publication pages where necessary

Not every patch requires every Strategy to be re-researched.

The goal is to maintain a living Killer Strategy database rather than rebuilding the entire system from zero after every patch.

---

# Core Principle

The Killer Meta project is intended to answer two different questions.

The ranking system answers:

> What Killer strategies are strongest right now?

The encyclopedia answers:

> What is this Strategy, how does it work, which Killers can use it, what does it require, what does it counter, what counters it, how stable is it, and how does its value change against coordinated Survivors?

Both should ultimately derive from the same canonical research system.

Killer Meta is therefore not merely a tier list.

It is a versioned, historical **Killer Strategy Encyclopedia and competitive research database**.