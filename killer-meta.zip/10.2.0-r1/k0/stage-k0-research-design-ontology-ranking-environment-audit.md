# DEAD BY DAYLIGHT KILLER META
# STAGE K0 — RESEARCH DESIGN, ONTOLOGY, AND RANKING ENVIRONMENT AUDIT

You are designing the research architecture for a comprehensive **Dead by Daylight Killer Meta** project.

This stage occurs **before Killer strategy discovery, ranking, canonicalization, or publication**.

Its purpose is to define:

- what counts as a Killer Strategy
- what does not count as a Strategy
- how Killer character strength must be separated from Strategy strength
- which ranking environments should exist
- which parts of the Survivor Meta architecture can be reused
- which parts require Killer-specific interpretation
- how Killer-specific strategies, Power families, add-ons, tactics, maps, and compatibility should be represented
- which analytical dimensions later stages should evaluate
- what methodological risks must be controlled before discovery begins

This stage does **not**:

- discover the current Killer meta
- produce a Killer tier list
- rank strategies
- score strategies
- decide which current strategies are strongest
- build the canonical database
- produce website pages

Its purpose is:

> **Define the rules of the Killer Meta research before the research begins.**

---

# CORE ARCHITECTURAL DECISION

Reuse the successful Survivor persistence architecture:

```text
Strategy
→ StrategyPatchSnapshot[]
→ BuildImplementation[]
```

Do **not** reuse the Survivor ontology verbatim.

Killer strategy introduces a major complication:

> **The Killer character and native Power are major causal inputs into whether a strategy works.**

Therefore:

```text
KillerCharacter ≠ Strategy
```

They must be separate canonical concepts.

---

# PRIMARY RESEARCH RISK

The largest Killer-specific methodological risk is:

> **Conflating Killer character strength with Strategy strength.**

False reasoning example:

> Strategy X performs extremely well on a top Killer.  
> Therefore Strategy X is S-tier.

The real explanation may be:

> The Killer character is extremely strong and can make a mediocre Strategy perform well.

The inverse error also exists:

> Strategy Y performs badly when used on Killers poorly suited to it.  
> Therefore Strategy Y is weak.

That may simply mean the tested Killers are incompatible with the Strategy.

## Required guardrails

1. Separate `KillerCharacter` and `Strategy`.
2. Never average a Strategy across obviously incompatible Killers.
3. Declare a Strategy's applicability scope.
4. Evaluate Strategy Power conditional on appropriate Killer fit.
5. Store compatibility separately from Strategy Power.
6. Control for Killer identity when interpreting outcome evidence.
7. Keep Killer-character tier lists completely separate from Strategy tier lists.

If this distinction fails, later rankings become unreliable.

---

# KILLER CHARACTER

A **Killer Character** is the playable Killer and its native Power.

It is not a Strategy.

Minimum identity required for this project:

```text
KillerCharacter
- killerId
- name
- powerName
```

Additional character-strength analysis belongs in a separate research stream.

Do not create a Killer-character tier list as part of the Killer Strategy project.

---

# KILLER STRATEGY DEFINITION

A canonical Killer Strategy requires a **persistent gameplay plan**.

It should materially influence several of the following:

- target selection
- chase selection
- chase abandonment
- chase persistence
- hook decisions
- generator pressure
- injury management
- down-state management
- map movement
- territorial investment
- resource allocation
- native Power usage
- perk choices
- add-on choices
- how pressure converts into downs, hooks, eliminations, or objective delay

Use this diagnostic test:

> **If all perk and add-on names were removed, would an experienced player still recognize a distinct way of playing the match?**

If yes, the object may qualify as a Strategy.

If the description collapses to:

> Equip these four perks.

it probably does not.

---

# STRATEGIC OBJECT TYPES

## 1. Strategy

A persistent gameplay plan with its own meaningful objective, decision loop, resource pattern, and payoff structure.

---

## 2. Parent Strategy Family

A broad strategic objective containing children whose actual gameplay differs substantially.

A Parent Family can organize the Strategy Encyclopedia without receiving one aggregate Power score.

Examples may emerge around concepts such as:

- generator control
- hook-zone pressure
- territorial control
- target-focus sequencing

Do not assume any example is a Parent Family before discovery verifies it.

---

## 3. Meta Subtype

A recurring branch of a broader Strategy that:

- preserves the parent's strategic objective
- materially changes decisions or implementation
- has sufficiently distinct counterplay or execution

Replacing one perk with another is not enough.

---

## 4. Strategic Module

A reusable strategic component that can attach to multiple Strategies.

A Module affects an important part of gameplay but does not independently define the entire match plan.

Potential examples may include:

- information packages
- healing suppression
- generator blocking
- hook-state manipulation
- chase optimization

K1 must determine actual classifications.

---

## 5. Mechanic-Centered Build

A recognizable build ecosystem centered around one mechanic but lacking sufficient independent strategic identity.

Possible examples include:

- Hex shells
- Scourge Hook packages
- skill-check pressure
- carry optimization
- mechanic-specific perk frameworks

A recognizable build is not automatically a Strategy.

---

## 6. Niche Strategy

A legitimate independent Strategy whose viability is constrained by one or more of:

- specific Killer
- Power family
- map
- add-on
- Survivor behavior
- narrow matchup
- heavy opportunity cost
- low prevalence
- restrictive activation state

`NICHE` describes breadth, not validity or weakness.

---

## 7. Tactic

A **Tactic** is a local decision or maneuver.

Examples conceptually include:

- temporary slug
- leaving chase
- returning to hook
- forcing a trade
- bodyblocking a route
- defending one critical generator
- delaying pickup
- switching targets on contact

Using a tactic does not prove that a persistent Strategy exists.

Tactics should eventually live in a separate glossary/tactic layer.

They do not receive independent Strategy Power.

---

## 8. General Match Principle

Broad advice such as:

- leave inefficient chases
- pressure multiple Survivors
- protect important resources
- avoid wasting time

is generally a **principle**, not a Strategy.

Principles belong in educational content rather than the canonical Strategy catalog.

---

# KILLER-SPECIFIC SCOPE

Do **not** create a structural classification named:

```text
KILLER_SPECIFIC_STRATEGY
```

Instead use:

```text
applicabilityScope
```

with:

```text
BROAD_ROSTER
POWER_FAMILY
KILLER_SPECIFIC
```

Scope and structural classification answer different questions.

A Killer-specific object may still structurally be:

```text
META SUBTYPE
NICHE STRATEGY
STRATEGIC MODULE
MECHANIC-CENTERED BUILD
```

A Strategy should not be penalized merely because only one Killer can perform it.

---

# STRATEGIC ORIENTATION

Support an optional analytical field:

```text
strategicOrientation
```

Values:

```text
TEMPO
CONTROL
HYBRID
```

## TEMPO

Primarily converts current pressure rapidly into:

- hits
- downs
- hooks
- eliminations
- chained pressure

## CONTROL

Primarily restricts Survivor:

- objective progress
- movement
- healing
- resources
- territory
- safe choices

## HYBRID

Meaningful use of both.

This is an analytical orientation, not a structural classification.

---

# CANONICAL RANKING ENVIRONMENTS

Use exactly two primary Killer Strategy ranking environments.

---

## `KILLER_GENERAL_MATCHMAKING`

Represents normal live public matchmaking against the mixed Survivor population a Killer reasonably encounters.

This may include:

- Solo Q players
- duos
- trios
- casual four-person SWFs
- mixed skill levels
- mixed coordination levels

It does **not** mean:

> four isolated average Solo Q Survivors.

It represents:

> **practical public-queue expected strategic value.**

Research should acknowledge uncertainty where lobby composition materially affects results.

---

## `KILLER_VS_COORDINATED_SWF`

Represents four competent communicating Survivors playing under normal live rules.

Assume:

- competent callouts
- shared Killer-location information
- deliberate generator distribution
- coordinated rescue timing
- coordinated bodyblocks/saves
- role awareness
- team-aware healing decisions
- target-state communication
- deliberate perk/item coordination

Do **not** assume professional tournament execution.

This environment asks:

> **How well does the Strategy survive when Survivors competently exploit communication and coordination?**

---

# COMPETITIVE PLAY

Competitive DBD is a **secondary analytical lens**, not a third canonical ranking environment.

Competitive evidence can inform:

- strategy ceiling
- optimized execution
- counterplay
- matchup-specific insight
- proof that a Strategy can survive high-level opposition

But tournaments may impose:

- perk restrictions
- add-on restrictions
- Killer restrictions
- map pools
- custom scoring
- repeated matchup formats

Therefore competitive evidence should not automatically determine normal live-game Power.

Treat it as:

> **high-skill evidence**

rather than:

> **a direct model of normal matchmaking.**

---

# ENVIRONMENT DATA MODEL

Use generic:

```text
environmentEvaluations[]
```

rather than side-specific hardcoded fields.

Example conceptually:

```json
{
  "environmentId": "KILLER_GENERAL_MATCHMAKING",
  "rankingStatus": "RANKED",
  "power": 80,
  "tier": "A",
  "confidence": "MEDIUM"
}
```

This allows Survivor and Killer to share one persistence architecture while using different environment identities.

---

# SHARED STRATEGY FIELDS

Reuse shared side-neutral concepts such as:

```text
id
side
name
aliases
structuralClassification
currentStatus
trend
rankingStatus

metaStability

winConditionContribution
activationReliability
activationPayoff
denialRisk
strategicCommitment

skillFloor
skillCeiling
consistency
ceiling
matchupCoverage
mapCoverage
tempoEfficiency
slotEfficiency
recoveryValue
snowballValue
counterplayResilience
executionReliability

opportunityCost
mapDependence

prevalence

dependencies
synergies
counters

researchFlags
recheckConditions
```

---

# STRATEGIC COMMITMENT

Rename the shared Survivor-era concept:

```text
roleCommitment
```

to:

```text
strategicCommitment
```

For Killer this measures how strongly adopting the Strategy constrains:

- target selection
- chase persistence
- hook decisions
- patrol routes
- native Power usage
- slug/pickup decisions
- generator defense
- perk/add-on allocation

Higher means greater strategic commitment.

---

# STRATEGIC DIAGNOSTICS

Retain the shared 1–5 diagnostics:

```text
Win Condition Contribution
Activation Reliability
Activation Payoff
Denial Risk
Strategic Commitment
```

## Win Condition Contribution

For Killer:

> How directly successful execution advances elimination or materially prevents Survivor objective completion.

Possible value includes:

- downs
- hooks
- eliminations
- meaningful generator delay
- Survivor incapacitation
- health/resource depletion
- territorial restriction

Do not define Killer victory only through hooks.

---

## Activation Reliability

> How consistently can the Killer create or access the state required by the Strategy?

This distinguishes Killer-created activation from plans that depend heavily on Survivor choices.

---

## Activation Payoff

> Once successfully activated, how much strategic value does the plan create?

---

## Denial Risk

> How easily can competent Survivors deny the state or interaction the Strategy requires?

Higher is worse.

Possible denial methods include:

- pre-running
- refusing chase
- splitting generators
- refusing unnecessary heals
- avoiding prepared territory
- denying trades
- avoiding Totem interactions
- denying pickup windows
- changing target availability

---

# KILLER DEPENDENCIES

Reuse shared dependency types:

```text
OPPONENT_BEHAVIOR
MAP
RNG
GAME_STATE
POSITIONING
TIMING
RESOURCE_AVAILABILITY
```

Add:

```text
KILLER_POWER
ADD_ON
SURVIVOR_COMPOSITION
TARGET_STATE
```

Do not add separate general dependency enums for every map feature.

Use:

```text
mapFactors[]
```

for details such as:

- line-of-sight structure
- tile geometry
- generator clustering
- hook spacing
- Totem placement
- map size
- verticality
- setup space

---

# KILLER POWER MODEL

Do not reuse the Survivor Power dimensions unchanged.

Use the following Killer-specific dimensions:

1. **Consistency**
2. **Ceiling**
3. **Agency**
4. **Power Integration**
5. **Matchup Coverage**
6. **Map Coverage**
7. **Tempo Efficiency**
8. **Slot Efficiency**
9. **Recovery Value**
10. **Snowball Value**
11. **Counterplay Resilience**
12. **Execution Reliability**

---

## Consistency

How reliably the Strategy produces meaningful value across ordinary matches within its intended scope.

---

## Ceiling

Maximum realistic strategic value under excellent execution.

---

## Agency

How much the Killer can create the Strategy's required states rather than waiting for Survivor cooperation.

High Agency means the Killer controls activation.

Low Agency may depend on Survivors:

- grouping
- healing
- entering a region
- trading
- interacting with a side objective
- giving favorable chase states

---

## Power Integration

How naturally the Strategy works with the native Power of compatible Killers.

This is evaluated **inside the declared applicability scope**.

It is **not raw Killer strength**.

A Killer-specific Strategy should not lose points merely because only one Killer can perform it.

---

## Matchup Coverage

How robustly the Strategy performs across different Survivor:

- plans
- builds
- healing policies
- rescue policies
- coordination patterns
- target responses

---

## Map Coverage

How robust the Strategy is across:

- map size
- geometry
- line of sight
- verticality
- generator spacing
- hook spacing
- setup structure

---

## Tempo Efficiency

How much meaningful pressure the Strategy generates relative to Killer time invested.

---

## Slot Efficiency

Value relative to commitment of:

- perk slots
- add-ons
- offerings
- Power resources

---

## Recovery Value

Ability to stabilize or recover after falling behind.

---

## Snowball Value

Ability to compound an advantage into additional:

- downs
- hooks
- eliminations
- objective collapse

Snowball is primarily a **Strategy dimension/outcome property**, not automatically a standalone Strategy.

---

## Counterplay Resilience

How difficult the Strategy is for competent Survivors to neutralize.

---

## Execution Reliability

How realistically the intended Strategy can be executed outside ideal theoretical conditions.

Distinguish this from Ceiling.

A Strategy can have:

- high Ceiling
- low Execution Reliability

---

# POWER MODEL WEIGHTS

K0 defines the dimensions.

Do **not** lock weights in K0.

Weights should be selected and locked in K2 after the actual Strategy universe is known.

This prevents the scoring model from being optimized around imagined Strategies rather than the discovered ecology.

---

# ROSTER APPLICABILITY

Track breadth separately through:

```text
applicabilityScope
```

and compatibility.

Do **not** directly reward roster breadth inside Power.

Otherwise:

> excellent Strategy unique to one Killer

would automatically score below:

> mediocre Strategy usable by everyone.

That is not a valid definition of strategic strength.

---

# KILLER COMPATIBILITY MODEL

Eventually support:

```text
BEST_FIT
STRONG_FIT
VIABLE
WEAK_FIT
INCOMPATIBLE
```

Use sparse evaluated relationships.

Example:

```json
{
  "killerId": "...",
  "fit": "STRONG_FIT",
  "confidence": "MEDIUM",
  "rationale": "..."
}
```

Do **not** build a complete Killer × Strategy matrix merely for completeness.

Absence means:

> **not evaluated**

not:

> **viable**.

Compatibility should remain separate from Strategy Power.

---

# STRATEGY POWER QUESTION

Later scoring should answer:

> **How strong is this Strategy when competently used on an appropriately compatible Killer, relative to plausible alternative ways that same Killer could play?**

Do not calculate:

> average effectiveness across every Killer.

That would artificially punish specialization and reward broad but mediocre Strategies.

---

# META STABILITY

Reuse the shared six-component 100-point framework:

```text
Structural Independence   0–25
Core Mechanic Durability  0–20
Replacement Depth         0–15
Environmental Breadth     0–15
Counter-Meta Independence 0–10
Patch Durability          0–15
```

---

## Structural Independence

Ask:

> Is the Strategy dependent on one fragile perk, add-on, exploit, or recently changed interaction?

Do **not** penalize a Killer-specific Strategy merely because it requires that Killer.

---

## Core Mechanic Durability

Ask whether the core gameplay loop rests on durable game structure or volatile implementation details.

---

## Replacement Depth

Consider replacements among:

- perks
- add-ons
- implementation variants
- target patterns
- Power usage

If one enabling component disappears and the Strategy collapses, Replacement Depth is low.

---

## Environmental Breadth

Evaluate within intended scope.

Consider:

- maps
- Survivor team compositions
- Survivor builds
- matchmaking environments
- common game states

---

## Counter-Meta Independence

Ask how much the Strategy's viability depends on a narrow current Survivor meta.

---

## Patch Durability

Consider sensitivity to:

- Power reworks
- add-on reworks
- perk changes
- hook-system changes
- generator-system changes
- interaction fixes

Add-on-dependent Strategies may have strong Power but low Stability.

---

# STABILITY IS NOT POWER

A Strategy may be:

- powerful but fragile
- weak but structurally durable

Do not combine these concepts conceptually.

Stability is also separate from evidence confidence.

---

# ADD-ONS

Killer add-ons require more formal treatment than Survivor add-ons.

## Rule 1: add-ons usually belong to BuildImplementation

Normally:

```text
Strategy
→ StrategyPatchSnapshot
→ BuildImplementation
   → add-ons
```

---

## Rule 2: an add-on may justify a subtype

An add-on may justify a subtype when it materially changes several of:

- strategic objective
- Power usage
- target choice
- chase pattern
- map pressure
- resource loop
- counterplay

A numerical enhancement alone is insufficient.

---

## Rule 3: a new Strategy identity is rare

Create a wholly separate Strategy only when the add-on creates a genuinely different match plan.

---

## Rule 4: dependence affects Stability

If viability collapses without one specific add-on, this may reduce:

- Structural Independence
- Replacement Depth
- Patch Durability

---

## Rule 5: resource burden is not raw strength

Add-on rarity or scarcity may affect practical General Matchmaking value.

Do not confuse scarcity with theoretical strategic ceiling.

---

# BUILD IMPLEMENTATION

Extend BuildImplementation for Killer-specific requirements.

Support fields such as:

```text
killerId
perkIds
addOnIds
offeringId
environmentId
skillTarget
buildType
rationale
confidence
contentValidity
```

For a concrete Killer build:

```text
killerId
```

should normally be required.

A deliberately abstract framework may omit it if clearly labeled.

---

# MAP DEPENDENCE

Map offerings belong primarily to BuildImplementation.

Strategy snapshots should still track:

```text
mapDependence
mapFactors
```

Possible map factors include:

- indoor/outdoor structure
- line of sight
- tile geometry
- generator clustering
- hook spacing
- Totem placement
- map size
- verticality
- setup space

Do not rank Strategies under an assumption of perfect favorable-map selection.

If competitiveness depends strongly on forcing favorable geometry, that should increase:

- Map Dependence
- Opportunity Cost
- variance concerns

and may support a Niche Strategy classification.

---

# OPEN ONTOLOGY QUESTIONS FOR K1

K0 should **not** resolve these.

K1 must investigate them empirically.

---

## Tunneling / Target Focus

Determine whether current play supports:

- one independent Strategy
- multiple target-focus subtypes
- a Module
- primarily tactics
- different classifications depending on commitment

A single return to a recently unhooked Survivor is not automatically equivalent to a persistent elimination-focused plan.

---

## Slugging

Distinguish among:

- temporary tactical slug
- tempo slug
- chain-down pressure
- sustained down-state control
- bleedout outcome

Do not assume all belong under one Strategy identity.

---

## Camping / Hook Pressure

Do not create one `Camping` record by default.

Test distinctions among:

- static close camp
- proxy pressure
- hook-zone control
- forced trades
- hook + nearby-objective anchor control

---

## Generator Control

Investigate whether this is:

- one Strategy
- a Parent Family
- several distinct Strategies
- modules plus Strategies

Split implementations when they materially change:

- travel patterns
- chase abandonment
- generator selection
- hook decisions
- perk structure
- resource economy

---

## Chase Optimization

Do not assume `Chase Build` is a Strategy.

Potential components may include:

- anti-loop
- pallet destruction
- vault control
- basic-attack enhancement
- Power-centered chase

These may be Modules or Mechanic-Centered Builds.

---

## Information

Default hypothesis:

> often a Module.

But allow an independent information-oriented Strategy to emerge if evidence demonstrates a persistent gameplay loop with its own costs and payoff structure.

---

## Anti-Heal

Determine whether anti-heal independently defines a full match plan or primarily enables another Strategy such as injury attrition.

---

## Hit-and-Run

Test whether systematic:

```text
injure
→ disengage
→ rotate
→ recontact
```

constitutes a persistent independent Strategy.

---

## Stealth / Ambush

Stealth itself may simply be a Power property.

Determine whether there is a recurring strategic loop sufficiently distinct to qualify as an Ambush Strategy.

---

## Territorial Control

Determine whether prepared zones, trap networks, teleport nodes, and local control form:

- one Parent Family
- multiple Strategies
- Killer-specific implementations
- overlapping modules

---

## Mobility

Mobility itself is not automatically a Strategy.

A mobility-based Strategy should require mobility to systematically alter:

- chase commitment thresholds
- target switching
- objective routing
- pressure conversion

---

## Snowball

Default:

> outcome/state transition and scoring dimension.

Only promote Snowball into a Strategy if discovery finds a persistent deliberate gameplay plan beyond merely benefiting from multiple downs.

---

# PREVALENCE

Keep prevalence separate from strength.

Do not infer Strategy prevalence directly from:

- perk usage
- Killer pick rate
- add-on usage

unless the mapping is sufficiently specific.

Use descriptive prevalence only where evidence supports it.

Potential later labels may include:

```text
VERY COMMON
COMMON
MODERATE
UNCOMMON
RARE
UNKNOWN
```

Do not force numerical prevalence without adequate evidence.

---

# EVIDENCE RULES

Prioritize:

1. official Behaviour Interactive mechanics/patch information
2. strong current reference sources
3. current player/community evidence
4. competitive/high-level evidence where contextually appropriate
5. historical evidence only when resolving continuity or Legacy

Distinguish:

- mechanics evidence
- prevalence evidence
- implementation evidence
- Power evidence
- compatibility evidence

Do not allow one evidence type to impersonate another.

---

# CONFIDENCE

Do not collapse all uncertainty into one universal confidence score.

Later stages should be able to distinguish:

```text
mechanicsConfidence
prevalenceConfidence
powerConfidence
generalMatchmakingConfidence
coordinatedSWFConfidence
compatibilityConfidence
```

Potential labels:

```text
HIGH
MEDIUM_HIGH
MEDIUM
LOW_MEDIUM
LOW
```

Confidence is not Stability.

Confidence is not Power.

---

# COMPETITIVE EVIDENCE RULES

Competitive play is useful for:

- ceiling
- optimized implementation
- counterplay
- matchup insight
- testing whether a Strategy survives excellent opposition

It is weaker evidence for:

- normal public prevalence
- ordinary matchmaking Power
- practical build availability

Record restrictions where known:

- perk bans
- add-on bans
- maps
- scoring
- repeated matchup rules

Do not mechanically transfer tournament outcomes to public matchmaking.

---

# EDITORIAL LANGUAGE

Research topics such as:

- tunneling
- slugging
- camping

using neutral operational language.

Do:

- describe behavior
- measure effectiveness
- describe opportunity cost
- describe counterplay
- describe prevalence where supported
- identify enabling game states

Do not:

- infer malicious intent
- treat dislike as evidence of weakness
- treat effectiveness as moral approval
- use inflammatory framing where precise terminology works better

The project is cataloging strategy, not adjudicating player etiquette.

---

# LEGACY

Reuse the same persistent historical architecture:

```text
Strategy
→ StrategyPatchSnapshot[]
```

When a Strategy ceases to be current:

```text
currentStatus = LEGACY
```

Historical snapshots remain.

Old implementation recommendations may separately become:

```text
contentValidity = OUTDATED
```

Do not delete historical strategic identities merely because the current game no longer supports them.

---

# SHARED SURVIVOR / KILLER DATABASE

Use a genuinely shared Strategy persistence schema.

Do not require Survivor and Killer to use identical Power models.

Each snapshot should reference its scoring model:

```text
powerModelId
```

Examples:

```text
SURVIVOR_POWER_V1
KILLER_POWER_V1
```

This permits side-specific scoring while preserving shared infrastructure.

---

# PIPELINE

The final Killer Meta pipeline is:

```text
K0
Research Design / Ontology Audit
↓
K1
Comprehensive Discovery + Taxonomy + Full Practical Strategy Catalog
↓
K2
Adversarial Verification + Classification Resolution + Ranking
↓
K3A
Canonical Database
↓
K3B
Strategy Encyclopedia / Website Publication Layer
```

There is **no separate K1.5 stage**.

K1 must be sufficiently comprehensive that K2 can proceed directly without requiring another broad discovery pass.

---

# STAGE K1

Purpose:

> **Discover the complete practical Killer strategy universe and attach the current Patch state to every meaningful candidate.**

K1 investigates:

- independent Strategies
- Parent Families
- Meta Subtypes
- Modules
- Mechanic-Centered Builds
- Niche Strategies
- Killer-specific Strategies
- Power-family Strategies
- add-on-defined variants
- tactics
- Legacy candidates

K1 does **not** rank or score them.

---

# STAGE K2

Purpose:

> **Adversarially verify K1, resolve final classifications, establish compatibility, and rank eligible current Strategies.**

K2 should:

- challenge every K1 candidate
- resolve family vs Strategy vs subtype vs Module vs build vs tactic
- investigate unresolved mechanics
- audit transformative add-ons
- rank eligible Strategies in both canonical environments
- lock the Killer Power model and weights before scoring
- calculate Stability
- evaluate compatibility
- evaluate map dependence
- test Survivor coordination effects
- preserve PROVISIONAL and UNRANKED where evidence is immature
- separate prevalence from strength
- preserve Legacy

No Killer-character tier list should be smuggled into K2.

---

# STAGE K3A

Purpose:

> **Convert the resolved K2 universe into the validated canonical Killer Meta truth layer.**

K3A handles:

- persistent Strategy IDs
- StrategyPatchSnapshots
- BuildImplementations
- tactics
- Killer references
- methodology metadata
- canonical relationships
- normalization of merges/splits
- validation
- Legacy persistence

K3A does not rediscover or rerank the meta.

---

# STAGE K3B

Purpose:

> **Transform the frozen K3A canonical database into player-facing encyclopedia and website content.**

K3B:

- publishes every canonical Strategy-layer object
- publishes tactics separately
- explains rankings
- presents compatibility
- presents builds where supported
- presents Legacy
- creates indexes/navigation
- preserves uncertainty
- does not alter canonical conclusions

The canonical database remains upstream truth.

---

# REQUIRED DECISIONS TO LOCK BEFORE K1

The following are considered resolved by K0:

1. Reuse `Strategy → StrategyPatchSnapshot → BuildImplementation`.
2. Separate Killer Character from Strategy.
3. Separate character rankings from Strategy rankings.
4. Use:
   - `KILLER_GENERAL_MATCHMAKING`
   - `KILLER_VS_COORDINATED_SWF`
5. Competitive play is secondary evidence, not a third canonical environment.
6. Use generic `environmentEvaluations[]`.
7. Rename `Role Commitment` to `Strategic Commitment`.
8. Add `applicabilityScope`.
9. Allow side-specific Power models.
10. Use the 12 Killer Power dimensions defined above.
11. Do not put roster breadth directly into Power.
12. Use sparse Killer compatibility.
13. Extend BuildImplementation for Killer/add-ons.
14. Add minimal Killer dependency vocabulary.
15. Treat tactics separately from Strategies.
16. Treat Snowball primarily as a dimension/outcome rather than automatically a Strategy.
17. Do not pre-classify tunneling, slugging, camping, generator control, information, chase, or similar labels.
18. Reuse the shared Stability framework with Killer-aware interpretation.
19. Do not require K1.5.
20. Preserve Legacy through historical snapshots rather than destructive replacement.

---

# K1 READINESS

## READY

No additional architectural research is required before Stage K1.

K1 should now be free to determine whether familiar Killer concepts are actually:

- independent Strategies
- Parent Families
- Meta Subtypes
- Strategic Modules
- Mechanic-Centered Builds
- Niche Strategies
- Tactics
- principles
- Legacy forms

without K0 prejudging the result.

The most important discipline throughout all later stages remains:

> **Never allow Killer character strength to masquerade as Strategy strength.**

# END STAGE K0