---
tacticId: "KTAC-004"
side: "KILLER"
name: "Force Trade"
slug: "force-trade"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-011", "KSTR-012"]
---

# Force Trade

Pressure rescuer so rescue produces another down/hook.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Pressure rescuer so rescue produces another down/hook.

## Strategic Purpose

Maintain hook pressure without necessarily focusing same Survivor.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Hook-Zone / Rescue Pressure](../strategies/hook-zone-rescue-pressure.md)
- [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md)

## What It Is Not

Using this tactic once does not automatically establish any of its related Strategy identities. Tactics are local decisions; Strategies are persistent gameplay plans.

## Environment Sensitivity

Strongly affected by health states, Endurance and coordination

## Source Metadata

- **Tactic ID:** `KTAC-004`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
