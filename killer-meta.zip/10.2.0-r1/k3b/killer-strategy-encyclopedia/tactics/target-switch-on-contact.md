---
tacticId: "KTAC-014"
side: "KILLER"
name: "Target Switch on Contact"
slug: "target-switch-on-contact"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-008", "KSTR-017", "KSTR-026"]
---

# Target Switch on Contact

Drop current pursuit immediately when a higher-value Survivor becomes reachable.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Drop current pursuit immediately when a higher-value Survivor becomes reachable.

## Strategic Purpose

Improve hook-state or injury conversion.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Target Focus / Elimination Sequencing](../strategies/target-focus-elimination-sequencing.md)
- [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md)
- [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md)

## What It Is Not

Using this tactic once does not automatically establish any of its related Strategy identities. Tactics are local decisions; Strategies are persistent gameplay plans.

## Environment Sensitivity

Strongly communication-sensitive

## Source Metadata

- **Tactic ID:** `KTAC-014`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
