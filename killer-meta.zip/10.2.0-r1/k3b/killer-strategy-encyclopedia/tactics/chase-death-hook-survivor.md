---
tacticId: "KTAC-006"
side: "KILLER"
name: "Chase Death-Hook Survivor"
slug: "chase-death-hook-survivor"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-008", "KSTR-010"]
---

# Chase Death-Hook Survivor

Prefer a currently accessible Survivor whose next hook eliminates.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Prefer a currently accessible Survivor whose next hook eliminates.

## Strategic Purpose

Convert a local opportunity efficiently.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Target Focus / Elimination Sequencing](../strategies/target-focus-elimination-sequencing.md)
- [Hook-State Prioritization](../strategies/hook-state-prioritization.md)

## What It Is Not

Using this tactic once does not automatically establish any of its related Strategy identities. Tactics are local decisions; Strategies are persistent gameplay plans.

## Environment Sensitivity

Hook-state knowledge and Shoulder transfer matter

## Source Metadata

- **Tactic ID:** `KTAC-006`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
