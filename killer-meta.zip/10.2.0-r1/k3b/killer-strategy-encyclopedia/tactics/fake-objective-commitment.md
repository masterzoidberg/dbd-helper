---
tacticId: "KTAC-011"
side: "KILLER"
name: "Fake Objective Commitment"
slug: "fake-objective-commitment"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-001", "KSTR-064"]
---

# Fake Objective Commitment

Begin/telegraph kick, teleport, projection or patrol action to force Survivor displacement without completing it.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Begin/telegraph kick, teleport, projection or patrol action to force Survivor displacement without completing it.

## Strategic Purpose

Gain movement/error value without full action cost.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Generator Control](../strategies/generator-control.md)
- [Dream Projection Pressure Module](../strategies/dream-projection-pressure-module.md)

## What It Is Not

Using this tactic once does not automatically establish any of its related Strategy identities. Tactics are local decisions; Strategies are persistent gameplay plans.

## Environment Sensitivity

Stronger teams may call the bluff

## Source Metadata

- **Tactic ID:** `KTAC-011`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
