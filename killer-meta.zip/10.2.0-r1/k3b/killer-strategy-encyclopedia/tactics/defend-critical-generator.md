---
tacticId: "KTAC-005"
side: "KILLER"
name: "Defend Critical Generator"
slug: "defend-critical-generator"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-001", "KSTR-023"]
---

# Defend Critical Generator

Temporarily prioritize a high-progress or cluster-critical gen.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Temporarily prioritize a high-progress or cluster-critical gen.

## Strategic Purpose

Prevent immediate objective loss.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Generator Control](../strategies/generator-control.md)
- [Territorial Control](../strategies/territorial-control.md)

## What It Is Not

Using this tactic once does not automatically establish any of its related Strategy identities. Tactics are local decisions; Strategies are persistent gameplay plans.

## Environment Sensitivity

SWF can deliberately split elsewhere

## Source Metadata

- **Tactic ID:** `KTAC-005`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
