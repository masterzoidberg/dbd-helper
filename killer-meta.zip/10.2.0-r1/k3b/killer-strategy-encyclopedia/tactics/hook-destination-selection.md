---
tacticId: "KTAC-013"
side: "KILLER"
name: "Hook-Destination Selection"
slug: "hook-destination-selection"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-013", "KSTR-014", "KSTR-030"]
---

# Hook-Destination Selection

Carry to a particular hook for location rather than nearest-time efficiency.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Carry to a particular hook for location rather than nearest-time efficiency.

## Strategic Purpose

Set up basement, Scourge, cluster or territorial conversion.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md)
- [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md)
- [Scourge-Hook Routing](../strategies/scourge-hook-routing.md)

## What It Is Not

Using this tactic once does not automatically establish any of its related Strategy identities. Tactics are local decisions; Strategies are persistent gameplay plans.

## Environment Sensitivity

Sabotage/bodyblock coordination matters

## Source Metadata

- **Tactic ID:** `KTAC-013`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
