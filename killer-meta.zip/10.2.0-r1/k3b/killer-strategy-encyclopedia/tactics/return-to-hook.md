---
tacticId: "KTAC-003"
side: "KILLER"
name: "Return to Hook"
slug: "return-to-hook"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-008", "KSTR-011"]
---

# Return to Hook

Re-enter hook area after leaving.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Re-enter hook area after leaving.

## Strategic Purpose

Intercept rescue, reacquire target, protect nearby anchor.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Target Focus / Elimination Sequencing](../strategies/target-focus-elimination-sequencing.md)
- [Hook-Zone / Rescue Pressure](../strategies/hook-zone-rescue-pressure.md)

## What It Is Not

Returning to a hook once does **not** automatically establish Proxy Hook-Zone Control or Committed Elimination Focus. Strategy identity requires a repeated match-level plan, not one local return.

## Environment Sensitivity

Coordinated callouts make timing more predictable on both sides

## Source Metadata

- **Tactic ID:** `KTAC-003`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
