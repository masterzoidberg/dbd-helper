---
tacticId: "KTAC-007"
side: "KILLER"
name: "Delay Pickup"
slug: "delay-pickup"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-015"]
---

# Delay Pickup

Wait before lifting a downed Survivor.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Wait before lifting a downed Survivor.

## Strategic Purpose

Avoid flashlight/pallet save, bait helpers, use Power cooldown.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Chain-Down Pressure](../strategies/chain-down-pressure.md)

## What It Is Not

Using this tactic once does not automatically establish any of its related Strategy identities. Tactics are local decisions; Strategies are persistent gameplay plans.

## Environment Sensitivity

Stronger coordinated save teams increase value/risk

## Source Metadata

- **Tactic ID:** `KTAC-007`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
