---
tacticId: "KTAC-002"
side: "KILLER"
name: "Leave Chase"
slug: "leave-chase"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: []
---

# Leave Chase

Deliberately abandon an inefficient pursuit.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Deliberately abandon an inefficient pursuit.

## Strategic Purpose

Preserve tempo and contest higher-value target/objective.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

K3A does not establish a related Strategy for this tactic.

## What It Is Not

Using this tactic once does not automatically establish any of its related Strategy identities. Tactics are local decisions; Strategies are persistent gameplay plans.

## Environment Sensitivity

Strong SWF gen distribution increases cost of overcommitment

## Source Metadata

- **Tactic ID:** `KTAC-002`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
