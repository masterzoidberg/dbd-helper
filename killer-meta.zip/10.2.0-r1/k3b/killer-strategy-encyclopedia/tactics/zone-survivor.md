---
tacticId: "KTAC-008"
side: "KILLER"
name: "Zone Survivor"
slug: "zone-survivor"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-011", "KSTR-020", "KSTR-023"]
---

# Zone Survivor

Occupy position/path so Survivor is forced toward weaker route.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Occupy position/path so Survivor is forced toward weaker route.

## Strategic Purpose

Shape chase geometry or deny rescue/objective access.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Hook-Zone / Rescue Pressure](../strategies/hook-zone-rescue-pressure.md)
- [Chase Optimization Suite](../strategies/chase-optimization-suite.md)
- [Territorial Control](../strategies/territorial-control.md)

## What It Is Not

Using this tactic once does not automatically establish any of its related Strategy identities. Tactics are local decisions; Strategies are persistent gameplay plans.

## Environment Sensitivity

Map geometry highly sensitive

## Source Metadata

- **Tactic ID:** `KTAC-008`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
