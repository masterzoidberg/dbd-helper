---
tacticId: "KTAC-001"
side: "KILLER"
name: "Temporary Slug"
slug: "temporary-slug"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-001", "KSTR-011", "KSTR-015"]
---

# Temporary Slug

Leave a downed Survivor briefly instead of immediately picking up.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Leave a downed Survivor briefly instead of immediately picking up.

## Strategic Purpose

Chase a nearby threat, avoid save, reposition, protect objective.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Generator Control](../strategies/generator-control.md)
- [Hook-Zone / Rescue Pressure](../strategies/hook-zone-rescue-pressure.md)
- [Chain-Down Pressure](../strategies/chain-down-pressure.md)

## What It Is Not

A temporary slug does **not** automatically mean the Killer is using Sustained Down-State Control. The tactic can serve several broader plans.

## Environment Sensitivity

Higher coordinated recovery/save capability reduces safe window

## Source Metadata

- **Tactic ID:** `KTAC-001`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
