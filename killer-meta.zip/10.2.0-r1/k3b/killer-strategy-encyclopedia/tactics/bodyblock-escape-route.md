---
tacticId: "KTAC-009"
side: "KILLER"
name: "Bodyblock Escape Route"
slug: "bodyblock-escape-route"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-020", "KSTR-022", "KSTR-023"]
---

# Bodyblock Escape Route

Use Killer collision to deny path temporarily.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Use Killer collision to deny path temporarily.

## Strategic Purpose

Secure hit/down, protect trap/door/hook path.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Chase Optimization Suite](../strategies/chase-optimization-suite.md)
- [Ambush Rotation](../strategies/ambush-rotation.md)
- [Territorial Control](../strategies/territorial-control.md)

## What It Is Not

Using this tactic once does not automatically establish any of its related Strategy identities. Tactics are local decisions; Strategies are persistent gameplay plans.

## Environment Sensitivity

Tile-specific

## Source Metadata

- **Tactic ID:** `KTAC-009`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
