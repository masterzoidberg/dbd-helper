---
tacticId: "KTAC-012"
side: "KILLER"
name: "Break-and-Leave"
slug: "break-and-leave"
pageType: "TACTIC"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: "10.2.0-r1"
relatedStrategyIds: ["KSTR-019"]
---

# Break-and-Leave

Consume a pallet/breakable resource and abandon the chase.

> **Tactic:** A situational Killer decision, not an independently ranked Strategy. It has no Power, Tier, Meta Stability, or Ranking Index.

## Definition

Consume a pallet/breakable resource and abandon the chase.

## Strategic Purpose

Convert present chase into later resource advantage.

## When It Is Used

K3A records this tactic as a local decision used to accomplish the purpose above. It does not, by itself, establish a full-match Strategy identity.

## Strategies That Commonly Use It

- [Pallet / Resource Attrition](../strategies/pallet-resource-attrition.md)

## What It Is Not

Using this tactic once does not automatically establish any of its related Strategy identities. Tactics are local decisions; Strategies are persistent gameplay plans.

## Environment Sensitivity

Tile/map dependent

## Source Metadata

- **Tactic ID:** `KTAC-012`
- **Patch baseline:** `10.2.0-r1`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
