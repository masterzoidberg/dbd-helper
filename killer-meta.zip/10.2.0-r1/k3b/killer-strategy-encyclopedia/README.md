# Dead by Daylight Killer Strategy Encyclopedia — Stage K3B

This package is the publication layer for the frozen **Dead by Daylight Killer Meta Patch 10.2.0-r1** canonical database.

## Purpose

K3B turns canonical K3A records into player-facing Markdown encyclopedia pages and navigation data. It does **not** discover, rerank, rescore, or modify the research.

## Baseline

- Patch: **10.2.0-r1**
- Research cutoff represented by K3A: **October 7, 2026**
- Strategy-layer pages: **71**
- Tactic pages: **14**
- Total publication-object pages: **85**

## Folder Structure

- `strategies/` — 71 Strategy-layer pages: current independent Strategies, Parent Families, Strategic Modules, Mechanic-Centered Builds, and Legacy objects.
- `tactics/` — 14 Tactic Glossary pages.
- `indexes/` — ranking/navigation, families, compatibility, tactics, Legacy, and methodology pages.
- `data/publication-manifest.json` — lightweight website navigation/search metadata.
- `data/publication-issues.json` — downstream publication issues and augmentation requests only.
- `validation.json` — machine-readable publication validation.
- `stage-k3b-report.md` — human-readable build report.

## Authority Boundary

The K3A database remains authoritative. These pages are downstream publication artifacts. If publication prose and canonical K3A data ever disagree, **K3A wins**.

K3B does not introduce post-cutoff evidence, perform a new meta pass, fabricate missing builds, interpret missing compatibility as viability, or assign ranks where K3A leaves them null.
