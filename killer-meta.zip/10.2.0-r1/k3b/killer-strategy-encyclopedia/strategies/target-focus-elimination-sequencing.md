---
canonicalId: "KSTR-008"
side: "KILLER"
name: "Target Focus / Elimination Sequencing"
slug: "target-focus-elimination-sequencing"
pageType: "PARENT_STRATEGY_FAMILY"
structuralClassification: "PARENT STRATEGY FAMILY"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "TEMPO"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-008@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: ["KSTR-009", "KSTR-010"]
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Target Focus / Elimination Sequencing

Concentrate pressure where hook states and target vulnerability convert fastest.

> **Strategy Family:** This is an organizational family, not an independently ranked gameplay plan. It has no aggregate Power, Tier, or Ranking Index.

## Family Definition

**Shared objective:** Concentrate pressure where hook states and target vulnerability convert fastest.

**Shared loop:** Track survivor states → differentiate targets → choose persistence/switching based on elimination value.

Convert target identity/hook state into faster removal.

## Current Children

| Child | Classification | General Matchmaking | Coordinated SWF |
|---|---|---|---|
| [Committed Elimination Focus](committed-elimination-focus.md) | META | A — 83 | B — 77 |
| [Hook-State Prioritization](hook-state-prioritization.md) | STRATEGIC MODULE | Not independently ranked | Not independently ranked |

## How the Children Differ

- **[Committed Elimination Focus](committed-elimination-focus.md):** Remove one Survivor earlier by persistently prioritizing that target
- **[Hook-State Prioritization](hook-state-prioritization.md):** Prefer Survivors whose next down/hook converts more efficiently

## Shared Counterplay

protection, hiding, hook-state redistribution, bodyblocks.

## Related Families and Cross-Links


**Canonical relationship note:** Hook-Zone Pressure; Onryō target states.

## Strongest Current Children

- **General Matchmaking:** Committed Elimination 83
- **Coordinated SWF:** Committed Elimination 77

These are child-level canonical results, not an aggregate score for the family.

## Family Scope

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

## Source Metadata

- **Canonical ID:** `KSTR-008`
- **Snapshot:** `KSTR-008@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
