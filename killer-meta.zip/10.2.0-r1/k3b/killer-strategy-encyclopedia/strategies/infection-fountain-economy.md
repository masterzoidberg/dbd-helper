---
canonicalId: "KSTR-040"
side: "KILLER"
name: "Infection / Fountain Economy"
slug: "infection-fountain-economy"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-040@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 84
powerSWF: 79
tierGeneral: "A"
tierSWF: "A"
metaStability: 92
stabilityLabel: "VERY STABLE"
trend: null
---

# Infection / Fountain Economy

Infect targets/objects, maintain forced injury, evaluate cleansing state, then time Corrupt Purge collection and lethal conversion.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | KILLER_SPECIFIC |
| Strategic orientation | Not established |
| Current status | ESTABLISHED |
| General Matchmaking | A — 84 |
| Coordinated SWF | A — 79 |
| Meta Stability | 92 — VERY STABLE |
| Skill Floor | 3/5 — Moderate |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 2/5 — intermediate canonical value |
| Opportunity Cost | 2/5 — intermediate canonical value |

## What This Strategy Is

**Infection / Fountain Economy** is a Killer strategy built around this objective: **Infect targets/objects, maintain forced injury, evaluate cleansing state, then time Corrupt Purge collection and lethal conversion**.

Its defining loop is **Infect targets/objects, maintain forced injury, evaluate cleansing state, then time Corrupt Purge collection and lethal conversion**.

**K3A independence rationale:** Survivor cleanse policy creates a genuine injury/resource economy.

## How It Plays

The practical decision loop is: **Infect targets/objects, maintain forced injury, evaluate cleansing state, then time Corrupt Purge collection and lethal conversion**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 4/5 — intermediate canonical value.

## When It Works Best

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

**Material dependencies:** `KILLER_POWER`, `OPPONENT_BEHAVIOR`, `RESOURCE_AVAILABILITY`, `TIMING`

**Canonical synergies:** info, gen pressure, chain-down

## Killer Fit

**Best Fits:** The Plague

**Canonical fit rationale:** Infection/fountains required.

**Global exclusion:** all other Killers are `INCOMPATIBLE` for this Strategy. Infection/fountains required.

## General Matchmaking

**A — 84.**

Plague's cleanse dilemma converts Survivor healing policy into a Killer resource economy.

## Against Coordinated SWF

**A — 79.**

Coordinated cleanse policy improves Survivor control, but every policy still has a meaningful Plague-side tradeoff.

## Why the Two Environments Differ

The canonical Power estimate changes from **84** in General Matchmaking to **79** against coordinated SWF (-5 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 8 → 6.5 (-1.5)
- **Consistency:** 8 → 7 (-1)
- **Matchup Coverage:** 8.5 → 7.5 (-1)
- **Ceiling:** 9 → 8.5 (-0.5)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 9.5/10, Slot Efficiency 9.5/10, Ceiling 9/10, Agency 8.5/10.

- Synergy: info
- Synergy: gen pressure
- Synergy: chain-down

## Weaknesses and Counterplay

- coordinated cleanse policy/timing

The lowest General Matchmaking Power dimensions are Consistency 8/10, Counterplay Resilience 8/10, Execution Reliability 8/10, Map Coverage 8/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** fountain placement, LOS.

**Map Dependence:** 2/5 — intermediate canonical value.

**General Matchmaking Map Coverage:** 8/10.

## Skill Profile

- **Skill Floor:** 3/5 — Moderate
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 2/5 — intermediate canonical value
- **Execution Reliability, General Matchmaking:** 8/10
- **Strategic Commitment:** 4/5 — intermediate canonical value

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Representative Implementations

### Framework — `KSTR-040-B01`

- **Killer:** The Plague
- **Implementation:** Native infection/fountain framework; perks flexible
- **Rationale:** Optimize infection and Corrupt conversion around cleanse policy
- **Strengths:** Survivor cannot avoid making a policy choice
- **Weaknesses:** Coordinated cleanse timing lowers surprise
- **Confidence:** HIGH
- **Content validity:** LIVE_10_2_SOURCE_SUPPORTED

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 5/5 |
| Activation Reliability | 5/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 4/5 |

## Meta Stability

**92 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 24/25 |
| Core Mechanic Durability | 20/20 |
| Replacement Depth | 13/15 |
| Environmental Breadth | 12/15 |
| Counter-Meta Independence | 9/10 |
| Patch Durability | 14/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

No additional canonical Strategy relationships are established in K3A.

## Source Metadata

- **Canonical ID:** `KSTR-040`
- **Snapshot:** `KSTR-040@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
