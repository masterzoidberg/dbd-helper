---
canonicalId: "KSTR-012"
side: "KILLER"
name: "Proxy Hook-Zone Control"
slug: "proxy-hook-zone-control"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "HYBRID"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-012@10.2.0-r1"
parentStrategyId: "KSTR-011"
relatedStrategyIds: []
childStrategyIds: ["KSTR-069"]
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 76
powerSWF: 69
tierGeneral: "B"
tierSWF: "B"
metaStability: 91
stabilityLabel: "VERY STABLE"
trend: null
---

# Proxy Hook-Zone Control

Threaten rescues while preserving ability to contest surrounding map.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META |
| Applicability scope | BROAD_ROSTER |
| Strategic orientation | HYBRID |
| Current status | ESTABLISHED |
| General Matchmaking | B — 76 |
| Coordinated SWF | B — 69 |
| Meta Stability | 91 — VERY STABLE |
| Skill Floor | 2/5 — intermediate canonical value |
| Skill Ceiling | 4/5 — intermediate canonical value |
| Map Dependence | 3/5 — Material |
| Opportunity Cost | 3/5 — Meaningful tradeoff |

## What This Strategy Is

**Proxy Hook-Zone Control** is a Killer strategy built around this objective: **Threaten rescues while preserving ability to contest surrounding map**.

Its defining loop is **Hook → move through interception radius / nearby objective → read rescue timing → collapse on rescuer or returning target**.

**K3A independence rationale:** Sustained interception/rescue conversion remains distinct from static close facecamping.

## How It Plays

The practical decision loop is: **Hook → move through interception radius / nearby objective → read rescue timing → collapse on rescuer or returning target**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 4/5 — intermediate canonical value.

## When It Works Best

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

**Material dependencies:** `POSITIONING`, `TIMING`, `TARGET_STATE`, `MAP`

**Canonical synergies:** range, mobility, territory

## Killer Fit

**Best Fits:** The Cannibal, The Hag, The Artist
**Strong Fits:** The Huntress, The Deathslinger, The Demogorgon
**Viable Fits:** The Doctor, The Knight

**Canonical fit rationale:** Threat must reach rescue lanes without requiring stationary close proximity.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**B — 76.**

Rescue pressure remains strong without requiring obsolete facecamping behavior.

## Against Coordinated SWF

**B — 69.**

Rescue teams can coordinate bait, timing and bodyblocks, but must still spend players/time on the rescue.

## Why the Two Environments Differ

The canonical Power estimate changes from **76** in General Matchmaking to **69** against coordinated SWF (-7 points).

The largest canonical dimension shifts are:
- **Matchup Coverage:** 7.5 → 6 (-1.5)
- **Consistency:** 7.5 → 6.5 (-1)
- **Counterplay Resilience:** 6.5 → 5.5 (-1)
- **Snowball Value:** 8 → 7 (-1)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Slot Efficiency 9/10, Ceiling 8/10, Snowball Value 8/10, Tempo Efficiency 8/10.

- Synergy: range
- Synergy: mobility
- Synergy: territory

## Weaknesses and Counterplay

- coordinated rescue
- split gens
- Resolve pressure

The lowest General Matchmaking Power dimensions are Counterplay Resilience 6.5/10, Map Coverage 7/10, Recovery Value 7/10, Agency 7.5/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** hook lanes, LOS, nearby gens.

**Map Dependence:** 3/5 — Material.

**General Matchmaking Map Coverage:** 7/10.

## Skill Profile

- **Skill Floor:** 2/5 — intermediate canonical value
- **Skill Ceiling:** 4/5 — intermediate canonical value
- **Opportunity Cost:** 3/5 — Meaningful tradeoff
- **Execution Reliability, General Matchmaking:** 7.5/10
- **Strategic Commitment:** 4/5 — intermediate canonical value

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 4/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 4/5 |

## Meta Stability

**91 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 24/25 |
| Core Mechanic Durability | 19/20 |
| Replacement Depth | 14/15 |
| Environmental Breadth | 12/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 14/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | MEDIUM_HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Hook-Zone / Rescue Pressure](hook-zone-rescue-pressure.md)
- [Pre-Resolve-Bar Close Facecamp Form](pre-resolve-bar-close-facecamp-form.md)

## Source Metadata

- **Canonical ID:** `KSTR-012`
- **Snapshot:** `KSTR-012@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
