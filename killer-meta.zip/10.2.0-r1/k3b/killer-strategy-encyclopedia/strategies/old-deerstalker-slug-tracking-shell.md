---
canonicalId: "KSTR-068"
side: "KILLER"
name: "Old Deerstalker Slug-Tracking Shell"
slug: "old-deerstalker-slug-tracking-shell"
pageType: "LEGACY"
structuralClassification: "MECHANIC-CENTERED BUILD"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: null
currentStatus: "LEGACY"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-068@10.2.0-r1"
parentStrategyId: "KSTR-016"
relatedStrategyIds: ["KSTR-021"]
childStrategyIds: []
rankingStatusGeneral: "NOT_CURRENT"
rankingStatusSWF: "NOT_CURRENT"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Old Deerstalker Slug-Tracking Shell

> **LEGACY — Not Current on Patch 10.2.0-r1**

Track downed Survivors to manage extended slug states.

## What It Was

Track downed Survivors to manage extended slug states

## How It Played

Track downed Survivors to manage extended slug states.

## Why It Is No Longer Current

10.2 Deerstalker now periodically creates mutual Killer/Survivor aura reading rather than its historical downed-survivor tracking role

**Transition:** Patch 10.2.0.

## What Replaced It

- [Information Chaining](information-chaining.md)

**Canonical successor note:** Generic Information Chaining.

## Terminology Warning

Old Deerstalker references are not live descriptions.

## Current Ranking Status

Both current environments are `NOT_CURRENT`. Power, Tier, and Ranking Index are intentionally null.

## Source Metadata

- **Canonical ID:** `KSTR-068`
- **Snapshot:** `KSTR-068@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| BHVR_PATCH_10_2_0 | Dead by Daylight 10.2.0 Mid-Chapter | 2026-10-06 | Official live Patch 10.2.0 mechanics. |
