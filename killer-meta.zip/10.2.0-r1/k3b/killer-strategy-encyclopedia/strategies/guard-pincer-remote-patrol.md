---
canonicalId: "KSTR-051"
side: "KILLER"
name: "Guard Pincer / Remote Patrol"
slug: "guard-pincer-remote-patrol"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-051@10.2.0-r1"
parentStrategyId: "KSTR-023"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Guard Pincer / Remote Patrol

Assign Guards to patrol/hunt or interact with obstacles, use them to cut routes, create pincer pressure, or contest space while Knight approaches elsewhere.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Assign Guards to patrol/hunt or interact with obstacles, use them to cut routes, create pincer pressure, or contest space while Knight approaches elsewhere.

**Decision loop:** Assign Guards to patrol/hunt or interact with obstacles, use them to cut routes, create pincer pressure, or contest space while Knight approaches elsewhere.

## What Strategic Problem It Solves

Territorial/chase.

## Strategies It Supports

- [Territorial Control](territorial-control.md)

**Canonical support note:** Territorial/chase.

## How It Changes Killer Decisions

Assign Guards to patrol/hunt or interact with obstacles, use them to cut routes, create pincer pressure, or contest space while Knight approaches elsewhere.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Assign Guards to patrol/hunt or interact with obstacles, use them to cut routes, create pincer pressure, or contest space while Knight approaches elsewhere**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Predominantly local zoning/remote chase.

## Promotion Condition

Persistent map-level patrol objective shown.

## Related Strategies

- [Territorial Control](territorial-control.md)

## Source Metadata

- **Canonical ID:** `KSTR-051`
- **Snapshot:** `KSTR-051@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
