---
canonicalId: "KSTR-050"
side: "KILLER"
name: "Locker / Nightfall Rotation Module"
slug: "locker-nightfall-rotation-module"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-050@10.2.0-r1"
parentStrategyId: "KSTR-022"
relatedStrategyIds: ["KSTR-026"]
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Locker / Nightfall Rotation Module

Route through lockers, reposition unpredictably, use darkness windows to increase ambush efficiency, and leave unfavorable chases more readily.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Route through lockers, reposition unpredictably, use darkness windows to increase ambush efficiency, and leave unfavorable chases more readily.

**Decision loop:** Route through lockers, reposition unpredictably, use darkness windows to increase ambush efficiency, and leave unfavorable chases more readily.

## What Strategic Problem It Solves

Ambush/Rotation.

## Strategies It Supports

- [Ambush Rotation](ambush-rotation.md)
- [Rapid Rotation Pressure](rapid-rotation-pressure.md)

**Canonical support note:** Ambush/Rotation.

## How It Changes Killer Decisions

Route through lockers, reposition unpredictably, use darkness windows to increase ambush efficiency, and leave unfavorable chases more readily.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Route through lockers, reposition unpredictably, use darkness windows to increase ambush efficiency, and leave unfavorable chases more readily**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Native implementation of both.

## Promotion Condition

Separate macro objective appears.

## Related Strategies

- [Ambush Rotation](ambush-rotation.md)
- [Rapid Rotation Pressure](rapid-rotation-pressure.md)

## Source Metadata

- **Canonical ID:** `KSTR-050`
- **Snapshot:** `KSTR-050@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
