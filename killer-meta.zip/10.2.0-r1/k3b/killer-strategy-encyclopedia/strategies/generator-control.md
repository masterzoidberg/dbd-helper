---
canonicalId: "KSTR-001"
side: "KILLER"
name: "Generator Control"
slug: "generator-control"
pageType: "PARENT_STRATEGY_FAMILY"
structuralClassification: "PARENT STRATEGY FAMILY"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-001@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: ["KSTR-013"]
childStrategyIds: ["KSTR-002", "KSTR-003", "KSTR-004", "KSTR-005", "KSTR-006", "KSTR-007", "KSTR-035"]
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Generator Control

Reduce or redirect repair progress long enough to convert downs/hooks/eliminations.

> **Strategy Family:** This is an organizational family, not an independently ranked gameplay plan. It has no aggregate Power, Tier, or Ranking Index.

## Family Definition

**Shared objective:** Reduce or redirect repair progress long enough to convert downs/hooks/eliminations.

**Shared loop:** Identify valuable generators → pressure/deny/regress/block → choose chase commitments around objective value → revisit threatened lanes.

Convert Killer time/actions/position into delayed, removed or redirected repair progress.

## Current Children

| Child | Classification | General Matchmaking | Coordinated SWF |
|---|---|---|---|
| [Active Regression Conversion](active-regression-conversion.md) | META | A — 79 | B — 76 |
| [Hook-to-Generator Conversion](hook-to-generator-conversion.md) | META SUBTYPE | Provisional A — 79 | Provisional B — 75 |
| [Generator Blocking / Repair Denial](generator-blocking-repair-denial.md) | STRATEGIC MODULE | Not independently ranked | Not independently ranked |
| [Generator-Cluster Defense](generator-cluster-defense.md) | NICHE STRATEGY | B — 72 | C — 65 |
| [Repair-Speed Suppression](repair-speed-suppression.md) | STRATEGIC MODULE | Not independently ranked | Not independently ranked |
| [Compromised-Generator Payoff Framework](compromised-generator-payoff-framework.md) | MECHANIC-CENTERED BUILD | Not independently ranked | Not independently ranked |
| [Indefinite Repeated-Kick Three-Gen](indefinite-repeated-kick-three-gen.md) | META SUBTYPE | Not current | Not current |

## How the Children Differ

- **[Active Regression Conversion](active-regression-conversion.md):** Turn Killer actions into meaningful loss of repaired progress
- **[Hook-to-Generator Conversion](hook-to-generator-conversion.md):** Make each hook generate immediate objective pressure
- **[Generator Blocking / Repair Denial](generator-blocking-repair-denial.md):** Prevent repair during a pressure window
- **[Generator-Cluster Defense](generator-cluster-defense.md):** Preserve a defensible final objective cluster
- **[Repair-Speed Suppression](repair-speed-suppression.md):** Increase time cost of repairing rather than directly removing progress
- **[Compromised-Generator Payoff Framework](compromised-generator-payoff-framework.md):** Mark generators and convert later Survivor completion into Killer tempo
- **[Indefinite Repeated-Kick Three-Gen](indefinite-repeated-kick-three-gen.md):** Recycle regression indefinitely on same cluster

## Shared Counterplay

split repairs, pre-run, avoid repeated high-value regression states.

## Related Families and Cross-Links

- [Hook + Objective Anchor Control](hook-objective-anchor-control.md)

**Canonical relationship note:** Territorial Control; Hook Anchor.

## Strongest Current Children

- **General Matchmaking:** Active Regression / Hook-to-Gen 79
- **Coordinated SWF:** Active Regression 76

These are child-level canonical results, not an aggregate score for the family.

## Family Scope

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

## Source Metadata

- **Canonical ID:** `KSTR-001`
- **Snapshot:** `KSTR-001@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
