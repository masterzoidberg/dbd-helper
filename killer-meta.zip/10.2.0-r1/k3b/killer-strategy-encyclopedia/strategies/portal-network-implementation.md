---
canonicalId: "KSTR-047"
side: "KILLER"
name: "Portal Network Implementation"
slug: "portal-network-implementation"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-047@10.2.0-r1"
parentStrategyId: "KSTR-025"
relatedStrategyIds: ["KSTR-026"]
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Portal Network Implementation

Seed portals near objectives/routes, activate them through use, detect nearby Survivors, teleport and emerge Undetectable.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Seed portals near objectives/routes, activate them through use, detect nearby Survivors, teleport and emerge Undetectable.

**Decision loop:** Seed portals near objectives/routes, activate them through use, detect nearby Survivors, teleport and emerge Undetectable.

## What Strategic Problem It Solves

Network/Rotation.

## Strategies It Supports

- [Network Surveillance / Teleport Control](network-surveillance-teleport-control.md)
- [Rapid Rotation Pressure](rapid-rotation-pressure.md)

**Canonical support note:** Network/Rotation.

## How It Changes Killer Decisions

Seed portals near objectives/routes, activate them through use, detect nearby Survivors, teleport and emerge Undetectable.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Seed portals near objectives/routes, activate them through use, detect nearby Survivors, teleport and emerge Undetectable**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Portal mechanics implement broader loops.

## Promotion Condition

Separate objective appears.

## Related Strategies

- [Network Surveillance / Teleport Control](network-surveillance-teleport-control.md)
- [Rapid Rotation Pressure](rapid-rotation-pressure.md)

## Source Metadata

- **Canonical ID:** `KSTR-047`
- **Snapshot:** `KSTR-047@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
