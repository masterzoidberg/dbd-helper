---
canonicalId: "KSTR-052"
side: "KILLER"
name: "Crow Zoning / Remote Probe"
slug: "crow-zoning-remote-probe"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-052@10.2.0-r1"
parentStrategyId: "KSTR-021"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Crow Zoning / Remote Probe

Pre-place crow trajectories, close escape routes, probe distant objectives, then convert swarm information into route denial or hits.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Pre-place crow trajectories, close escape routes, probe distant objectives, then convert swarm information into route denial or hits.

**Decision loop:** Pre-place crow trajectories, close escape routes, probe distant objectives, then convert swarm information into route denial or hits.

## What Strategic Problem It Solves

Information/chase.

## Strategies It Supports

- [Information Chaining](information-chaining.md)

**Canonical support note:** Information/chase.

## How It Changes Killer Decisions

Pre-place crow trajectories, close escape routes, probe distant objectives, then convert swarm information into route denial or hits.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Pre-place crow trajectories, close escape routes, probe distant objectives, then convert swarm information into route denial or hits**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Supports routing/zoning.

## Promotion Condition

Probe itself becomes independent objective.

## Related Strategies

- [Information Chaining](information-chaining.md)

## Source Metadata

- **Canonical ID:** `KSTR-052`
- **Snapshot:** `KSTR-052@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
