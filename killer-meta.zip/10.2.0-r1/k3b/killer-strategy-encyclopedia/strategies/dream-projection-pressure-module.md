---
canonicalId: "KSTR-064"
side: "KILLER"
name: "Dream Projection Pressure Module"
slug: "dream-projection-pressure-module"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-064@10.2.0-r1"
parentStrategyId: "KSTR-026"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Dream Projection Pressure Module

Use unfinished generators as teleport anchors, project/cancel to displace repairers, and combine Dream World with Snares or Pallets to create favorable chase zones.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Use unfinished generators as teleport anchors, project/cancel to displace repairers, and combine Dream World with Snares or Pallets to create favorable chase zones.

**Decision loop:** Use unfinished generators as teleport anchors, project/cancel to displace repairers, and combine Dream World with Snares or Pallets to create favorable chase zones.

## What Strategic Problem It Solves

Rotation/Generator Control.

## Strategies It Supports

- [Rapid Rotation Pressure](rapid-rotation-pressure.md)

**Canonical support note:** Rotation/Generator Control.

## How It Changes Killer Decisions

Use unfinished generators as teleport anchors, project/cancel to displace repairers, and combine Dream World with Snares or Pallets to create favorable chase zones.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Use unfinished generators as teleport anchors, project/cancel to displace repairers, and combine Dream World with Snares or Pallets to create favorable chase zones**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Native teleport/objective implementation.

## Promotion Condition

Independent decision loop beyond broader families.

## Related Strategies

- [Rapid Rotation Pressure](rapid-rotation-pressure.md)

## Source Metadata

- **Canonical ID:** `KSTR-064`
- **Snapshot:** `KSTR-064@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
