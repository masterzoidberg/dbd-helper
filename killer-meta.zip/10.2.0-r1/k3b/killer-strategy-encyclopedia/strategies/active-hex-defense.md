---
canonicalId: "KSTR-027"
side: "KILLER"
name: "Active Hex Defense"
slug: "active-hex-defense"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "EMERGING"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-027@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: ["KSTR-070"]
rankingStatusGeneral: "UNRANKED"
rankingStatusSWF: "UNRANKED"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: 44
stabilityLabel: "VOLATILE"
trend: null
---

# Active Hex Defense

Preserve high-value Hex infrastructure by actively converting totem interactions into pressure.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | BROAD_ROSTER |
| Strategic orientation | CONTROL |
| Current status | EMERGING |
| General Matchmaking | Unranked |
| Coordinated SWF | Unranked |
| Meta Stability | 44 — VOLATILE |
| Skill Floor | 3/5 — Moderate |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 5/5 — Extreme |
| Opportunity Cost | 5/5 — Severe commitment/resources foregone |

> **UNRANKED:** This is a current, coherent Strategy, but K3A does not assign Power, Tier, or Ranking Index in the current environments.

## What This Strategy Is

**Active Hex Defense** is a Killer strategy built around this objective: **Preserve high-value Hex infrastructure by actively converting totem interactions into pressure**.

Its defining loop is **Establish Hex state → monitor/detect cleanse attempts → rotate/intercept → gain hooks → prolong/restore Hex value**.

**K3A independence rationale:** 10.2 produces a real active-defense loop, but evidence is too fresh for numerical Power.

## How It Plays

The practical decision loop is: **Establish Hex state → monitor/detect cleanse attempts → rotate/intercept → gain hooks → prolong/restore Hex value**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

**Material dependencies:** `MAP`, `RNG`, `RESOURCE_AVAILABILITY`, `TIMING`

**Canonical synergies:** mobility, Totem info, hook tempo

## Killer Fit

**Best Fits:** The Hag, The Demogorgon, The Wraith
**Strong Fits:** The Dredge, The Singularity
**Viable Fits:** The Doctor

**Canonical fit rationale:** Killer must actually contest cleanse windows; Hex perks alone do not qualify.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**Unranked.**

K3A intentionally leaves the Strategy without a numerical placement in this environment.

## Against Coordinated SWF

**Unranked.**

K3A intentionally leaves the Strategy without a numerical placement in this environment.

## Strengths


- Synergy: mobility
- Synergy: Totem info
- Synergy: hook tempo

## Weaknesses and Counterplay

- early cleanse windows
- split Totem pressure

## Map Considerations

**Material map factors:** Totem placement, size, LOS.

**Map Dependence:** 5/5 — Extreme.

## Skill Profile

- **Skill Floor:** 3/5 — Moderate
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 5/5 — Severe commitment/resources foregone
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 3/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 5/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**44 — VOLATILE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 10/25 |
| Core Mechanic Durability | 11/20 |
| Replacement Depth | 6/15 |
| Environmental Breadth | 7/15 |
| Counter-Meta Independence | 4/10 |
| Patch Durability | 6/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | LOW |
| General Matchmaking | LOW |
| Coordinated SWF | LOW |
| Compatibility | MEDIUM |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## What We Are Watching

**Missing evidence / research flags:**
- Stable builds, cleanse behavior, Totem-defense payoff and whether new Thrill ecology persists

**Uncertainty profile:** Power confidence `LOW`, General Matchmaking `LOW`, Coordinated SWF `LOW`.

**Recheck conditions:**
- Remain UNRANKED until a clean 10.2 evidence window and stable implementations exist

## Related Strategies

- [Passive Thrill Totem-Defense Form](passive-thrill-totem-defense-form.md)

## Source Metadata

- **Canonical ID:** `KSTR-027`
- **Snapshot:** `KSTR-027@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
| BHVR_PATCH_10_2_0 | Dead by Daylight 10.2.0 Mid-Chapter | 2026-10-06 | Official live Patch 10.2.0 mechanics. |
