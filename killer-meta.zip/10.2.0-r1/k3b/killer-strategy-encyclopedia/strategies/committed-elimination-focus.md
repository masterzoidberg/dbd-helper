---
canonicalId: "KSTR-009"
side: "KILLER"
name: "Committed Elimination Focus"
slug: "committed-elimination-focus"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "TEMPO"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-009@10.2.0-r1"
parentStrategyId: "KSTR-008"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 83
powerSWF: 77
tierGeneral: "A"
tierSWF: "B"
metaStability: 97
stabilityLabel: "VERY STABLE"
trend: null
---

# Committed Elimination Focus

Remove one Survivor earlier by persistently prioritizing that target.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META |
| Applicability scope | BROAD_ROSTER |
| Strategic orientation | TEMPO |
| Current status | ESTABLISHED |
| General Matchmaking | A — 83 |
| Coordinated SWF | B — 77 |
| Meta Stability | 97 — VERY STABLE |
| Skill Floor | 2/5 — intermediate canonical value |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 2/5 — intermediate canonical value |
| Opportunity Cost | 4/5 — intermediate canonical value |

## What This Strategy Is

**Committed Elimination Focus** is a Killer strategy built around this objective: **Remove one Survivor earlier by persistently prioritizing that target**.

Its defining loop is **Hook target → monitor rescue → re-acquire same target when feasible → accept some objective opportunity cost → repeat until elimination or commitment becomes untenable**.

**K3A independence rationale:** Sustained target commitment materially changes chase persistence, hook sequencing and pathing.

## How It Plays

The practical decision loop is: **Hook target → monitor rescue → re-acquire same target when feasible → accept some objective opportunity cost → repeat until elimination or commitment becomes untenable**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

**Material dependencies:** `TARGET_STATE`, `GAME_STATE`, `POSITIONING`, `TIMING`

**Canonical synergies:** chase conversion, mobility, rescue info

## Killer Fit

**Best Fits:** The Mastermind, The Spirit, The Ghoul
**Strong Fits:** The Wraith, The Demogorgon, The Clown
**Viable Fits:** The Doctor, The Nemesis, The Pig

**Canonical fit rationale:** Broad strategy; fit is re-acquisition/chase conversion.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**A — 83.**

Early removal is a direct win-condition accelerator when re-acquisition cost is controlled.

## Against Coordinated SWF

**B — 77.**

Bodyblocks, protection calls and Shoulder the Burden reduce reliability without removing elimination value.

## Why the Two Environments Differ

The canonical Power estimate changes from **83** in General Matchmaking to **77** against coordinated SWF (-6 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 7.5 → 6 (-1.5)
- **Matchup Coverage:** 8 → 6.5 (-1.5)
- **Consistency:** 8.5 → 7.5 (-1)
- **Agency:** 8.5 → 8 (-0.5)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Ceiling 9/10, Slot Efficiency 9/10, Tempo Efficiency 9/10, Agency 8.5/10.

- Synergy: chase conversion
- Synergy: mobility
- Synergy: rescue info

## Weaknesses and Counterplay

- Shoulder the Burden
- bodyblocks
- protection
- hiding

The lowest General Matchmaking Power dimensions are Counterplay Resilience 7.5/10, Recovery Value 7.5/10, Execution Reliability 8/10, Map Coverage 8/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** hooks, tile safety, size.

**Map Dependence:** 2/5 — intermediate canonical value.

**General Matchmaking Map Coverage:** 8/10.

## Skill Profile

- **Skill Floor:** 2/5 — intermediate canonical value
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 4/5 — intermediate canonical value
- **Execution Reliability, General Matchmaking:** 8/10
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 5/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**97 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 25/25 |
| Core Mechanic Durability | 20/20 |
| Replacement Depth | 15/15 |
| Environmental Breadth | 13/15 |
| Counter-Meta Independence | 9/10 |
| Patch Durability | 15/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | MEDIUM_HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Target Focus / Elimination Sequencing](target-focus-elimination-sequencing.md)

## Source Metadata

- **Canonical ID:** `KSTR-009`
- **Snapshot:** `KSTR-009@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
