---
canonicalId: "KSTR-060"
side: "KILLER"
name: "Leech / Form-Cycle Module"
slug: "leech-form-cycle-module"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-060@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Leech / Form-Cycle Module

Infect in Body Form, then switch to faster Head Form when infection makes whip conversion more favorable.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Infect in Body Form, then switch to faster Head Form when infection makes whip conversion more favorable.

**Decision loop:** Infect in Body Form, then switch to faster Head Form when infection makes whip conversion more favorable.

## What Strategic Problem It Solves

chase conversion.

## Strategies It Supports


**Canonical support note:** chase conversion.

## How It Changes Killer Decisions

Infect in Body Form, then switch to faster Head Form when infection makes whip conversion more favorable.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Infect in Body Form, then switch to faster Head Form when infection makes whip conversion more favorable**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Native Power execution.

## Promotion Condition

Independent macro target-state economy demonstrated.

## Related Strategies

No additional canonical Strategy relationships are established in K3A.

## Source Metadata

- **Canonical ID:** `KSTR-060`
- **Snapshot:** `KSTR-060@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
