---
canonicalId: "KSTR-053"
side: "KILLER"
name: "Madness / Interaction Disruption"
slug: "madness-interaction-disruption"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-053@10.2.0-r1"
parentStrategyId: "KSTR-031"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Madness / Interaction Disruption

Repeatedly build Madness, use shocks to reveal/disrupt, exploit impaired interactions and skill checks, then collapse on located targets.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Repeatedly build Madness, use shocks to reveal/disrupt, exploit impaired interactions and skill checks, then collapse on located targets.

**Decision loop:** Repeatedly build Madness, use shocks to reveal/disrupt, exploit impaired interactions and skill checks, then collapse on located targets.

## What Strategic Problem It Solves

info/skill-check/chase.

## Strategies It Supports

- [Skill-Check / Interaction Pressure](skill-check-interaction-pressure.md)

**Canonical support note:** info/skill-check/chase.

## How It Changes Killer Decisions

Repeatedly build Madness, use shocks to reveal/disrupt, exploit impaired interactions and skill checks, then collapse on located targets.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Repeatedly build Madness, use shocks to reveal/disrupt, exploit impaired interactions and skill checks, then collapse on located targets**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Persistent native state but not independent macro plan.

## Promotion Condition

Distinct Madness-economy target loop demonstrated.

## Related Strategies

- [Skill-Check / Interaction Pressure](skill-check-interaction-pressure.md)

## Source Metadata

- **Canonical ID:** `KSTR-053`
- **Snapshot:** `KSTR-053@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
