---
canonicalId: "KSTR-039"
side: "KILLER"
name: "Condemn Pressure"
slug: "condemn-pressure"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-039@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 78
powerSWF: 65
tierGeneral: "A"
tierSWF: "C"
metaStability: 79
stabilityLabel: "STABLE"
trend: null
---

# Condemn Pressure

Teleport frequently, create Condemned stacks, identify high-Condemned targets, force tape/TV interactions, convert max Condemned into alternate kill pressure.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | KILLER_SPECIFIC |
| Strategic orientation | Not established |
| Current status | ESTABLISHED |
| General Matchmaking | A — 78 |
| Coordinated SWF | C — 65 |
| Meta Stability | 79 — STABLE |
| Skill Floor | 4/5 — intermediate canonical value |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 3/5 — Material |
| Opportunity Cost | 4/5 — intermediate canonical value |

## What This Strategy Is

**Condemn Pressure** is a Killer strategy built around this objective: **Teleport frequently, create Condemned stacks, identify high-Condemned targets, force tape/TV interactions, convert max Condemned into alternate kill pressure**.

Its defining loop is **Teleport frequently, create Condemned stacks, identify high-Condemned targets, force tape/TV interactions, convert max Condemned into alternate kill pressure**.

**K3A independence rationale:** Condemned/tape/TV management creates an alternate elimination axis.

## How It Plays

The practical decision loop is: **Teleport frequently, create Condemned stacks, identify high-Condemned targets, force tape/TV interactions, convert max Condemned into alternate kill pressure**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

**Material dependencies:** `KILLER_POWER`, `TARGET_STATE`, `OPPONENT_BEHAVIOR`, `TIMING`

**Canonical synergies:** rotation, target focus

## Killer Fit

**Best Fits:** The Onryō

**Canonical fit rationale:** TVs/tapes/Condemned required.

**Global exclusion:** all other Killers are `INCOMPATIBLE` for this Strategy. TVs/tapes/Condemned required.

## General Matchmaking

**A — 78.**

Public teams are comparatively vulnerable to uneven tape/TV management and target-state mistakes.

## Against Coordinated SWF

**C — 65.**

Tape ownership and high-Condemned target state are much easier to communicate.

## Why the Two Environments Differ

The canonical Power estimate changes from **78** in General Matchmaking to **65** against coordinated SWF (-13 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 7 → 4.5 (-2.5)
- **Matchup Coverage:** 7.5 → 5 (-2.5)
- **Consistency:** 7 → 5 (-2)
- **Tempo Efficiency:** 8 → 6 (-2)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 9.5/10, Slot Efficiency 9.5/10, Ceiling 8.5/10, Snowball Value 8/10.

- Synergy: rotation
- Synergy: target focus

## Weaknesses and Counterplay

- tape assignments
- TV management
- Condemn calls

The lowest General Matchmaking Power dimensions are Consistency 7/10, Counterplay Resilience 7/10, Execution Reliability 7/10, Agency 7.5/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** TV distribution, size.

**Map Dependence:** 3/5 — Material.

**General Matchmaking Map Coverage:** 7.5/10.

## Skill Profile

- **Skill Floor:** 4/5 — intermediate canonical value
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 4/5 — intermediate canonical value
- **Execution Reliability, General Matchmaking:** 7/10
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 5/5 |
| Activation Reliability | 3/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 4/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**79 — STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 22/25 |
| Core Mechanic Durability | 17/20 |
| Replacement Depth | 11/15 |
| Environmental Breadth | 10/15 |
| Counter-Meta Independence | 7/10 |
| Patch Durability | 12/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM |
| General Matchmaking | MEDIUM |
| Coordinated SWF | LOW_MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

No additional canonical Strategy relationships are established in K3A.

## Source Metadata

- **Canonical ID:** `KSTR-039`
- **Snapshot:** `KSTR-039@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
