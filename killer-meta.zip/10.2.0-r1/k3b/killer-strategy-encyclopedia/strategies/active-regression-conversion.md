---
canonicalId: "KSTR-002"
side: "KILLER"
name: "Active Regression Conversion"
slug: "active-regression-conversion"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-002@10.2.0-r1"
parentStrategyId: "KSTR-001"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 79
powerSWF: 76
tierGeneral: "A"
tierSWF: "B"
metaStability: 89
stabilityLabel: "VERY STABLE"
trend: null
---

# Active Regression Conversion

Turn Killer actions into meaningful loss of repaired progress.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META |
| Applicability scope | BROAD_ROSTER |
| Strategic orientation | CONTROL |
| Current status | ESTABLISHED |
| General Matchmaking | A — 79 |
| Coordinated SWF | B — 76 |
| Meta Stability | 89 — VERY STABLE |
| Skill Floor | 2/5 — intermediate canonical value |
| Skill Ceiling | 4/5 — intermediate canonical value |
| Map Dependence | 2/5 — intermediate canonical value |
| Opportunity Cost | 3/5 — Meaningful tradeoff |

## What This Strategy Is

**Active Regression Conversion** is a Killer strategy built around this objective: **Turn Killer actions into meaningful loss of repaired progress**.

Its defining loop is **Create chase/down/hook window → identify high-value repair → trigger/kick regression → force Survivors back → repeat**.

**K3A independence rationale:** Persistent regression-conversion loop survives removal of exact perk names.

## How It Plays

The practical decision loop is: **Create chase/down/hook window → identify high-value repair → trigger/kick regression → force Survivors back → repeat**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 3/5 — Meaningful.

## When It Works Best

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

**Material dependencies:** `GAME_STATE`, `POSITIONING`, `TIMING`

**Canonical synergies:** mobility, info, hook conversion

## Killer Fit

**Best Fits:** The Wraith, The Demogorgon
**Strong Fits:** The Dredge, The Mastermind, The Doctor
**Viable Fits:** The Nemesis, The Clown, The Legion

**Canonical fit rationale:** Scored around ordinary compatible Killers, not elite mobility outliers.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**A — 79.**

Reliable objective conversion with broad replacement depth; bounded by current regression rules.

## Against Coordinated SWF

**B — 76.**

Coordinated splitting and pre-running lower conversion, but regression remains a direct and largely information-independent control tool.

## Why the Two Environments Differ

The canonical Power estimate changes from **79** in General Matchmaking to **76** against coordinated SWF (-3 points).

The largest canonical dimension shifts are:
- **Consistency:** 8.5 → 8 (-0.5)
- **Counterplay Resilience:** 7.5 → 7 (-0.5)
- **Matchup Coverage:** 8 → 7.5 (-0.5)
- **Recovery Value:** 7.5 → 7 (-0.5)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Agency 8.5/10, Consistency 8.5/10, Tempo Efficiency 8.5/10, Ceiling 8/10.

- Synergy: mobility
- Synergy: info
- Synergy: hook conversion

## Weaknesses and Counterplay

- split repair
- pre-run
- regression caps

The lowest General Matchmaking Power dimensions are Snowball Value 6.5/10, Slot Efficiency 7/10, Counterplay Resilience 7.5/10, Map Coverage 7.5/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** gen spacing, size, verticality.

**Map Dependence:** 2/5 — intermediate canonical value.

**General Matchmaking Map Coverage:** 7.5/10.

## Skill Profile

- **Skill Floor:** 2/5 — intermediate canonical value
- **Skill Ceiling:** 4/5 — intermediate canonical value
- **Opportunity Cost:** 3/5 — Meaningful tradeoff
- **Execution Reliability, General Matchmaking:** 8/10
- **Strategic Commitment:** 3/5 — Meaningful

## Build and Add-on Ecosystem

**Canonical perk ecosystem:** Pop Goes the Weasel, Corrupt Intervention, Eruption, Pain Resonance

Names are preserved from the K2 representative implementation; canonical perk IDs were not supplied here and are intentionally null.

## Representative Implementations

### Concrete Build — `KSTR-002-B01`

- **Killer:** The Wraith
- **Environment:** `KILLER_GENERAL_MATCHMAKING`
- **Perks:** Pop Goes the Weasel, Corrupt Intervention, Eruption, Pain Resonance
- **Implementation:** Observed mixed-window example: Pop Goes the Weasel + Corrupt Intervention + Eruption + Pain Resonance; no mandatory add-on/offering
- **Rationale:** K1 recorded this as a tracked four-perk implementation since 10.1, not as clean 10.2 strategy telemetry.
- **Strengths:** Multiple objective-conversion triggers
- **Weaknesses:** Mixed-patch evidence; a loadout does not itself prove the Strategy
- **Confidence:** MEDIUM
- **Content validity:** MIXED_PATCH_OBSERVED

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 5/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 4/5 |
| Denial Risk | 2/5 |
| Strategic Commitment | 3/5 |

## Meta Stability

**89 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 23/25 |
| Core Mechanic Durability | 18/20 |
| Replacement Depth | 14/15 |
| Environmental Breadth | 13/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 13/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | MEDIUM_HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Generator Control](generator-control.md)

## Source Metadata

- **Canonical ID:** `KSTR-002`
- **Snapshot:** `KSTR-002@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
