---
canonicalId: "KSTR-033"
side: "KILLER"
name: "Basic-Attack Tempo Framework"
slug: "basic-attack-tempo-framework"
pageType: "MECHANIC_CENTERED_BUILD"
structuralClassification: "MECHANIC-CENTERED BUILD"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "TEMPO"
currentStatus: "EMERGING"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-033@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Basic-Attack Tempo Framework

Repeatedly reduce M1 chase and hit-recovery friction.

> **Mechanic-Centered Build:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What the Build Family Is

**Core mechanic/idea:** Repeatedly reduce M1 chase and hit-recovery friction.

**Canonical loop:** Take M1-oriented chases → exploit faster vault/break/hit-recovery/Haste windows → chain next contact.

## Typical Strategic Uses

chase/rotation.

## Strategies It Supports


**Canonical support note:** chase/rotation.

## How It Changes Gameplay

Take M1-oriented chases → exploit faster vault/break/hit-recovery/Haste windows → chain next contact.

## Killer / Power Interaction

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

The canonical decision loop depends on: **Take M1-oriented chases → exploit faster vault/break/hit-recovery/Haste windows → chain next contact**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not a Standalone Strategy

10.2 M1 package does not determine macro objective.

## Promotion Condition

Stable full-match M1-specific strategic loop.

## Related Strategies

No additional canonical Strategy relationships are established in K3A.

## Source Metadata

- **Canonical ID:** `KSTR-033`
- **Snapshot:** `KSTR-033@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
| BHVR_PATCH_10_2_0 | Dead by Daylight 10.2.0 Mid-Chapter | 2026-10-06 | Official live Patch 10.2.0 mechanics. |
