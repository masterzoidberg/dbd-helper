---
canonicalId: "KSTR-058"
side: "KILLER"
name: "Security-Door Rotation / Ambush Module"
slug: "security-door-rotation-ambush-module"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-058@10.2.0-r1"
parentStrategyId: "KSTR-026"
relatedStrategyIds: ["KSTR-017", "KSTR-022", "KSTR-026", "KSTR-057", "KSTR-058"]
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Security-Door Rotation / Ambush Module

Use Security Doors as a recurring rotation and ambush support loop rather than as an independent macro-strategy.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Compress traversal and create surprise/contested-door pressure through the Security-Door network.

**Decision loop:** Select a Security Door route → traverse toward an objective or target → convert arrival into rotation or ambush pressure → reroute.

## What Strategic Problem It Solves

Rapid Rotation/Ambush/injury.

## Strategies It Supports

- [Rapid Rotation Pressure](rapid-rotation-pressure.md)
- [Hit-and-Run Injury Attrition](hit-and-run-injury-attrition.md)
- [Ambush Rotation](ambush-rotation.md)
- [Axe-Impale Attrition Module](axe-impale-attrition-module.md)

**Canonical support note:** Rapid Rotation/Ambush/injury.

## How It Changes Killer Decisions

Select a Security Door route → traverse toward an objective or target → convert arrival into rotation or ambush pressure → reroute.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Select a Security Door route → traverse toward an objective or target → convert arrival into rotation or ambush pressure → reroute.**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

K1 combined two separable mechanics.

## Promotion Condition

One component proves independent macro plan.

## Related Strategies

- [Rapid Rotation Pressure](rapid-rotation-pressure.md)
- [Hit-and-Run Injury Attrition](hit-and-run-injury-attrition.md)
- [Ambush Rotation](ambush-rotation.md)
- [Axe-Impale Attrition Module](axe-impale-attrition-module.md)

## Source Metadata

- **Canonical ID:** `KSTR-058`
- **Snapshot:** `KSTR-058@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
