---
canonicalId: "KSTR-038"
side: "KILLER"
name: "Reverse-Bear-Trap Objective Tax"
slug: "reverse-bear-trap-objective-tax"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-038@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 73
powerSWF: 62
tierGeneral: "B"
tierSWF: "C"
metaStability: 83
stabilityLabel: "STABLE"
trend: null
---

# Reverse-Bear-Trap Objective Tax

Spend finite traps on downed Survivors, then manipulate generator-completion timing and target selection around active trap side objectives.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | KILLER_SPECIFIC |
| Strategic orientation | Not established |
| Current status | ESTABLISHED |
| General Matchmaking | B — 73 |
| Coordinated SWF | C — 62 |
| Meta Stability | 83 — STABLE |
| Skill Floor | 3/5 — Moderate |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 3/5 — Material |
| Opportunity Cost | 3/5 — Meaningful tradeoff |

## What This Strategy Is

**Reverse-Bear-Trap Objective Tax** is a Killer strategy built around this objective: **Spend finite traps on downed Survivors, then manipulate generator-completion timing and target selection around active trap side objectives**.

Its defining loop is **Spend finite traps on downed Survivors, then manipulate generator-completion timing and target selection around active trap side objectives**.

**K3A independence rationale:** Finite trap allocation and generator timing create a distinct side-objective economy.

## How It Plays

The practical decision loop is: **Spend finite traps on downed Survivors, then manipulate generator-completion timing and target selection around active trap side objectives**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 4/5 — intermediate canonical value.

## When It Works Best

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

**Material dependencies:** `KILLER_POWER`, `RESOURCE_AVAILABILITY`, `OPPONENT_BEHAVIOR`, `GAME_STATE`

**Canonical synergies:** gen pressure, info, Video Tape

## Killer Fit

**Best Fits:** The Pig

**Canonical fit rationale:** Reverse Bear Traps/Jigsaw Boxes required.

**Global exclusion:** all other Killers are `INCOMPATIBLE` for this Strategy. Reverse Bear Traps/Jigsaw Boxes required.

## General Matchmaking

**B — 73.**

Side-objective time is reliable, but trap conversion is partly Survivor-controlled.

## Against Coordinated SWF

**C — 62.**

Side-objective time remains real, but role assignment and generator-timing calls reduce wasted movement.

## Why the Two Environments Differ

The canonical Power estimate changes from **73** in General Matchmaking to **62** against coordinated SWF (-11 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 6.5 → 4.5 (-2)
- **Matchup Coverage:** 7 → 5 (-2)
- **Consistency:** 6.5 → 5 (-1.5)
- **Recovery Value:** 6.5 → 5 (-1.5)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 9.5/10, Slot Efficiency 9.5/10, Map Coverage 8/10, Ceiling 7.5/10.

- Synergy: gen pressure
- Synergy: info
- Synergy: Video Tape

## Weaknesses and Counterplay

- generator timing
- efficient searches
- role assignment

The lowest General Matchmaking Power dimensions are Consistency 6.5/10, Counterplay Resilience 6.5/10, Recovery Value 6.5/10, Tempo Efficiency 6.5/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** Box routes, size.

**Map Dependence:** 3/5 — Material.

**General Matchmaking Map Coverage:** 8/10.

## Skill Profile

- **Skill Floor:** 3/5 — Moderate
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 3/5 — Meaningful tradeoff
- **Execution Reliability, General Matchmaking:** 7.5/10
- **Strategic Commitment:** 4/5 — intermediate canonical value

## Build and Add-on Ecosystem

**Canonical add-on ecosystem:**
- **Video Tape** — SUBTYPE ENABLER: All Survivors start with RBTs, front-loading the same Objective-Tax strategy rather than creating another one.

## Representative Implementations

### Addon Variant — `KSTR-038-B01`

- **Killer:** The Pig
- **Environment:** `KILLER_GENERAL_MATCHMAKING`
- **Add-ons:** Video Tape
- **Implementation:** Add-on variant: Video Tape; perks flexible
- **Rationale:** Front-loads RBT side-objectives while preserving the same strategy
- **Strengths:** Immediate objective tax
- **Weaknesses:** Coordinated teams can assign roles
- **Confidence:** HIGH
- **Content validity:** LIVE_10_2_SOURCE_SUPPORTED

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 4/5 |
| Denial Risk | 4/5 |
| Strategic Commitment | 4/5 |

## Meta Stability

**83 — STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 23/25 |
| Core Mechanic Durability | 18/20 |
| Replacement Depth | 12/15 |
| Environmental Breadth | 10/15 |
| Counter-Meta Independence | 7/10 |
| Patch Durability | 13/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM |
| General Matchmaking | MEDIUM |
| Coordinated SWF | LOW_MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

No additional canonical Strategy relationships are established in K3A.

## Source Metadata

- **Canonical ID:** `KSTR-038`
- **Snapshot:** `KSTR-038@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
