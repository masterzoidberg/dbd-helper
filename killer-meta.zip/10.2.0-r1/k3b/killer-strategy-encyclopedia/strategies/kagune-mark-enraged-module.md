---
canonicalId: "KSTR-062"
side: "KILLER"
name: "Kagune-Mark / Enraged Module"
slug: "kagune-mark-enraged-module"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-062@10.2.0-r1"
parentStrategyId: "KSTR-026"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Kagune-Mark / Enraged Module

Acquire a Mark through a second leap grab, then preserve/refresh the marked state to maintain enhanced three-leap mobility and conversion potential.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Acquire a Mark through a second leap grab, then preserve/refresh the marked state to maintain enhanced three-leap mobility and conversion potential.

**Decision loop:** Acquire a Mark through a second leap grab, then preserve/refresh the marked state to maintain enhanced three-leap mobility and conversion potential.

## What Strategic Problem It Solves

Rotation/chase.

## Strategies It Supports

- [Rapid Rotation Pressure](rapid-rotation-pressure.md)

**Canonical support note:** Rotation/chase.

## How It Changes Killer Decisions

Acquire a Mark through a second leap grab, then preserve/refresh the marked state to maintain enhanced three-leap mobility and conversion potential.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Acquire a Mark through a second leap grab, then preserve/refresh the marked state to maintain enhanced three-leap mobility and conversion potential**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Native Power optimization.

## Promotion Condition

Macro plan independent of Power use demonstrated.

## Related Strategies

- [Rapid Rotation Pressure](rapid-rotation-pressure.md)

## Source Metadata

- **Canonical ID:** `KSTR-062`
- **Snapshot:** `KSTR-062@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
