---
canonicalId: "KSTR-018"
side: "KILLER"
name: "Healing Suppression"
slug: "healing-suppression"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-018@10.2.0-r1"
parentStrategyId: "KSTR-017"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Healing Suppression

Raise time/risk cost of healing.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Raise time/risk cost of healing.

**Decision loop:** Apply injury → create slower/unsafe healing conditions → use recovered time/info to pressure elsewhere.

## What Strategic Problem It Solves

Hit-and-Run, injury strategies.

## Strategies It Supports

- [Hit-and-Run Injury Attrition](hit-and-run-injury-attrition.md)

**Canonical support note:** Hit-and-Run, injury strategies.

## How It Changes Killer Decisions

Apply injury → create slower/unsafe healing conditions → use recovered time/info to pressure elsewhere.

## Killer / Power Interaction

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

The canonical decision loop depends on: **Apply injury → create slower/unsafe healing conditions → use recovered time/info to pressure elsewhere**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Changes healing economics only.

## Promotion Condition

Independent target/movement/payoff cycle.

## Related Strategies

- [Hit-and-Run Injury Attrition](hit-and-run-injury-attrition.md)

## Source Metadata

- **Canonical ID:** `KSTR-018`
- **Snapshot:** `KSTR-018@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
