---
canonicalId: "KSTR-022"
side: "KILLER"
name: "Ambush Rotation"
slug: "ambush-rotation"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META"
applicabilityScope: "POWER_FAMILY"
strategicOrientation: "TEMPO"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-022@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: ["KSTR-036", "KSTR-050", "KSTR-059", "KSTR-065"]
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 74
powerSWF: 60
tierGeneral: "B"
tierSWF: "C"
metaStability: 85
stabilityLabel: "VERY STABLE"
trend: null
---

# Ambush Rotation

Repeatedly convert information denial into cheap first hits/downs.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META |
| Applicability scope | POWER_FAMILY |
| Strategic orientation | TEMPO |
| Current status | ESTABLISHED |
| General Matchmaking | B — 74 |
| Coordinated SWF | C — 60 |
| Meta Stability | 85 — VERY STABLE |
| Skill Floor | 3/5 — Moderate |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 4/5 — intermediate canonical value |
| Opportunity Cost | 3/5 — Meaningful tradeoff |

## What This Strategy Is

**Ambush Rotation** is a Killer strategy built around this objective: **Repeatedly convert information denial into cheap first hits/downs**.

Its defining loop is **Conceal approach → hit/mark/pressure before normal chase develops → decide quickly whether to finish → disappear/rotate → repeat**.

**K3A independence rationale:** Hidden approach plus deliberately short visible commitments forms a coherent recurring plan.

## How It Plays

The practical decision loop is: **Conceal approach → hit/mark/pressure before normal chase develops → decide quickly whether to finish → disappear/rotate → repeat**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 4/5 — intermediate canonical value.

## When It Works Best

This plan depends on a family of native Power qualities. A superficially similar Power is not automatically enough for compatibility.

**Material dependencies:** `KILLER_POWER`, `MAP`, `OPPONENT_BEHAVIOR`, `POSITIONING`

**Canonical synergies:** stealth, mobility, info denial

## Killer Fit

**Best Fits:** The Ghost Face, The Wraith, The Dredge
**Strong Fits:** The Onryō, The Good Guy, The Slasher, The Xenomorph
**Viable Fits:** The Animatronic
**Weak Fits:** The Huntress

**Canonical fit rationale:** Native approach denial must repeatedly reduce warning.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**B — 74.**

Public information gaps make hidden approach and fast disengagement valuable.

## Against Coordinated SWF

**C — 60.**

Four-player Killer-location callouts directly attack information asymmetry.

## Why the Two Environments Differ

The canonical Power estimate changes from **74** in General Matchmaking to **60** against coordinated SWF (-14 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 6 → 3.5 (-2.5)
- **Matchup Coverage:** 7 → 4.5 (-2.5)
- **Consistency:** 7 → 5 (-2)
- **Tempo Efficiency:** 8 → 6 (-2)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 9/10, Slot Efficiency 8.5/10, Ceiling 8/10, Tempo Efficiency 8/10.

- Synergy: stealth
- Synergy: mobility
- Synergy: info denial

## Weaknesses and Counterplay

- callouts
- pre-run
- open maps

The lowest General Matchmaking Power dimensions are Counterplay Resilience 6/10, Recovery Value 6.5/10, Consistency 7/10, Execution Reliability 7/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** LOS, indoor/outdoor, cover.

**Map Dependence:** 4/5 — intermediate canonical value.

**General Matchmaking Map Coverage:** 7/10.

## Skill Profile

- **Skill Floor:** 3/5 — Moderate
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 3/5 — Meaningful tradeoff
- **Execution Reliability, General Matchmaking:** 7/10
- **Strategic Commitment:** 4/5 — intermediate canonical value

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 4/5 |
| Denial Risk | 4/5 |
| Strategic Commitment | 4/5 |

## Meta Stability

**85 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 23/25 |
| Core Mechanic Durability | 18/20 |
| Replacement Depth | 13/15 |
| Environmental Breadth | 11/15 |
| Counter-Meta Independence | 7/10 |
| Patch Durability | 13/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Stalk-to-Expose Ambush](stalk-to-expose-ambush.md)
- [Locker / Nightfall Rotation Module](locker-nightfall-rotation-module.md)
- [Omnipresent-Evil Ambush Module](omnipresent-evil-ambush-module.md)
- [Scratched-Mirror Ambush](scratched-mirror-ambush.md)

## Source Metadata

- **Canonical ID:** `KSTR-022`
- **Snapshot:** `KSTR-022@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
