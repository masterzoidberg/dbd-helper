---
canonicalId: "KSTR-054"
side: "KILLER"
name: "Feral-Frenzy Injury-Spread Module"
slug: "feral-frenzy-injury-spread-module"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-054@10.2.0-r1"
parentStrategyId: "KSTR-017"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Feral-Frenzy Injury-Spread Module

Enter Frenzy to tag multiple Survivors, distribute Deep Wound/injury, use revealed positions to chain contacts, then leave Frenzy and convert unresolved states.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Enter Frenzy to tag multiple Survivors, distribute Deep Wound/injury, use revealed positions to chain contacts, then leave Frenzy and convert unresolved states.

**Decision loop:** Enter Frenzy to tag multiple Survivors, distribute Deep Wound/injury, use revealed positions to chain contacts, then leave Frenzy and convert unresolved states.

## What Strategic Problem It Solves

Hit-and-Run.

## Strategies It Supports

- [Hit-and-Run Injury Attrition](hit-and-run-injury-attrition.md)

**Canonical support note:** Hit-and-Run.

## How It Changes Killer Decisions

Enter Frenzy to tag multiple Survivors, distribute Deep Wound/injury, use revealed positions to chain contacts, then leave Frenzy and convert unresolved states.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Enter Frenzy to tag multiple Survivors, distribute Deep Wound/injury, use revealed positions to chain contacts, then leave Frenzy and convert unresolved states**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Native implementation.

## Promotion Condition

Strategy-level loop differing materially from Hit-and-Run.

## Related Strategies

- [Hit-and-Run Injury Attrition](hit-and-run-injury-attrition.md)

## Source Metadata

- **Canonical ID:** `KSTR-054`
- **Snapshot:** `KSTR-054@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
