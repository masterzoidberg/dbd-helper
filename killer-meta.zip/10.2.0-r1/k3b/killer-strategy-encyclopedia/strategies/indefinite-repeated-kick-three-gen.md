---
canonicalId: "KSTR-035"
side: "KILLER"
name: "Indefinite Repeated-Kick Three-Gen"
slug: "indefinite-repeated-kick-three-gen"
pageType: "LEGACY"
structuralClassification: "META SUBTYPE"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "LEGACY"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-035@10.2.0-r1"
parentStrategyId: "KSTR-001"
relatedStrategyIds: ["KSTR-005"]
childStrategyIds: []
rankingStatusGeneral: "NOT_CURRENT"
rankingStatusSWF: "NOT_CURRENT"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Indefinite Repeated-Kick Three-Gen

> **LEGACY — Not Current on Patch 10.2.0-r1**

Recycle regression indefinitely on same cluster.

## What It Was

Recycle regression indefinitely on same cluster

## How It Played

Recycle regression indefinitely on same cluster.

## Why It Is No Longer Current

Current regression-event limit prevents indefinite loop

**Transition:** Anti-three-gen system.

## What Replaced It

- [Generator-Cluster Defense](generator-cluster-defense.md)

**Canonical successor note:** Generator-Cluster Defense.

## Terminology Warning

“Three-gen” does not automatically mean the old infinite-kick implementation.

## Current Ranking Status

Both current environments are `NOT_CURRENT`. Power, Tier, and Ranking Index are intentionally null.

## Source Metadata

- **Canonical ID:** `KSTR-035`
- **Snapshot:** `KSTR-035@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
| BHVR_PATCH_10_2_0 | Dead by Daylight 10.2.0 Mid-Chapter | 2026-10-06 | Official live Patch 10.2.0 mechanics. |
