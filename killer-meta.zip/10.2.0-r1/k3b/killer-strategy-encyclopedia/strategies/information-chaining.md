---
canonicalId: "KSTR-021"
side: "KILLER"
name: "Information Chaining"
slug: "information-chaining"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "TEMPO"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-021@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: ["KSTR-052", "KSTR-063"]
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Information Chaining

Minimize search time and continuously route into useful contacts.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Minimize search time and continuously route into useful contacts.

**Decision loop:** Trigger information → select best target/objective → move immediately → trigger next read → chain pressure.

## What Strategic Problem It Solves

Rotation, Chain-Down, Ambush.

## Strategies It Supports


**Canonical support note:** Rotation, Chain-Down, Ambush.

## How It Changes Killer Decisions

Trigger information → select best target/objective → move immediately → trigger next read → chain pressure.

## Killer / Power Interaction

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

The canonical decision loop depends on: **Trigger information → select best target/objective → move immediately → trigger next read → chain pressure**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Information is input, not win state.

## Promotion Condition

Independent routing plan with unique costs/counterplay shown.

## Related Strategies

- [Crow Zoning / Remote Probe](crow-zoning-remote-probe.md)
- [Search-to-Chase Routing Module](search-to-chase-routing-module.md)

## Source Metadata

- **Canonical ID:** `KSTR-021`
- **Snapshot:** `KSTR-021@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
