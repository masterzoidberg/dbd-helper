---
canonicalId: "KSTR-014"
side: "KILLER"
name: "Basement / Fixed-Anchor Control"
slug: "basement-fixed-anchor-control"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-014@10.2.0-r1"
parentStrategyId: "KSTR-011"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 71
powerSWF: 63
tierGeneral: "B"
tierSWF: "C"
metaStability: 84
stabilityLabel: "STABLE"
trend: null
---

# Basement / Fixed-Anchor Control

Convert a very defensible hook zone into repeated rescue pressure.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | BROAD_ROSTER |
| Strategic orientation | CONTROL |
| Current status | ESTABLISHED |
| General Matchmaking | B — 71 |
| Coordinated SWF | C — 63 |
| Meta Stability | 84 — STABLE |
| Skill Floor | 3/5 — Moderate |
| Skill Ceiling | 4/5 — intermediate canonical value |
| Map Dependence | 5/5 — Extreme |
| Opportunity Cost | 5/5 — Severe commitment/resources foregone |

## What This Strategy Is

**Basement / Fixed-Anchor Control** is a Killer strategy built around this objective: **Convert a very defensible hook zone into repeated rescue pressure**.

Its defining loop is **Transport to anchor → control exits/approaches → force high-risk rescues/trades → re-hook or convert nearby targets**.

**K3A independence rationale:** Hook-destination investment and fixed-zone defense create a persistent niche loop.

## How It Plays

The practical decision loop is: **Transport to anchor → control exits/approaches → force high-risk rescues/trades → re-hook or convert nearby targets**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

**Material dependencies:** `MAP`, `RNG`, `POSITIONING`, `GAME_STATE`

**Canonical synergies:** carry, traps, high rescue threat

## Killer Fit

**Best Fits:** The Trapper, The Hag, The Cannibal
**Strong Fits:** The Knight, The Demogorgon, The Huntress
**Viable Fits:** The Doctor

**Canonical fit rationale:** Requires transport feasibility and anchor geometry.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**B — 71.**

High anchor payoff but severe transport, layout and opportunity-cost constraints.

## Against Coordinated SWF

**C — 63.**

Coordinated teams better avoid bad chase zones and execute transport denial/rescues.

## Why the Two Environments Differ

The canonical Power estimate changes from **71** in General Matchmaking to **63** against coordinated SWF (-8 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 7 → 5.5 (-1.5)
- **Matchup Coverage:** 7.5 → 6 (-1.5)
- **Consistency:** 6.5 → 5.5 (-1)
- **Recovery Value:** 7 → 6 (-1)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Ceiling 9/10, Snowball Value 9/10, Power Integration 8/10, Matchup Coverage 7.5/10.

- Synergy: carry
- Synergy: traps
- Synergy: high rescue threat

## Weaknesses and Counterplay

- avoid area
- bodyblock/sabotage transport
- coordinated rescue

The lowest General Matchmaking Power dimensions are Map Coverage 5/10, Agency 6.5/10, Consistency 6.5/10, Execution Reliability 6.5/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** basement location, access, nearby objective.

**Map Dependence:** 5/5 — Extreme.

**General Matchmaking Map Coverage:** 5/10.

## Skill Profile

- **Skill Floor:** 3/5 — Moderate
- **Skill Ceiling:** 4/5 — intermediate canonical value
- **Opportunity Cost:** 5/5 — Severe commitment/resources foregone
- **Execution Reliability, General Matchmaking:** 6.5/10
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 2/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 4/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**84 — STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 23/25 |
| Core Mechanic Durability | 19/20 |
| Replacement Depth | 13/15 |
| Environmental Breadth | 8/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 13/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM |
| General Matchmaking | MEDIUM |
| Coordinated SWF | LOW_MEDIUM |
| Compatibility | MEDIUM_HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Hook-Zone / Rescue Pressure](hook-zone-rescue-pressure.md)

## Source Metadata

- **Canonical ID:** `KSTR-014`
- **Snapshot:** `KSTR-014@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
