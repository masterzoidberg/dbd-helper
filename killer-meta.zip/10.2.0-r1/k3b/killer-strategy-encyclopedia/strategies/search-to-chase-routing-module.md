---
canonicalId: "KSTR-063"
side: "KILLER"
name: "Search-to-Chase Routing Module"
slug: "search-to-chase-routing-module"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-063@10.2.0-r1"
parentStrategyId: "KSTR-021"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Search-to-Chase Routing Module

Send Search along useful routes for detection/movement, then convert information into redirected Chase commands and drag/Hindered pressure.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Send Search along useful routes for detection/movement, then convert information into redirected Chase commands and drag/Hindered pressure.

**Decision loop:** Send Search along useful routes for detection/movement, then convert information into redirected Chase commands and drag/Hindered pressure.

## What Strategic Problem It Solves

Information/chase.

## Strategies It Supports

- [Information Chaining](information-chaining.md)

**Canonical support note:** Information/chase.

## How It Changes Killer Decisions

Send Search along useful routes for detection/movement, then convert information into redirected Chase commands and drag/Hindered pressure.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Send Search along useful routes for detection/movement, then convert information into redirected Chase commands and drag/Hindered pressure**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Routing input.

## Promotion Condition

Independent macro routing objective demonstrated.

## Related Strategies

- [Information Chaining](information-chaining.md)

## Source Metadata

- **Canonical ID:** `KSTR-063`
- **Snapshot:** `KSTR-063@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
