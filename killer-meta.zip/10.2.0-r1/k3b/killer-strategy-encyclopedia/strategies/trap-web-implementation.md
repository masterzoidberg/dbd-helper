---
canonicalId: "KSTR-044"
side: "KILLER"
name: "Trap-Web Implementation"
slug: "trap-web-implementation"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-044@10.2.0-r1"
parentStrategyId: "KSTR-024"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Trap-Web Implementation

Build a connected Phantasm Trap web around valuable routes/objectives, fight inside it, replace lost traps, teleport to triggers.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Build a connected Phantasm Trap web around valuable routes/objectives, fight inside it, replace lost traps, teleport to triggers.

**Decision loop:** Build a connected Phantasm Trap web around valuable routes/objectives, fight inside it, replace lost traps, teleport to triggers.

## What Strategic Problem It Solves

Setup-Zone.

## Strategies It Supports

- [Setup-Zone Lockdown](setup-zone-lockdown.md)

**Canonical support note:** Setup-Zone.

## How It Changes Killer Decisions

Build a connected Phantasm Trap web around valuable routes/objectives, fight inside it, replace lost traps, teleport to triggers.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Build a connected Phantasm Trap web around valuable routes/objectives, fight inside it, replace lost traps, teleport to triggers**.

## Perk / Add-on Ecosystem

**Canonical add-on ecosystem:**
- **Scarred Hand** — SUBTYPE ENABLER: Trap/Mud-Phantasm collision plus disabled teleport similarly transforms how the web converts territory, but not its strategic objective.
- **Mint Rag** — IMPLEMENTATION DETAIL, SUBTYPE ENABLER: Teleport to untripped traps changes network reaction flexibility; still Setup-Zone.

## Why It Is Not Independently Ranked

Same setup objective.

## Promotion Condition

Separate strategy beyond setup territory.

## Related Strategies

- [Setup-Zone Lockdown](setup-zone-lockdown.md)

## Source Metadata

- **Canonical ID:** `KSTR-044`
- **Snapshot:** `KSTR-044@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
