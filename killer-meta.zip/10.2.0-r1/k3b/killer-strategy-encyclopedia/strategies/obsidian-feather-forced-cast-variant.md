---
canonicalId: "KSTR-066"
side: "KILLER"
name: "Obsidian-Feather Forced-Cast Variant"
slug: "obsidian-feather-forced-cast-variant"
pageType: "MECHANIC_CENTERED_BUILD"
structuralClassification: "MECHANIC-CENTERED BUILD"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "EMERGING"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-066@10.2.0-r1"
parentStrategyId: "KSTR-056"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Obsidian-Feather Forced-Cast Variant

Trade manual-cast control for a higher-speed, shorter-control Divine Light pattern requiring different setup and prediction.

> **Mechanic-Centered Build:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What the Build Family Is

**Core mechanic/idea:** Trade manual-cast control for a higher-speed, shorter-control Divine Light pattern requiring different setup and prediction.

**Canonical loop:** Trade manual-cast control for a higher-speed, shorter-control Divine Light pattern requiring different setup and prediction.

## Typical Strategic Uses

Judgment.

## Strategies It Supports

- [Heresy / Exile / Zealous Sequencing](heresy-exile-zealous-sequencing.md)

**Canonical support note:** Judgment.

## How It Changes Gameplay

Trade manual-cast control for a higher-speed, shorter-control Divine Light pattern requiring different setup and prediction.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Trade manual-cast control for a higher-speed, shorter-control Divine Light pattern requiring different setup and prediction**.

## Perk / Add-on Ecosystem

**Canonical add-on ecosystem:**
- **Obsidian Feather** — IMPLEMENTATION DETAIL: Very transformative Divine Light handling, but its transformation is projectile execution rather than target/hook/objective policy.

## Why It Is Not a Standalone Strategy

Projectile-control transform only.

## Promotion Condition

Evidence it changes target/exile/map policy persistently.

## Related Strategies

- [Heresy / Exile / Zealous Sequencing](heresy-exile-zealous-sequencing.md)

## Source Metadata

- **Canonical ID:** `KSTR-066`
- **Snapshot:** `KSTR-066@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
| BHVR_PATCH_10_1_2A | Dead by Daylight 10.1.2a Hotfix | 2026-09-17 | K2 resolves The Judgment's live state in favor of the 10.1.2a hotfix. |
