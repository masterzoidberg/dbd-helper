---
canonicalId: "KSTR-071"
side: "KILLER"
name: "Historical Tombstone-Piece Direct-Kill Shape"
slug: "historical-tombstone-piece-direct-kill-shape"
pageType: "LEGACY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "LEGACY"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-071@10.2.0-r1"
parentStrategyId: "KSTR-036"
relatedStrategyIds: ["KSTR-036"]
childStrategyIds: []
rankingStatusGeneral: "NOT_CURRENT"
rankingStatusSWF: "NOT_CURRENT"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Historical Tombstone-Piece Direct-Kill Shape

> **LEGACY — Not Current on Patch 10.2.0-r1**

Directly kill a healthy/injured Survivor during Evil Within III.

## What It Was

Directly kill a healthy/injured Survivor during Evil Within III

## How It Played

Directly kill a healthy/injured Survivor during Evil Within III.

## Why It Is No Longer Current

Current Tombstone Piece instead grants Undetectable when Evil Incarnate activates; direct-kill text is historical.

**Transition:** Current Shape add-on redesign.

## What Replaced It

- [Stalk-to-Expose Ambush](stalk-to-expose-ambush.md)

**Canonical successor note:** Stalk-to-Expose Ambush/current Evil Incarnate implementations.

## Terminology Warning

“Tombstone Myers” is especially ambiguous because the historical direct-kill add-ons no longer match old guides.

## Current Ranking Status

Both current environments are `NOT_CURRENT`. Power, Tier, and Ranking Index are intentionally null.

## Current Add-on Clarification

**Canonical add-on ecosystem:**
- **Current Tombstone Piece** — REJECTED FALSE POSITIVE: No current direct-kill Strategy: the present add-on grants Undetectable after Evil Incarnate activates; direct-kill text belongs to its history.
- **Current Judith's Tombstone** — REJECTED FALSE POSITIVE: Current form refreshes/caps Evil Incarnate duration through hooking; its historical direct-kill form is not live.

## Source Metadata

- **Canonical ID:** `KSTR-071`
- **Snapshot:** `KSTR-071@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| BHVR_PATCH_10_2_0 | Dead by Daylight 10.2.0 Mid-Chapter | 2026-10-06 | Official live Patch 10.2.0 mechanics. |
