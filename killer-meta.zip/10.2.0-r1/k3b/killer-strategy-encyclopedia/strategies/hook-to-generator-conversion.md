---
canonicalId: "KSTR-003"
side: "KILLER"
name: "Hook-to-Generator Conversion"
slug: "hook-to-generator-conversion"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META SUBTYPE"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "HYBRID"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-003@10.2.0-r1"
parentStrategyId: "KSTR-001"
relatedStrategyIds: ["KSTR-026"]
childStrategyIds: []
rankingStatusGeneral: "PROVISIONAL"
rankingStatusSWF: "PROVISIONAL"
powerGeneral: 79
powerSWF: 75
tierGeneral: "A"
tierSWF: "B"
metaStability: 85
stabilityLabel: "VERY STABLE"
trend: null
---

# Hook-to-Generator Conversion

Make each hook generate immediate objective pressure.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META SUBTYPE |
| Applicability scope | BROAD_ROSTER |
| Strategic orientation | HYBRID |
| Current status | ESTABLISHED |
| General Matchmaking | Provisional A — 79 |
| Coordinated SWF | Provisional B — 75 |
| Meta Stability | 85 — VERY STABLE |
| Skill Floor | 3/5 — Moderate |
| Skill Ceiling | 4/5 — intermediate canonical value |
| Map Dependence | 2/5 — intermediate canonical value |
| Opportunity Cost | 3/5 — Meaningful tradeoff |

> **PROVISIONAL:** K3A contains numerical estimates, but the placement is not considered fully settled because the evidence base is still maturing.

## What This Strategy Is

**Hook-to-Generator Conversion** is a Killer strategy built around this objective: **Make each hook generate immediate objective pressure**.

Its defining loop is **Down → select hook → trigger/route toward vulnerable generator → force repair interruption/regression/block → start next chase**.

**K3A independence rationale:** Independent hook→objective loop survives; 10.2 materially re-formed support.

## How It Plays

The practical decision loop is: **Down → select hook → trigger/route toward vulnerable generator → force repair interruption/regression/block → start next chase**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 4/5 — intermediate canonical value.

## When It Works Best

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

**Material dependencies:** `GAME_STATE`, `POSITIONING`, `TIMING`

**Canonical synergies:** mobility, Scourge routing, info

## Killer Fit

**Best Fits:** The Wraith, The Dredge, The Demogorgon
**Strong Fits:** The Xenomorph, The Hillbilly, The Mastermind
**Viable Fits:** The Doctor, The Nemesis

**Canonical fit rationale:** Requires reliable post-hook reach to a chosen objective.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**Provisional A — 79.**

10.2's new hook→gen support looks strong, but clean optimization evidence is immature.

## Against Coordinated SWF

**Provisional B — 75.**

Good conversion remains, but coordinated teams are better at leaving, splitting and deliberately selecting which repairer yields pressure.

## Why the Two Environments Differ

The canonical Power estimate changes from **79** in General Matchmaking to **75** against coordinated SWF (-4 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 7.5 → 6.5 (-1)
- **Matchup Coverage:** 8 → 7 (-1)
- **Ceiling:** 8.5 → 8 (-0.5)
- **Consistency:** 8 → 7.5 (-0.5)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Ceiling 8.5/10, Tempo Efficiency 8.5/10, Agency 8/10, Consistency 8/10.

- Synergy: mobility
- Synergy: Scourge routing
- Synergy: info

## Weaknesses and Counterplay

- pre-leave
- split repair

The lowest General Matchmaking Power dimensions are Recovery Value 7/10, Slot Efficiency 7/10, Counterplay Resilience 7.5/10, Map Coverage 7.5/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** hook↔gen spacing, traversal.

**Map Dependence:** 2/5 — intermediate canonical value.

**General Matchmaking Map Coverage:** 7.5/10.

## Skill Profile

- **Skill Floor:** 3/5 — Moderate
- **Skill Ceiling:** 4/5 — intermediate canonical value
- **Opportunity Cost:** 3/5 — Meaningful tradeoff
- **Execution Reliability, General Matchmaking:** 8/10
- **Strategic Commitment:** 4/5 — intermediate canonical value

## Build and Add-on Ecosystem

**Canonical perk ecosystem:** Pain Resonance, Dead Man's Switch, Undone

Names are preserved from the K2 representative implementation; canonical perk IDs were not supplied here and are intentionally null.

## Representative Implementations

### Framework — `KSTR-003-B01`

- **Killer:** The Demogorgon
- **Environment:** `KILLER_GENERAL_MATCHMAKING`
- **Perks:** Pain Resonance, Dead Man's Switch, Undone
- **Implementation:** Framework: Dead Man's Switch + Pain Resonance or Undone; remaining slots flexible
- **Rationale:** DMS's live rework explicitly gives time to pressure the generator the Killer wants blocked.
- **Strengths:** Clear hook→travel→gen loop
- **Weaknesses:** 10.2 exact optimum unsettled
- **Confidence:** MEDIUM
- **Content validity:** LIVE_10_2_SOURCE_SUPPORTED

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 5/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 4/5 |
| Denial Risk | 2/5 |
| Strategic Commitment | 4/5 |

## Meta Stability

**85 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 22/25 |
| Core Mechanic Durability | 18/20 |
| Replacement Depth | 13/15 |
| Environmental Breadth | 12/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 12/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM |
| General Matchmaking | MEDIUM |
| Coordinated SWF | LOW_MEDIUM |
| Compatibility | MEDIUM_HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## What We Are Watching

**Missing evidence / research flags:**
- Clean 10.2 implementation distribution and optimized DMS/Undone/Monstrous Shrine sequencing

**Uncertainty profile:** Power confidence `MEDIUM`, General Matchmaking `MEDIUM`, Coordinated SWF `LOW_MEDIUM`.

**Recheck conditions:**
- Re-evaluate after a clean post-10.2 window large enough to isolate the reworked ecosystem from pre-10.2 matches

## Related Strategies

- [Generator Control](generator-control.md)
- [Rapid Rotation Pressure](rapid-rotation-pressure.md)

## Source Metadata

- **Canonical ID:** `KSTR-003`
- **Snapshot:** `KSTR-003@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
| BHVR_PATCH_10_2_0 | Dead by Daylight 10.2.0 Mid-Chapter | 2026-10-06 | Official live Patch 10.2.0 mechanics. |
