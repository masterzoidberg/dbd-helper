---
canonicalId: "KSTR-025"
side: "KILLER"
name: "Network Surveillance / Teleport Control"
slug: "network-surveillance-teleport-control"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META SUBTYPE"
applicabilityScope: "POWER_FAMILY"
strategicOrientation: "HYBRID"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-025@10.2.0-r1"
parentStrategyId: "KSTR-023"
relatedStrategyIds: ["KSTR-026"]
childStrategyIds: ["KSTR-043", "KSTR-047", "KSTR-048"]
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 78
powerSWF: 70
tierGeneral: "A"
tierSWF: "B"
metaStability: 85
stabilityLabel: "VERY STABLE"
trend: null
---

# Network Surveillance / Teleport Control

Establish map nodes that simultaneously provide movement, information or threat.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META SUBTYPE |
| Applicability scope | POWER_FAMILY |
| Strategic orientation | HYBRID |
| Current status | ESTABLISHED |
| General Matchmaking | A — 78 |
| Coordinated SWF | B — 70 |
| Meta Stability | 85 — VERY STABLE |
| Skill Floor | 4/5 — intermediate canonical value |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 4/5 — intermediate canonical value |
| Opportunity Cost | 4/5 — intermediate canonical value |

## What This Strategy Is

**Network Surveillance / Teleport Control** is a Killer strategy built around this objective: **Establish map nodes that simultaneously provide movement, information or threat**.

Its defining loop is **Establish/accumulate nodes → monitor interactions → traverse/react → force Survivors to spend time disabling network**.

**K3A independence rationale:** Persistent map nodes create movement/information/disablement economy.

## How It Plays

The practical decision loop is: **Establish/accumulate nodes → monitor interactions → traverse/react → force Survivors to spend time disabling network**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan depends on a family of native Power qualities. A superficially similar Power is not automatically enough for compatibility.

**Material dependencies:** `KILLER_POWER`, `MAP`, `RESOURCE_AVAILABILITY`, `POSITIONING`

**Canonical synergies:** rotation, info, generator control

## Killer Fit

**Best Fits:** The Singularity, The Demogorgon, The Unknown
**Strong Fits:** The Xenomorph, The Dredge, The Animatronic
**Viable Fits:** The Onryō

**Canonical fit rationale:** Persistent nodes/stations create travel, information or disablement counterplay.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**A — 78.**

Persistent nodes reduce search/travel costs while forcing Survivor disablement work.

## Against Coordinated SWF

**B — 70.**

Coordinated disablement and node callouts reduce network information value.

## Why the Two Environments Differ

The canonical Power estimate changes from **78** in General Matchmaking to **70** against coordinated SWF (-8 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 7 → 5.5 (-1.5)
- **Matchup Coverage:** 7.5 → 6 (-1.5)
- **Consistency:** 7.5 → 6.5 (-1)
- **Recovery Value:** 7.5 → 6.5 (-1)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 9.5/10, Ceiling 8.5/10, Slot Efficiency 8.5/10, Snowball Value 8.5/10.

- Synergy: rotation
- Synergy: info
- Synergy: generator control

## Weaknesses and Counterplay

- disable/EMP/seal/dispel
- force rebuilds

The lowest General Matchmaking Power dimensions are Map Coverage 6.5/10, Counterplay Resilience 7/10, Execution Reliability 7/10, Consistency 7.5/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** node LOS, size, verticality.

**Map Dependence:** 4/5 — intermediate canonical value.

**General Matchmaking Map Coverage:** 6.5/10.

## Skill Profile

- **Skill Floor:** 4/5 — intermediate canonical value
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 4/5 — intermediate canonical value
- **Execution Reliability, General Matchmaking:** 7/10
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Representative Implementations

### Framework — `KSTR-025-B01`

- **Killer:** The Singularity
- **Implementation:** Native Biopod network; perk package flexible
- **Rationale:** Seed useful sightlines, convert Slipstream/network reactions, rebuild around disablement
- **Strengths:** Info + traversal
- **Weaknesses:** Counter-network resource economy
- **Confidence:** HIGH
- **Content validity:** LIVE_10_2_SOURCE_SUPPORTED

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**85 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 23/25 |
| Core Mechanic Durability | 18/20 |
| Replacement Depth | 12/15 |
| Environmental Breadth | 11/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 13/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Territorial Control](territorial-control.md)
- [Rapid Rotation Pressure](rapid-rotation-pressure.md)
- [Biopod Network Implementation](biopod-network-implementation.md)
- [Portal Network Implementation](portal-network-implementation.md)
- [Hallucination Network Implementation](hallucination-network-implementation.md)

## Source Metadata

- **Canonical ID:** `KSTR-025`
- **Snapshot:** `KSTR-025@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
