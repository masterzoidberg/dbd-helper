---
canonicalId: "KSTR-031"
side: "KILLER"
name: "Skill-Check / Interaction Pressure"
slug: "skill-check-interaction-pressure"
pageType: "MECHANIC_CENTERED_BUILD"
structuralClassification: "MECHANIC-CENTERED BUILD"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-031@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: ["KSTR-053"]
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Skill-Check / Interaction Pressure

Increase error/interaction costs.

> **Mechanic-Centered Build:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What the Build Family Is

**Core mechanic/idea:** Increase error/interaction costs.

**Canonical loop:** Expand/destabilize skill checks or punish misses → exploit lost progress/info/status effects.

## Typical Strategic Uses

Doctor, Generator Control.

## Strategies It Supports


**Canonical support note:** Doctor, Generator Control.

## How It Changes Gameplay

Expand/destabilize skill checks or punish misses → exploit lost progress/info/status effects.

## Killer / Power Interaction

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

The canonical decision loop depends on: **Expand/destabilize skill checks or punish misses → exploit lost progress/info/status effects**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not a Standalone Strategy

Package recognition exceeds strategic independence.

## Promotion Condition

Persistent macro plan beyond interaction difficulty.

## Related Strategies

- [Madness / Interaction Disruption](madness-interaction-disruption.md)

## Source Metadata

- **Canonical ID:** `KSTR-031`
- **Snapshot:** `KSTR-031@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
