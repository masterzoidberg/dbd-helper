---
canonicalId: "KSTR-004"
side: "KILLER"
name: "Generator Blocking / Repair Denial"
slug: "generator-blocking-repair-denial"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-004@10.2.0-r1"
parentStrategyId: "KSTR-001"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Generator Blocking / Repair Denial

Prevent repair during a pressure window.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Prevent repair during a pressure window.

**Decision loop:** Trigger block → exploit forced downtime to chase/rotate/reset generator state.

## What Strategic Problem It Solves

Regression, Hook-to-Gen, Cluster.

## Strategies It Supports

- [Generator Control](generator-control.md)

**Canonical support note:** Regression, Hook-to-Gen, Cluster.

## How It Changes Killer Decisions

Trigger block → exploit forced downtime to chase/rotate/reset generator state.

## Killer / Power Interaction

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

The canonical decision loop depends on: **Trigger block → exploit forced downtime to chase/rotate/reset generator state**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

No independent objective beyond creating downtime.

## Promotion Condition

Evidence of a distinct blocking-centered full-match decision loop.

## Related Strategies

- [Generator Control](generator-control.md)

## Source Metadata

- **Canonical ID:** `KSTR-004`
- **Snapshot:** `KSTR-004@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
