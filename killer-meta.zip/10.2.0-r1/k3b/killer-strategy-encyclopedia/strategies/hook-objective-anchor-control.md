---
canonicalId: "KSTR-013"
side: "KILLER"
name: "Hook + Objective Anchor Control"
slug: "hook-objective-anchor-control"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META SUBTYPE"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-013@10.2.0-r1"
parentStrategyId: "KSTR-011"
relatedStrategyIds: ["KSTR-001", "KSTR-023"]
childStrategyIds: []
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 78
powerSWF: 71
tierGeneral: "A"
tierSWF: "B"
metaStability: 85
stabilityLabel: "VERY STABLE"
trend: null
---

# Hook + Objective Anchor Control

Defend a hooked Survivor and high-value nearby generator/territory simultaneously.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META SUBTYPE |
| Applicability scope | BROAD_ROSTER |
| Strategic orientation | CONTROL |
| Current status | ESTABLISHED |
| General Matchmaking | A — 78 |
| Coordinated SWF | B — 71 |
| Meta Stability | 85 — VERY STABLE |
| Skill Floor | 3/5 — Moderate |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 4/5 — intermediate canonical value |
| Opportunity Cost | 4/5 — intermediate canonical value |

## What This Strategy Is

**Hook + Objective Anchor Control** is a Killer strategy built around this objective: **Defend a hooked Survivor and high-value nearby generator/territory simultaneously**.

Its defining loop is **Select strategically placed hook → patrol hook-objective lane → punish repair or rescue → preserve dual anchor**.

**K3A independence rationale:** Defending hook and valuable objective through one patrol structure is independently meaningful.

## How It Plays

The practical decision loop is: **Select strategically placed hook → patrol hook-objective lane → punish repair or rescue → preserve dual anchor**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

**Material dependencies:** `MAP`, `RNG`, `POSITIONING`, `GAME_STATE`

**Canonical synergies:** setup, Scourge, carry

## Killer Fit

**Best Fits:** The Hag, The Trapper, The Singularity
**Strong Fits:** The Demogorgon, The Doctor, The Knight
**Viable Fits:** The Wraith

**Canonical fit rationale:** Best when one route can contest hook and objective.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**A — 78.**

One patrol structure can pressure rescue and repair simultaneously.

## Against Coordinated SWF

**B — 71.**

SWF can deliberately split rescue and repair responsibilities, but dual-anchor geometry still creates real pressure.

## Why the Two Environments Differ

The canonical Power estimate changes from **78** in General Matchmaking to **71** against coordinated SWF (-7 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 7.5 → 6 (-1.5)
- **Matchup Coverage:** 8 → 6.5 (-1.5)
- **Consistency:** 7.5 → 6.5 (-1)
- **Snowball Value:** 8.5 → 7.5 (-1)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Ceiling 8.5/10, Power Integration 8.5/10, Slot Efficiency 8.5/10, Snowball Value 8.5/10.

- Synergy: setup
- Synergy: Scourge
- Synergy: carry

## Weaknesses and Counterplay

- work elsewhere
- stagger rescue
- deny destination

The lowest General Matchmaking Power dimensions are Map Coverage 6/10, Execution Reliability 7/10, Agency 7.5/10, Consistency 7.5/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** hook-gen proximity, approach lanes.

**Map Dependence:** 4/5 — intermediate canonical value.

**General Matchmaking Map Coverage:** 6/10.

## Skill Profile

- **Skill Floor:** 3/5 — Moderate
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 4/5 — intermediate canonical value
- **Execution Reliability, General Matchmaking:** 7/10
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 5/5 |
| Activation Reliability | 3/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**85 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 23/25 |
| Core Mechanic Durability | 18/20 |
| Replacement Depth | 13/15 |
| Environmental Breadth | 10/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 13/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM |
| General Matchmaking | MEDIUM |
| Coordinated SWF | LOW_MEDIUM |
| Compatibility | MEDIUM_HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Hook-Zone / Rescue Pressure](hook-zone-rescue-pressure.md)
- [Generator Control](generator-control.md)
- [Territorial Control](territorial-control.md)

## Source Metadata

- **Canonical ID:** `KSTR-013`
- **Snapshot:** `KSTR-013@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
