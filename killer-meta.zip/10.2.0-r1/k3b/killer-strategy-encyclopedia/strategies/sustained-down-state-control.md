---
canonicalId: "KSTR-016"
side: "KILLER"
name: "Sustained Down-State Control"
slug: "sustained-down-state-control"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "POWER_FAMILY"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-016@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: ["KSTR-015"]
childStrategyIds: ["KSTR-068"]
rankingStatusGeneral: "PROVISIONAL"
rankingStatusSWF: "PROVISIONAL"
powerGeneral: 65
powerSWF: 52
tierGeneral: "C"
tierSWF: "C"
metaStability: 68
stabilityLabel: "WATCH"
trend: null
---

# Sustained Down-State Control

Keep multiple Survivors down or repeatedly re-down them to deny coordinated recovery and objective work.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | POWER_FAMILY |
| Strategic orientation | CONTROL |
| Current status | ESTABLISHED |
| General Matchmaking | Provisional C — 65 |
| Coordinated SWF | Provisional C — 52 |
| Meta Stability | 68 — WATCH |
| Skill Floor | 3/5 — Moderate |
| Skill Ceiling | 4/5 — intermediate canonical value |
| Map Dependence | 3/5 — Material |
| Opportunity Cost | 5/5 — Severe commitment/resources foregone |

> **PROVISIONAL:** K3A contains numerical estimates, but the placement is not considered fully settled because the evidence base is still maturing.

## What This Strategy Is

**Sustained Down-State Control** is a Killer strategy built around this objective: **Keep multiple Survivors down or repeatedly re-down them to deny coordinated recovery and objective work**.

Its defining loop is **Down → leave → monitor/re-down recovery attempts → maintain incapacitated population → hook only when strategically favorable**.

**K3A independence rationale:** Survives on appropriate re-down/rotation Powers, but old Knock Out support is gone.

## How It Plays

The practical decision loop is: **Down → leave → monitor/re-down recovery attempts → maintain incapacitated population → hook only when strategically favorable**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan depends on a family of native Power qualities. A superficially similar Power is not automatically enough for compatibility.

**Material dependencies:** `KILLER_POWER`, `SURVIVOR_COMPOSITION`, `TARGET_STATE`, `POSITIONING`

**Canonical synergies:** re-down, mobility, info

## Killer Fit

**Best Fits:** The Twins, The Oni
**Strong Fits:** The Nurse, The Blight
**Viable Fits:** The Wraith, The Ghoul
**Weak Fits:** The Trapper

**Canonical fit rationale:** Requires reliable re-down/recontact; old Knock Out concealment is excluded.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**Provisional C — 65.**

Still real on re-down/rotation Powers, but post-Knock-Out support is materially weaker and less proven.

## Against Coordinated SWF

**Provisional C — 52.**

Rapid recovery coordination, pickup calls and spread positioning sharply reduce sustained control.

## Why the Two Environments Differ

The canonical Power estimate changes from **65** in General Matchmaking to **52** against coordinated SWF (-13 points).

The largest canonical dimension shifts are:
- **Consistency:** 5.5 → 3.5 (-2)
- **Counterplay Resilience:** 5.5 → 3.5 (-2)
- **Matchup Coverage:** 5.5 → 3.5 (-2)
- **Recovery Value:** 6.5 → 4.5 (-2)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Slot Efficiency 9/10, Snowball Value 9/10, Ceiling 8/10, Power Integration 7.5/10.

- Synergy: re-down
- Synergy: mobility
- Synergy: info

## Weaknesses and Counterplay

- coordinated pickups
- recovery perks
- spread

The lowest General Matchmaking Power dimensions are Consistency 5.5/10, Counterplay Resilience 5.5/10, Matchup Coverage 5.5/10, Agency 6/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** size, recovery routes.

**Map Dependence:** 3/5 — Material.

**General Matchmaking Map Coverage:** 6/10.

## Skill Profile

- **Skill Floor:** 3/5 — Moderate
- **Skill Ceiling:** 4/5 — intermediate canonical value
- **Opportunity Cost:** 5/5 — Severe commitment/resources foregone
- **Execution Reliability, General Matchmaking:** 6/10
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 3/5 |
| Activation Payoff | 4/5 |
| Denial Risk | 4/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**68 — WATCH**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 18/25 |
| Core Mechanic Durability | 16/20 |
| Replacement Depth | 10/15 |
| Environmental Breadth | 8/15 |
| Counter-Meta Independence | 6/10 |
| Patch Durability | 10/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | LOW_MEDIUM |
| General Matchmaking | LOW_MEDIUM |
| Coordinated SWF | LOW |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## What We Are Watching

**Missing evidence / research flags:**
- Actual persistence after loss of old Knock Out concealment; recovery-counterplay frequency

**Uncertainty profile:** Power confidence `LOW_MEDIUM`, General Matchmaking `LOW_MEDIUM`, Coordinated SWF `LOW`.

**Recheck conditions:**
- Recheck when post-10.2 data can separate intentional sustained control from temporary/chain-down slugs

## Related Strategies

- [Chain-Down Pressure](chain-down-pressure.md)
- [Old Deerstalker Slug-Tracking Shell](old-deerstalker-slug-tracking-shell.md)

## Source Metadata

- **Canonical ID:** `KSTR-016`
- **Snapshot:** `KSTR-016@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
