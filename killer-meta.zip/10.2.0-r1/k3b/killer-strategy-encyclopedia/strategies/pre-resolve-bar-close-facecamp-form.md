---
canonicalId: "KSTR-069"
side: "KILLER"
name: "Pre-Resolve-Bar Close Facecamp Form"
slug: "pre-resolve-bar-close-facecamp-form"
pageType: "LEGACY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: null
currentStatus: "LEGACY"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-069@10.2.0-r1"
parentStrategyId: "KSTR-012"
relatedStrategyIds: ["KSTR-012"]
childStrategyIds: []
rankingStatusGeneral: "NOT_CURRENT"
rankingStatusSWF: "NOT_CURRENT"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Pre-Resolve-Bar Close Facecamp Form

> **LEGACY — Not Current on Patch 10.2.0-r1**

Remain immediately adjacent to hook to prevent/force rescue.

## What It Was

Remain immediately adjacent to hook to prevent/force rescue

## How It Played

Remain immediately adjacent to hook to prevent/force rescue.

## Why It Is No Longer Current

Current Resolve anti-facecamp mechanics specifically impose escalating consequences on prolonged close proximity

**Transition:** Resolve system/current tuning.

## What Replaced It

- [Proxy Hook-Zone Control](proxy-hook-zone-control.md)

**Canonical successor note:** Proxy Hook-Zone Control.

## Terminology Warning

“Camping” should not collapse proxy and obsolete close-facecamp forms.

## Current Ranking Status

Both current environments are `NOT_CURRENT`. Power, Tier, and Ranking Index are intentionally null.

## Source Metadata

- **Canonical ID:** `KSTR-069`
- **Snapshot:** `KSTR-069@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| BHVR_PATCH_10_2_0 | Dead by Daylight 10.2.0 Mid-Chapter | 2026-10-06 | Official live Patch 10.2.0 mechanics. |
