---
canonicalId: "KSTR-070"
side: "KILLER"
name: "Passive Thrill Totem-Defense Form"
slug: "passive-thrill-totem-defense-form"
pageType: "LEGACY"
structuralClassification: "MECHANIC-CENTERED BUILD"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: null
currentStatus: "LEGACY"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-070@10.2.0-r1"
parentStrategyId: "KSTR-027"
relatedStrategyIds: ["KSTR-027"]
childStrategyIds: []
rankingStatusGeneral: "NOT_CURRENT"
rankingStatusSWF: "NOT_CURRENT"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Passive Thrill Totem-Defense Form

> **LEGACY — Not Current on Patch 10.2.0-r1**

Passive cleanse/bless slowdown from remaining Totems.

## What It Was

Passive cleanse/bless slowdown from remaining Totems

## How It Played

Passive cleanse/bless slowdown from remaining Totems.

## Why It Is No Longer Current

10.2 Thrill now ignites after first hook and blocks lit Hex Totems on hooks

**Transition:** Patch 10.2.0.

## What Replaced It

- [Active Hex Defense](active-hex-defense.md)

**Canonical successor note:** Active Hex Defense.

## Terminology Warning

Old “Thrill defense” guides are mechanically stale.

## Current Ranking Status

Both current environments are `NOT_CURRENT`. Power, Tier, and Ranking Index are intentionally null.

## Source Metadata

- **Canonical ID:** `KSTR-070`
- **Snapshot:** `KSTR-070@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| BHVR_PATCH_10_2_0 | Dead by Daylight 10.2.0 Mid-Chapter | 2026-10-06 | Official live Patch 10.2.0 mechanics. |
