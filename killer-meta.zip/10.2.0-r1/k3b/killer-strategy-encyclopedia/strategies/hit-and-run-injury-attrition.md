---
canonicalId: "KSTR-017"
side: "KILLER"
name: "Hit-and-Run Injury Attrition"
slug: "hit-and-run-injury-attrition"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META"
applicabilityScope: "POWER_FAMILY"
strategicOrientation: "HYBRID"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-017@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: ["KSTR-018", "KSTR-054", "KSTR-057"]
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 76
powerSWF: 67
tierGeneral: "B"
tierSWF: "B"
metaStability: 85
stabilityLabel: "VERY STABLE"
trend: null
---

# Hit-and-Run Injury Attrition

Keep multiple Survivors injured/unresolved rather than completing every first chase.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META |
| Applicability scope | POWER_FAMILY |
| Strategic orientation | HYBRID |
| Current status | ESTABLISHED |
| General Matchmaking | B — 76 |
| Coordinated SWF | B — 67 |
| Meta Stability | 85 — VERY STABLE |
| Skill Floor | 3/5 — Moderate |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 3/5 — Material |
| Opportunity Cost | 4/5 — intermediate canonical value |

## What This Strategy Is

**Hit-and-Run Injury Attrition** is a Killer strategy built around this objective: **Keep multiple Survivors injured/unresolved rather than completing every first chase**.

Its defining loop is **Injure → disengage → rotate → force heal/mend decisions → re-contact vulnerable target → convert when efficient**.

**K3A independence rationale:** Systematic injure→disengage→rotate→recontact policy survives perk removal.

## How It Plays

The practical decision loop is: **Injure → disengage → rotate → force heal/mend decisions → re-contact vulnerable target → convert when efficient**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 4/5 — intermediate canonical value.

## When It Works Best

This plan depends on a family of native Power qualities. A superficially similar Power is not automatically enough for compatibility.

**Material dependencies:** `KILLER_POWER`, `OPPONENT_BEHAVIOR`, `TARGET_STATE`, `TIMING`

**Canonical synergies:** stealth, mobility, healing suppression

## Killer Fit

**Best Fits:** The Wraith, The Legion, The Onryō
**Strong Fits:** The Dredge, The Ghost Face, The Skull Merchant
**Viable Fits:** The Demogorgon, The Good Guy
**Weak Fits:** The Cannibal

**Canonical fit rationale:** Cheap first hits plus economical recontact.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**B — 76.**

Inconsistent public healing and location sharing increase unresolved-injury value.

## Against Coordinated SWF

**B — 67.**

Coordinated reset calls and healing allocation attack the strategy's central unresolved-injury assumption.

## Why the Two Environments Differ

The canonical Power estimate changes from **76** in General Matchmaking to **67** against coordinated SWF (-9 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 6.5 → 4.5 (-2)
- **Consistency:** 7 → 5.5 (-1.5)
- **Matchup Coverage:** 7 → 5.5 (-1.5)
- **Tempo Efficiency:** 8 → 6.5 (-1.5)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 9/10, Slot Efficiency 8.5/10, Agency 8/10, Ceiling 8/10.

- Synergy: stealth
- Synergy: mobility
- Synergy: healing suppression

## Weaknesses and Counterplay

- efficient heals
- comms
- pre-run

The lowest General Matchmaking Power dimensions are Counterplay Resilience 6.5/10, Consistency 7/10, Matchup Coverage 7/10, Snowball Value 7/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** size, healing cover, travel lanes.

**Map Dependence:** 3/5 — Material.

**General Matchmaking Map Coverage:** 7.5/10.

## Skill Profile

- **Skill Floor:** 3/5 — Moderate
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 4/5 — intermediate canonical value
- **Execution Reliability, General Matchmaking:** 8/10
- **Strategic Commitment:** 4/5 — intermediate canonical value

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 4/5 |
| Denial Risk | 4/5 |
| Strategic Commitment | 4/5 |

## Meta Stability

**85 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 23/25 |
| Core Mechanic Durability | 18/20 |
| Replacement Depth | 13/15 |
| Environmental Breadth | 11/15 |
| Counter-Meta Independence | 7/10 |
| Patch Durability | 13/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Healing Suppression](healing-suppression.md)
- [Feral-Frenzy Injury-Spread Module](feral-frenzy-injury-spread-module.md)
- [Axe-Impale Attrition Module](axe-impale-attrition-module.md)

## Source Metadata

- **Canonical ID:** `KSTR-017`
- **Snapshot:** `KSTR-017@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
