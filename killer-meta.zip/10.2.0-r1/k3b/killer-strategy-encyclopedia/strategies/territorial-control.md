---
canonicalId: "KSTR-023"
side: "KILLER"
name: "Territorial Control"
slug: "territorial-control"
pageType: "PARENT_STRATEGY_FAMILY"
structuralClassification: "PARENT STRATEGY FAMILY"
applicabilityScope: "POWER_FAMILY"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-023@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: ["KSTR-005", "KSTR-013"]
childStrategyIds: ["KSTR-024", "KSTR-025", "KSTR-046", "KSTR-051"]
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Territorial Control

Make selected parts of the map disproportionately dangerous or expensive to contest.

> **Strategy Family:** This is an organizational family, not an independently ranked gameplay plan. It has no aggregate Power, Tier, or Ranking Index.

## Family Definition

**Shared objective:** Make selected parts of the map disproportionately dangerous or expensive to contest.

**Shared loop:** Invest Power/resources in region/network → patrol/intercept around it → punish entry/disarm → preserve or relocate control.

Pre-invest in a region/network and convert Survivor interaction with it into pressure.

## Current Children

| Child | Classification | General Matchmaking | Coordinated SWF |
|---|---|---|---|
| [Setup-Zone Lockdown](setup-zone-lockdown.md) | META SUBTYPE | B — 74 | B — 66 |
| [Network Surveillance / Teleport Control](network-surveillance-teleport-control.md) | META SUBTYPE | A — 78 | B — 70 |
| [Drone Surveillance / Chase-Zone Module](drone-surveillance-chase-zone-module.md) | STRATEGIC MODULE | Not independently ranked | Not independently ranked |
| [Guard Pincer / Remote Patrol](guard-pincer-remote-patrol.md) | STRATEGIC MODULE | Not independently ranked | Not independently ranked |

## How the Children Differ

- **[Setup-Zone Lockdown](setup-zone-lockdown.md):** Build a local web of traps or hazards and fight where the Power is already invested
- **[Network Surveillance / Teleport Control](network-surveillance-teleport-control.md):** Establish map nodes that simultaneously provide movement, information or threat
- **[Drone Surveillance / Chase-Zone Module](drone-surveillance-chase-zone-module.md):** Build overlapping or strategically spaced drone threat areas, read scans, and steer chases/objective contests through monitored space
- **[Guard Pincer / Remote Patrol](guard-pincer-remote-patrol.md):** Assign Guards to patrol/hunt or interact with obstacles, use them to cut routes, create pincer pressure, or contest space while Knight approaches elsewhere

## Shared Counterplay

avoid/disarm/disable zone, split map, force relocation.

## Related Families and Cross-Links

- [Generator-Cluster Defense](generator-cluster-defense.md)
- [Hook + Objective Anchor Control](hook-objective-anchor-control.md)

**Canonical relationship note:** Generator Control; Hook pressure; Rapid Rotation.

## Strongest Current Children

- **General Matchmaking:** Network Control 78
- **Coordinated SWF:** Network Control 70

These are child-level canonical results, not an aggregate score for the family.

## Family Scope

This plan depends on a family of native Power qualities. A superficially similar Power is not automatically enough for compatibility.

## Source Metadata

- **Canonical ID:** `KSTR-023`
- **Snapshot:** `KSTR-023@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
