---
canonicalId: "KSTR-032"
side: "KILLER"
name: "Carry / Hook-Transport Optimization"
slug: "carry-hook-transport-optimization"
pageType: "MECHANIC_CENTERED_BUILD"
structuralClassification: "MECHANIC-CENTERED BUILD"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-032@10.2.0-r1"
parentStrategyId: "KSTR-011"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Carry / Hook-Transport Optimization

Reach strategically better hooks and punish interference.

> **Mechanic-Centered Build:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What the Build Family Is

**Core mechanic/idea:** Reach strategically better hooks and punish interference.

**Canonical loop:** Down → choose destination → use carrying speed/control → reach anchor/Scourge/basement → convert.

## Typical Strategic Uses

Basement, Hook Anchor, Scourge.

## Strategies It Supports

- [Hook-Zone / Rescue Pressure](hook-zone-rescue-pressure.md)

**Canonical support note:** Basement, Hook Anchor, Scourge.

## How It Changes Gameplay

Down → choose destination → use carrying speed/control → reach anchor/Scourge/basement → convert.

## Killer / Power Interaction

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

The canonical decision loop depends on: **Down → choose destination → use carrying speed/control → reach anchor/Scourge/basement → convert**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not a Standalone Strategy

Delivery mechanism.

## Promotion Condition

Destination policy becomes independent win loop.

## Related Strategies

- [Hook-Zone / Rescue Pressure](hook-zone-rescue-pressure.md)

## Source Metadata

- **Canonical ID:** `KSTR-032`
- **Snapshot:** `KSTR-032@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
