---
canonicalId: "KSTR-065"
side: "KILLER"
name: "Scratched-Mirror Ambush"
slug: "scratched-mirror-ambush"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-065@10.2.0-r1"
parentStrategyId: "KSTR-022"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 62
powerSWF: 49
tierGeneral: "C"
tierSWF: "D"
metaStability: 50
stabilityLabel: "WATCH"
trend: null
---

# Scratched-Mirror Ambush

Trade normal Evil Within progression for persistent close-range aura-aided hidden hunting, heavily changing pathing and map preference.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | KILLER_SPECIFIC |
| Strategic orientation | Not established |
| Current status | ESTABLISHED |
| General Matchmaking | C — 62 |
| Coordinated SWF | D — 49 |
| Meta Stability | 50 — WATCH |
| Skill Floor | 4/5 — intermediate canonical value |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 5/5 — Extreme |
| Opportunity Cost | 5/5 — Severe commitment/resources foregone |

## What This Strategy Is

**Scratched-Mirror Ambush** is a Killer strategy built around this objective: **Trade normal Evil Within progression for persistent close-range aura-aided hidden hunting, heavily changing pathing and map preference**.

Its defining loop is **Trade normal Evil Within progression for persistent close-range aura-aided hidden hunting, heavily changing pathing and map preference**.

**K3A independence rationale:** Add-on permanently changes information, movement/chase profile and map policy.

## How It Plays

The practical decision loop is: **Trade normal Evil Within progression for persistent close-range aura-aided hidden hunting, heavily changing pathing and map preference**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

**Material dependencies:** `ADD_ON`, `MAP`, `OPPONENT_BEHAVIOR`, `POSITIONING`

**Canonical synergies:** indoor geometry, ambush routing

## Killer Fit

**Best Fits:** The Shape

**Canonical fit rationale:** Removing the add-on removes the strategic identity.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**C — 62.**

Powerful information in favorable geometry, but major movement/map opportunity cost prevents a higher placement.

## Against Coordinated SWF

**D — 49.**

Low movement and extreme geometry dependence become much harder to hide from a coordinated team.

## Why the Two Environments Differ

The canonical Power estimate changes from **62** in General Matchmaking to **49** against coordinated SWF (-13 points).

The largest canonical dimension shifts are:
- **Matchup Coverage:** 5.5 → 3 (-2.5)
- **Consistency:** 5.5 → 3.5 (-2)
- **Counterplay Resilience:** 5.5 → 3.5 (-2)
- **Agency:** 7 → 5.5 (-1.5)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 10/10, Ceiling 8.5/10, Agency 7/10, Slot Efficiency 7/10.

- Synergy: indoor geometry
- Synergy: ambush routing

## Weaknesses and Counterplay

- open maps
- comms
- pre-run
- distance

The lowest General Matchmaking Power dimensions are Map Coverage 3/10, Recovery Value 5/10, Consistency 5.5/10, Counterplay Resilience 5.5/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** indoor/outdoor, walls, size.

**Map Dependence:** 5/5 — Extreme.

**General Matchmaking Map Coverage:** 3/10.

## Skill Profile

- **Skill Floor:** 4/5 — intermediate canonical value
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 5/5 — Severe commitment/resources foregone
- **Execution Reliability, General Matchmaking:** 6/10
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

**Canonical add-on ecosystem:**
- **Scratched Mirror** — STRATEGY DEFINER: Permanent aura-led Stalker-mode hunting changes approach, map preference and chase economics enough to sustain K1-ADD-MIRROR. Current effect reveals nearby Survivor auras and prevents normal Stalker-state progression.

**Offering notes:** No Realm offering assumed.

## Representative Implementations

### Addon Variant — `KSTR-065-B01`

- **Killer:** The Shape
- **Environment:** `KILLER_GENERAL_MATCHMAKING`
- **Add-ons:** Scratched Mirror
- **Implementation:** Mandatory add-on: Scratched Mirror; no Realm offering assumed
- **Rationale:** Aura-led hidden routing becomes the core plan
- **Strengths:** Strong information in dense indoor geometry
- **Weaknesses:** Extreme open-map dependence
- **Confidence:** HIGH
- **Content validity:** LIVE_10_2_SOURCE_SUPPORTED

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 3/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 3/5 |
| Denial Risk | 5/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**50 — WATCH**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 9/25 |
| Core Mechanic Durability | 18/20 |
| Replacement Depth | 3/15 |
| Environmental Breadth | 5/15 |
| Counter-Meta Independence | 6/10 |
| Patch Durability | 9/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM |
| General Matchmaking | MEDIUM |
| Coordinated SWF | LOW_MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Ambush Rotation](ambush-rotation.md)

## Source Metadata

- **Canonical ID:** `KSTR-065`
- **Snapshot:** `KSTR-065@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
