---
canonicalId: "KSTR-061"
side: "KILLER"
name: "Worldbreaker / Upside-Down Module"
slug: "worldbreaker-upside-down-module"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-061@10.2.0-r1"
parentStrategyId: "KSTR-026"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Worldbreaker / Upside-Down Module

Use special attacks to build Curse, traverse through the Upside Down, then prioritize cursed targets because Power damage/finishing options change.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Use special attacks to build Curse, traverse through the Upside Down, then prioritize cursed targets because Power damage/finishing options change.

**Decision loop:** Use special attacks to build Curse, traverse through the Upside Down, then prioritize cursed targets because Power damage/finishing options change.

## What Strategic Problem It Solves

Rotation/target pressure.

## Strategies It Supports

- [Rapid Rotation Pressure](rapid-rotation-pressure.md)

**Canonical support note:** Rotation/target pressure.

## How It Changes Killer Decisions

Use special attacks to build Curse, traverse through the Upside Down, then prioritize cursed targets because Power damage/finishing options change.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Use special attacks to build Curse, traverse through the Upside Down, then prioritize cursed targets because Power damage/finishing options change**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Native state/travel execution.

## Promotion Condition

Persistent alternative strategic route demonstrated.

## Related Strategies

- [Rapid Rotation Pressure](rapid-rotation-pressure.md)

## Source Metadata

- **Canonical ID:** `KSTR-061`
- **Snapshot:** `KSTR-061@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
