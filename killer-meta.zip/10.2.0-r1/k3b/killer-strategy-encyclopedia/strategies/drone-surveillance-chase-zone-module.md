---
canonicalId: "KSTR-046"
side: "KILLER"
name: "Drone Surveillance / Chase-Zone Module"
slug: "drone-surveillance-chase-zone-module"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-046@10.2.0-r1"
parentStrategyId: "KSTR-023"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Drone Surveillance / Chase-Zone Module

Build overlapping or strategically spaced drone threat areas, read scans, and steer chases/objective contests through monitored space.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Build overlapping or strategically spaced drone threat areas, read scans, and steer chases/objective contests through monitored space.

**Decision loop:** Build overlapping or strategically spaced drone threat areas, read scans, and steer chases/objective contests through monitored space.

## What Strategic Problem It Solves

Territorial/chase.

## Strategies It Supports

- [Territorial Control](territorial-control.md)

**Canonical support note:** Territorial/chase.

## How It Changes Killer Decisions

Build overlapping or strategically spaced drone threat areas, read scans, and steer chases/objective contests through monitored space.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Build overlapping or strategically spaced drone threat areas, read scans, and steer chases/objective contests through monitored space**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Current drones serve zone/chase pressure; old three-gen identity invalid.

## Promotion Condition

New persistent macro loop under current Power.

## Related Strategies

- [Territorial Control](territorial-control.md)

## Source Metadata

- **Canonical ID:** `KSTR-046`
- **Snapshot:** `KSTR-046@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
