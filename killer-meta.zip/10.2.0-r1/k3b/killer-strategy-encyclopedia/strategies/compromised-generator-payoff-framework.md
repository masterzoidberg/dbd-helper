---
canonicalId: "KSTR-007"
side: "KILLER"
name: "Compromised-Generator Payoff Framework"
slug: "compromised-generator-payoff-framework"
pageType: "MECHANIC_CENTERED_BUILD"
structuralClassification: "MECHANIC-CENTERED BUILD"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "HYBRID"
currentStatus: "EMERGING"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-007@10.2.0-r1"
parentStrategyId: "KSTR-001"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Compromised-Generator Payoff Framework

Mark generators and convert later Survivor completion into Killer tempo.

> **Mechanic-Centered Build:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What the Build Family Is

**Core mechanic/idea:** Mark generators and convert later Survivor completion into Killer tempo.

**Canonical loop:** Damage selected gens → maintain several compromised options → intentionally or unavoidably let one finish → harvest mobility/M1/regression payoff.

## Typical Strategic Uses

Generator Control, M1 tempo.

## Strategies It Supports

- [Generator Control](generator-control.md)

**Canonical support note:** Generator Control, M1 tempo.

## How It Changes Gameplay

Damage selected gens → maintain several compromised options → intentionally or unavoidably let one finish → harvest mobility/M1/regression payoff.

## Killer / Power Interaction

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

The canonical decision loop depends on: **Damage selected gens → maintain several compromised options → intentionally or unavoidably let one finish → harvest mobility/M1/regression payoff**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not a Standalone Strategy

10.2 mechanics are fresh and perk-defined.

## Promotion Condition

Clean evidence of deliberate gen-completion manipulation as a match plan.

## Related Strategies

- [Generator Control](generator-control.md)

## Source Metadata

- **Canonical ID:** `KSTR-007`
- **Snapshot:** `KSTR-007@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
| BHVR_PATCH_10_2_0 | Dead by Daylight 10.2.0 Mid-Chapter | 2026-10-06 | Official live Patch 10.2.0 mechanics. |
