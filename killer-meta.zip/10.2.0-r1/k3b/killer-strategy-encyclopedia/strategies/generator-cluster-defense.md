---
canonicalId: "KSTR-005"
side: "KILLER"
name: "Generator-Cluster Defense"
slug: "generator-cluster-defense"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-005@10.2.0-r1"
parentStrategyId: "KSTR-001"
relatedStrategyIds: ["KSTR-023"]
childStrategyIds: []
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 72
powerSWF: 65
tierGeneral: "B"
tierSWF: "C"
metaStability: 82
stabilityLabel: "STABLE"
trend: null
---

# Generator-Cluster Defense

Preserve a defensible final objective cluster.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | BROAD_ROSTER |
| Strategic orientation | CONTROL |
| Current status | ESTABLISHED |
| General Matchmaking | B — 72 |
| Coordinated SWF | C — 65 |
| Meta Stability | 82 — STABLE |
| Skill Floor | 3/5 — Moderate |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 5/5 — Extreme |
| Opportunity Cost | 4/5 — intermediate canonical value |

## What This Strategy Is

**Generator-Cluster Defense** is a Killer strategy built around this objective: **Preserve a defensible final objective cluster**.

Its defining loop is **Identify cluster → concede lower-value territory → shorten patrol loop → abandon unfavorable chases → force resource attrition around cluster**.

**K3A independence rationale:** Current cluster defense survives, but indefinite kick cycling does not; each generator has a finite regression-event budget.

## How It Plays

The practical decision loop is: **Identify cluster → concede lower-value territory → shorten patrol loop → abandon unfavorable chases → force resource attrition around cluster**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

**Material dependencies:** `MAP`, `RNG`, `GAME_STATE`, `POSITIONING`

**Canonical synergies:** setup, anchors, mobility

## Killer Fit

**Best Fits:** The Hag, The Trapper, The Singularity
**Strong Fits:** The Demogorgon, The Knight, The Doctor
**Viable Fits:** The Skull Merchant
**Weak Fits:** The Huntress

**Canonical fit rationale:** Fit derives from short territorial patrols, not roster tier.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**B — 72.**

Still viable when layout cooperates, but modern regression caps and map variance suppress the old ceiling.

## Against Coordinated SWF

**C — 65.**

Coordinated teams attack separate generators and deliberately consume the cluster's finite regression budget.

## Why the Two Environments Differ

The canonical Power estimate changes from **72** in General Matchmaking to **65** against coordinated SWF (-7 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 6.5 → 5 (-1.5)
- **Matchup Coverage:** 7 → 5.5 (-1.5)
- **Consistency:** 7 → 6 (-1)
- **Agency:** 7.5 → 7 (-0.5)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Ceiling 8/10, Power Integration 8/10, Recovery Value 8/10, Slot Efficiency 8/10.

- Synergy: setup
- Synergy: anchors
- Synergy: mobility

## Weaknesses and Counterplay

- break cluster early
- split
- regression cap

The lowest General Matchmaking Power dimensions are Map Coverage 5.5/10, Counterplay Resilience 6.5/10, Consistency 7/10, Execution Reliability 7/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** clustering, size, tiles.

**Map Dependence:** 5/5 — Extreme.

**General Matchmaking Map Coverage:** 5.5/10.

## Skill Profile

- **Skill Floor:** 3/5 — Moderate
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 4/5 — intermediate canonical value
- **Execution Reliability, General Matchmaking:** 7/10
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 3/5 |
| Activation Payoff | 4/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**82 — STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 22/25 |
| Core Mechanic Durability | 18/20 |
| Replacement Depth | 12/15 |
| Environmental Breadth | 10/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 12/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | MEDIUM_HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Generator Control](generator-control.md)
- [Territorial Control](territorial-control.md)

## Source Metadata

- **Canonical ID:** `KSTR-005`
- **Snapshot:** `KSTR-005@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
