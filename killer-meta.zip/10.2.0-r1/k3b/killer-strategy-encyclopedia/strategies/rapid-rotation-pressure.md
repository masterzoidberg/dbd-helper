---
canonicalId: "KSTR-026"
side: "KILLER"
name: "Rapid Rotation Pressure"
slug: "rapid-rotation-pressure"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META"
applicabilityScope: "POWER_FAMILY"
strategicOrientation: "TEMPO"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-026@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: ["KSTR-003", "KSTR-025"]
childStrategyIds: ["KSTR-049", "KSTR-058", "KSTR-061", "KSTR-062", "KSTR-064"]
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 85
powerSWF: 82
tierGeneral: "A"
tierSWF: "A"
metaStability: 97
stabilityLabel: "VERY STABLE"
trend: "STABLE"
---

# Rapid Rotation Pressure

Trade chase commitment for faster multi-lane map pressure.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META |
| Applicability scope | POWER_FAMILY |
| Strategic orientation | TEMPO |
| Current status | ESTABLISHED |
| General Matchmaking | A — 85 |
| Coordinated SWF | A — 82 |
| Meta Stability | 97 — VERY STABLE |
| Skill Floor | 4/5 — intermediate canonical value |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 2/5 — intermediate canonical value |
| Opportunity Cost | 2/5 — intermediate canonical value |

## What This Strategy Is

**Rapid Rotation Pressure** is a Killer strategy built around this objective: **Trade chase commitment for faster multi-lane map pressure**.

Its defining loop is **Scan state → traverse rapidly → pressure gen/target → abandon diminishing-return chase → rotate → repeat**.

**K3A independence rationale:** Passes only when mobility systematically changes target-switch and chase-commitment thresholds.

## How It Plays

The practical decision loop is: **Scan state → traverse rapidly → pressure gen/target → abandon diminishing-return chase → rotate → repeat**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 4/5 — intermediate canonical value.

## When It Works Best

This plan depends on a family of native Power qualities. A superficially similar Power is not automatically enough for compatibility.

**Material dependencies:** `KILLER_POWER`, `POSITIONING`, `GAME_STATE`, `TIMING`

**Canonical synergies:** info, hook→gen, regression

## Killer Fit

**Best Fits:** The Hillbilly, The Dredge, The Xenomorph, The Blight
**Strong Fits:** The Wraith, The Demogorgon, The Onryō, The Unknown
**Viable Fits:** The First, The Ghoul, The Spirit, The Animatronic
**Weak Fits:** The Trapper

**Canonical fit rationale:** Mobility must alter commitment policy, not merely traversal.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**A — 85.**

Compresses travel/search losses and lets the Killer abandon declining-value engagements without surrendering map pressure.

## Against Coordinated SWF

**A — 82.**

Communication does not remove the Killer's ability to compress travel and contest multiple lanes.

## Why the Two Environments Differ

The canonical Power estimate changes from **85** in General Matchmaking to **82** against coordinated SWF (-3 points).

The largest canonical dimension shifts are:
- **Ceiling:** 9.5 → 8.5 (-1)
- **Recovery Value:** 8 → 7 (-1)
- **Consistency:** 8.5 → 8 (-0.5)
- **Counterplay Resilience:** 7.5 → 7 (-0.5)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Ceiling 9.5/10, Power Integration 9.5/10, Slot Efficiency 9/10, Tempo Efficiency 9/10.

- Synergy: info
- Synergy: hook→gen
- Synergy: regression

## Weaknesses and Counterplay

- spread
- pre-run
- hide
- recharge windows

The lowest General Matchmaking Power dimensions are Counterplay Resilience 7.5/10, Execution Reliability 8/10, Matchup Coverage 8/10, Recovery Value 8/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** size, traversal, verticality.

**Map Dependence:** 2/5 — intermediate canonical value.

**General Matchmaking Map Coverage:** 8.5/10.

## Skill Profile

- **Skill Floor:** 4/5 — intermediate canonical value
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 2/5 — intermediate canonical value
- **Execution Reliability, General Matchmaking:** 8/10
- **Strategic Commitment:** 4/5 — intermediate canonical value

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 5/5 |
| Activation Reliability | 5/5 |
| Activation Payoff | 4/5 |
| Denial Risk | 2/5 |
| Strategic Commitment | 4/5 |

## Meta Stability

**97 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 25/25 |
| Core Mechanic Durability | 20/20 |
| Replacement Depth | 14/15 |
| Environmental Breadth | 14/15 |
| Counter-Meta Independence | 9/10 |
| Patch Durability | 15/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM_HIGH |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Hook-to-Generator Conversion](hook-to-generator-conversion.md)
- [Network Surveillance / Teleport Control](network-surveillance-teleport-control.md)
- [Tunnel Rotation Implementation](tunnel-rotation-implementation.md)
- [Security-Door Rotation / Ambush Module](security-door-rotation-ambush-module.md)
- [Worldbreaker / Upside-Down Module](worldbreaker-upside-down-module.md)
- [Kagune-Mark / Enraged Module](kagune-mark-enraged-module.md)
- [Dream Projection Pressure Module](dream-projection-pressure-module.md)

## Source Metadata

- **Canonical ID:** `KSTR-026`
- **Snapshot:** `KSTR-026@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
