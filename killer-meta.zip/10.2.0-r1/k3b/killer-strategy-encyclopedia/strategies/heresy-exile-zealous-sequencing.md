---
canonicalId: "KSTR-056"
side: "KILLER"
name: "Heresy / Exile / Zealous Sequencing"
slug: "heresy-exile-zealous-sequencing"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "EMERGING"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-056@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: ["KSTR-066"]
rankingStatusGeneral: "PROVISIONAL"
rankingStatusSWF: "PROVISIONAL"
powerGeneral: 78
powerSWF: 71
tierGeneral: "A"
tierSWF: "B"
metaStability: 62
stabilityLabel: "WATCH"
trend: null
---

# Heresy / Exile / Zealous Sequencing

Apply Heresy, decide when to Exile eligible downed targets instead of conventional hook flow, exploit Zealous state and Shrine/Exile counterplay.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | KILLER_SPECIFIC |
| Strategic orientation | Not established |
| Current status | EMERGING |
| General Matchmaking | Provisional A — 78 |
| Coordinated SWF | Provisional B — 71 |
| Meta Stability | 62 — WATCH |
| Skill Floor | 4/5 — intermediate canonical value |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 3/5 — Material |
| Opportunity Cost | 3/5 — Meaningful tradeoff |

> **PROVISIONAL:** K3A contains numerical estimates, but the placement is not considered fully settled because the evidence base is still maturing.

## What This Strategy Is

**Heresy / Exile / Zealous Sequencing** is a Killer strategy built around this objective: **Apply Heresy, decide when to Exile eligible downed targets instead of conventional hook flow, exploit Zealous state and Shrine/Exile counterplay**.

Its defining loop is **Apply Heresy, decide when to Exile eligible downed targets instead of conventional hook flow, exploit Zealous state and Shrine/Exile counterplay**.

**K3A independence rationale:** Unique sacrifice-state economy, but recent Killer and 10.1.2a reversal prevent high confidence.

## How It Plays

The practical decision loop is: **Apply Heresy, decide when to Exile eligible downed targets instead of conventional hook flow, exploit Zealous state and Shrine/Exile counterplay**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 4/5 — intermediate canonical value.

## When It Works Best

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

**Material dependencies:** `KILLER_POWER`, `TARGET_STATE`, `TIMING`, `POSITIONING`

**Canonical synergies:** Zealous conversion, target tracking

## Killer Fit

**Best Fits:** The Judgment

**Canonical fit rationale:** Heresy/Exile/Zealous required.

**Global exclusion:** all other Killers are `INCOMPATIBLE` for this Strategy. Heresy/Exile/Zealous required.

## General Matchmaking

**Provisional A — 78.**

Exile's alternate sacrifice routing and Zealous payoff are meaningful, but the post-hotfix optimum is not settled.

## Against Coordinated SWF

**Provisional B — 71.**

Coordinated Shrine/Exile management lowers payoff and evidence remains immature.

## Why the Two Environments Differ

The canonical Power estimate changes from **78** in General Matchmaking to **71** against coordinated SWF (-7 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 7 → 5.5 (-1.5)
- **Consistency:** 7 → 6 (-1)
- **Matchup Coverage:** 7.5 → 6.5 (-1)
- **Recovery Value:** 7.5 → 6.5 (-1)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 9.5/10, Slot Efficiency 9.5/10, Ceiling 8.5/10, Agency 8/10.

- Synergy: Zealous conversion
- Synergy: target tracking

## Weaknesses and Counterplay

- Repent
- coordinate liberation
- avoid Heresy

The lowest General Matchmaking Power dimensions are Execution Reliability 6/10, Consistency 7/10, Counterplay Resilience 7/10, Map Coverage 7.5/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** Shrine routes, size, attack geometry.

**Map Dependence:** 3/5 — Material.

**General Matchmaking Map Coverage:** 7.5/10.

## Skill Profile

- **Skill Floor:** 4/5 — intermediate canonical value
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 3/5 — Meaningful tradeoff
- **Execution Reliability, General Matchmaking:** 6/10
- **Strategic Commitment:** 4/5 — intermediate canonical value

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Representative Implementations

### Framework — `KSTR-056-B01`

- **Killer:** The Judgment
- **Implementation:** Framework: selective Exile; no definitive four-perk package
- **Rationale:** Choose Exile when saved transport/hook-trigger bypass + Zealous exceeds alternate rescue downside
- **Strengths:** Unique sacrifice routing
- **Weaknesses:** Fresh hotfix ecosystem
- **Confidence:** LOW_MEDIUM
- **Content validity:** LIVE_10_2_SOURCE_SUPPORTED

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 3/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 4/5 |

## Meta Stability

**62 — WATCH**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 16/25 |
| Core Mechanic Durability | 14/20 |
| Replacement Depth | 8/15 |
| Environmental Breadth | 10/15 |
| Counter-Meta Independence | 6/10 |
| Patch Durability | 8/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | MEDIUM_HIGH |
| Power | LOW_MEDIUM |
| General Matchmaking | LOW_MEDIUM |
| Coordinated SWF | LOW |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## What We Are Watching

**Missing evidence / research flags:**
- Mature Exile-vs-hook criteria, optimized add-on/perk interaction, post-10.1.2a stability

**Uncertainty profile:** Power confidence `LOW_MEDIUM`, General Matchmaking `LOW_MEDIUM`, Coordinated SWF `LOW`.

**Recheck conditions:**
- Recheck after a stable post-10.1.2a/10.2 window without another material Power hotfix

## Related Strategies

- [Obsidian-Feather Forced-Cast Variant](obsidian-feather-forced-cast-variant.md)

## Source Metadata

- **Canonical ID:** `KSTR-056`
- **Snapshot:** `KSTR-056@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
| BHVR_PATCH_10_1_2A | Dead by Daylight 10.1.2a Hotfix | 2026-09-17 | K2 resolves The Judgment's live state in favor of the 10.1.2a hotfix. |
