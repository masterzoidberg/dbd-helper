---
canonicalId: "KSTR-010"
side: "KILLER"
name: "Hook-State Prioritization"
slug: "hook-state-prioritization"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "TEMPO"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-010@10.2.0-r1"
parentStrategyId: "KSTR-008"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Hook-State Prioritization

Prefer Survivors whose next down/hook converts more efficiently.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Prefer Survivors whose next down/hook converts more efficiently.

**Decision loop:** Track hook states → switch toward death-hook targets → abandon lower-value pursuits when a higher-conversion target appears.

## What Strategic Problem It Solves

Committed Elimination.

## Strategies It Supports

- [Target Focus / Elimination Sequencing](target-focus-elimination-sequencing.md)

**Canonical support note:** Committed Elimination.

## How It Changes Killer Decisions

Track hook states → switch toward death-hook targets → abandon lower-value pursuits when a higher-conversion target appears.

## Killer / Power Interaction

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

The canonical decision loop depends on: **Track hook states → switch toward death-hook targets → abandon lower-value pursuits when a higher-conversion target appears**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Usually rational state-aware target selection.

## Promotion Condition

Demonstrably independent target-switch loop beyond ordinary optimization.

## Related Strategies

- [Target Focus / Elimination Sequencing](target-focus-elimination-sequencing.md)

## Source Metadata

- **Canonical ID:** `KSTR-010`
- **Snapshot:** `KSTR-010@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
