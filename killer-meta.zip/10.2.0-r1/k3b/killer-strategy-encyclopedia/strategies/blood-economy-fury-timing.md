---
canonicalId: "KSTR-041"
side: "KILLER"
name: "Blood Economy / Fury Timing"
slug: "blood-economy-fury-timing"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-041@10.2.0-r1"
parentStrategyId: "KSTR-015"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Blood Economy / Fury Timing

Generate injuries, collect/preserve Blood Orbs, choose Fury activation timing, then seek rapid multi-down conversion.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Generate injuries, collect/preserve Blood Orbs, choose Fury activation timing, then seek rapid multi-down conversion.

**Decision loop:** Generate injuries, collect/preserve Blood Orbs, choose Fury activation timing, then seek rapid multi-down conversion.

## What Strategic Problem It Solves

Chain-Down.

## Strategies It Supports

- [Chain-Down Pressure](chain-down-pressure.md)

**Canonical support note:** Chain-Down.

## How It Changes Killer Decisions

Generate injuries, collect/preserve Blood Orbs, choose Fury activation timing, then seek rapid multi-down conversion.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Generate injuries, collect/preserve Blood Orbs, choose Fury activation timing, then seek rapid multi-down conversion**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Native resource execution.

## Promotion Condition

Separate macro objective beyond Chain-Down demonstrated.

## Related Strategies

- [Chain-Down Pressure](chain-down-pressure.md)

## Source Metadata

- **Canonical ID:** `KSTR-041`
- **Snapshot:** `KSTR-041@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
