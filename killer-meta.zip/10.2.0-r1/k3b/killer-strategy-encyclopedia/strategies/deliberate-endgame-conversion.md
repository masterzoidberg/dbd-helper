---
canonicalId: "KSTR-028"
side: "KILLER"
name: "Deliberate Endgame Conversion"
slug: "deliberate-endgame-conversion"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "HYBRID"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-028@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: ["KSTR-029"]
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 74
powerSWF: 65
tierGeneral: "B"
tierSWF: "C"
metaStability: 87
stabilityLabel: "VERY STABLE"
trend: null
---

# Deliberate Endgame Conversion

Enter powered-gate phase with deliberately preserved resources and a planned conversion window.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | BROAD_ROSTER |
| Strategic orientation | HYBRID |
| Current status | ESTABLISHED |
| General Matchmaking | B — 74 |
| Coordinated SWF | C — 65 |
| Meta Stability | 87 — VERY STABLE |
| Skill Floor | 2/5 — intermediate canonical value |
| Skill Ceiling | 4/5 — intermediate canonical value |
| Map Dependence | 4/5 — intermediate canonical value |
| Opportunity Cost | 5/5 — Severe commitment/resources foregone |

## What This Strategy Is

**Deliberate Endgame Conversion** is a Killer strategy built around this objective: **Enter powered-gate phase with deliberately preserved resources and a planned conversion window**.

Its defining loop is **Accept some earlier gen progress → accumulate tokens/resources → position for final completion → contest gates/hooks → convert late**.

**K3A independence rationale:** Earlier resources are deliberately traded for powered-gate conversion.

## How It Plays

The practical decision loop is: **Accept some earlier gen progress → accumulate tokens/resources → position for final completion → contest gates/hooks → convert late**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

**Material dependencies:** `GAME_STATE`, `MAP`, `RESOURCE_AVAILABILITY`, `TIMING`

**Canonical synergies:** gate mobility, saved resources

## Killer Fit

**Best Fits:** The Dredge, The Wraith, The Nightmare, The Demogorgon
**Strong Fits:** The Trapper, The Hag, The Doctor
**Viable Fits:** The Clown, The Pig

**Canonical fit rationale:** Fit rises with gate coverage/resource banking.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**B — 74.**

Large late payoff but intentionally concedes earlier objective leverage.

## Against Coordinated SWF

**C — 65.**

Coordinated gate splitting and pre-positioning reduce late conversion reliability.

## Why the Two Environments Differ

The canonical Power estimate changes from **74** in General Matchmaking to **65** against coordinated SWF (-9 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 7 → 5.5 (-1.5)
- **Matchup Coverage:** 7.5 → 6 (-1.5)
- **Agency:** 8 → 7 (-1)
- **Consistency:** 6.5 → 5.5 (-1)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Recovery Value 9/10, Snowball Value 9/10, Ceiling 8.5/10, Agency 8/10.

- Synergy: gate mobility
- Synergy: saved resources

## Weaknesses and Counterplay

- split gates
- pre-position
- coordinated rescue

The lowest General Matchmaking Power dimensions are Consistency 6.5/10, Map Coverage 6.5/10, Tempo Efficiency 6.5/10, Counterplay Resilience 7/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** gate spacing/sightlines, hooks.

**Map Dependence:** 4/5 — intermediate canonical value.

**General Matchmaking Map Coverage:** 6.5/10.

## Skill Profile

- **Skill Floor:** 2/5 — intermediate canonical value
- **Skill Ceiling:** 4/5 — intermediate canonical value
- **Opportunity Cost:** 5/5 — Severe commitment/resources foregone
- **Execution Reliability, General Matchmaking:** 7/10
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**87 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 23/25 |
| Core Mechanic Durability | 19/20 |
| Replacement Depth | 13/15 |
| Environmental Breadth | 10/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 14/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM |
| General Matchmaking | MEDIUM |
| Coordinated SWF | LOW_MEDIUM |
| Compatibility | MEDIUM_HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Gate Control](gate-control.md)

## Source Metadata

- **Canonical ID:** `KSTR-028`
- **Snapshot:** `KSTR-028@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
