---
canonicalId: "KSTR-029"
side: "KILLER"
name: "Gate Control"
slug: "gate-control"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-029@10.2.0-r1"
parentStrategyId: "KSTR-028"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Gate Control

Delay or punish exit-gate opening once generators are complete.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Delay or punish exit-gate opening once generators are complete.

**Decision loop:** Patrol switches → interrupt opening → exploit regression/blocking/info → force rescue-vs-gate decisions.

## What Strategic Problem It Solves

Endgame Conversion.

## Strategies It Supports

- [Deliberate Endgame Conversion](deliberate-endgame-conversion.md)

**Canonical support note:** Endgame Conversion.

## How It Changes Killer Decisions

Patrol switches → interrupt opening → exploit regression/blocking/info → force rescue-vs-gate decisions.

## Killer / Power Interaction

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

The canonical decision loop depends on: **Patrol switches → interrupt opening → exploit regression/blocking/info → force rescue-vs-gate decisions**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Late-phase support only.

## Promotion Condition

Independent pre-endgame commitment loop.

## Related Strategies

- [Deliberate Endgame Conversion](deliberate-endgame-conversion.md)

## Source Metadata

- **Canonical ID:** `KSTR-029`
- **Snapshot:** `KSTR-029@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
