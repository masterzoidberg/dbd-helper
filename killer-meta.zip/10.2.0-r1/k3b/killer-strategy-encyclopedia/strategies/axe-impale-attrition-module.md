---
canonicalId: "KSTR-057"
side: "KILLER"
name: "Axe-Impale Attrition Module"
slug: "axe-impale-attrition-module"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-057@10.2.0-r1"
parentStrategyId: "KSTR-017"
relatedStrategyIds: ["KSTR-017", "KSTR-022", "KSTR-026", "KSTR-057", "KSTR-058"]
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Axe-Impale Attrition Module

Use Fire Axe impalement as a healing-denial and injury-attrition support loop rather than as an independent macro-strategy.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Create temporary healing constraints that improve injury attrition and recontact value.

**Decision loop:** Impale a Survivor → force embedded-Axe removal before healing → exploit delayed reset or recontact windows.

## What Strategic Problem It Solves

Rapid Rotation/Ambush/injury.

## Strategies It Supports

- [Hit-and-Run Injury Attrition](hit-and-run-injury-attrition.md)
- [Ambush Rotation](ambush-rotation.md)
- [Rapid Rotation Pressure](rapid-rotation-pressure.md)
- [Security-Door Rotation / Ambush Module](security-door-rotation-ambush-module.md)

**Canonical support note:** Rapid Rotation/Ambush/injury.

## How It Changes Killer Decisions

Impale a Survivor → force embedded-Axe removal before healing → exploit delayed reset or recontact windows.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Impale a Survivor → force embedded-Axe removal before healing → exploit delayed reset or recontact windows.**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

K1 combined two separable mechanics.

## Promotion Condition

One component proves independent macro plan.

## Related Strategies

- [Hit-and-Run Injury Attrition](hit-and-run-injury-attrition.md)
- [Ambush Rotation](ambush-rotation.md)
- [Rapid Rotation Pressure](rapid-rotation-pressure.md)
- [Security-Door Rotation / Ambush Module](security-door-rotation-ambush-module.md)

## Source Metadata

- **Canonical ID:** `KSTR-057`
- **Snapshot:** `KSTR-057@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
