---
canonicalId: "KSTR-036"
side: "KILLER"
name: "Stalk-to-Expose Ambush"
slug: "stalk-to-expose-ambush"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META SUBTYPE"
applicabilityScope: "POWER_FAMILY"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-036@10.2.0-r1"
parentStrategyId: "KSTR-022"
relatedStrategyIds: []
childStrategyIds: ["KSTR-071"]
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 77
powerSWF: 62
tierGeneral: "B"
tierSWF: "C"
metaStability: 87
stabilityLabel: "VERY STABLE"
trend: null
---

# Stalk-to-Expose Ambush

Spend approach time acquiring stalk/expose value, select high-value marked targets, then convert a short lethal chase.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META SUBTYPE |
| Applicability scope | POWER_FAMILY |
| Strategic orientation | Not established |
| Current status | ESTABLISHED |
| General Matchmaking | B — 77 |
| Coordinated SWF | C — 62 |
| Meta Stability | 87 — VERY STABLE |
| Skill Floor | 4/5 — intermediate canonical value |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 5/5 — Extreme |
| Opportunity Cost | 4/5 — intermediate canonical value |

## What This Strategy Is

**Stalk-to-Expose Ambush** is a Killer strategy built around this objective: **Spend approach time acquiring stalk/expose value, select high-value marked targets, then convert a short lethal chase**.

Its defining loop is **Spend approach time acquiring stalk/expose value, select high-value marked targets, then convert a short lethal chase**.

**K3A independence rationale:** Stalk investment changes approach time and target conversion enough to remain distinct.

## How It Plays

The practical decision loop is: **Spend approach time acquiring stalk/expose value, select high-value marked targets, then convert a short lethal chase**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 4/5 — intermediate canonical value.

## When It Works Best

This plan depends on a family of native Power qualities. A superficially similar Power is not automatically enough for compatibility.

**Material dependencies:** `KILLER_POWER`, `MAP`, `OPPONENT_BEHAVIOR`, `POSITIONING`

**Canonical synergies:** Ambush Rotation, target tracking

## Killer Fit

**Best Fits:** The Ghost Face
**Strong Fits:** The Shape

**Canonical fit rationale:** Only stalk/expose Powers belong to the family.

**Global exclusion:** all other Killers are `INCOMPATIBLE` for this Strategy. Only stalk/expose Powers belong to the family.

## General Matchmaking

**B — 77.**

Strong surprise/lethal conversion where sightlines permit stalking.

## Against Coordinated SWF

**C — 62.**

Stalk progress/location callouts directly undermine surprise conversion.

## Why the Two Environments Differ

The canonical Power estimate changes from **77** in General Matchmaking to **62** against coordinated SWF (-15 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 6.5 → 4 (-2.5)
- **Matchup Coverage:** 7 → 4.5 (-2.5)
- **Consistency:** 7 → 5 (-2)
- **Tempo Efficiency:** 8 → 6 (-2)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 10/10, Slot Efficiency 9.5/10, Ceiling 9/10, Snowball Value 8/10.

- Synergy: Ambush Rotation
- Synergy: target tracking

## Weaknesses and Counterplay

- deny stalk
- callouts
- pre-run

The lowest General Matchmaking Power dimensions are Counterplay Resilience 6.5/10, Execution Reliability 6.5/10, Map Coverage 6.5/10, Consistency 7/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** LOS, cover, openness.

**Map Dependence:** 5/5 — Extreme.

**General Matchmaking Map Coverage:** 6.5/10.

## Skill Profile

- **Skill Floor:** 4/5 — intermediate canonical value
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 4/5 — intermediate canonical value
- **Execution Reliability, General Matchmaking:** 6.5/10
- **Strategic Commitment:** 4/5 — intermediate canonical value

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 3/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 4/5 |
| Strategic Commitment | 4/5 |

## Meta Stability

**87 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 24/25 |
| Core Mechanic Durability | 19/20 |
| Replacement Depth | 13/15 |
| Environmental Breadth | 10/15 |
| Counter-Meta Independence | 7/10 |
| Patch Durability | 14/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Ambush Rotation](ambush-rotation.md)
- [Historical Tombstone-Piece Direct-Kill Shape](historical-tombstone-piece-direct-kill-shape.md)

## Source Metadata

- **Canonical ID:** `KSTR-036`
- **Snapshot:** `KSTR-036@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
