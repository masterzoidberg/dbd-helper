---
canonicalId: "KSTR-055"
side: "KILLER"
name: "Torment / Cage Sequencing"
slug: "torment-cage-sequencing"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-055@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 77
powerSWF: 76
tierGeneral: "B"
tierSWF: "B"
metaStability: 88
stabilityLabel: "VERY STABLE"
trend: null
---

# Torment / Cage Sequencing

Create Torment, decide whether to Cage instead of hook, exploit alternate sacrifice routing and bypass/avoid hook-trigger ecosystems where appropriate.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | KILLER_SPECIFIC |
| Strategic orientation | Not established |
| Current status | ESTABLISHED |
| General Matchmaking | B — 77 |
| Coordinated SWF | B — 76 |
| Meta Stability | 88 — VERY STABLE |
| Skill Floor | 4/5 — intermediate canonical value |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 3/5 — Material |
| Opportunity Cost | 3/5 — Meaningful tradeoff |

## What This Strategy Is

**Torment / Cage Sequencing** is a Killer strategy built around this objective: **Create Torment, decide whether to Cage instead of hook, exploit alternate sacrifice routing and bypass/avoid hook-trigger ecosystems where appropriate**.

Its defining loop is **Create Torment, decide whether to Cage instead of hook, exploit alternate sacrifice routing and bypass/avoid hook-trigger ecosystems where appropriate**.

**K3A independence rationale:** Cage-vs-hook choice materially changes transport, perk triggers and sacrifice routing.

## How It Plays

The practical decision loop is: **Create Torment, decide whether to Cage instead of hook, exploit alternate sacrifice routing and bypass/avoid hook-trigger ecosystems where appropriate**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 4/5 — intermediate canonical value.

## When It Works Best

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

**Material dependencies:** `KILLER_POWER`, `TARGET_STATE`, `POSITIONING`, `TIMING`

**Canonical synergies:** non-hook pressure, zoning

## Killer Fit

**Best Fits:** The Executioner

**Canonical fit rationale:** Torment/Cage required.

**Global exclusion:** all other Killers are `INCOMPATIBLE` for this Strategy. Torment/Cage required.

## General Matchmaking

**B — 77.**

Cage routing saves transport and bypasses hook-trigger structures when Torment is available, but activation is conditional.

## Against Coordinated SWF

**B — 76.**

One of the most coordination-resilient niche plans: communication does not erase Torment or the Cage-vs-hook choice.

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 9.5/10, Slot Efficiency 9.5/10, Ceiling 8/10, Agency 7.5/10.

- Synergy: non-hook pressure
- Synergy: zoning

## Weaknesses and Counterplay

- avoid Torment
- force low-value ordinary routing

The lowest General Matchmaking Power dimensions are Consistency 7/10, Execution Reliability 7/10, Snowball Value 7/10, Agency 7.5/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** trail space, tile geometry.

**Map Dependence:** 3/5 — Material.

**General Matchmaking Map Coverage:** 7.5/10.

## Skill Profile

- **Skill Floor:** 4/5 — intermediate canonical value
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 3/5 — Meaningful tradeoff
- **Execution Reliability, General Matchmaking:** 7/10
- **Strategic Commitment:** 4/5 — intermediate canonical value

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 3/5 |
| Activation Payoff | 4/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 4/5 |

## Meta Stability

**88 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 24/25 |
| Core Mechanic Durability | 19/20 |
| Replacement Depth | 12/15 |
| Environmental Breadth | 11/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 14/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

No additional canonical Strategy relationships are established in K3A.

## Source Metadata

- **Canonical ID:** `KSTR-055`
- **Snapshot:** `KSTR-055@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
