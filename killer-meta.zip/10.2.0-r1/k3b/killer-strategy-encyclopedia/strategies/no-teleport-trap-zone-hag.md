---
canonicalId: "KSTR-067"
side: "KILLER"
name: "No-Teleport Trap-Zone Hag"
slug: "no-teleport-trap-zone-hag"
pageType: "MECHANIC_CENTERED_BUILD"
structuralClassification: "MECHANIC-CENTERED BUILD"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-067@10.2.0-r1"
parentStrategyId: "KSTR-024"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# No-Teleport Trap-Zone Hag

No-teleport Hag variant that converts the trap web toward local movement denial while remaining an implementation of Setup-Zone Lockdown.

> **Mechanic-Centered Build:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What the Build Family Is

**Core mechanic/idea:** No-teleport Hag variant that converts the trap web toward local movement denial while remaining an implementation of Setup-Zone Lockdown.

**Canonical loop:** Build a compact trap web → contest triggered zones without teleporting → exploit local speed/Hindered pressure → maintain the same setup-zone objective.

## Typical Strategic Uses

Setup-Zone.

## Strategies It Supports

- [Setup-Zone Lockdown](setup-zone-lockdown.md)

**Canonical support note:** Setup-Zone.

## How It Changes Gameplay

Build a compact trap web → contest triggered zones without teleporting → exploit local speed/Hindered pressure → maintain the same setup-zone objective.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Build a compact trap web → contest triggered zones without teleporting → exploit local speed/Hindered pressure → maintain the same setup-zone objective.**.

## Perk / Add-on Ecosystem

**Canonical add-on ecosystem:**
- **Waterlogged Shoe** — SUBTYPE ENABLER: K2-new support object. Teleport is removed; speed/Hindered turn the trap web toward local movement denial. Same Setup-Zone objective, so no independent Power.

## Why It Is Not a Standalone Strategy

Major Power-use transformation, same strategic objective.

## Promotion Condition

Only promote if no-teleport Hag develops independent objective/counterplay beyond Setup-Zone.

## Related Strategies

- [Setup-Zone Lockdown](setup-zone-lockdown.md)

## Source Metadata

- **Canonical ID:** `KSTR-067`
- **Snapshot:** `KSTR-067@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
