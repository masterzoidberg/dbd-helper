---
canonicalId: "KSTR-006"
side: "KILLER"
name: "Repair-Speed Suppression"
slug: "repair-speed-suppression"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-006@10.2.0-r1"
parentStrategyId: "KSTR-001"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Repair-Speed Suppression

Increase time cost of repairing rather than directly removing progress.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Increase time cost of repairing rather than directly removing progress.

**Decision loop:** Maintain required conditions → let slower repair create extra chase/rotation time.

## What Strategic Problem It Solves

Generator/Attrition.

## Strategies It Supports

- [Generator Control](generator-control.md)

**Canonical support note:** Generator/Attrition.

## How It Changes Killer Decisions

Maintain required conditions → let slower repair create extra chase/rotation time.

## Killer / Power Interaction

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

The canonical decision loop depends on: **Maintain required conditions → let slower repair create extra chase/rotation time**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Supplies time rather than defining its use.

## Promotion Condition

Distinct target/movement policy caused by suppression itself.

## Related Strategies

- [Generator Control](generator-control.md)

## Source Metadata

- **Canonical ID:** `KSTR-006`
- **Snapshot:** `KSTR-006@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
