---
canonicalId: "KSTR-037"
side: "KILLER"
name: "Lament Configuration / Chain-Hunt Control"
slug: "lament-configuration-chain-hunt-control"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "NICHE STRATEGY"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-037@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 82
powerSWF: 72
tierGeneral: "A"
tierSWF: "B"
metaStability: 85
stabilityLabel: "VERY STABLE"
trend: null
---

# Lament Configuration / Chain-Hunt Control

Track and contest the Box, force solve timing, teleport/intercept, convert Chain Hunt into multi-Survivor slowdown.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | NICHE STRATEGY |
| Applicability scope | KILLER_SPECIFIC |
| Strategic orientation | Not established |
| Current status | ESTABLISHED |
| General Matchmaking | A — 82 |
| Coordinated SWF | B — 72 |
| Meta Stability | 85 — VERY STABLE |
| Skill Floor | 4/5 — intermediate canonical value |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 3/5 — Material |
| Opportunity Cost | 3/5 — Meaningful tradeoff |

## What This Strategy Is

**Lament Configuration / Chain-Hunt Control** is a Killer strategy built around this objective: **Track and contest the Box, force solve timing, teleport/intercept, convert Chain Hunt into multi-Survivor slowdown**.

Its defining loop is **Track and contest the Box, force solve timing, teleport/intercept, convert Chain Hunt into multi-Survivor slowdown**.

**K3A independence rationale:** Box contest is a unique secondary-objective control loop.

## How It Plays

The practical decision loop is: **Track and contest the Box, force solve timing, teleport/intercept, convert Chain Hunt into multi-Survivor slowdown**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

**Material dependencies:** `KILLER_POWER`, `OPPONENT_BEHAVIOR`, `TIMING`, `POSITIONING`

**Canonical synergies:** info, interception, gen pressure

## Killer Fit

**Best Fits:** The Cenobite

**Canonical fit rationale:** Lament Configuration/Chain Hunt required.

**Global exclusion:** all other Killers are `INCOMPATIBLE` for this Strategy. Lament Configuration/Chain Hunt required.

## General Matchmaking

**A — 82.**

Box timing and interception create large multi-Survivor opportunity costs.

## Against Coordinated SWF

**B — 72.**

Dedicated solver roles and box callouts materially reduce public-match error value.

## Why the Two Environments Differ

The canonical Power estimate changes from **82** in General Matchmaking to **72** against coordinated SWF (-10 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 7.5 → 5.5 (-2)
- **Matchup Coverage:** 8 → 6 (-2)
- **Consistency:** 8 → 6.5 (-1.5)
- **Recovery Value:** 7.5 → 6 (-1.5)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 9.5/10, Slot Efficiency 9.5/10, Ceiling 8.5/10, Snowball Value 8.5/10.

- Synergy: info
- Synergy: interception
- Synergy: gen pressure

## Weaknesses and Counterplay

- dedicated solver
- solve timing
- callouts

The lowest General Matchmaking Power dimensions are Execution Reliability 7/10, Counterplay Resilience 7.5/10, Recovery Value 7.5/10, Agency 8/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** box search geometry, size.

**Map Dependence:** 3/5 — Material.

**General Matchmaking Map Coverage:** 8/10.

## Skill Profile

- **Skill Floor:** 4/5 — intermediate canonical value
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 3/5 — Meaningful tradeoff
- **Execution Reliability, General Matchmaking:** 7/10
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 5/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**85 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 23/25 |
| Core Mechanic Durability | 18/20 |
| Replacement Depth | 12/15 |
| Environmental Breadth | 11/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 13/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

No additional canonical Strategy relationships are established in K3A.

## Source Metadata

- **Canonical ID:** `KSTR-037`
- **Snapshot:** `KSTR-037@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
