---
canonicalId: "KSTR-042"
side: "KILLER"
name: "Split-Body Chain Sequencing"
slug: "split-body-chain-sequencing"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-042@10.2.0-r1"
parentStrategyId: "KSTR-015"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Split-Body Chain Sequencing

Position Charlotte, deploy Victor for distant chase/down/attachment pressure, chain contacts, then route Charlotte for pickups/hooks.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Position Charlotte, deploy Victor for distant chase/down/attachment pressure, chain contacts, then route Charlotte for pickups/hooks.

**Decision loop:** Position Charlotte, deploy Victor for distant chase/down/attachment pressure, chain contacts, then route Charlotte for pickups/hooks.

## What Strategic Problem It Solves

Chain-/Down-State.

## Strategies It Supports

- [Chain-Down Pressure](chain-down-pressure.md)

**Canonical support note:** Chain-/Down-State.

## How It Changes Killer Decisions

Position Charlotte, deploy Victor for distant chase/down/attachment pressure, chain contacts, then route Charlotte for pickups/hooks.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Position Charlotte, deploy Victor for distant chase/down/attachment pressure, chain contacts, then route Charlotte for pickups/hooks**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Native pickup/down implementation.

## Promotion Condition

Distinct strategic win loop independent of multi-down policy.

## Related Strategies

- [Chain-Down Pressure](chain-down-pressure.md)

## Source Metadata

- **Canonical ID:** `KSTR-042`
- **Snapshot:** `KSTR-042@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
