---
canonicalId: "KSTR-011"
side: "KILLER"
name: "Hook-Zone / Rescue Pressure"
slug: "hook-zone-rescue-pressure"
pageType: "PARENT_STRATEGY_FAMILY"
structuralClassification: "PARENT STRATEGY FAMILY"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "HYBRID"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-011@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: ["KSTR-012", "KSTR-013", "KSTR-014", "KSTR-032"]
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Hook-Zone / Rescue Pressure

Convert a hooked Survivor into secondary pressure on rescuers and nearby objectives.

> **Strategy Family:** This is an organizational family, not an independently ranked gameplay plan. It has no aggregate Power, Tier, or Ranking Index.

## Family Definition

**Shared objective:** Convert a hooked Survivor into secondary pressure on rescuers and nearby objectives.

**Shared loop:** Hook → control approach routes/nearby resources → force delayed rescue, trade, health loss or generator abandonment.

Convert a hooked Survivor into secondary pressure on rescuers/objectives.

## Current Children

| Child | Classification | General Matchmaking | Coordinated SWF |
|---|---|---|---|
| [Proxy Hook-Zone Control](proxy-hook-zone-control.md) | META | B — 76 | B — 69 |
| [Hook + Objective Anchor Control](hook-objective-anchor-control.md) | META SUBTYPE | A — 78 | B — 71 |
| [Basement / Fixed-Anchor Control](basement-fixed-anchor-control.md) | NICHE STRATEGY | B — 71 | C — 63 |
| [Carry / Hook-Transport Optimization](carry-hook-transport-optimization.md) | MECHANIC-CENTERED BUILD | Not independently ranked | Not independently ranked |

## How the Children Differ

- **[Proxy Hook-Zone Control](proxy-hook-zone-control.md):** Threaten rescues while preserving ability to contest surrounding map
- **[Hook + Objective Anchor Control](hook-objective-anchor-control.md):** Defend a hooked Survivor and high-value nearby generator/territory simultaneously
- **[Basement / Fixed-Anchor Control](basement-fixed-anchor-control.md):** Convert a very defensible hook zone into repeated rescue pressure
- **[Carry / Hook-Transport Optimization](carry-hook-transport-optimization.md):** Reach strategically better hooks and punish interference

## Shared Counterplay

rescue timing, bodyblocks, work elsewhere, Resolve constraints.

## Related Families and Cross-Links


**Canonical relationship note:** Generator Control; Territorial.

## Strongest Current Children

- **General Matchmaking:** Hook Anchor 78
- **Coordinated SWF:** Hook Anchor 71

These are child-level canonical results, not an aggregate score for the family.

## Family Scope

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

## Source Metadata

- **Canonical ID:** `KSTR-011`
- **Snapshot:** `KSTR-011@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
