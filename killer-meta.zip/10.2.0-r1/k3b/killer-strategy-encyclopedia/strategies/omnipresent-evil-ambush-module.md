---
canonicalId: "KSTR-059"
side: "KILLER"
name: "Omnipresent-Evil Ambush Module"
slug: "omnipresent-evil-ambush-module"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-059@10.2.0-r1"
parentStrategyId: "KSTR-022"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Omnipresent-Evil Ambush Module

Use hidden/Undetectable traversal and instant reposition opportunities to approach unexpectedly, then convert Impaling Throw geometry into injuries/pins.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Use hidden/Undetectable traversal and instant reposition opportunities to approach unexpectedly, then convert Impaling Throw geometry into injuries/pins.

**Decision loop:** Use hidden/Undetectable traversal and instant reposition opportunities to approach unexpectedly, then convert Impaling Throw geometry into injuries/pins.

## What Strategic Problem It Solves

Ambush.

## Strategies It Supports

- [Ambush Rotation](ambush-rotation.md)

**Canonical support note:** Ambush.

## How It Changes Killer Decisions

Use hidden/Undetectable traversal and instant reposition opportunities to approach unexpectedly, then convert Impaling Throw geometry into injuries/pins.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Use hidden/Undetectable traversal and instant reposition opportunities to approach unexpectedly, then convert Impaling Throw geometry into injuries/pins**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not Independently Ranked

Native implementation.

## Promotion Condition

Distinct objective beyond ambush routing.

## Related Strategies

- [Ambush Rotation](ambush-rotation.md)

## Source Metadata

- **Canonical ID:** `KSTR-059`
- **Snapshot:** `KSTR-059@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
