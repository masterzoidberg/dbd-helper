---
canonicalId: "KSTR-030"
side: "KILLER"
name: "Scourge-Hook Routing"
slug: "scourge-hook-routing"
pageType: "MECHANIC_CENTERED_BUILD"
structuralClassification: "MECHANIC-CENTERED BUILD"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "HYBRID"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-030@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Scourge-Hook Routing

Convert selected hook locations into specific effects.

> **Mechanic-Centered Build:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What the Build Family Is

**Core mechanic/idea:** Convert selected hook locations into specific effects.

**Canonical loop:** Down → evaluate Scourge location/transport cost → hook there if worthwhile → exploit payoff.

## Typical Strategic Uses

Hook-to-Gen, Hook Anchor, info.

## Strategies It Supports


**Canonical support note:** Hook-to-Gen, Hook Anchor, info.

## How It Changes Gameplay

Down → evaluate Scourge location/transport cost → hook there if worthwhile → exploit payoff.

## Killer / Power Interaction

This plan is defined broadly enough to apply across multiple Killers; K3A evaluates fit sparsely rather than assuming universal compatibility.

The canonical decision loop depends on: **Down → evaluate Scourge location/transport cost → hook there if worthwhile → exploit payoff**.

## Perk / Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Why It Is Not a Standalone Strategy

Hook-location mechanic shared by several Strategies.

## Promotion Condition

Independent objective beyond effect delivery.

## Related Strategies

No additional canonical Strategy relationships are established in K3A.

## Source Metadata

- **Canonical ID:** `KSTR-030`
- **Snapshot:** `KSTR-030@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
