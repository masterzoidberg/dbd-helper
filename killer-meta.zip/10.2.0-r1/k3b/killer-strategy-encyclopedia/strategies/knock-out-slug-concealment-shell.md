---
canonicalId: "KSTR-034"
side: "KILLER"
name: "Knock Out Slug-Concealment Shell"
slug: "knock-out-slug-concealment-shell"
pageType: "LEGACY"
structuralClassification: "MECHANIC-CENTERED BUILD"
applicabilityScope: "BROAD_ROSTER"
strategicOrientation: "CONTROL"
currentStatus: "LEGACY"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-034@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: ["KSTR-015", "KSTR-016"]
childStrategyIds: []
rankingStatusGeneral: "NOT_CURRENT"
rankingStatusSWF: "NOT_CURRENT"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Knock Out Slug-Concealment Shell

> **LEGACY — Not Current on Patch 10.2.0-r1**

Conceal/inhibit recovery information around downed Survivors to sustain down-state pressure.

## What It Was

Conceal/inhibit recovery information around downed Survivors to sustain down-state pressure

## How It Played

Conceal/inhibit recovery information around downed Survivors to sustain down-state pressure.

## Why It Is No Longer Current

10.2 Knock Out is now a pallet/Hindered perk

**Transition:** Patch 10.2.0 rework.

## What Replaced It

- [Chain-Down Pressure](chain-down-pressure.md)
- [Sustained Down-State Control](sustained-down-state-control.md)

**Canonical successor note:** Sustained Down-State / Chain-Down without old shell.

## Terminology Warning

“Knock Out slug build” now describes obsolete mechanics unless explicitly historical.

## Current Ranking Status

Both current environments are `NOT_CURRENT`. Power, Tier, and Ranking Index are intentionally null.

## Source Metadata

- **Canonical ID:** `KSTR-034`
- **Snapshot:** `KSTR-034@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
| BHVR_PATCH_10_2_0 | Dead by Daylight 10.2.0 Mid-Chapter | 2026-10-06 | Official live Patch 10.2.0 mechanics. |
