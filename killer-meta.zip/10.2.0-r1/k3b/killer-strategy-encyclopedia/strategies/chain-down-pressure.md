---
canonicalId: "KSTR-015"
side: "KILLER"
name: "Chain-Down Pressure"
slug: "chain-down-pressure"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META"
applicabilityScope: "POWER_FAMILY"
strategicOrientation: "TEMPO"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-015@10.2.0-r1"
parentStrategyId: null
relatedStrategyIds: []
childStrategyIds: ["KSTR-041", "KSTR-042"]
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 85
powerSWF: 77
tierGeneral: "A"
tierSWF: "B"
metaStability: 91
stabilityLabel: "VERY STABLE"
trend: null
---

# Chain-Down Pressure

Delay pickup to convert a temporary numerical advantage into additional downs.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META |
| Applicability scope | POWER_FAMILY |
| Strategic orientation | TEMPO |
| Current status | ESTABLISHED |
| General Matchmaking | A — 85 |
| Coordinated SWF | B — 77 |
| Meta Stability | 91 — VERY STABLE |
| Skill Floor | 4/5 — intermediate canonical value |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 3/5 — Material |
| Opportunity Cost | 4/5 — intermediate canonical value |

## What This Strategy Is

**Chain-Down Pressure** is a Killer strategy built around this objective: **Delay pickup to convert a temporary numerical advantage into additional downs**.

Its defining loop is **Down → detect/reach another vulnerable Survivor → chase/down again → hook once opposition collapses or risk rises**.

**K3A independence rationale:** Deliberate second/third-down pursuit is distinct from temporary slugging and from “snowball” as an outcome.

## How It Plays

The practical decision loop is: **Down → detect/reach another vulnerable Survivor → chase/down again → hook once opposition collapses or risk rises**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 4/5 — intermediate canonical value.

## When It Works Best

This plan depends on a family of native Power qualities. A superficially similar Power is not automatically enough for compatibility.

**Material dependencies:** `KILLER_POWER`, `POSITIONING`, `TARGET_STATE`, `TIMING`

**Canonical synergies:** mobility, info, multi-down Power

## Killer Fit

**Best Fits:** The Oni, The Twins, The Spirit
**Strong Fits:** The Hillbilly, The Blight, The Ghoul
**Viable Fits:** The Xenomorph, The Wraith
**Weak Fits:** The Trapper

**Canonical fit rationale:** Family boundary: second target can be reached before pickup delay loses value.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**A — 85.**

High second-down conversion on appropriate Powers; public teams are less reliable at rapid recovery coordination.

## Against Coordinated SWF

**B — 77.**

Voice comms greatly improve recovery/pickup spacing, but compatible Powers can still punish clustered mistakes.

## Why the Two Environments Differ

The canonical Power estimate changes from **85** in General Matchmaking to **77** against coordinated SWF (-8 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 7.5 → 6 (-1.5)
- **Matchup Coverage:** 8 → 6.5 (-1.5)
- **Consistency:** 8 → 7 (-1)
- **Recovery Value:** 8.5 → 7.5 (-1)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Snowball Value 10/10, Ceiling 9.5/10, Power Integration 9/10, Slot Efficiency 9/10.

- Synergy: mobility
- Synergy: info
- Synergy: multi-down Power

## Weaknesses and Counterplay

- spread
- rapid pickups
- recovery
- deny next-target info

The lowest General Matchmaking Power dimensions are Counterplay Resilience 7.5/10, Execution Reliability 7.5/10, Map Coverage 7.5/10, Consistency 8/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** Survivor spacing, LOS, travel.

**Map Dependence:** 3/5 — Material.

**General Matchmaking Map Coverage:** 7.5/10.

## Skill Profile

- **Skill Floor:** 4/5 — intermediate canonical value
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 4/5 — intermediate canonical value
- **Execution Reliability, General Matchmaking:** 7.5/10
- **Strategic Commitment:** 4/5 — intermediate canonical value

## Build and Add-on Ecosystem

**Canonical add-on ecosystem:**
- **Matchbox** — IMPLEMENTATION DETAIL: One Blink plus 4.4 m/s changes chase execution dramatically, but does not create an independent macro objective.

## Representative Implementations

### Framework — `KSTR-015-B01`

- **Killer:** The Oni
- **Implementation:** Framework: native Fury window + optional information; no mandatory four-perk package
- **Rationale:** Continue to second target only when additional-down value exceeds pickup delay
- **Strengths:** Very high snowball
- **Weaknesses:** Recovery calls punish overextension
- **Confidence:** MEDIUM_HIGH
- **Content validity:** LIVE_10_2_SOURCE_SUPPORTED

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 5/5 |
| Activation Reliability | 4/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 4/5 |

## Meta Stability

**91 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 24/25 |
| Core Mechanic Durability | 19/20 |
| Replacement Depth | 14/15 |
| Environmental Breadth | 12/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 14/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Blood Economy / Fury Timing](blood-economy-fury-timing.md)
- [Split-Body Chain Sequencing](split-body-chain-sequencing.md)

## Source Metadata

- **Canonical ID:** `KSTR-015`
- **Snapshot:** `KSTR-015@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
