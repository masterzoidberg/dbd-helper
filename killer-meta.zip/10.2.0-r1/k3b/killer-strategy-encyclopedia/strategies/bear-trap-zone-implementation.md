---
canonicalId: "KSTR-045"
side: "KILLER"
name: "Bear-Trap Zone Implementation"
slug: "bear-trap-zone-implementation"
pageType: "STRATEGIC_MODULE"
structuralClassification: "STRATEGIC MODULE"
applicabilityScope: "KILLER_SPECIFIC"
strategicOrientation: null
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-045@10.2.0-r1"
parentStrategyId: "KSTR-024"
relatedStrategyIds: []
childStrategyIds: []
rankingStatusGeneral: "NOT_APPLICABLE"
rankingStatusSWF: "NOT_APPLICABLE"
powerGeneral: null
powerSWF: null
tierGeneral: null
tierSWF: null
metaStability: null
stabilityLabel: null
trend: null
---

# Bear-Trap Zone Implementation

Invest early/setup time in high-traffic traps, shape pathing, then pressure Survivors through trapped or resource-depleted regions.

> **Strategic Module:** This object is strategically useful but is not independently ranked. K3A assigns no Power, Tier, or Ranking Index.

## What It Does

**Objective:** Invest early/setup time in high-traffic traps, shape pathing, then pressure Survivors through trapped or resource-depleted regions.

**Decision loop:** Invest early/setup time in high-traffic traps, shape pathing, then pressure Survivors through trapped or resource-depleted regions.

## What Strategic Problem It Solves

Setup-Zone.

## Strategies It Supports

- [Setup-Zone Lockdown](setup-zone-lockdown.md)

**Canonical support note:** Setup-Zone.

## How It Changes Killer Decisions

Invest early/setup time in high-traffic traps, shape pathing, then pressure Survivors through trapped or resource-depleted regions.

## Killer / Power Interaction

This plan depends on a specific Killer’s native mechanics and should not be generalized to the roster.

The canonical decision loop depends on: **Invest early/setup time in high-traffic traps, shape pathing, then pressure Survivors through trapped or resource-depleted regions**.

## Perk / Add-on Ecosystem

**Canonical add-on ecosystem:**
- **Trapper Sack** — SUBTYPE ENABLER: All traps start in inventory, but placed traps cannot be picked back up; substantially changes setup timing and relocation commitment, not the objective.

## Why It Is Not Independently Ranked

Same setup objective.

## Promotion Condition

Same.

## Related Strategies

- [Setup-Zone Lockdown](setup-zone-lockdown.md)

## Source Metadata

- **Canonical ID:** `KSTR-045`
- **Snapshot:** `KSTR-045@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
