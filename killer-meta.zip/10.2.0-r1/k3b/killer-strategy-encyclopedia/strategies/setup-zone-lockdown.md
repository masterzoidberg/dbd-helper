---
canonicalId: "KSTR-024"
side: "KILLER"
name: "Setup-Zone Lockdown"
slug: "setup-zone-lockdown"
pageType: "CURRENT_INDEPENDENT_STRATEGY"
structuralClassification: "META SUBTYPE"
applicabilityScope: "POWER_FAMILY"
strategicOrientation: "CONTROL"
currentStatus: "ESTABLISHED"
patchBaseline: "10.2.0"
researchRevision: 1
snapshotId: "KSTR-024@10.2.0-r1"
parentStrategyId: "KSTR-023"
relatedStrategyIds: []
childStrategyIds: ["KSTR-044", "KSTR-045", "KSTR-067"]
rankingStatusGeneral: "RANKED"
rankingStatusSWF: "RANKED"
powerGeneral: 74
powerSWF: 66
tierGeneral: "B"
tierSWF: "B"
metaStability: 87
stabilityLabel: "VERY STABLE"
trend: null
---

# Setup-Zone Lockdown

Build a local web of traps or hazards and fight where the Power is already invested.

## At a Glance

| Field | Current canonical view |
|---|---|
| Structural classification | META SUBTYPE |
| Applicability scope | POWER_FAMILY |
| Strategic orientation | CONTROL |
| Current status | ESTABLISHED |
| General Matchmaking | B — 74 |
| Coordinated SWF | B — 66 |
| Meta Stability | 87 — VERY STABLE |
| Skill Floor | 4/5 — intermediate canonical value |
| Skill Ceiling | 5/5 — Very deep decision/execution ceiling |
| Map Dependence | 5/5 — Extreme |
| Opportunity Cost | 5/5 — Severe commitment/resources foregone |

## What This Strategy Is

**Setup-Zone Lockdown** is a Killer strategy built around this objective: **Build a local web of traps or hazards and fight where the Power is already invested**.

Its defining loop is **Place/setup → steer Survivors into prepared area → react to trigger/disarm → rebuild or relocate**.

**K3A independence rationale:** Pre-invested hazards/resources create a persistent territorial loop.

## How It Plays

The practical decision loop is: **Place/setup → steer Survivors into prepared area → react to trigger/disarm → rebuild or relocate**. The Strategy is the repeated decision policy around that loop, not merely one perk activation or one use of a Killer Power.

**Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources.

## When It Works Best

This plan depends on a family of native Power qualities. A superficially similar Power is not automatically enough for compatibility.

**Material dependencies:** `KILLER_POWER`, `MAP`, `RESOURCE_AVAILABILITY`, `TIMING`

**Canonical synergies:** anchors, clusters, info

## Killer Fit

**Best Fits:** The Hag, The Trapper
**Strong Fits:** The Skull Merchant
**Viable Fits:** The Singularity
**Weak Fits:** The Nurse

**Canonical fit rationale:** Pre-invest finite hazards/resources in a local region.

Killers not listed above are **not evaluated**, not implicitly viable or weak.

## General Matchmaking

**B — 74.**

Strong prepared-zone payoff, offset by setup and relocation cost.

## Against Coordinated SWF

**B — 66.**

Comms improve disarm/avoidance and let Survivors deliberately work outside prepared territory.

## Why the Two Environments Differ

The canonical Power estimate changes from **74** in General Matchmaking to **66** against coordinated SWF (-8 points).

The largest canonical dimension shifts are:
- **Counterplay Resilience:** 7 → 5.5 (-1.5)
- **Matchup Coverage:** 7 → 5.5 (-1.5)
- **Consistency:** 7 → 6 (-1)
- **Recovery Value:** 7.5 → 6.5 (-1)

## Strengths

K3A’s strongest General Matchmaking Power dimensions are Power Integration 9.5/10, Ceiling 8.5/10, Slot Efficiency 8.5/10, Snowball Value 8.5/10.

- Synergy: anchors
- Synergy: clusters
- Synergy: info

## Weaknesses and Counterplay

- disarm/avoid
- split map
- rush early gens

The lowest General Matchmaking Power dimensions are Map Coverage 5/10, Execution Reliability 6.5/10, Consistency 7/10, Counterplay Resilience 7/10. These are comparative model dimensions, not claims that the Strategy always fails in those areas.

## Map Considerations

**Material map factors:** geometry, chokepoints, setup space.

**Map Dependence:** 5/5 — Extreme.

**General Matchmaking Map Coverage:** 5/10.

## Skill Profile

- **Skill Floor:** 4/5 — intermediate canonical value
- **Skill Ceiling:** 5/5 — Very deep decision/execution ceiling
- **Opportunity Cost:** 5/5 — Severe commitment/resources foregone
- **Execution Reliability, General Matchmaking:** 6.5/10
- **Strategic Commitment:** 5/5 — Strongly constrains targets/pathing/hooks/resources

## Build and Add-on Ecosystem

K3A does not establish a canonical perk, add-on, or offering package for this object. No loadout is invented here.

## Representative Implementations

### Addon Variant — `KSTR-024-B01`

- **Killer:** The Hag
- **Add-ons:** Waterlogged Shoe
- **Implementation:** Base teleporting trap web; Waterlogged Shoe kept as separate support variant
- **Rationale:** Build a compact high-value web and fight through invested territory
- **Strengths:** Prepared-zone conversion
- **Weaknesses:** Setup/relocation cost
- **Confidence:** HIGH
- **Content validity:** LIVE_10_2_SOURCE_SUPPORTED

## Strategic Diagnostics

| Diagnostic | Canonical value |
|---|---:|
| Win Condition Contribution | 4/5 |
| Activation Reliability | 3/5 |
| Activation Payoff | 5/5 |
| Denial Risk | 3/5 |
| Strategic Commitment | 5/5 |

## Meta Stability

**87 — VERY STABLE**

Meta Stability describes structural durability, not current strength, popularity, or evidence certainty.

| Component | Score |
|---|---:|
| Structural Independence | 24/25 |
| Core Mechanic Durability | 19/20 |
| Replacement Depth | 13/15 |
| Environmental Breadth | 9/15 |
| Counter-Meta Independence | 8/10 |
| Patch Durability | 14/15 |

## Current Confidence

| Dimension | Confidence |
|---|---|
| Mechanics | HIGH |
| Power | MEDIUM_HIGH |
| General Matchmaking | MEDIUM_HIGH |
| Coordinated SWF | MEDIUM |
| Compatibility | HIGH |
| Prevalence | LOW |

Strategy prevalence is **unknown** in K3A; it is not inferred from perk usage, Killer popularity, or add-on usage.

## Related Strategies

- [Territorial Control](territorial-control.md)
- [Trap-Web Implementation](trap-web-implementation.md)
- [Bear-Trap Zone Implementation](bear-trap-zone-implementation.md)
- [No-Teleport Trap-Zone Hag](no-teleport-trap-zone-hag.md)

## Source Metadata

- **Canonical ID:** `KSTR-024`
- **Snapshot:** `KSTR-024@10.2.0-r1`
- **Patch baseline:** `10.2.0-r1`
- **Research date:** `2026-10-07`

| Source | Title | Date | Note |
|---|---|---|---|
| STAGE_K2 | Stage K2 — Adversarial Verification, Classification Resolution, and Ranking | 2026-10-07 | Primary analytical authority. |
| STAGE_K1 | Stage K1 — Comprehensive Discovery and Taxonomy | 2026-10-07 | Identity/taxonomy origin where applicable. |
