# Strategy Families

The four Parent Strategy Families organize related gameplay plans. Families are not independently ranked and receive no aggregate Power or Tier.

## [Generator Control](../strategies/generator-control.md)

Reduce or redirect repair progress long enough to convert downs/hooks/eliminations.

| Child | Classification | General | SWF |
|---|---|---|---|
| [Active Regression Conversion](../strategies/active-regression-conversion.md) | META | A — 79 | B — 76 |
| [Hook-to-Generator Conversion](../strategies/hook-to-generator-conversion.md) | META SUBTYPE | Provisional A — 79 | Provisional B — 75 |
| [Generator Blocking / Repair Denial](../strategies/generator-blocking-repair-denial.md) | STRATEGIC MODULE | Not independently ranked | Not independently ranked |
| [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) | NICHE STRATEGY | B — 72 | C — 65 |
| [Repair-Speed Suppression](../strategies/repair-speed-suppression.md) | STRATEGIC MODULE | Not independently ranked | Not independently ranked |
| [Compromised-Generator Payoff Framework](../strategies/compromised-generator-payoff-framework.md) | MECHANIC-CENTERED BUILD | Not independently ranked | Not independently ranked |
| [Indefinite Repeated-Kick Three-Gen](../strategies/indefinite-repeated-kick-three-gen.md) | META SUBTYPE | Not current | Not current |

**Cross-family / graph relationships:** [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md)

## [Target Focus / Elimination Sequencing](../strategies/target-focus-elimination-sequencing.md)

Concentrate pressure where hook states and target vulnerability convert fastest.

| Child | Classification | General | SWF |
|---|---|---|---|
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | META | A — 83 | B — 77 |
| [Hook-State Prioritization](../strategies/hook-state-prioritization.md) | STRATEGIC MODULE | Not independently ranked | Not independently ranked |

## [Hook-Zone / Rescue Pressure](../strategies/hook-zone-rescue-pressure.md)

Convert a hooked Survivor into secondary pressure on rescuers and nearby objectives.

| Child | Classification | General | SWF |
|---|---|---|---|
| [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) | META | B — 76 | B — 69 |
| [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md) | META SUBTYPE | A — 78 | B — 71 |
| [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md) | NICHE STRATEGY | B — 71 | C — 63 |
| [Carry / Hook-Transport Optimization](../strategies/carry-hook-transport-optimization.md) | MECHANIC-CENTERED BUILD | Not independently ranked | Not independently ranked |

## [Territorial Control](../strategies/territorial-control.md)

Make selected parts of the map disproportionately dangerous or expensive to contest.

| Child | Classification | General | SWF |
|---|---|---|---|
| [Setup-Zone Lockdown](../strategies/setup-zone-lockdown.md) | META SUBTYPE | B — 74 | B — 66 |
| [Network Surveillance / Teleport Control](../strategies/network-surveillance-teleport-control.md) | META SUBTYPE | A — 78 | B — 70 |
| [Drone Surveillance / Chase-Zone Module](../strategies/drone-surveillance-chase-zone-module.md) | STRATEGIC MODULE | Not independently ranked | Not independently ranked |
| [Guard Pincer / Remote Patrol](../strategies/guard-pincer-remote-patrol.md) | STRATEGIC MODULE | Not independently ranked | Not independently ranked |

**Cross-family / graph relationships:** [Generator-Cluster Defense](../strategies/generator-cluster-defense.md), [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md)
