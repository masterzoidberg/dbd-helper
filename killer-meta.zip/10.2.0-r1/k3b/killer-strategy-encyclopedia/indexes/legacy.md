# Legacy Killer Strategy Objects

These six pages preserve historically meaningful Strategy/build identities that are **not current on Patch 10.2.0-r1**. They help explain why older guides or community terminology may conflict with current mechanics.

| Legacy object | Historical function | Transition reason | Current successor / related object |
|---|---|---|---|
| [Knock Out Slug-Concealment Shell](../strategies/knock-out-slug-concealment-shell.md) | Conceal/inhibit recovery information around downed Survivors to sustain down-state pressure | 10.2 Knock Out is now a pallet/Hindered perk | [Chain-Down Pressure](../strategies/chain-down-pressure.md), [Sustained Down-State Control](../strategies/sustained-down-state-control.md) |
| [Indefinite Repeated-Kick Three-Gen](../strategies/indefinite-repeated-kick-three-gen.md) | Recycle regression indefinitely on same cluster | Current regression-event limit prevents indefinite loop | [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) |
| [Old Deerstalker Slug-Tracking Shell](../strategies/old-deerstalker-slug-tracking-shell.md) | Track downed Survivors to manage extended slug states | 10.2 Deerstalker now periodically creates mutual Killer/Survivor aura reading rather than its historical downed-survivor tracking role | [Information Chaining](../strategies/information-chaining.md) |
| [Pre-Resolve-Bar Close Facecamp Form](../strategies/pre-resolve-bar-close-facecamp-form.md) | Remain immediately adjacent to hook to prevent/force rescue | Current Resolve anti-facecamp mechanics specifically impose escalating consequences on prolonged close proximity | [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) |
| [Passive Thrill Totem-Defense Form](../strategies/passive-thrill-totem-defense-form.md) | Passive cleanse/bless slowdown from remaining Totems | 10.2 Thrill now ignites after first hook and blocks lit Hex Totems on hooks | [Active Hex Defense](../strategies/active-hex-defense.md) |
| [Historical Tombstone-Piece Direct-Kill Shape](../strategies/historical-tombstone-piece-direct-kill-shape.md) | Directly kill a healthy/injured Survivor during Evil Within III | Current Tombstone Piece instead grants Undetectable when Evil Incarnate activates; direct-kill text is historical. | [Stalk-to-Expose Ambush](../strategies/stalk-to-expose-ambush.md) |
