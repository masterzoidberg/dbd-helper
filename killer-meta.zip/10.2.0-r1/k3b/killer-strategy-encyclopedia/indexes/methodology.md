# How to Read the Killer Strategy Encyclopedia

**Baseline:** Patch 10.2.0-r1, representing research through October 7, 2026.

## Strategy vs Killer Character

A **Strategy** is a persistent gameplay plan. A Killer character is a toolset that may fit some Strategies better than others. Compatibility is therefore not a character tier list.

## Strategy vs Module vs Tactic

- **Independent Strategy:** a match-level plan that can receive environment-specific Power when evidence supports it.
- **Parent Strategy Family:** an organizational umbrella for related plans; never given aggregate Power.
- **Strategic Module:** a useful component that solves a narrower strategic problem but does not independently organize the match.
- **Mechanic-Centered Build:** a recognizable framework built around a mechanic rather than a complete strategic objective.
- **Tactic:** a situational decision inside one or more Strategies; never independently ranked.
- **Legacy:** a historically meaningful object that is no longer current.

## The Two Environments

### `KILLER_GENERAL_MATCHMAKING`

Ordinary live matchmaking/public-play environment evaluated by K2, including imperfect coordination and the 10.2 Survivor Intent system without assuming voice-level coordination.

### `KILLER_VS_COORDINATED_SWF`

Coordinated Survivor-with-Friends environment with deliberate communication, target-state management, rescue coordination, and build/role coordination.

## Power

Comparative strategic strength on an appropriately compatible Killer; not kill rate, win probability, 4K probability, MMR outcome percentage, roster breadth, or inherent Killer strength.

The model uses twelve 0–10 dimensions with fixed weights. Power is environment-specific.

| Dimension | Weight |
|---|---:|
| Consistency | 11 |
| Ceiling | 8 |
| Agency | 11 |
| Power Integration | 7 |
| Matchup Coverage | 9 |
| Map Coverage | 8 |
| Tempo Efficiency | 12 |
| Slot Efficiency | 7 |
| Recovery Value | 6 |
| Snowball Value | 6 |
| Counterplay Resilience | 9 |
| Execution Reliability | 6 |

## Tiers

| Tier | Power range |
|---|---:|
| S | 88–100 |
| A | 78–87 |
| B | 66–77 |
| C | 50–65 |
| D | 0–49 |

## Meta Stability

Meta Stability is the durability of a Strategy’s structure across mechanics, environments, counters, and patches. It is **not** Power, popularity, or confidence.

| Label | Range |
|---|---:|
| VERY STABLE | 85–100 |
| STABLE | 70–84 |
| WATCH | 50–69 |
| VOLATILE | 30–49 |
| HIGHLY EXPERIMENTAL / UNSTABLE | 0–29 |

## Confidence

Confidence describes how well supported a conclusion is. K3A preserves separate confidence for mechanics, prevalence, Power, each environment, and compatibility. A high Power score does not imply high confidence.

## Provisional

`PROVISIONAL` means K3A has a numerical estimate but the research debt is still material enough that placement is not fully settled.

## Unranked

`UNRANKED` means the object is a current coherent Strategy but K3A does not assign a responsible numerical Power/Tier. No editorial estimate is substituted.

## Legacy

`LEGACY` objects are historical. Their current environment evaluations are `NOT_CURRENT`, and they have no current Power/Tier/Ranking Index.

## Applicability Scope

- `BROAD_ROSTER`: strategically broad, but still subject to sparse compatibility evaluation.
- `POWER_FAMILY`: requires specific native Power qualities.
- `KILLER_SPECIFIC`: depends on one Killer’s mechanics.

## Prevalence

Where K3A records prevalence as `UNKNOWN`, this encyclopedia does not infer popularity from perk use, add-on use, or Killer pick rate.
