# Killer Tactic Glossary

**Tactics are situational decisions, not independently ranked Strategies.** They receive no Power, Tier, Meta Stability, or Ranking Index.

| Tactic | Short definition | Related Strategies |
|---|---|---|
| [Temporary Slug](../tactics/temporary-slug.md) | Leave a downed Survivor briefly instead of immediately picking up | [Generator Control](../strategies/generator-control.md), [Hook-Zone / Rescue Pressure](../strategies/hook-zone-rescue-pressure.md), [Chain-Down Pressure](../strategies/chain-down-pressure.md) |
| [Leave Chase](../tactics/leave-chase.md) | Deliberately abandon an inefficient pursuit | — |
| [Return to Hook](../tactics/return-to-hook.md) | Re-enter hook area after leaving | [Target Focus / Elimination Sequencing](../strategies/target-focus-elimination-sequencing.md), [Hook-Zone / Rescue Pressure](../strategies/hook-zone-rescue-pressure.md) |
| [Force Trade](../tactics/force-trade.md) | Pressure rescuer so rescue produces another down/hook | [Hook-Zone / Rescue Pressure](../strategies/hook-zone-rescue-pressure.md), [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) |
| [Defend Critical Generator](../tactics/defend-critical-generator.md) | Temporarily prioritize a high-progress or cluster-critical gen | [Generator Control](../strategies/generator-control.md), [Territorial Control](../strategies/territorial-control.md) |
| [Chase Death-Hook Survivor](../tactics/chase-death-hook-survivor.md) | Prefer a currently accessible Survivor whose next hook eliminates | [Target Focus / Elimination Sequencing](../strategies/target-focus-elimination-sequencing.md), [Hook-State Prioritization](../strategies/hook-state-prioritization.md) |
| [Delay Pickup](../tactics/delay-pickup.md) | Wait before lifting a downed Survivor | [Chain-Down Pressure](../strategies/chain-down-pressure.md) |
| [Zone Survivor](../tactics/zone-survivor.md) | Occupy position/path so Survivor is forced toward weaker route | [Hook-Zone / Rescue Pressure](../strategies/hook-zone-rescue-pressure.md), [Chase Optimization Suite](../strategies/chase-optimization-suite.md), [Territorial Control](../strategies/territorial-control.md) |
| [Bodyblock Escape Route](../tactics/bodyblock-escape-route.md) | Use Killer collision to deny path temporarily | [Chase Optimization Suite](../strategies/chase-optimization-suite.md), [Ambush Rotation](../strategies/ambush-rotation.md), [Territorial Control](../strategies/territorial-control.md) |
| [Rescue Interception](../tactics/rescue-interception.md) | Predict approach route and meet rescuer before hook | [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) |
| [Fake Objective Commitment](../tactics/fake-objective-commitment.md) | Begin/telegraph kick, teleport, projection or patrol action to force Survivor displacement without completing it | [Generator Control](../strategies/generator-control.md), [Dream Projection Pressure Module](../strategies/dream-projection-pressure-module.md) |
| [Break-and-Leave](../tactics/break-and-leave.md) | Consume a pallet/breakable resource and abandon the chase | [Pallet / Resource Attrition](../strategies/pallet-resource-attrition.md) |
| [Hook-Destination Selection](../tactics/hook-destination-selection.md) | Carry to a particular hook for location rather than nearest-time efficiency | [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md), [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md), [Scourge-Hook Routing](../strategies/scourge-hook-routing.md) |
| [Target Switch on Contact](../tactics/target-switch-on-contact.md) | Drop current pursuit immediately when a higher-value Survivor becomes reachable | [Target Focus / Elimination Sequencing](../strategies/target-focus-elimination-sequencing.md), [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md), [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) |
