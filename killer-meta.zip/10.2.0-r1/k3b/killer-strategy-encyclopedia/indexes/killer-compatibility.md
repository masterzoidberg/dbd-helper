# Killer Compatibility Index

This index shows only compatibility relations explicitly evaluated in K3A. **Missing relations mean not evaluated, not viable.** It is a Strategy-fit index, not a Killer tier list.

## The Animatronic

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Network Surveillance / Teleport Control](../strategies/network-surveillance-teleport-control.md) | STRONG_FIT | HIGH | Persistent nodes/stations create travel, information or disablement counterplay. |
| [Ambush Rotation](../strategies/ambush-rotation.md) | VIABLE | HIGH | Native approach denial must repeatedly reduce warning. |
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | VIABLE | HIGH | Mobility must alter commitment policy, not merely traversal. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Artist

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) | BEST_FIT | MEDIUM_HIGH | Threat must reach rescue lanes without requiring stationary close proximity. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Blight

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | BEST_FIT | HIGH | Mobility must alter commitment policy, not merely traversal. |
| [Chain-Down Pressure](../strategies/chain-down-pressure.md) | STRONG_FIT | HIGH | Family boundary: second target can be reached before pickup delay loses value. |
| [Sustained Down-State Control](../strategies/sustained-down-state-control.md) | STRONG_FIT | HIGH | Requires reliable re-down/recontact; old Knock Out concealment is excluded. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Cannibal

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md) | BEST_FIT | MEDIUM_HIGH | Requires transport feasibility and anchor geometry. |
| [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) | BEST_FIT | MEDIUM_HIGH | Threat must reach rescue lanes without requiring stationary close proximity. |
| [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md) | WEAK_FIT | HIGH | Cheap first hits plus economical recontact. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Cenobite

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Lament Configuration / Chain-Hunt Control](../strategies/lament-configuration-chain-hunt-control.md) | BEST_FIT | HIGH | Lament Configuration/Chain Hunt required. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Clown

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | STRONG_FIT | MEDIUM_HIGH | Broad strategy; fit is re-acquisition/chase conversion. |
| [Active Regression Conversion](../strategies/active-regression-conversion.md) | VIABLE | MEDIUM_HIGH | Scored around ordinary compatible Killers, not elite mobility outliers. |
| [Deliberate Endgame Conversion](../strategies/deliberate-endgame-conversion.md) | VIABLE | MEDIUM_HIGH | Fit rises with gate coverage/resource banking. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Deathslinger

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) | STRONG_FIT | MEDIUM_HIGH | Threat must reach rescue lanes without requiring stationary close proximity. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Demogorgon

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Active Hex Defense](../strategies/active-hex-defense.md) | BEST_FIT | MEDIUM | Killer must actually contest cleanse windows; Hex perks alone do not qualify. |
| [Active Regression Conversion](../strategies/active-regression-conversion.md) | BEST_FIT | MEDIUM_HIGH | Scored around ordinary compatible Killers, not elite mobility outliers. |
| [Deliberate Endgame Conversion](../strategies/deliberate-endgame-conversion.md) | BEST_FIT | MEDIUM_HIGH | Fit rises with gate coverage/resource banking. |
| [Hook-to-Generator Conversion](../strategies/hook-to-generator-conversion.md) | BEST_FIT | MEDIUM_HIGH | Requires reliable post-hook reach to a chosen objective. |
| [Network Surveillance / Teleport Control](../strategies/network-surveillance-teleport-control.md) | BEST_FIT | HIGH | Persistent nodes/stations create travel, information or disablement counterplay. |
| [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md) | STRONG_FIT | MEDIUM_HIGH | Requires transport feasibility and anchor geometry. |
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | STRONG_FIT | MEDIUM_HIGH | Broad strategy; fit is re-acquisition/chase conversion. |
| [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) | STRONG_FIT | MEDIUM_HIGH | Fit derives from short territorial patrols, not roster tier. |
| [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md) | STRONG_FIT | MEDIUM_HIGH | Best when one route can contest hook and objective. |
| [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) | STRONG_FIT | MEDIUM_HIGH | Threat must reach rescue lanes without requiring stationary close proximity. |
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | STRONG_FIT | HIGH | Mobility must alter commitment policy, not merely traversal. |
| [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md) | VIABLE | HIGH | Cheap first hits plus economical recontact. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Doctor

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Active Regression Conversion](../strategies/active-regression-conversion.md) | STRONG_FIT | MEDIUM_HIGH | Scored around ordinary compatible Killers, not elite mobility outliers. |
| [Deliberate Endgame Conversion](../strategies/deliberate-endgame-conversion.md) | STRONG_FIT | MEDIUM_HIGH | Fit rises with gate coverage/resource banking. |
| [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) | STRONG_FIT | MEDIUM_HIGH | Fit derives from short territorial patrols, not roster tier. |
| [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md) | STRONG_FIT | MEDIUM_HIGH | Best when one route can contest hook and objective. |
| [Active Hex Defense](../strategies/active-hex-defense.md) | VIABLE | MEDIUM | Killer must actually contest cleanse windows; Hex perks alone do not qualify. |
| [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md) | VIABLE | MEDIUM_HIGH | Requires transport feasibility and anchor geometry. |
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | VIABLE | MEDIUM_HIGH | Broad strategy; fit is re-acquisition/chase conversion. |
| [Hook-to-Generator Conversion](../strategies/hook-to-generator-conversion.md) | VIABLE | MEDIUM_HIGH | Requires reliable post-hook reach to a chosen objective. |
| [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) | VIABLE | MEDIUM_HIGH | Threat must reach rescue lanes without requiring stationary close proximity. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Dredge

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Ambush Rotation](../strategies/ambush-rotation.md) | BEST_FIT | HIGH | Native approach denial must repeatedly reduce warning. |
| [Deliberate Endgame Conversion](../strategies/deliberate-endgame-conversion.md) | BEST_FIT | MEDIUM_HIGH | Fit rises with gate coverage/resource banking. |
| [Hook-to-Generator Conversion](../strategies/hook-to-generator-conversion.md) | BEST_FIT | MEDIUM_HIGH | Requires reliable post-hook reach to a chosen objective. |
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | BEST_FIT | HIGH | Mobility must alter commitment policy, not merely traversal. |
| [Active Hex Defense](../strategies/active-hex-defense.md) | STRONG_FIT | MEDIUM | Killer must actually contest cleanse windows; Hex perks alone do not qualify. |
| [Active Regression Conversion](../strategies/active-regression-conversion.md) | STRONG_FIT | MEDIUM_HIGH | Scored around ordinary compatible Killers, not elite mobility outliers. |
| [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md) | STRONG_FIT | HIGH | Cheap first hits plus economical recontact. |
| [Network Surveillance / Teleport Control](../strategies/network-surveillance-teleport-control.md) | STRONG_FIT | HIGH | Persistent nodes/stations create travel, information or disablement counterplay. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Executioner

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Torment / Cage Sequencing](../strategies/torment-cage-sequencing.md) | BEST_FIT | HIGH | Torment/Cage required. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The First

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | VIABLE | HIGH | Mobility must alter commitment policy, not merely traversal. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Ghost Face

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Ambush Rotation](../strategies/ambush-rotation.md) | BEST_FIT | HIGH | Native approach denial must repeatedly reduce warning. |
| [Stalk-to-Expose Ambush](../strategies/stalk-to-expose-ambush.md) | BEST_FIT | HIGH | Only stalk/expose Powers belong to the family. |
| [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md) | STRONG_FIT | HIGH | Cheap first hits plus economical recontact. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Ghoul

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | BEST_FIT | MEDIUM_HIGH | Broad strategy; fit is re-acquisition/chase conversion. |
| [Chain-Down Pressure](../strategies/chain-down-pressure.md) | STRONG_FIT | HIGH | Family boundary: second target can be reached before pickup delay loses value. |
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | VIABLE | HIGH | Mobility must alter commitment policy, not merely traversal. |
| [Sustained Down-State Control](../strategies/sustained-down-state-control.md) | VIABLE | HIGH | Requires reliable re-down/recontact; old Knock Out concealment is excluded. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Good Guy

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Ambush Rotation](../strategies/ambush-rotation.md) | STRONG_FIT | HIGH | Native approach denial must repeatedly reduce warning. |
| [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md) | VIABLE | HIGH | Cheap first hits plus economical recontact. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Hag

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Active Hex Defense](../strategies/active-hex-defense.md) | BEST_FIT | MEDIUM | Killer must actually contest cleanse windows; Hex perks alone do not qualify. |
| [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md) | BEST_FIT | MEDIUM_HIGH | Requires transport feasibility and anchor geometry. |
| [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) | BEST_FIT | MEDIUM_HIGH | Fit derives from short territorial patrols, not roster tier. |
| [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md) | BEST_FIT | MEDIUM_HIGH | Best when one route can contest hook and objective. |
| [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) | BEST_FIT | MEDIUM_HIGH | Threat must reach rescue lanes without requiring stationary close proximity. |
| [Setup-Zone Lockdown](../strategies/setup-zone-lockdown.md) | BEST_FIT | HIGH | Pre-invest finite hazards/resources in a local region. |
| [Deliberate Endgame Conversion](../strategies/deliberate-endgame-conversion.md) | STRONG_FIT | MEDIUM_HIGH | Fit rises with gate coverage/resource banking. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Hillbilly

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | BEST_FIT | HIGH | Mobility must alter commitment policy, not merely traversal. |
| [Chain-Down Pressure](../strategies/chain-down-pressure.md) | STRONG_FIT | HIGH | Family boundary: second target can be reached before pickup delay loses value. |
| [Hook-to-Generator Conversion](../strategies/hook-to-generator-conversion.md) | STRONG_FIT | MEDIUM_HIGH | Requires reliable post-hook reach to a chosen objective. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Huntress

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md) | STRONG_FIT | MEDIUM_HIGH | Requires transport feasibility and anchor geometry. |
| [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) | STRONG_FIT | MEDIUM_HIGH | Threat must reach rescue lanes without requiring stationary close proximity. |
| [Ambush Rotation](../strategies/ambush-rotation.md) | WEAK_FIT | HIGH | Native approach denial must repeatedly reduce warning. |
| [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) | WEAK_FIT | MEDIUM_HIGH | Fit derives from short territorial patrols, not roster tier. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Judgment

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Heresy / Exile / Zealous Sequencing](../strategies/heresy-exile-zealous-sequencing.md) | BEST_FIT | HIGH | Heresy/Exile/Zealous required. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Knight

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md) | STRONG_FIT | MEDIUM_HIGH | Requires transport feasibility and anchor geometry. |
| [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) | STRONG_FIT | MEDIUM_HIGH | Fit derives from short territorial patrols, not roster tier. |
| [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md) | STRONG_FIT | MEDIUM_HIGH | Best when one route can contest hook and objective. |
| [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) | VIABLE | MEDIUM_HIGH | Threat must reach rescue lanes without requiring stationary close proximity. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Legion

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md) | BEST_FIT | HIGH | Cheap first hits plus economical recontact. |
| [Active Regression Conversion](../strategies/active-regression-conversion.md) | VIABLE | MEDIUM_HIGH | Scored around ordinary compatible Killers, not elite mobility outliers. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Mastermind

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | BEST_FIT | MEDIUM_HIGH | Broad strategy; fit is re-acquisition/chase conversion. |
| [Active Regression Conversion](../strategies/active-regression-conversion.md) | STRONG_FIT | MEDIUM_HIGH | Scored around ordinary compatible Killers, not elite mobility outliers. |
| [Hook-to-Generator Conversion](../strategies/hook-to-generator-conversion.md) | STRONG_FIT | MEDIUM_HIGH | Requires reliable post-hook reach to a chosen objective. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Nemesis

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Active Regression Conversion](../strategies/active-regression-conversion.md) | VIABLE | MEDIUM_HIGH | Scored around ordinary compatible Killers, not elite mobility outliers. |
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | VIABLE | MEDIUM_HIGH | Broad strategy; fit is re-acquisition/chase conversion. |
| [Hook-to-Generator Conversion](../strategies/hook-to-generator-conversion.md) | VIABLE | MEDIUM_HIGH | Requires reliable post-hook reach to a chosen objective. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Nightmare

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Deliberate Endgame Conversion](../strategies/deliberate-endgame-conversion.md) | BEST_FIT | MEDIUM_HIGH | Fit rises with gate coverage/resource banking. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Nurse

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Sustained Down-State Control](../strategies/sustained-down-state-control.md) | STRONG_FIT | HIGH | Requires reliable re-down/recontact; old Knock Out concealment is excluded. |
| [Setup-Zone Lockdown](../strategies/setup-zone-lockdown.md) | WEAK_FIT | HIGH | Pre-invest finite hazards/resources in a local region. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Oni

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Chain-Down Pressure](../strategies/chain-down-pressure.md) | BEST_FIT | HIGH | Family boundary: second target can be reached before pickup delay loses value. |
| [Sustained Down-State Control](../strategies/sustained-down-state-control.md) | BEST_FIT | HIGH | Requires reliable re-down/recontact; old Knock Out concealment is excluded. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Onryō

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Condemn Pressure](../strategies/condemn-pressure.md) | BEST_FIT | HIGH | TVs/tapes/Condemned required. |
| [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md) | BEST_FIT | HIGH | Cheap first hits plus economical recontact. |
| [Ambush Rotation](../strategies/ambush-rotation.md) | STRONG_FIT | HIGH | Native approach denial must repeatedly reduce warning. |
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | STRONG_FIT | HIGH | Mobility must alter commitment policy, not merely traversal. |
| [Network Surveillance / Teleport Control](../strategies/network-surveillance-teleport-control.md) | VIABLE | HIGH | Persistent nodes/stations create travel, information or disablement counterplay. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Pig

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Reverse-Bear-Trap Objective Tax](../strategies/reverse-bear-trap-objective-tax.md) | BEST_FIT | HIGH | Reverse Bear Traps/Jigsaw Boxes required. |
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | VIABLE | MEDIUM_HIGH | Broad strategy; fit is re-acquisition/chase conversion. |
| [Deliberate Endgame Conversion](../strategies/deliberate-endgame-conversion.md) | VIABLE | MEDIUM_HIGH | Fit rises with gate coverage/resource banking. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Plague

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Infection / Fountain Economy](../strategies/infection-fountain-economy.md) | BEST_FIT | HIGH | Infection/fountains required. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Shape

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Scratched-Mirror Ambush](../strategies/scratched-mirror-ambush.md) | BEST_FIT | HIGH | Removing the add-on removes the strategic identity. |
| [Stalk-to-Expose Ambush](../strategies/stalk-to-expose-ambush.md) | STRONG_FIT | HIGH | Only stalk/expose Powers belong to the family. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Singularity

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) | BEST_FIT | MEDIUM_HIGH | Fit derives from short territorial patrols, not roster tier. |
| [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md) | BEST_FIT | MEDIUM_HIGH | Best when one route can contest hook and objective. |
| [Network Surveillance / Teleport Control](../strategies/network-surveillance-teleport-control.md) | BEST_FIT | HIGH | Persistent nodes/stations create travel, information or disablement counterplay. |
| [Active Hex Defense](../strategies/active-hex-defense.md) | STRONG_FIT | MEDIUM | Killer must actually contest cleanse windows; Hex perks alone do not qualify. |
| [Setup-Zone Lockdown](../strategies/setup-zone-lockdown.md) | VIABLE | HIGH | Pre-invest finite hazards/resources in a local region. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Skull Merchant

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md) | STRONG_FIT | HIGH | Cheap first hits plus economical recontact. |
| [Setup-Zone Lockdown](../strategies/setup-zone-lockdown.md) | STRONG_FIT | HIGH | Pre-invest finite hazards/resources in a local region. |
| [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) | VIABLE | MEDIUM_HIGH | Fit derives from short territorial patrols, not roster tier. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Slasher

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Ambush Rotation](../strategies/ambush-rotation.md) | STRONG_FIT | HIGH | Native approach denial must repeatedly reduce warning. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Spirit

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Chain-Down Pressure](../strategies/chain-down-pressure.md) | BEST_FIT | HIGH | Family boundary: second target can be reached before pickup delay loses value. |
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | BEST_FIT | MEDIUM_HIGH | Broad strategy; fit is re-acquisition/chase conversion. |
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | VIABLE | HIGH | Mobility must alter commitment policy, not merely traversal. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Trapper

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md) | BEST_FIT | MEDIUM_HIGH | Requires transport feasibility and anchor geometry. |
| [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) | BEST_FIT | MEDIUM_HIGH | Fit derives from short territorial patrols, not roster tier. |
| [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md) | BEST_FIT | MEDIUM_HIGH | Best when one route can contest hook and objective. |
| [Setup-Zone Lockdown](../strategies/setup-zone-lockdown.md) | BEST_FIT | HIGH | Pre-invest finite hazards/resources in a local region. |
| [Deliberate Endgame Conversion](../strategies/deliberate-endgame-conversion.md) | STRONG_FIT | MEDIUM_HIGH | Fit rises with gate coverage/resource banking. |
| [Chain-Down Pressure](../strategies/chain-down-pressure.md) | WEAK_FIT | HIGH | Family boundary: second target can be reached before pickup delay loses value. |
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | WEAK_FIT | HIGH | Mobility must alter commitment policy, not merely traversal. |
| [Sustained Down-State Control](../strategies/sustained-down-state-control.md) | WEAK_FIT | HIGH | Requires reliable re-down/recontact; old Knock Out concealment is excluded. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Twins

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Chain-Down Pressure](../strategies/chain-down-pressure.md) | BEST_FIT | HIGH | Family boundary: second target can be reached before pickup delay loses value. |
| [Sustained Down-State Control](../strategies/sustained-down-state-control.md) | BEST_FIT | HIGH | Requires reliable re-down/recontact; old Knock Out concealment is excluded. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Unknown

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Network Surveillance / Teleport Control](../strategies/network-surveillance-teleport-control.md) | BEST_FIT | HIGH | Persistent nodes/stations create travel, information or disablement counterplay. |
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | STRONG_FIT | HIGH | Mobility must alter commitment policy, not merely traversal. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Wraith

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Active Hex Defense](../strategies/active-hex-defense.md) | BEST_FIT | MEDIUM | Killer must actually contest cleanse windows; Hex perks alone do not qualify. |
| [Active Regression Conversion](../strategies/active-regression-conversion.md) | BEST_FIT | MEDIUM_HIGH | Scored around ordinary compatible Killers, not elite mobility outliers. |
| [Ambush Rotation](../strategies/ambush-rotation.md) | BEST_FIT | HIGH | Native approach denial must repeatedly reduce warning. |
| [Deliberate Endgame Conversion](../strategies/deliberate-endgame-conversion.md) | BEST_FIT | MEDIUM_HIGH | Fit rises with gate coverage/resource banking. |
| [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md) | BEST_FIT | HIGH | Cheap first hits plus economical recontact. |
| [Hook-to-Generator Conversion](../strategies/hook-to-generator-conversion.md) | BEST_FIT | MEDIUM_HIGH | Requires reliable post-hook reach to a chosen objective. |
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | STRONG_FIT | MEDIUM_HIGH | Broad strategy; fit is re-acquisition/chase conversion. |
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | STRONG_FIT | HIGH | Mobility must alter commitment policy, not merely traversal. |
| [Chain-Down Pressure](../strategies/chain-down-pressure.md) | VIABLE | HIGH | Family boundary: second target can be reached before pickup delay loses value. |
| [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md) | VIABLE | MEDIUM_HIGH | Best when one route can contest hook and objective. |
| [Sustained Down-State Control](../strategies/sustained-down-state-control.md) | VIABLE | HIGH | Requires reliable re-down/recontact; old Knock Out concealment is excluded. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## The Xenomorph

| Strategy | Fit | Confidence | Rationale |
|---|---|---|---|
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | BEST_FIT | HIGH | Mobility must alter commitment policy, not merely traversal. |
| [Ambush Rotation](../strategies/ambush-rotation.md) | STRONG_FIT | HIGH | Native approach denial must repeatedly reduce warning. |
| [Hook-to-Generator Conversion](../strategies/hook-to-generator-conversion.md) | STRONG_FIT | MEDIUM_HIGH | Requires reliable post-hook reach to a chosen objective. |
| [Network Surveillance / Teleport Control](../strategies/network-surveillance-teleport-control.md) | STRONG_FIT | HIGH | Persistent nodes/stations create travel, information or disablement counterplay. |
| [Chain-Down Pressure](../strategies/chain-down-pressure.md) | VIABLE | HIGH | Family boundary: second target can be reached before pickup delay loses value. |

All other Strategy fits are **not evaluated** unless a canonical global exclusion below applies.

## Killers With No Explicit Sparse Compatibility Relations

For these Killer reference records, K3A does not provide any explicit per-Strategy fit relations:

- The Dark Lord
- The Houndmaster
- The Krasue
- The Lich
- The Trickster

## Canonical Global Exclusions

These KILLER_SPECIFIC Strategies explicitly mark all other Killers incompatible rather than merely unevaluated:

- [Stalk-to-Expose Ambush](../strategies/stalk-to-expose-ambush.md): **all other Killers = INCOMPATIBLE**. Only stalk/expose Powers belong to the family.
- [Lament Configuration / Chain-Hunt Control](../strategies/lament-configuration-chain-hunt-control.md): **all other Killers = INCOMPATIBLE**. Lament Configuration/Chain Hunt required.
- [Reverse-Bear-Trap Objective Tax](../strategies/reverse-bear-trap-objective-tax.md): **all other Killers = INCOMPATIBLE**. Reverse Bear Traps/Jigsaw Boxes required.
- [Condemn Pressure](../strategies/condemn-pressure.md): **all other Killers = INCOMPATIBLE**. TVs/tapes/Condemned required.
- [Infection / Fountain Economy](../strategies/infection-fountain-economy.md): **all other Killers = INCOMPATIBLE**. Infection/fountains required.
- [Torment / Cage Sequencing](../strategies/torment-cage-sequencing.md): **all other Killers = INCOMPATIBLE**. Torment/Cage required.
- [Heresy / Exile / Zealous Sequencing](../strategies/heresy-exile-zealous-sequencing.md): **all other Killers = INCOMPATIBLE**. Heresy/Exile/Zealous required.

## Availability Note

Killer character references preserve `playableLive` separately from `currentlyObtainable`; availability is not a strength judgment.
