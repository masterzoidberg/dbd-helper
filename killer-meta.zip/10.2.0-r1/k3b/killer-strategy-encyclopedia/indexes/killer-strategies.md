# Killer Strategy Encyclopedia

**Patch baseline:** 10.2.0-r1  
**Research cutoff represented:** October 7, 2026

This index is a publication view of the frozen K3A database. Power is an environment-specific comparative research-model score, not kill rate or win probability. Ordering within a Tier is dynamically derived from the current snapshot and is not a persistent ordinal rank.

## Current Ranked Strategies — General Matchmaking

### A Tier

| Strategy | Power | Stability | Scope | Orientation |
|---|---:|---:|---|---|
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | 85 | 97 | POWER_FAMILY | TEMPO |
| [Chain-Down Pressure](../strategies/chain-down-pressure.md) | 85 | 91 | POWER_FAMILY | TEMPO |
| [Infection / Fountain Economy](../strategies/infection-fountain-economy.md) | 84 | 92 | KILLER_SPECIFIC | — |
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | 83 | 97 | BROAD_ROSTER | TEMPO |
| [Lament Configuration / Chain-Hunt Control](../strategies/lament-configuration-chain-hunt-control.md) | 82 | 85 | KILLER_SPECIFIC | — |
| [Active Regression Conversion](../strategies/active-regression-conversion.md) | 79 | 89 | BROAD_ROSTER | CONTROL |
| [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md) | 78 | 85 | BROAD_ROSTER | CONTROL |
| [Network Surveillance / Teleport Control](../strategies/network-surveillance-teleport-control.md) | 78 | 85 | POWER_FAMILY | HYBRID |
| [Condemn Pressure](../strategies/condemn-pressure.md) | 78 | 79 | KILLER_SPECIFIC | — |

### B Tier

| Strategy | Power | Stability | Scope | Orientation |
|---|---:|---:|---|---|
| [Torment / Cage Sequencing](../strategies/torment-cage-sequencing.md) | 77 | 88 | KILLER_SPECIFIC | — |
| [Stalk-to-Expose Ambush](../strategies/stalk-to-expose-ambush.md) | 77 | 87 | POWER_FAMILY | — |
| [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) | 76 | 91 | BROAD_ROSTER | HYBRID |
| [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md) | 76 | 85 | POWER_FAMILY | HYBRID |
| [Deliberate Endgame Conversion](../strategies/deliberate-endgame-conversion.md) | 74 | 87 | BROAD_ROSTER | HYBRID |
| [Setup-Zone Lockdown](../strategies/setup-zone-lockdown.md) | 74 | 87 | POWER_FAMILY | CONTROL |
| [Ambush Rotation](../strategies/ambush-rotation.md) | 74 | 85 | POWER_FAMILY | TEMPO |
| [Reverse-Bear-Trap Objective Tax](../strategies/reverse-bear-trap-objective-tax.md) | 73 | 83 | KILLER_SPECIFIC | — |
| [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) | 72 | 82 | BROAD_ROSTER | CONTROL |
| [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md) | 71 | 84 | BROAD_ROSTER | CONTROL |

### C Tier

| Strategy | Power | Stability | Scope | Orientation |
|---|---:|---:|---|---|
| [Scratched-Mirror Ambush](../strategies/scratched-mirror-ambush.md) | 62 | 50 | KILLER_SPECIFIC | — |

## Current Ranked Strategies — Coordinated SWF

### A Tier

| Strategy | Power | Stability | Scope | Orientation |
|---|---:|---:|---|---|
| [Rapid Rotation Pressure](../strategies/rapid-rotation-pressure.md) | 82 | 97 | POWER_FAMILY | TEMPO |
| [Infection / Fountain Economy](../strategies/infection-fountain-economy.md) | 79 | 92 | KILLER_SPECIFIC | — |

### B Tier

| Strategy | Power | Stability | Scope | Orientation |
|---|---:|---:|---|---|
| [Committed Elimination Focus](../strategies/committed-elimination-focus.md) | 77 | 97 | BROAD_ROSTER | TEMPO |
| [Chain-Down Pressure](../strategies/chain-down-pressure.md) | 77 | 91 | POWER_FAMILY | TEMPO |
| [Active Regression Conversion](../strategies/active-regression-conversion.md) | 76 | 89 | BROAD_ROSTER | CONTROL |
| [Torment / Cage Sequencing](../strategies/torment-cage-sequencing.md) | 76 | 88 | KILLER_SPECIFIC | — |
| [Lament Configuration / Chain-Hunt Control](../strategies/lament-configuration-chain-hunt-control.md) | 72 | 85 | KILLER_SPECIFIC | — |
| [Hook + Objective Anchor Control](../strategies/hook-objective-anchor-control.md) | 71 | 85 | BROAD_ROSTER | CONTROL |
| [Network Surveillance / Teleport Control](../strategies/network-surveillance-teleport-control.md) | 70 | 85 | POWER_FAMILY | HYBRID |
| [Proxy Hook-Zone Control](../strategies/proxy-hook-zone-control.md) | 69 | 91 | BROAD_ROSTER | HYBRID |
| [Hit-and-Run Injury Attrition](../strategies/hit-and-run-injury-attrition.md) | 67 | 85 | POWER_FAMILY | HYBRID |
| [Setup-Zone Lockdown](../strategies/setup-zone-lockdown.md) | 66 | 87 | POWER_FAMILY | CONTROL |

### C Tier

| Strategy | Power | Stability | Scope | Orientation |
|---|---:|---:|---|---|
| [Deliberate Endgame Conversion](../strategies/deliberate-endgame-conversion.md) | 65 | 87 | BROAD_ROSTER | HYBRID |
| [Generator-Cluster Defense](../strategies/generator-cluster-defense.md) | 65 | 82 | BROAD_ROSTER | CONTROL |
| [Condemn Pressure](../strategies/condemn-pressure.md) | 65 | 79 | KILLER_SPECIFIC | — |
| [Basement / Fixed-Anchor Control](../strategies/basement-fixed-anchor-control.md) | 63 | 84 | BROAD_ROSTER | CONTROL |
| [Stalk-to-Expose Ambush](../strategies/stalk-to-expose-ambush.md) | 62 | 87 | POWER_FAMILY | — |
| [Reverse-Bear-Trap Objective Tax](../strategies/reverse-bear-trap-objective-tax.md) | 62 | 83 | KILLER_SPECIFIC | — |
| [Ambush Rotation](../strategies/ambush-rotation.md) | 60 | 85 | POWER_FAMILY | TEMPO |

### D Tier

| Strategy | Power | Stability | Scope | Orientation |
|---|---:|---:|---|---|
| [Scratched-Mirror Ambush](../strategies/scratched-mirror-ambush.md) | 49 | 50 | KILLER_SPECIFIC | — |

## Provisional Strategies

- [Hook-to-Generator Conversion](../strategies/hook-to-generator-conversion.md) — General: **Provisional A — 79**; SWF: **Provisional B — 75**
- [Heresy / Exile / Zealous Sequencing](../strategies/heresy-exile-zealous-sequencing.md) — General: **Provisional A — 78**; SWF: **Provisional B — 71**
- [Sustained Down-State Control](../strategies/sustained-down-state-control.md) — General: **Provisional C — 65**; SWF: **Provisional C — 52**

## Unranked Current Strategies

- [Active Hex Defense](../strategies/active-hex-defense.md) — **Unranked** in both current environments; no Power or Tier is assigned.

## Parent Families

- [Generator Control](../strategies/generator-control.md) — PARENT STRATEGY FAMILY; ESTABLISHED
- [Hook-Zone / Rescue Pressure](../strategies/hook-zone-rescue-pressure.md) — PARENT STRATEGY FAMILY; ESTABLISHED
- [Target Focus / Elimination Sequencing](../strategies/target-focus-elimination-sequencing.md) — PARENT STRATEGY FAMILY; ESTABLISHED
- [Territorial Control](../strategies/territorial-control.md) — PARENT STRATEGY FAMILY; ESTABLISHED

## Strategic Modules

- [Axe-Impale Attrition Module](../strategies/axe-impale-attrition-module.md) — STRATEGIC MODULE; ESTABLISHED
- [Bear-Trap Zone Implementation](../strategies/bear-trap-zone-implementation.md) — STRATEGIC MODULE; ESTABLISHED
- [Biopod Network Implementation](../strategies/biopod-network-implementation.md) — STRATEGIC MODULE; ESTABLISHED
- [Blood Economy / Fury Timing](../strategies/blood-economy-fury-timing.md) — STRATEGIC MODULE; ESTABLISHED
- [Chase Optimization Suite](../strategies/chase-optimization-suite.md) — STRATEGIC MODULE; ESTABLISHED
- [Crow Zoning / Remote Probe](../strategies/crow-zoning-remote-probe.md) — STRATEGIC MODULE; ESTABLISHED
- [Dream Projection Pressure Module](../strategies/dream-projection-pressure-module.md) — STRATEGIC MODULE; ESTABLISHED
- [Drone Surveillance / Chase-Zone Module](../strategies/drone-surveillance-chase-zone-module.md) — STRATEGIC MODULE; ESTABLISHED
- [Feral-Frenzy Injury-Spread Module](../strategies/feral-frenzy-injury-spread-module.md) — STRATEGIC MODULE; ESTABLISHED
- [Gate Control](../strategies/gate-control.md) — STRATEGIC MODULE; ESTABLISHED
- [Generator Blocking / Repair Denial](../strategies/generator-blocking-repair-denial.md) — STRATEGIC MODULE; ESTABLISHED
- [Guard Pincer / Remote Patrol](../strategies/guard-pincer-remote-patrol.md) — STRATEGIC MODULE; ESTABLISHED
- [Hallucination Network Implementation](../strategies/hallucination-network-implementation.md) — STRATEGIC MODULE; ESTABLISHED
- [Healing Suppression](../strategies/healing-suppression.md) — STRATEGIC MODULE; ESTABLISHED
- [Hook-State Prioritization](../strategies/hook-state-prioritization.md) — STRATEGIC MODULE; ESTABLISHED
- [Information Chaining](../strategies/information-chaining.md) — STRATEGIC MODULE; ESTABLISHED
- [Kagune-Mark / Enraged Module](../strategies/kagune-mark-enraged-module.md) — STRATEGIC MODULE; ESTABLISHED
- [Leech / Form-Cycle Module](../strategies/leech-form-cycle-module.md) — STRATEGIC MODULE; ESTABLISHED
- [Locker / Nightfall Rotation Module](../strategies/locker-nightfall-rotation-module.md) — STRATEGIC MODULE; ESTABLISHED
- [Madness / Interaction Disruption](../strategies/madness-interaction-disruption.md) — STRATEGIC MODULE; ESTABLISHED
- [Omnipresent-Evil Ambush Module](../strategies/omnipresent-evil-ambush-module.md) — STRATEGIC MODULE; ESTABLISHED
- [Pallet / Resource Attrition](../strategies/pallet-resource-attrition.md) — STRATEGIC MODULE; ESTABLISHED
- [Portal Network Implementation](../strategies/portal-network-implementation.md) — STRATEGIC MODULE; ESTABLISHED
- [Repair-Speed Suppression](../strategies/repair-speed-suppression.md) — STRATEGIC MODULE; ESTABLISHED
- [Search-to-Chase Routing Module](../strategies/search-to-chase-routing-module.md) — STRATEGIC MODULE; ESTABLISHED
- [Security-Door Rotation / Ambush Module](../strategies/security-door-rotation-ambush-module.md) — STRATEGIC MODULE; ESTABLISHED
- [Split-Body Chain Sequencing](../strategies/split-body-chain-sequencing.md) — STRATEGIC MODULE; ESTABLISHED
- [Trap-Web Implementation](../strategies/trap-web-implementation.md) — STRATEGIC MODULE; ESTABLISHED
- [Tunnel Rotation Implementation](../strategies/tunnel-rotation-implementation.md) — STRATEGIC MODULE; ESTABLISHED
- [Worldbreaker / Upside-Down Module](../strategies/worldbreaker-upside-down-module.md) — STRATEGIC MODULE; ESTABLISHED

## Mechanic-Centered Builds

- [Basic-Attack Tempo Framework](../strategies/basic-attack-tempo-framework.md) — MECHANIC-CENTERED BUILD; EMERGING
- [Carry / Hook-Transport Optimization](../strategies/carry-hook-transport-optimization.md) — MECHANIC-CENTERED BUILD; ESTABLISHED
- [Compromised-Generator Payoff Framework](../strategies/compromised-generator-payoff-framework.md) — MECHANIC-CENTERED BUILD; EMERGING
- [No-Teleport Trap-Zone Hag](../strategies/no-teleport-trap-zone-hag.md) — MECHANIC-CENTERED BUILD; ESTABLISHED
- [Obsidian-Feather Forced-Cast Variant](../strategies/obsidian-feather-forced-cast-variant.md) — MECHANIC-CENTERED BUILD; EMERGING
- [Scourge-Hook Routing](../strategies/scourge-hook-routing.md) — MECHANIC-CENTERED BUILD; ESTABLISHED
- [Skill-Check / Interaction Pressure](../strategies/skill-check-interaction-pressure.md) — MECHANIC-CENTERED BUILD; ESTABLISHED

## Legacy

- [Historical Tombstone-Piece Direct-Kill Shape](../strategies/historical-tombstone-piece-direct-kill-shape.md) — NICHE STRATEGY; LEGACY
- [Indefinite Repeated-Kick Three-Gen](../strategies/indefinite-repeated-kick-three-gen.md) — META SUBTYPE; LEGACY
- [Knock Out Slug-Concealment Shell](../strategies/knock-out-slug-concealment-shell.md) — MECHANIC-CENTERED BUILD; LEGACY
- [Old Deerstalker Slug-Tracking Shell](../strategies/old-deerstalker-slug-tracking-shell.md) — MECHANIC-CENTERED BUILD; LEGACY
- [Passive Thrill Totem-Defense Form](../strategies/passive-thrill-totem-defense-form.md) — MECHANIC-CENTERED BUILD; LEGACY
- [Pre-Resolve-Bar Close Facecamp Form](../strategies/pre-resolve-bar-close-facecamp-form.md) — NICHE STRATEGY; LEGACY

## Filter Metadata

The publication manifest exposes `structuralClassification`, `applicabilityScope`, `currentStatus`, both environment ranking statuses/Tiers, and `stabilityLabel` for future website filtering.
