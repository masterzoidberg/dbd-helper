# Dead by Daylight Killer Meta — Stage K3A
## Canonical Database, Final Rankings, and Publication Data

**Patch baseline:** 10.2.0  
**Research cutoff:** October 7, 2026  
**Canonical revision:** 10.2.0-r1  
**Side:** KILLER

> Provenance note: the supplied K2 handoff JSON explicitly identifies itself as reconstructed from the K2 report rather than recovered as the original external artifact. K3A treats the supplied structured ledger as the primary handoff source while preserving that provenance warning. No later gameplay evidence or broad rediscovery was introduced.

## 1. Executive Summary

| Metric | Final K3A count |
| --- | --- |
| Canonical Strategy-layer objects | 71 |
| Current independent Strategies | 24 |
| Parent Strategy Families | 4 |
| Current Strategic Modules | 30 |
| Current Mechanic-Centered Builds | 7 |
| Legacy objects | 6 |
| Tactics (separate layer) | 14 |
| RANKED | 20 |
| PROVISIONAL | 3 |
| UNRANKED | 1 |
| NOT_APPLICABLE Strategy-layer objects | 41 |
| NOT_CURRENT | 6 |
| Verified live-playable Killers | 44 |

K2 contained **84 handoff records**. Fourteen tactic records move out of the Strategy collection, leaving 70 Strategy-layer records. K3A then resolves the single K2 `SPLIT` object, `K1-KS-ANIM`, into two support modules, yielding **71 Strategy-layer objects + 14 tactics = 85 final canonical objects**. This normalization increases the current Strategic Module count from K2's 29 to **30**, but it does **not** change the locked competitive universe: 24 current independent Strategies, 23 numerically scored, 20 `RANKED`, 3 `PROVISIONAL`, and 1 `UNRANKED`.

No analytical Power, Tier, Stability, or Ranking Index corrections were required. All recomputed scored evaluations matched K2.

## 2. Canonicalization Changes

| Action | Count |
| --- | --- |
| LEGACY | 6 |
| MERGED | 9 |
| MOVED_TO_TACTIC_LAYER | 14 |
| PRESERVED | 35 |
| RECLASSIFIED | 19 |
| SPLIT | 1 |

### ID migration

Research Candidate IDs remain provenance only. Persistent Strategy-layer identities are now `KSTR-001` through `KSTR-071`; tactic identities are `KTAC-001` through `KTAC-014`; Killer identities are `KILL-001` through `KILL-044`. Canonical IDs encode no Power, Tier, status, or classification.

### Animatronic split

`K1-KS-ANIM` is normalized to **KSTR-057 Axe-Impale Attrition Module** and **KSTR-058 Security-Door Rotation / Ambush Module**. K2 explicitly concluded that Fire Axe attrition and Security-Door rotation/ambush were separable support behaviors rather than one independent macro Strategy. Both remain `NOT_APPLICABLE` for Power.

### Waterlogged Shoe

`K2-ADD-HAG-SHOE` becomes **KSTR-067 No-Teleport Trap-Zone Hag**, a current `MECHANIC-CENTERED BUILD` under Setup-Zone Lockdown. Waterlogged Shoe remains a **SUBTYPE ENABLER**, not a separately ranked Strategy.

### Legacy materialization

All six K2 Legacy objects remain canonical historical Strategy-layer records. Their current environment evaluations are `NOT_CURRENT` with null Power, Tier, and Ranking Index. Legacy is not D tier.

## 3. General Matchmaking Tier List

| Tier | Strategy | Status | Power | Stability | Ranking Index | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| A | Rapid Rotation Pressure | RANKED | 85 | 97 | 87.4 | MEDIUM_HIGH |
| A | Chain-Down Pressure | RANKED | 85 | 91 | 86.2 | MEDIUM_HIGH |
| A | Infection / Fountain Economy | RANKED | 84 | 92 | 85.6 | MEDIUM_HIGH |
| A | Committed Elimination Focus | RANKED | 83 | 97 | 85.8 | MEDIUM_HIGH |
| A | Lament Configuration / Chain-Hunt Control | RANKED | 82 | 85 | 82.6 | MEDIUM_HIGH |
| A | Active Regression Conversion | RANKED | 79 | 89 | 81.0 | MEDIUM_HIGH |
| A | Hook-to-Generator Conversion | PROVISIONAL | 79 | 85 | 80.2 | MEDIUM |
| A | Hook + Objective Anchor Control | RANKED | 78 | 85 | 79.4 | MEDIUM |
| A | Network Surveillance / Teleport Control | RANKED | 78 | 85 | 79.4 | MEDIUM_HIGH |
| A | Condemn Pressure | RANKED | 78 | 79 | 78.2 | MEDIUM |
| A | Heresy / Exile / Zealous Sequencing | PROVISIONAL | 78 | 62 | 74.8 | LOW_MEDIUM |
| B | Torment / Cage Sequencing | RANKED | 77 | 88 | 79.2 | MEDIUM_HIGH |
| B | Stalk-to-Expose Ambush | RANKED | 77 | 87 | 79.0 | MEDIUM_HIGH |
| B | Proxy Hook-Zone Control | RANKED | 76 | 91 | 79.0 | MEDIUM_HIGH |
| B | Hit-and-Run Injury Attrition | RANKED | 76 | 85 | 77.8 | MEDIUM_HIGH |
| B | Setup-Zone Lockdown | RANKED | 74 | 87 | 76.6 | MEDIUM_HIGH |
| B | Deliberate Endgame Conversion | RANKED | 74 | 87 | 76.6 | MEDIUM |
| B | Ambush Rotation | RANKED | 74 | 85 | 76.2 | MEDIUM_HIGH |
| B | Reverse-Bear-Trap Objective Tax | RANKED | 73 | 83 | 75.0 | MEDIUM |
| B | Generator-Cluster Defense | RANKED | 72 | 82 | 74.0 | MEDIUM_HIGH |
| B | Basement / Fixed-Anchor Control | RANKED | 71 | 84 | 73.6 | MEDIUM |
| C | Sustained Down-State Control | PROVISIONAL | 65 | 68 | 65.6 | LOW_MEDIUM |
| C | Scratched-Mirror Ambush | RANKED | 62 | 50 | 59.6 | MEDIUM |
| — | Active Hex Defense | UNRANKED | — | 44 | — | — |

No Strategy reaches S tier. `PROVISIONAL` rows retain numerical K2 placement but remain explicitly provisional. Active Hex Defense is current but `UNRANKED` and therefore has no Power, Tier, or Ranking Index.

## 4. Coordinated SWF Tier List

| Tier | Strategy | Status | Power | Stability | Ranking Index | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| A | Rapid Rotation Pressure | RANKED | 82 | 97 | 85.0 | MEDIUM_HIGH |
| A | Infection / Fountain Economy | RANKED | 79 | 92 | 81.6 | MEDIUM |
| B | Committed Elimination Focus | RANKED | 77 | 97 | 81.0 | MEDIUM |
| B | Chain-Down Pressure | RANKED | 77 | 91 | 79.8 | MEDIUM |
| B | Active Regression Conversion | RANKED | 76 | 89 | 78.6 | MEDIUM |
| B | Torment / Cage Sequencing | RANKED | 76 | 88 | 78.4 | MEDIUM |
| B | Hook-to-Generator Conversion | PROVISIONAL | 75 | 85 | 77.0 | LOW_MEDIUM |
| B | Lament Configuration / Chain-Hunt Control | RANKED | 72 | 85 | 74.6 | MEDIUM |
| B | Hook + Objective Anchor Control | RANKED | 71 | 85 | 73.8 | LOW_MEDIUM |
| B | Heresy / Exile / Zealous Sequencing | PROVISIONAL | 71 | 62 | 69.2 | LOW |
| B | Network Surveillance / Teleport Control | RANKED | 70 | 85 | 73.0 | MEDIUM |
| B | Proxy Hook-Zone Control | RANKED | 69 | 91 | 73.4 | MEDIUM |
| B | Hit-and-Run Injury Attrition | RANKED | 67 | 85 | 70.6 | MEDIUM |
| B | Setup-Zone Lockdown | RANKED | 66 | 87 | 70.2 | MEDIUM |
| C | Deliberate Endgame Conversion | RANKED | 65 | 87 | 69.4 | LOW_MEDIUM |
| C | Generator-Cluster Defense | RANKED | 65 | 82 | 68.4 | MEDIUM |
| C | Condemn Pressure | RANKED | 65 | 79 | 67.8 | LOW_MEDIUM |
| C | Basement / Fixed-Anchor Control | RANKED | 63 | 84 | 67.2 | LOW_MEDIUM |
| C | Stalk-to-Expose Ambush | RANKED | 62 | 87 | 67.0 | MEDIUM |
| C | Reverse-Bear-Trap Objective Tax | RANKED | 62 | 83 | 66.2 | LOW_MEDIUM |
| C | Ambush Rotation | RANKED | 60 | 85 | 65.0 | MEDIUM |
| C | Sustained Down-State Control | PROVISIONAL | 52 | 68 | 55.2 | LOW |
| D | Scratched-Mirror Ambush | RANKED | 49 | 50 | 49.2 | LOW_MEDIUM |
| — | Active Hex Defense | UNRANKED | — | 44 | — | — |

Against coordinated SWF, only Rapid Rotation Pressure and Infection / Fountain Economy remain A tier. The same locked weights are used; coordination changes the raw strategic properties, not the definition of strategic strength.

## 5. Provisional / Unranked

| Object | Ranking status | Missing evidence | Mechanics confidence | Power confidence | General confidence | SWF confidence | Exact recheck condition |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Hook-to-Generator Conversion | PROVISIONAL | Clean 10.2 implementation distribution and optimized DMS/Undone/Monstrous Shrine sequencing | HIGH | MEDIUM | MEDIUM | LOW_MEDIUM | Re-evaluate after a clean post-10.2 window large enough to isolate the reworked ecosystem from pre-10.2 matches |
| Sustained Down-State Control | PROVISIONAL | Actual persistence after loss of old Knock Out concealment; recovery-counterplay frequency | HIGH | LOW_MEDIUM | LOW_MEDIUM | LOW | Recheck when post-10.2 data can separate intentional sustained control from temporary/chain-down slugs |
| Active Hex Defense | UNRANKED | Stable builds, cleanse behavior, Totem-defense payoff and whether new Thrill ecology persists | HIGH | LOW | LOW | LOW | Remain UNRANKED until a clean 10.2 evidence window and stable implementations exist |
| Heresy / Exile / Zealous Sequencing | PROVISIONAL | Mature Exile-vs-hook criteria, optimized add-on/perk interaction, post-10.1.2a stability | MEDIUM_HIGH | LOW_MEDIUM | LOW_MEDIUM | LOW | Recheck after a stable post-10.1.2a/10.2 window without another material Power hotfix |

These research debts are preserved rather than cleaned up for database symmetry. Active Hex Defense remains current and `UNRANKED` in both environments.

## 6. Parent Families

| Parent Family | Canonical current children | Cross-family relationships |
| --- | --- | --- |
| Generator Control | Active Regression Conversion, Hook-to-Generator Conversion, Generator Blocking / Repair Denial, Generator-Cluster Defense, Repair-Speed Suppression, Compromised-Generator Payoff Framework | Hook + Objective Anchor Control |
| Target Focus / Elimination Sequencing | Committed Elimination Focus, Hook-State Prioritization | — |
| Hook-Zone / Rescue Pressure | Proxy Hook-Zone Control, Hook + Objective Anchor Control, Basement / Fixed-Anchor Control, Carry / Hook-Transport Optimization | — |
| Territorial Control | Setup-Zone Lockdown, Network Surveillance / Teleport Control, Drone Surveillance / Chase-Zone Module, Guard Pincer / Remote Patrol | Generator-Cluster Defense, Hook + Objective Anchor Control |

The relationship model is a graph, not a forced tree. In particular, Generator-Cluster Defense remains a Generator-Control child with a Territorial relationship; Hook + Objective Anchor remains a Hook-Zone child with Generator and Territorial relationships; Network Control retains its Rapid Rotation relationship; Rapid Rotation retains relationships to Network Control and Hook-to-Generator Conversion.

## 7. Supporting Objects

### Strategic Modules (30 current)

Generator Blocking / Repair Denial, Repair-Speed Suppression, Hook-State Prioritization, Healing Suppression, Pallet / Resource Attrition, Chase Optimization Suite, Information Chaining, Gate Control, Blood Economy / Fury Timing, Split-Body Chain Sequencing, Biopod Network Implementation, Trap-Web Implementation, Bear-Trap Zone Implementation, Drone Surveillance / Chase-Zone Module, Portal Network Implementation, Hallucination Network Implementation, Tunnel Rotation Implementation, Locker / Nightfall Rotation Module, Guard Pincer / Remote Patrol, Crow Zoning / Remote Probe, Madness / Interaction Disruption, Feral-Frenzy Injury-Spread Module, Axe-Impale Attrition Module, Security-Door Rotation / Ambush Module, Omnipresent-Evil Ambush Module, Leech / Form-Cycle Module, Worldbreaker / Upside-Down Module, Kagune-Mark / Enraged Module, Search-to-Chase Routing Module, Dream Projection Pressure Module.

### Mechanic-Centered Builds (7 current)

Compromised-Generator Payoff Framework, Scourge-Hook Routing, Skill-Check / Interaction Pressure, Carry / Hook-Transport Optimization, Basic-Attack Tempo Framework, Obsidian-Feather Forced-Cast Variant, No-Teleport Trap-Zone Hag.

These objects are publication-worthy support records but are not independently ranked Strategies. The K3A split adds one module relative to K2's 29-module ledger count.

## 8. Killer Compatibility

| Strategy | Scope | Best fit | Strong fit | Viable | Weak fit examples | Unlisted semantics |
| --- | --- | --- | --- | --- | --- | --- |
| Active Regression Conversion | BROAD_ROSTER | The Wraith, The Demogorgon | The Dredge, The Mastermind, The Doctor | The Nemesis, The Clown, The Legion | — | Unlisted Killers not evaluated |
| Hook-to-Generator Conversion | BROAD_ROSTER | The Wraith, The Dredge, The Demogorgon | The Xenomorph, The Hillbilly, The Mastermind | The Doctor, The Nemesis | — | Unlisted Killers not evaluated |
| Generator-Cluster Defense | BROAD_ROSTER | The Hag, The Trapper, The Singularity | The Demogorgon, The Knight, The Doctor | The Skull Merchant | The Huntress | Unlisted Killers not evaluated |
| Committed Elimination Focus | BROAD_ROSTER | The Mastermind, The Spirit, The Ghoul | The Wraith, The Demogorgon, The Clown | The Doctor, The Nemesis, The Pig | — | Unlisted Killers not evaluated |
| Proxy Hook-Zone Control | BROAD_ROSTER | The Cannibal, The Hag, The Artist | The Huntress, The Deathslinger, The Demogorgon | The Doctor, The Knight | — | Unlisted Killers not evaluated |
| Hook + Objective Anchor Control | BROAD_ROSTER | The Hag, The Trapper, The Singularity | The Demogorgon, The Doctor, The Knight | The Wraith | — | Unlisted Killers not evaluated |
| Basement / Fixed-Anchor Control | BROAD_ROSTER | The Trapper, The Hag, The Cannibal | The Knight, The Demogorgon, The Huntress | The Doctor | — | Unlisted Killers not evaluated |
| Chain-Down Pressure | POWER_FAMILY | The Oni, The Twins, The Spirit | The Hillbilly, The Blight, The Ghoul | The Xenomorph, The Wraith | The Trapper | Unlisted Killers not evaluated |
| Sustained Down-State Control | POWER_FAMILY | The Twins, The Oni | The Nurse, The Blight | The Wraith, The Ghoul | The Trapper | Unlisted Killers not evaluated |
| Hit-and-Run Injury Attrition | POWER_FAMILY | The Wraith, The Legion, The Onryō | The Dredge, The Ghost Face, The Skull Merchant | The Demogorgon, The Good Guy | The Cannibal | Unlisted Killers not evaluated |
| Ambush Rotation | POWER_FAMILY | The Ghost Face, The Wraith, The Dredge | The Onryō, The Good Guy, The Slasher, The Xenomorph | The Animatronic | The Huntress | Unlisted Killers not evaluated |
| Setup-Zone Lockdown | POWER_FAMILY | The Hag, The Trapper | The Skull Merchant | The Singularity | The Nurse | Unlisted Killers not evaluated |
| Network Surveillance / Teleport Control | POWER_FAMILY | The Singularity, The Demogorgon, The Unknown | The Xenomorph, The Dredge, The Animatronic | The Onryō | — | Unlisted Killers not evaluated |
| Rapid Rotation Pressure | POWER_FAMILY | The Hillbilly, The Dredge, The Xenomorph, The Blight | The Wraith, The Demogorgon, The Onryō, The Unknown | The First, The Ghoul, The Spirit, The Animatronic | The Trapper | Unlisted Killers not evaluated |
| Active Hex Defense | BROAD_ROSTER | The Hag, The Demogorgon, The Wraith | The Dredge, The Singularity | The Doctor | — | Unlisted Killers not evaluated |
| Deliberate Endgame Conversion | BROAD_ROSTER | The Dredge, The Wraith, The Nightmare, The Demogorgon | The Trapper, The Hag, The Doctor | The Clown, The Pig | — | Unlisted Killers not evaluated |
| Stalk-to-Expose Ambush | POWER_FAMILY | The Ghost Face | The Shape | — | — | All other Killers explicitly incompatible |
| Lament Configuration / Chain-Hunt Control | KILLER_SPECIFIC | The Cenobite | — | — | — | All other Killers explicitly incompatible |
| Reverse-Bear-Trap Objective Tax | KILLER_SPECIFIC | The Pig | — | — | — | All other Killers explicitly incompatible |
| Condemn Pressure | KILLER_SPECIFIC | The Onryō | — | — | — | All other Killers explicitly incompatible |
| Infection / Fountain Economy | KILLER_SPECIFIC | The Plague | — | — | — | All other Killers explicitly incompatible |
| Torment / Cage Sequencing | KILLER_SPECIFIC | The Executioner | — | — | — | All other Killers explicitly incompatible |
| Heresy / Exile / Zealous Sequencing | KILLER_SPECIFIC | The Judgment | — | — | — | All other Killers explicitly incompatible |
| Scratched-Mirror Ambush | KILLER_SPECIFIC | The Shape | — | — | — | Unlisted Killers not evaluated |

Compatibility remains sparse. An omitted Killer means **not evaluated**, never implicitly viable. Killer-specific records preserve K2's explicit all-other-Killers incompatibility as a compact global exclusion rather than manufacturing a full 44 × Strategy matrix.

The character reference file contains the verified 44 live-playable Killers. The Cenobite and The Shape are `playableLive: true` but `currentlyObtainable: false`.

## 9. Legacy

| Legacy object | Historical function | Why not current | Current successor / closest object | Terminology warning |
| --- | --- | --- | --- | --- |
| Knock Out Slug-Concealment Shell | Conceal/inhibit recovery information around downed Survivors to sustain down-state pressure | 10.2 Knock Out is now a pallet/Hindered perk | Sustained Down-State / Chain-Down without old shell | “Knock Out slug build” now describes obsolete mechanics unless explicitly historical |
| Indefinite Repeated-Kick Three-Gen | Recycle regression indefinitely on same cluster | Current regression-event limit prevents indefinite loop | Generator-Cluster Defense | “Three-gen” does not automatically mean the old infinite-kick implementation |
| Old Deerstalker Slug-Tracking Shell | Track downed Survivors to manage extended slug states | 10.2 Deerstalker now periodically creates mutual Killer/Survivor aura reading rather than its historical downed-survivor tracking role | Generic Information Chaining | Old Deerstalker references are not live descriptions |
| Pre-Resolve-Bar Close Facecamp Form | Remain immediately adjacent to hook to prevent/force rescue | Current Resolve anti-facecamp mechanics specifically impose escalating consequences on prolonged close proximity | Proxy Hook-Zone Control | “Camping” should not collapse proxy and obsolete close-facecamp forms |
| Passive Thrill Totem-Defense Form | Passive cleanse/bless slowdown from remaining Totems | 10.2 Thrill now ignites after first hook and blocks lit Hex Totems on hooks | Active Hex Defense | Old “Thrill defense” guides are mechanically stale |
| Historical Tombstone-Piece Direct-Kill Shape | Directly kill a healthy/injured Survivor during Evil Within III | Current Tombstone Piece instead grants Undetectable when Evil Incarnate activates; direct-kill text is historical. | Stalk-to-Expose Ambush/current Evil Incarnate implementations | “Tombstone Myers” is especially ambiguous because the historical direct-kill add-ons no longer match old guides |

Legacy mechanics are intentionally described as historical. They are never presented as live 10.2 behavior.

## 10. Tactic Glossary

| Tactic ID | Tactic | Definition | Strategic purpose | Related Strategy-layer objects |
| --- | --- | --- | --- | --- |
| KTAC-001 | Temporary Slug | Leave a downed Survivor briefly instead of immediately picking up | Chase a nearby threat, avoid save, reposition, protect objective | Generator Control, Hook-Zone / Rescue Pressure, Chain-Down Pressure |
| KTAC-002 | Leave Chase | Deliberately abandon an inefficient pursuit | Preserve tempo and contest higher-value target/objective | — |
| KTAC-003 | Return to Hook | Re-enter hook area after leaving | Intercept rescue, reacquire target, protect nearby anchor | Target Focus / Elimination Sequencing, Hook-Zone / Rescue Pressure |
| KTAC-004 | Force Trade | Pressure rescuer so rescue produces another down/hook | Maintain hook pressure without necessarily focusing same Survivor | Hook-Zone / Rescue Pressure, Proxy Hook-Zone Control |
| KTAC-005 | Defend Critical Generator | Temporarily prioritize a high-progress or cluster-critical gen | Prevent immediate objective loss | Generator Control, Territorial Control |
| KTAC-006 | Chase Death-Hook Survivor | Prefer a currently accessible Survivor whose next hook eliminates | Convert a local opportunity efficiently | Target Focus / Elimination Sequencing, Hook-State Prioritization |
| KTAC-007 | Delay Pickup | Wait before lifting a downed Survivor | Avoid flashlight/pallet save, bait helpers, use Power cooldown | Chain-Down Pressure |
| KTAC-008 | Zone Survivor | Occupy position/path so Survivor is forced toward weaker route | Shape chase geometry or deny rescue/objective access | Hook-Zone / Rescue Pressure, Chase Optimization Suite, Territorial Control |
| KTAC-009 | Bodyblock Escape Route | Use Killer collision to deny path temporarily | Secure hit/down, protect trap/door/hook path | Chase Optimization Suite, Ambush Rotation, Territorial Control |
| KTAC-010 | Rescue Interception | Predict approach route and meet rescuer before hook | Delay rescue and create second chase | Proxy Hook-Zone Control |
| KTAC-011 | Fake Objective Commitment | Begin/telegraph kick, teleport, projection or patrol action to force Survivor displacement without completing it | Gain movement/error value without full action cost | Generator Control, Dream Projection Pressure Module |
| KTAC-012 | Break-and-Leave | Consume a pallet/breakable resource and abandon the chase | Convert present chase into later resource advantage | Pallet / Resource Attrition |
| KTAC-013 | Hook-Destination Selection | Carry to a particular hook for location rather than nearest-time efficiency | Set up basement, Scourge, cluster or territorial conversion | Hook + Objective Anchor Control, Basement / Fixed-Anchor Control, Scourge-Hook Routing |
| KTAC-014 | Target Switch on Contact | Drop current pursuit immediately when a higher-value Survivor becomes reachable | Improve hook-state or injury conversion | Target Focus / Elimination Sequencing, Hit-and-Run Injury Attrition, Rapid Rotation Pressure |

All 14 tactics are absent from `killer-strategies.json` and carry no Power, Tier, Ranking Index, or Meta Stability.

## 11. Data-Integrity Audit

| Validation check | Result | Details |
| --- | --- | --- |
| unique canonical Strategy IDs | PASS | {"count": 71} |
| unique snapshot IDs | PASS | {"count": 71} |
| unique tactic IDs | PASS | {"count": 14} |
| unique Killer IDs | PASS | {"count": 44} |
| no source Candidate ID unaccounted for | PASS | {"mapped": 84, "ledger": 84} |
| every snapshot strategyId exists | PASS | — |
| every parentStrategyId exists | PASS | — |
| every relatedStrategyId exists | PASS | — |
| every childStrategyId exists | PASS | — |
| every tactic relatedStrategyId exists | PASS | — |
| every compatibility killerId exists | PASS | {"references": 138} |
| every BuildImplementation killerId exists | PASS | {"references": 9} |
| no tactic ID is used as a Strategy ID | PASS | — |
| every Strategy snapshot has exactly two required environments | PASS | — |
| ranking null/numeric semantics | PASS | — |
| Power dimensions and arithmetic | PASS | {"mismatches": []} |
| Tier thresholds | PASS | {"mismatches": []} |
| Stability components/sum/label | PASS | {"mismatches": []} |
| Ranking Index formula | PASS | {"mismatches": []} |
| rankable current Strategies preserve analytical fields | PASS | — |
| Legacy semantics | PASS | {"legacyCount": 6} |
| Parent Families have no aggregate Power | PASS | {"parentCount": 4} |
| Tactics absent from Strategy collection | PASS | — |
| Tactics contain no Power/Tier/Index fields | PASS | — |
| Compatibility absence semantics is NOT_EVALUATED | PASS | — |
| Content references do not fabricate canonical perk/add-on IDs | PASS | — |
| KILLER_POWER_V1 weights sum to 100 | PASS | {"sum": 100} |
| KILLER_GENERAL_MATCHMAKING canonical status counts | PASS | {"NOT_APPLICABLE": 41, "RANKED": 20, "PROVISIONAL": 3, "UNRANKED": 1, "NOT_CURRENT": 6} |
| KILLER_VS_COORDINATED_SWF canonical status counts | PASS | {"NOT_APPLICABLE": 41, "RANKED": 20, "PROVISIONAL": 3, "UNRANKED": 1, "NOT_CURRENT": 6} |
| Animatronic SPLIT resolved into two module records | PASS | — |
| current Strategic Module count reflects legitimate split | PASS | {"PARENT STRATEGY FAMILY": 4, "META": 7, "META SUBTYPE": 5, "STRATEGIC MODULE": 30, "NICHE STRATEGY": 12, "MECHANIC-CENTERED BUILD": 7} |
| canonical Strategy-layer object count | PASS | {"count": 71} |
| tactic count | PASS | {"count": 14} |
| killer roster count | PASS | {"count": 44} |

**Validation result: PASS — 34 checks, 0 failures.**

The audit verifies identity uniqueness, source-accounting, referential integrity, exactly two environment evaluations per Strategy-layer snapshot, status/null semantics, raw Power dimensions, KILLER_POWER_V1 arithmetic, tier thresholds, Stability sums/labels, Ranking Index, analytical fields, Legacy behavior, Parent Family behavior, tactic separation, compatibility references, Killer references, and non-fabrication of perk/add-on canonical IDs.

## Release Artifacts

- `killer-strategies.json`
- `killer-strategy-snapshots.json`
- `killer-tactics.json`
- `killer-characters.json`
- `killer-meta-methodology.json`
- `canonicalization-map.json`
- `validation.json`
- `stage-k3a-report.md`
