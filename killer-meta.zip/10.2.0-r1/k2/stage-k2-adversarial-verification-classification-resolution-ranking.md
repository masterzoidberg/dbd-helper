# Dead by Daylight Killer Meta — Stage K2: Adversarial Verification, Classification Resolution, and Ranking

## Executive resolution

Stage K2 resolves the K1 universe against the **October 7, 2026 research cutoff** and **live Patch 10.2.0**, which went live October 6. The practical consequence is severe: there was only about one day of genuinely clean 10.2 public-play evidence at cutoff. I therefore use official live mechanics as authoritative, use pre-/mixed-window community evidence only for recognition and implementation context, and do **not** treat mixed-window perk statistics as clean 10.2 strategy telemetry. fileciteturn0file0 fileciteturn0file1

The most important K2 conclusion is that K1 was broadly complete at the **Strategy layer**, but substantially over-granular at the Killer-specific implementation layer. Many Killer-specific K1 objects survive as useful records but fail the independence test: Oni Blood/Fury timing, Twins body sequencing, Hag/Trapper/Singularity network implementations, Xenomorph tunnels, Dredge lockers, Legion Frenzy spreading, Artist probing, Knight Guard routing, and several newer-Killer Power loops are better represented as **Strategic Modules or implementations of a broader Strategy**, not separately scored Strategies. That change is important because separately tiering each of them would quietly reintroduce the exact character-strength confound K2 is supposed to prevent. fileciteturn0file0

The resulting canonical layer is:

| K2 result | Count |
|---|---:|
| Confirmed current independent Strategies | **24** |
| Parent Strategy Families | **4** |
| Current Strategic Modules | **29** |
| Current Mechanic-Centered Builds | **7** |
| Current Niche Strategies | **12** |
| Explicit Tactics retained | **14** |
| Legacy objects | **6** |
| Numerically scored current Strategies | **23** |
| `RANKED` | **20** |
| `PROVISIONAL` | **3** |
| `UNRANKED` | **1** |
| Current `NOT_APPLICABLE` supporting objects | **54** |

The three provisional Strategies are **Hook-to-Generator Conversion**, **Sustained Down-State Control**, and **Heresy / Exile / Zealous Sequencing**. **Active Hex Defense** survives as a genuine current niche Strategy but is `UNRANKED`: its 10.2 implementation was re-formed too recently to support a defensible numerical estimate. Thrill of the Hunt is now hook-driven, Knock Out no longer provides its old downed-Survivor concealment shell, and Dead Man's Switch/Undone/Monstrous Shrine materially changed the hook-to-generator ecosystem in 10.2. fileciteturn0file1

No current Strategy reaches the deliberately stringent **S = 88–100** threshold. In General Matchmaking, the top K2 model results are **Rapid Rotation Pressure 85**, **Chain-Down Pressure 85**, **Plague Infection / Fountain Economy 84**, **Committed Elimination Focus 83**, and **Cenobite Chain-Hunt Control 82**. Against coordinated SWF, only **Rapid Rotation Pressure 82** and **Plague Infection / Fountain Economy 79** remain A-tier; the next cluster drops into high B because communication directly attacks target-state ambiguity, recovery windows, rescue pressure, stealth, and side-objective mistakes.

This does **not** mean Rapid Rotation is “good because Blight/Nurse are good,” nor that Chain-Down is “good because Oni is good.” Each score is conditioned on an appropriately compatible Killer and asks whether the decision policy creates incremental value relative to plausible alternative play on that same Killer. Applicability breadth never contributes directly to Power.

**The carried K1 research flags resolve as follows.**

| K1 flag | K2 resolution |
|---|---|
| Fresh 10.2 evidence | **Material limitation.** It lowers Power/prevalence confidence, especially for newly re-formed ecosystems; it does not invalidate mechanically mature Strategies. |
| Mixed-patch statistics | **Not valid as clean 10.2 telemetry.** K1's NightLight snapshot remains ecosystem/recognition evidence only; community statistics are based on uploaded matches rather than a controlled patch-specific population. fileciteturn0file0 |
| Recently changed database descriptions | **Official live mechanics win.** Community/reference text is used only after consistency checks against live patch material. |
| Nowhere to Hide discrepancy | **Resolved.** The live 10.1 change centers the aura search on the damaged generator at 24 m; 10.1.2 subsequently fixed inconsistent description/range behavior. The obsolete “around the Killer” reading is not used in K2. citeturn16search0turn16search1 |
| Judgment 10.1.2 vs 10.1.2a | **Resolved in favor of 10.1.2a.** Zealous Divine Light's curve window reverted from 0.8 s to 0.6 s and the non-Zealous 0.3 s curve was removed. citeturn20search0turn20search3 |
| Shape/Cenobite live vs obtainable | **Separate fields required.** Both remain playable/supported for prior owners while no longer being normally obtainable; the practical playable roster remains 44. citeturn17search0turn17search1turn12search4 |
| Target Focus vs tactical hook return | **Resolved by split.** Committed Elimination Focus is a Strategy; Hook-State Prioritization is a Module; one Return to Hook remains a Tactic. |
| Sustained slugging after Knock Out | **Survives narrowly.** Sustained Down-State Control remains a Power-family Strategy, but is provisional and much less structurally supported; the old Knock Out implementation is Legacy. Knock Out is now a pallet/Hindered perk. fileciteturn0file1 |
| Active Hex Defense | **Current Strategy, UNRANKED.** The 10.2 Thrill redesign creates an active hook-driven defense loop, but one day of live ecology does not justify Power. fileciteturn0file1 |
| Compromised Generator framework | **Mechanic-Centered Build.** Machine Learning/Help Wanted now support three compromised generators, but there is insufficient evidence that the framework independently organizes whole matches. fileciteturn0file1 |
| Mobility Strategy threshold | **Resolved operationally.** Rapid Rotation exists only when mobility repeatedly lowers chase-commitment thresholds and drives target/objective re-routing; simply using a mobility Power is not the Strategy. |
| Information Strategy vs Module | **Module.** Information Chaining can determine movement but lacks an independent win objective/payoff loop. |
| Territorial vs Generator Control | **Graph, not tree.** Three-gen defense and Hook + Objective Anchor have legitimate cross-family relationships. |
| Non-guaranteed Realm offerings | **Explicitly priced into Map Dependence.** Current Realm offerings provide a 20% Realm influence rather than deterministic map selection; favorable-map assumptions are therefore invalid. citeturn14search1 |
| Survivor Intent | **Narrows, but does not erase, public coordination gaps.** The live system provides eight predefined, customizable team messages and is optional; it is not equivalent to continuous four-person voice comms. fileciteturn0file1 |
| Shoulder the Burden | **Material coordinated counterplay.** Each eligible user can transfer one hook state once per trial; the PTB team-wide deactivation was removed before live. Its value is therefore especially exploitable by coordinated hook-state management. fileciteturn0file1 |
| Competitive contamination | **Controlled.** Tournament evidence is used only for ceiling, optimized counterplay, and implementation; DBDLeague uses Killer/map/add-on/perk restrictions that materially differ from normal live rules. citeturn9search2 |
| Add-on-defined variants | **Audited.** Scratched Mirror survives as a Strategy Definer; several others are subtype enablers or implementation transforms. One additional support-level Hag subtype was found, but no new Strategy-level object. |
| Historical terminology drift | **Explicitly separated.** Old Knock Out slugging, infinite-kick three-gen, pre-Resolve close facecamp, passive Thrill defense, old Deerstalker slug tracking, and old Tombstone-Piece direct kill are Legacy. |
| Skull Merchant continuity | **Resolved against historical contamination.** Current drone play is not the old generator-defense identity; earlier reworks explicitly moved the Power away from primarily defending generators, and later changes further altered scan/chase behavior. citeturn10search7turn14search16 |
| Perk prevalence vs Strategy prevalence | **Kept separate.** Strategy prevalence is `UNKNOWN` unless the mapping is specific enough to justify a stronger claim. |

The most important uncertainty is therefore **measurement**, not ontology. The main strategic structures are identifiable; clean 10.2 prevalence and outcome evidence is not yet mature enough to pretend that one- or two-point tier differences are empirically proven.

## Locked Killer power model

The model was locked before final candidate scores were calculated. I use the **same weights in General Matchmaking and Coordinated SWF**. This is deliberate: coordination should change the Strategy's observed/expected properties—Consistency, Matchup Coverage, Counterplay Resilience, Activation conversion, and so on—not the definition of what Killer strategic strength means. Changing both weights and raw scores would risk double-counting communication effects.

**Model ID: `KILLER_POWER_V1`**

| Dimension | Operational K2 definition | Weight |
|---|---|---:|
| Consistency | Reliability of meaningful value across ordinary matches inside intended compatibility scope | **11** |
| Ceiling | Maximum realistic value under excellent execution | **8** |
| Agency | Killer's ability to create required states instead of waiting for Survivor mistakes | **11** |
| Power Integration | Natural fit with compatible native Powers; explicitly **not raw Killer strength** | **7** |
| Matchup Coverage | Robustness across Survivor plans, loadouts, healing/rescue policies, coordination and target responses | **9** |
| Map Coverage | Robustness across size, geometry, sightlines, verticality, generator/hook spacing and setup structure | **8** |
| Tempo Efficiency | Pressure created per unit of Killer time | **12** |
| Slot Efficiency | Value relative to perk/add-on/offering/Power-resource commitment | **7** |
| Recovery Value | Capacity to stabilize after falling behind | **6** |
| Snowball Value | Capacity to compound an advantage into further downs/hooks/eliminations/objective collapse | **6** |
| Counterplay Resilience | Difficulty for competent Survivors to neutralize the plan | **9** |
| Execution Reliability | Practical reproducibility by appropriately skilled Killer players | **6** |
| **Total** |  | **100** |

Tempo Efficiency receives the largest weight because Killer macro play is fundamentally time-constrained: a plan that produces nominal pressure but consumes too much Killer time is strategically weak. Consistency and Agency are next because K2 is evaluating repeatable plans rather than highlight-reel ceilings or Survivor mistakes. Counterplay and matchup/map coverage receive substantial but not dominant weight. Power Integration is deliberately only 7% so that “works beautifully with this Power” does not silently become “the Killer is top tier.”

Each Power dimension is scored **0–10** in whole or half-point increments. The calculation is:

`Power = weighted mean of the twelve dimensions × 10`, rounded to the nearest whole number.

Power is a comparative research-model score. It is **not kill rate, win probability, 4K probability, or MMR outcome percentage**.

The tier thresholds are locked at **S 88–100; A 78–87; B 66–77; C 50–65; D 0–49**. D is current but weak; it is not Legacy.

The secondary sorting metric is:

`Ranking Index = Power × 0.80 + Meta Stability × 0.20`.

It never changes a Strategy's Tier.

For descriptive fields, K2 uses a consistent **1–5** scale:

| Field | 1 | 3 | 5 |
|---|---|---|---|
| Skill Floor | Little strategy-specific execution required | Moderate | Demanding baseline execution |
| Skill Ceiling | Shallow optimization | Substantial mastery | Very deep decision/execution ceiling |
| Opportunity Cost | Little foregone value | Meaningful tradeoff | Severe commitment/resources foregone |
| Map Dependence | Little sensitivity | Material | Extreme |
| Win Condition Contribution | Indirect | Meaningful | Directly converts downs/hooks/elimination/objective collapse |
| Activation Reliability | Rare/externally dependent | Mixed | Killer can create it reliably |
| Activation Payoff | Small | Material | Match-shaping |
| Denial Risk | Hard for Survivors to deny | Moderate | Easy to refuse/neutralize |
| Strategic Commitment | Lightly influences play | Meaningful | Strongly constrains targets/pathing/hooks/resources |

The six-component Stability framework is unchanged: **Structural Independence 25, Core Mechanic Durability 20, Replacement Depth 15, Environmental Breadth 15, Counter-Meta Independence 10, Patch Durability 15**. Stability is structural durability, not current Power and not evidence certainty.

## K1 to K2 disposition

Every K1 Candidate ID appears below. `TACTIC` is the one extra structural class retained beyond the Strategy ontology because K1 created explicit tactic IDs and K2 is required to preserve them; every TACTIC is `NOT_APPLICABLE` for Power. The K1 universe itself is sourced from the Stage K1 deliverable. fileciteturn0file0

| K1 Candidate ID | K1 Working Name | K2 Final Working Name | Final Structural Classification | Status | Scope | Disposition | Parent / related | Rankability | Reason | Evidence |
|---|---|---|---|---|---|---|---|---|---|---|
| K1-GEN-FAM | Generator Control | Generator Control | PARENT STRATEGY FAMILY | ESTABLISHED | BROAD_ROSTER | CONFIRMED | — | NOT_APPLICABLE | Heterogeneous family; averaged Power would be artificial. | HIGH |
| K1-GEN-REG | Active Regression Conversion | Active Regression Conversion | META | ESTABLISHED | BROAD_ROSTER | CONFIRMED | K1-GEN-FAM | RANKED | Persistent regression-conversion loop survives removal of exact perk names. | HIGH |
| K1-GEN-HOOK | Hook-to-Generator Conversion | Hook-to-Generator Conversion | META SUBTYPE | ESTABLISHED | BROAD_ROSTER | CONFIRMED | K1-GEN-FAM | PROVISIONAL | Independent hook→objective loop survives; 10.2 materially re-formed support. fileciteturn0file1 | HIGH |
| K1-GEN-BLOCK | Generator Blocking / Repair Denial | Generator Blocking / Repair Denial | STRATEGIC MODULE | ESTABLISHED | BROAD_ROSTER | CONFIRMED | K1-GEN-FAM | NOT_APPLICABLE | Blocking is a conversion tool, not an independent win loop. | HIGH |
| K1-GEN-3G | Generator-Cluster / Three-Generator Defense | Generator-Cluster Defense | NICHE STRATEGY | ESTABLISHED | BROAD_ROSTER | CONFIRMED_WITH_RECLASSIFICATION | K1-GEN-FAM; related K1-TERR-FAM | RANKED | Current cluster defense survives, but indefinite kick cycling does not; each generator has a finite regression-event budget. citeturn15search0 | HIGH |
| K1-GEN-DEBUFF | Repair-Speed Suppression | Repair-Speed Suppression | STRATEGIC MODULE | ESTABLISHED | BROAD_ROSTER | CONFIRMED | K1-GEN-FAM | NOT_APPLICABLE | Supplies time to another plan rather than defining one. | HIGH |
| K1-GEN-COMP | Compromised-Generator Payoff Framework | Compromised-Generator Payoff Framework | MECHANIC-CENTERED BUILD | EMERGING | BROAD_ROSTER | CONFIRMED | K1-GEN-FAM | NOT_APPLICABLE | 10.2 framework is real; independent full-match strategy is not established. fileciteturn0file1 | MEDIUM_HIGH |
| K1-TGT-FAM | Target Focus / Elimination Sequencing | Target Focus / Elimination Sequencing | PARENT STRATEGY FAMILY | ESTABLISHED | BROAD_ROSTER | CONFIRMED | — | NOT_APPLICABLE | Umbrella remains useful, but its children differ strategically. | HIGH |
| K1-TGT-COM | Committed Elimination Focus | Committed Elimination Focus | META | ESTABLISHED | BROAD_ROSTER | CONFIRMED | K1-TGT-FAM | RANKED | Sustained target commitment materially changes chase persistence, hook sequencing and pathing. | HIGH |
| K1-TGT-HOOK | Hook-State / Death-Hook Prioritization | Hook-State Prioritization | STRATEGIC MODULE | ESTABLISHED | BROAD_ROSTER | DEMOTED_TO_MODULE | K1-TGT-FAM | NOT_APPLICABLE | State-aware target choice lacks a sufficiently independent activation/payoff loop. | MEDIUM_HIGH |
| K1-HOOK-FAM | Hook-Zone / Rescue Pressure | Hook-Zone / Rescue Pressure | PARENT STRATEGY FAMILY | ESTABLISHED | BROAD_ROSTER | CONFIRMED | — | NOT_APPLICABLE | Organizes strategically distinct rescue-pressure children. | HIGH |
| K1-HOOK-PROXY | Proxy Hook-Zone Control | Proxy Hook-Zone Control | META | ESTABLISHED | BROAD_ROSTER | CONFIRMED | K1-HOOK-FAM | RANKED | Sustained interception/rescue conversion remains distinct from static close facecamping. | HIGH |
| K1-HOOK-ANCHOR | Hook + Objective Anchor Control | Hook + Objective Anchor Control | META SUBTYPE | ESTABLISHED | BROAD_ROSTER | CONFIRMED | K1-HOOK-FAM; related Generator/Territorial | RANKED | Defending hook and valuable objective through one patrol structure is independently meaningful. | MEDIUM_HIGH |
| K1-HOOK-BSMT | Basement / Fixed-Anchor Control | Basement / Fixed-Anchor Control | NICHE STRATEGY | ESTABLISHED | BROAD_ROSTER | CONFIRMED | K1-HOOK-FAM | RANKED | Hook-destination investment and fixed-zone defense create a persistent niche loop. | HIGH |
| K1-DOWN-CHAIN | Chain-Down Pressure | Chain-Down Pressure | META | ESTABLISHED | POWER_FAMILY | CONFIRMED | — | RANKED | Deliberate second/third-down pursuit is distinct from temporary slugging and from “snowball” as an outcome. | HIGH |
| K1-DOWN-SUST | Sustained Down-State Control | Sustained Down-State Control | NICHE STRATEGY | ESTABLISHED | POWER_FAMILY | CONFIRMED_WITH_RECLASSIFICATION | related K1-DOWN-CHAIN | PROVISIONAL | Survives on appropriate re-down/rotation Powers, but old Knock Out support is gone. fileciteturn0file1 | MEDIUM |
| K1-ATTR-HR | Hit-and-Run Injury Attrition | Hit-and-Run Injury Attrition | META | ESTABLISHED | POWER_FAMILY | CONFIRMED | — | RANKED | Systematic injure→disengage→rotate→recontact policy survives perk removal. | HIGH |
| K1-ATTR-AH | Healing Suppression | Healing Suppression | STRATEGIC MODULE | ESTABLISHED | BROAD_ROSTER | CONFIRMED | K1-ATTR-HR | NOT_APPLICABLE | Changes reset economics, but does not independently select targets/pathing/win state. | HIGH |
| K1-CHASE-RES | Pallet / Resource Attrition | Pallet / Resource Attrition | STRATEGIC MODULE | ESTABLISHED | BROAD_ROSTER | DEMOTED_TO_MODULE | related Chase Optimization | NOT_APPLICABLE | Long-horizon pallet depletion exists, but usually collapses into ordinary chase-resource management. | MEDIUM |
| K1-CHASE-MOD | Chase Optimization Suite | Chase Optimization Suite | STRATEGIC MODULE | ESTABLISHED | BROAD_ROSTER | CONFIRMED | — | NOT_APPLICABLE | Universal efficiency layer rather than differentiated macro plan. | HIGH |
| K1-INFO-CHAIN | Information Chaining | Information Chaining | STRATEGIC MODULE | ESTABLISHED | BROAD_ROSTER | CONFIRMED_WITH_RECLASSIFICATION | — | NOT_APPLICABLE | Information can dictate routing but remains an enabling input rather than an independent win condition. | HIGH |
| K1-AMBUSH | Ambush Rotation | Ambush Rotation | META | ESTABLISHED | POWER_FAMILY | CONFIRMED | — | RANKED | Hidden approach plus deliberately short visible commitments forms a coherent recurring plan. | HIGH |
| K1-TERR-FAM | Territorial Control | Territorial Control | PARENT STRATEGY FAMILY | ESTABLISHED | POWER_FAMILY | CONFIRMED | — | NOT_APPLICABLE | Setup/network children differ too much for aggregate Power. | HIGH |
| K1-TERR-SETUP | Setup-Zone Lockdown | Setup-Zone Lockdown | META SUBTYPE | ESTABLISHED | POWER_FAMILY | CONFIRMED | K1-TERR-FAM | RANKED | Pre-invested hazards/resources create a persistent territorial loop. | HIGH |
| K1-TERR-NET | Network Surveillance / Teleport Control | Network Surveillance / Teleport Control | META SUBTYPE | ESTABLISHED | POWER_FAMILY | CONFIRMED | K1-TERR-FAM | RANKED | Persistent map nodes create movement/information/disablement economy. | HIGH |
| K1-MOB-ROT | Rapid Rotation Pressure | Rapid Rotation Pressure | META | ESTABLISHED | POWER_FAMILY | CONFIRMED | related K1-TERR-NET, K1-GEN-HOOK | RANKED | Passes only when mobility systematically changes target-switch and chase-commitment thresholds. | HIGH |
| K1-HEX-DEF | Active Hex / Totem Defense | Active Hex Defense | NICHE STRATEGY | EMERGING | BROAD_ROSTER | CONFIRMED_WITH_RECLASSIFICATION | — | UNRANKED | 10.2 produces a real active-defense loop, but evidence is too fresh for numerical Power. fileciteturn0file1 | MEDIUM |
| K1-END-CONV | Deliberate Endgame Conversion | Deliberate Endgame Conversion | NICHE STRATEGY | ESTABLISHED | BROAD_ROSTER | CONFIRMED | — | RANKED | Earlier resources are deliberately traded for powered-gate conversion. | MEDIUM_HIGH |
| K1-END-GATE | Gate Control | Gate Control | STRATEGIC MODULE | ESTABLISHED | BROAD_ROSTER | CONFIRMED | K1-END-CONV | NOT_APPLICABLE | Activates too late and normally serves the broader endgame plan. | HIGH |
| K1-SCOURGE | Scourge-Hook Routing | Scourge-Hook Routing | MECHANIC-CENTERED BUILD | ESTABLISHED | BROAD_ROSTER | CONFIRMED | Hook/Generator ecosystem | NOT_APPLICABLE | Shared special-hook routing mechanic supports multiple Strategies. | HIGH |
| K1-SKILL | Skill-Check / Interaction Pressure | Skill-Check / Interaction Pressure | MECHANIC-CENTERED BUILD | ESTABLISHED | BROAD_ROSTER | CONFIRMED | — | NOT_APPLICABLE | Recognizable package, insufficient independent macro objective. | MEDIUM_HIGH |
| K1-CARRY | Carry / Hook-Transport Optimization | Carry / Hook-Transport Optimization | MECHANIC-CENTERED BUILD | ESTABLISHED | BROAD_ROSTER | CONFIRMED | K1-HOOK-FAM | NOT_APPLICABLE | Delivers Survivors to anchors/Scourges/basement; transport is not itself the win loop. | HIGH |
| K1-M1 | Basic-Attack Tempo Framework | Basic-Attack Tempo Framework | MECHANIC-CENTERED BUILD | EMERGING | BROAD_ROSTER | CONFIRMED | — | NOT_APPLICABLE | 10.2 creates a strong M1 package, not a separate Strategy. fileciteturn0file1 | MEDIUM_HIGH |
| K1-LEG-KO | Knock Out Slug-Concealment Shell | Knock Out Slug-Concealment Shell | MECHANIC-CENTERED BUILD | LEGACY | BROAD_ROSTER | LEGACY | related K1-DOWN-SUST | NOT_CURRENT | Knock Out no longer performs its historical slug-concealment function. fileciteturn0file1 | HIGH |
| K1-LEG-3G | Indefinite Repeated-Kick Three-Gen Attrition | Indefinite Repeated-Kick Three-Gen Attrition | META SUBTYPE | LEGACY | BROAD_ROSTER | LEGACY | K1-GEN-FAM | NOT_CURRENT | Regression-event limits ended indefinite same-generator kick cycling. citeturn15search0 | HIGH |
| K1-PF-STALK | Stalk-to-Expose Ambush | Stalk-to-Expose Ambush | META SUBTYPE | ESTABLISHED | POWER_FAMILY | CONFIRMED | K1-AMBUSH | RANKED | Stalk investment changes approach time and target conversion enough to remain distinct. | HIGH |
| K1-KS-CENO | Lament Configuration / Chain-Hunt Control | Lament Configuration / Chain-Hunt Control | NICHE STRATEGY | ESTABLISHED | KILLER_SPECIFIC | CONFIRMED | — | RANKED | Box contest is a unique secondary-objective control loop. | HIGH |
| K1-KS-PIG | Reverse-Bear-Trap Objective Tax | Reverse-Bear-Trap Objective Tax | NICHE STRATEGY | ESTABLISHED | KILLER_SPECIFIC | CONFIRMED | — | RANKED | Finite trap allocation and generator timing create a distinct side-objective economy. | HIGH |
| K1-KS-ONRYO | Condemn Pressure | Condemn Pressure | NICHE STRATEGY | ESTABLISHED | KILLER_SPECIFIC | CONFIRMED | — | RANKED | Condemned/tape/TV management creates an alternate elimination axis. | HIGH |
| K1-KS-PLAGUE | Infection / Fountain Economy | Infection / Fountain Economy | NICHE STRATEGY | ESTABLISHED | KILLER_SPECIFIC | CONFIRMED_WITH_RECLASSIFICATION | — | RANKED | Survivor cleanse policy creates a genuine injury/resource economy. | HIGH |
| K1-KS-ONI | Blood Economy → Fury Chain | Blood Economy / Fury Timing | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | DEMOTED_TO_MODULE | K1-DOWN-CHAIN | NOT_APPLICABLE | Blood/Fury timing is native Power execution; Chain-Down captures the macro plan. | HIGH |
| K1-KS-TWINS | Split-Body Chain Pressure | Split-Body Chain Sequencing | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | DEMOTED_TO_MODULE | K1-DOWN-CHAIN | NOT_APPLICABLE | Charlotte/Victor sequencing implements multi-down/pickup policy rather than a separate objective. | HIGH |
| K1-KS-SING | Biopod Network Control | Biopod Network Implementation | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | MERGED | K1-TERR-NET | NOT_APPLICABLE | Distinct execution/counterplay, same strategic Network-Control loop. | HIGH |
| K1-KS-HAG | Trap-Web Lockdown | Trap-Web Implementation | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | MERGED | K1-TERR-SETUP | NOT_APPLICABLE | Canonical Setup-Zone implementation, not a second Strategy score. | HIGH |
| K1-KS-TRAP | Trap-Zone Control | Bear-Trap Zone Implementation | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | MERGED | K1-TERR-SETUP | NOT_APPLICABLE | Resource rules differ, strategic objective does not. | HIGH |
| K1-KS-SKULL | Drone Surveillance Zones | Drone Surveillance / Chase-Zone Module | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | DEMOTED_TO_MODULE | K1-TERR-FAM | NOT_APPLICABLE | Current system cannot responsibly inherit old “three-gen Skull Merchant” identity. citeturn10search7turn14search16 | MEDIUM_HIGH |
| K1-KS-DEMO | Portal Network Pressure | Portal Network Implementation | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | MERGED | K1-TERR-NET / K1-MOB-ROT | NOT_APPLICABLE | Portal placement/travel implements Network and Rotation strategies. | HIGH |
| K1-KS-UNKNOWN | Hallucination Network Rotation | Hallucination Network Implementation | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | MERGED | K1-TERR-NET | NOT_APPLICABLE | Hallucination routing is a node-network implementation. | HIGH |
| K1-KS-XENO | Tunnel / Control-Station Rotation | Tunnel Rotation Implementation | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | MERGED | K1-MOB-ROT / K1-AMBUSH | NOT_APPLICABLE | Fixed tunnel travel primarily implements Rotation/Ambush. | HIGH |
| K1-KS-DREDGE | Locker / Nightfall Ambush Rotation | Locker / Nightfall Rotation Module | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | MERGED | K1-AMBUSH / K1-MOB-ROT | NOT_APPLICABLE | Locker/Nightfall mechanics implement broader strategies. | HIGH |
| K1-KS-KNIGHT | Guard Pincer / Remote Patrol | Guard Pincer / Remote Patrol | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | DEMOTED_TO_MODULE | K1-TERR-FAM | NOT_APPLICABLE | Most value is local zoning/remote chase execution rather than separate macro objective. | MEDIUM_HIGH |
| K1-KS-ARTIST | Crow Zoning / Remote Probe | Crow Zoning / Remote Probe | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | DEMOTED_TO_MODULE | K1-INFO-CHAIN | NOT_APPLICABLE | Remote probing serves chase/routing. | HIGH |
| K1-KS-DOCTOR | Madness / Interaction Disruption | Madness / Interaction Disruption | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | DEMOTED_TO_MODULE | K1-SKILL / info | NOT_APPLICABLE | Madness is persistent native state generation, but not an independent macro win plan. | MEDIUM_HIGH |
| K1-KS-LEGION | Feral-Frenzy Injury Spread | Feral-Frenzy Injury-Spread Module | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | MERGED | K1-ATTR-HR | NOT_APPLICABLE | Strong native Hit-and-Run implementation, not a separate score. | HIGH |
| K1-KS-EXEC | Torment / Cage Sequencing | Torment / Cage Sequencing | NICHE STRATEGY | ESTABLISHED | KILLER_SPECIFIC | CONFIRMED | — | RANKED | Cage-vs-hook choice materially changes transport, perk triggers and sacrifice routing. | HIGH |
| K1-KS-JUDGE | Heresy / Exile / Zealous Sequencing | Heresy / Exile / Zealous Sequencing | NICHE STRATEGY | EMERGING | KILLER_SPECIFIC | CONFIRMED | — | PROVISIONAL | Unique sacrifice-state economy, but recent Killer and 10.1.2a reversal prevent high confidence. citeturn20search0turn20search5 | MEDIUM_HIGH |
| K1-KS-ANIM | Axe-Impale / Security-Door Ambush | Axe-Impale + Security-Door Modules | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | SPLIT | K1-MOB-ROT / K1-AMBUSH / injury | NOT_APPLICABLE | Door rotation and Axe attrition do not form one independent macro object. | HIGH |
| K1-KS-SLASH | Omnipresent-Evil Ambush / Pin | Omnipresent-Evil Ambush Module | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | MERGED | K1-AMBUSH | NOT_APPLICABLE | Strong Ambush implementation; pinning is chase execution. | HIGH |
| K1-KS-KRASUE | Leech → Form-Cycle Conversion | Leech / Form-Cycle Module | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | DEMOTED_TO_MODULE | — | NOT_APPLICABLE | Form cycling is native Power conversion rather than separate match plan. | MEDIUM_HIGH |
| K1-KS-FIRST | Curse / Upside-Down Conversion | Worldbreaker / Upside-Down Module | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | CONFIRMED_WITH_RECLASSIFICATION | K1-MOB-ROT | NOT_APPLICABLE | K1 terminology needed correction; current Worldbreaker/movement loop is native Power execution. | MEDIUM_HIGH |
| K1-KS-GHOUL | Kagune-Mark / Enraged Maintenance | Kagune-Mark / Enraged Module | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | DEMOTED_TO_MODULE | K1-MOB-ROT | NOT_APPLICABLE | Mark maintenance optimizes native Power state rather than creating a separate objective. | MEDIUM_HIGH |
| K1-KS-HOUND | Search-to-Chase Lane Control | Search-to-Chase Routing Module | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | DEMOTED_TO_MODULE | K1-INFO-CHAIN | NOT_APPLICABLE | Search/Chase commands provide routing/chase conversion. | MEDIUM_HIGH |
| K1-KS-NIGHT | Dream Projection / Dream-Zone Pressure | Dream Projection Pressure Module | STRATEGIC MODULE | ESTABLISHED | KILLER_SPECIFIC | DEMOTED_TO_MODULE | K1-MOB-ROT / Generator Control | NOT_APPLICABLE | Projection implements mobility/objective pressure rather than independent macro strategy. | MEDIUM_HIGH |
| K1-ADD-MIRROR | Scratched-Mirror Ambush | Scratched-Mirror Ambush | NICHE STRATEGY | ESTABLISHED | KILLER_SPECIFIC | CONFIRMED | K1-AMBUSH | RANKED | Add-on permanently changes information, movement/chase profile and map policy. citeturn20search4 | HIGH |
| K1-ADD-JUDG | Obsidian-Feather Forced-Cast Variant | Obsidian-Feather Forced-Cast Variant | MECHANIC-CENTERED BUILD | EMERGING | KILLER_SPECIFIC | DEMOTED_TO_MECHANIC_BUILD | K1-KS-JUDGE | NOT_APPLICABLE | Transformative projectile handling does not create a separate persistent objective. fileciteturn0file1 | MEDIUM_HIGH |
| K1-TAC-01 | Temporary Slug | Temporary Slug | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | Down-State strategies | NOT_APPLICABLE | Local pickup decision. | HIGH |
| K1-TAC-02 | Leave Chase | Leave Chase | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | many | NOT_APPLICABLE | Universal tempo primitive. | HIGH |
| K1-TAC-03 | Return to Hook | Return to Hook | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | K1-HOOK-FAM | NOT_APPLICABLE | One hook return does not establish sustained target/hook strategy. | HIGH |
| K1-TAC-04 | Force Trade | Force Trade | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | K1-HOOK-FAM | NOT_APPLICABLE | Local rescue conversion. | HIGH |
| K1-TAC-05 | Defend Critical Generator | Defend Critical Generator | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | K1-GEN-FAM | NOT_APPLICABLE | Local objective prioritization. | HIGH |
| K1-TAC-06 | Chase Death-Hook Survivor | Chase Death-Hook Survivor | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | K1-TGT-FAM | NOT_APPLICABLE | Local target-value response unless sustained into a broader policy. | HIGH |
| K1-TAC-07 | Delay Pickup | Delay Pickup | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | Down-State | NOT_APPLICABLE | Temporary pickup timing decision. | HIGH |
| K1-TAC-08 | Zone Survivor | Zone Survivor | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | many | NOT_APPLICABLE | Local positional maneuver. | HIGH |
| K1-TAC-09 | Bodyblock Escape Route | Bodyblock Escape Route | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | chase/territory | NOT_APPLICABLE | Local collision/path denial. | HIGH |
| K1-TAC-10 | Rescue Interception | Rescue Interception | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | K1-HOOK-FAM | NOT_APPLICABLE | One interception is not the persistent hook-zone loop. | HIGH |
| K1-TAC-11 | Fake Objective Commitment | Fake Objective Commitment | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | Generator/Power pressure | NOT_APPLICABLE | Local feint. | HIGH |
| K1-TAC-12 | Break-and-Leave | Break-and-Leave | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | chase-resource module | NOT_APPLICABLE | One resource-conversion choice. | HIGH |
| K1-TAC-13 | Hook-Destination Selection | Hook-Destination Selection | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | K1-HOOK-FAM | NOT_APPLICABLE | Supports anchors, Scourges and basement; not independent. | HIGH |
| K1-TAC-14 | Target Switch on Contact | Target Switch on Contact | TACTIC | ESTABLISHED | BROAD_ROSTER | TACTIC_ONLY | Target/Rotation/Hit-and-Run | NOT_APPLICABLE | Local switching primitive. | HIGH |

The largest K1→K2 contraction is therefore deliberate: **native Power execution is not automatically a Strategy**. The strongest examples of this correction are Oni, Twins, Singularity, Hag, Trapper, Demogorgon, Unknown, Xenomorph, Dredge, Legion, Artist, Knight, Doctor, and several recent Killers. Their records remain strategically useful, but giving every native mechanic its own score would make Strategy Power track character strength rather than incremental strategic value.

## Environment rankings and coordination effects

Because 10.2 had only about a day of clean public evidence at cutoff, these placements combine verified mechanics, pre-existing strategic continuity, compatible-Killer implementation evidence, and adversarial counterplay analysis. They should not be read as empirical percentages. The 10.2 changes most relevant to rankings include the hook/generator perk pass, the Knock Out and Deerstalker reworks, active Thrill, Shoulder the Burden, and Survivor Intent. fileciteturn0file1

**KILLER_GENERAL_MATCHMAKING**

| Strategy | Class | Scope | Status | Ranking status | Power | Tier | Stability | Index | Confidence | Trend | K2 explanation |
|---|---|---|---|---|---:|---|---:|---:|---|---|---|
| Rapid Rotation Pressure | META | POWER_FAMILY | ESTABLISHED | RANKED | **85** | **A** | 97 | 87.4 | MEDIUM_HIGH | STABLE | Compresses travel/search losses and lets the Killer abandon declining-value engagements without surrendering map pressure. |
| Chain-Down Pressure | META | POWER_FAMILY | ESTABLISHED | RANKED | **85** | **A** | 91 | 86.2 | MEDIUM_HIGH | High second-down conversion on appropriate Powers; public teams are less reliable at rapid recovery coordination. |
| Infection / Fountain Economy | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **84** | **A** | 92 | 85.6 | MEDIUM_HIGH | Plague's cleanse dilemma converts Survivor healing policy into a Killer resource economy. |
| Committed Elimination Focus | META | BROAD_ROSTER | ESTABLISHED | RANKED | **83** | **A** | 97 | 85.8 | MEDIUM_HIGH | Early removal is a direct win-condition accelerator when re-acquisition cost is controlled. |
| Lament Configuration / Chain-Hunt Control | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **82** | **A** | 85 | 82.6 | MEDIUM_HIGH | Box timing and interception create large multi-Survivor opportunity costs. |
| Active Regression Conversion | META | BROAD_ROSTER | ESTABLISHED | RANKED | **79** | **A** | 89 | 81.0 | MEDIUM_HIGH | Reliable objective conversion with broad replacement depth; bounded by current regression rules. |
| Hook-to-Generator Conversion | META SUBTYPE | BROAD_ROSTER | ESTABLISHED | **PROVISIONAL** | **79** | **A** | 85 | 80.2 | MEDIUM | 10.2's new hook→gen support looks strong, but clean optimization evidence is immature. |
| Hook + Objective Anchor Control | META SUBTYPE | BROAD_ROSTER | ESTABLISHED | RANKED | **78** | **A** | 85 | 79.4 | MEDIUM | One patrol structure can pressure rescue and repair simultaneously. |
| Network Surveillance / Teleport Control | META SUBTYPE | POWER_FAMILY | ESTABLISHED | RANKED | **78** | **A** | 85 | 79.4 | MEDIUM_HIGH | Persistent nodes reduce search/travel costs while forcing Survivor disablement work. |
| Condemn Pressure | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **78** | **A** | 79 | 78.2 | MEDIUM | Public teams are comparatively vulnerable to uneven tape/TV management and target-state mistakes. |
| Heresy / Exile / Zealous Sequencing | NICHE STRATEGY | KILLER_SPECIFIC | EMERGING | **PROVISIONAL** | **78** | **A** | 62 | 74.8 | LOW_MEDIUM | Exile's alternate sacrifice routing and Zealous payoff are meaningful, but the post-hotfix optimum is not settled. |
| Torment / Cage Sequencing | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **77** | **B** | 88 | 79.2 | MEDIUM_HIGH | Cage routing saves transport and bypasses hook-trigger structures when Torment is available, but activation is conditional. |
| Stalk-to-Expose Ambush | META SUBTYPE | POWER_FAMILY | ESTABLISHED | RANKED | **77** | **B** | 87 | 79.0 | MEDIUM_HIGH | Strong surprise/lethal conversion where sightlines permit stalking. |
| Proxy Hook-Zone Control | META | BROAD_ROSTER | ESTABLISHED | RANKED | **76** | **B** | 91 | 79.0 | MEDIUM_HIGH | Rescue pressure remains strong without requiring obsolete facecamping behavior. |
| Hit-and-Run Injury Attrition | META | POWER_FAMILY | ESTABLISHED | RANKED | **76** | **B** | 85 | 77.8 | MEDIUM_HIGH | Inconsistent public healing and location sharing increase unresolved-injury value. |
| Setup-Zone Lockdown | META SUBTYPE | POWER_FAMILY | ESTABLISHED | RANKED | **74** | **B** | 87 | 76.6 | MEDIUM_HIGH | Strong prepared-zone payoff, offset by setup and relocation cost. |
| Deliberate Endgame Conversion | NICHE STRATEGY | BROAD_ROSTER | ESTABLISHED | RANKED | **74** | **B** | 87 | 76.6 | MEDIUM | Large late payoff but intentionally concedes earlier objective leverage. |
| Ambush Rotation | META | POWER_FAMILY | ESTABLISHED | RANKED | **74** | **B** | 85 | 76.2 | MEDIUM_HIGH | Public information gaps make hidden approach and fast disengagement valuable. |
| Reverse-Bear-Trap Objective Tax | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **73** | **B** | 83 | 75.0 | MEDIUM | Side-objective time is reliable, but trap conversion is partly Survivor-controlled. |
| Generator-Cluster Defense | NICHE STRATEGY | BROAD_ROSTER | ESTABLISHED | RANKED | **72** | **B** | 82 | 74.0 | MEDIUM_HIGH | Still viable when layout cooperates, but modern regression caps and map variance suppress the old ceiling. |
| Basement / Fixed-Anchor Control | NICHE STRATEGY | BROAD_ROSTER | ESTABLISHED | RANKED | **71** | **B** | 84 | 73.6 | MEDIUM | High anchor payoff but severe transport, layout and opportunity-cost constraints. |
| Sustained Down-State Control | NICHE STRATEGY | POWER_FAMILY | ESTABLISHED | **PROVISIONAL** | **65** | **C** | 68 | 65.6 | LOW_MEDIUM | Still real on re-down/rotation Powers, but post-Knock-Out support is materially weaker and less proven. |
| Scratched-Mirror Ambush | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **62** | **C** | 50 | 59.6 | MEDIUM | Powerful information in favorable geometry, but major movement/map opportunity cost prevents a higher placement. |

**GENERAL MATCHMAKING UNRANKED:** `K1-HEX-DEF Active Hex Defense`. It is current, strategically coherent and conceptually scoreable, but a numerical score after roughly one live day of the new Thrill/Dominance/Shattered Hope ecology would manufacture precision. fileciteturn0file1

**GENERAL MATCHMAKING NOT APPLICABLE:** the four Parent Families; all 29 Strategic Modules; all seven current Mechanic-Centered Builds, including the K2-discovered Waterlogged-Shoe support variant; and all 14 Tactics. The exact IDs and reasons appear in the disposition/support tables and K3A ledger.

**GENERAL MATCHMAKING NOT CURRENT:** `K1-LEG-KO`, `K1-LEG-3G`, `K2-LEG-DEER`, `K2-LEG-FACECAMP`, `K2-LEG-THRILL`, `K2-LEG-TOMB`.

**KILLER_VS_COORDINATED_SWF**

| Strategy | Class | Scope | Status | Ranking status | Power | Tier | Stability | Index | Confidence | Trend | K2 explanation |
|---|---|---|---|---|---:|---|---:|---:|---|---|---|
| Rapid Rotation Pressure | META | POWER_FAMILY | ESTABLISHED | RANKED | **82** | **A** | 97 | 85.0 | MEDIUM_HIGH | STABLE | Communication does not remove the Killer's ability to compress travel and contest multiple lanes. |
| Infection / Fountain Economy | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **79** | **A** | 92 | 81.6 | MEDIUM | Coordinated cleanse policy improves Survivor control, but every policy still has a meaningful Plague-side tradeoff. |
| Committed Elimination Focus | META | BROAD_ROSTER | ESTABLISHED | RANKED | **77** | **B** | 97 | 81.0 | MEDIUM | Bodyblocks, protection calls and Shoulder the Burden reduce reliability without removing elimination value. |
| Chain-Down Pressure | META | POWER_FAMILY | ESTABLISHED | RANKED | **77** | **B** | 91 | 79.8 | MEDIUM | Voice comms greatly improve recovery/pickup spacing, but compatible Powers can still punish clustered mistakes. |
| Active Regression Conversion | META | BROAD_ROSTER | ESTABLISHED | RANKED | **76** | **B** | 89 | 78.6 | MEDIUM | Coordinated splitting and pre-running lower conversion, but regression remains a direct and largely information-independent control tool. |
| Torment / Cage Sequencing | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **76** | **B** | 88 | 78.4 | MEDIUM | One of the most coordination-resilient niche plans: communication does not erase Torment or the Cage-vs-hook choice. |
| Hook-to-Generator Conversion | META SUBTYPE | BROAD_ROSTER | ESTABLISHED | **PROVISIONAL** | **75** | **B** | 85 | 77.0 | LOW_MEDIUM | Good conversion remains, but coordinated teams are better at leaving, splitting and deliberately selecting which repairer yields pressure. |
| Lament Configuration / Chain-Hunt Control | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **72** | **B** | 85 | 74.6 | MEDIUM | Dedicated solver roles and box callouts materially reduce public-match error value. |
| Hook + Objective Anchor Control | META SUBTYPE | BROAD_ROSTER | ESTABLISHED | RANKED | **71** | **B** | 85 | 73.8 | LOW_MEDIUM | SWF can deliberately split rescue and repair responsibilities, but dual-anchor geometry still creates real pressure. |
| Heresy / Exile / Zealous Sequencing | NICHE STRATEGY | KILLER_SPECIFIC | EMERGING | **PROVISIONAL** | **71** | **B** | 62 | 69.2 | LOW | Coordinated Shrine/Exile management lowers payoff and evidence remains immature. |
| Network Surveillance / Teleport Control | META SUBTYPE | POWER_FAMILY | ESTABLISHED | RANKED | **70** | **B** | 85 | 73.0 | MEDIUM | Coordinated disablement and node callouts reduce network information value. |
| Proxy Hook-Zone Control | META | BROAD_ROSTER | ESTABLISHED | RANKED | **69** | **B** | 91 | 73.4 | MEDIUM | Rescue teams can coordinate bait, timing and bodyblocks, but must still spend players/time on the rescue. |
| Hit-and-Run Injury Attrition | META | POWER_FAMILY | ESTABLISHED | RANKED | **67** | **B** | 85 | 70.6 | MEDIUM | Coordinated reset calls and healing allocation attack the strategy's central unresolved-injury assumption. |
| Setup-Zone Lockdown | META SUBTYPE | POWER_FAMILY | ESTABLISHED | RANKED | **66** | **B** | 87 | 70.2 | MEDIUM | Comms improve disarm/avoidance and let Survivors deliberately work outside prepared territory. |
| Deliberate Endgame Conversion | NICHE STRATEGY | BROAD_ROSTER | ESTABLISHED | RANKED | **65** | **C** | 87 | 69.4 | LOW_MEDIUM | Coordinated gate splitting and pre-positioning reduce late conversion reliability. |
| Generator-Cluster Defense | NICHE STRATEGY | BROAD_ROSTER | ESTABLISHED | RANKED | **65** | **C** | 82 | 68.4 | MEDIUM | Coordinated teams attack separate generators and deliberately consume the cluster's finite regression budget. |
| Condemn Pressure | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **65** | **C** | 79 | 67.8 | LOW_MEDIUM | Tape ownership and high-Condemned target state are much easier to communicate. |
| Basement / Fixed-Anchor Control | NICHE STRATEGY | BROAD_ROSTER | ESTABLISHED | RANKED | **63** | **C** | 84 | 67.2 | LOW_MEDIUM | Coordinated teams better avoid bad chase zones and execute transport denial/rescues. |
| Stalk-to-Expose Ambush | META SUBTYPE | POWER_FAMILY | ESTABLISHED | RANKED | **62** | **C** | 87 | 67.0 | MEDIUM | Stalk progress/location callouts directly undermine surprise conversion. |
| Reverse-Bear-Trap Objective Tax | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **62** | **C** | 83 | 66.2 | LOW_MEDIUM | Side-objective time remains real, but role assignment and generator-timing calls reduce wasted movement. |
| Ambush Rotation | META | POWER_FAMILY | ESTABLISHED | RANKED | **60** | **C** | 85 | 65.0 | MEDIUM | Four-player Killer-location callouts directly attack information asymmetry. |
| Sustained Down-State Control | NICHE STRATEGY | POWER_FAMILY | ESTABLISHED | **PROVISIONAL** | **52** | **C** | 68 | 55.2 | LOW | Rapid recovery coordination, pickup calls and spread positioning sharply reduce sustained control. |
| Scratched-Mirror Ambush | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | RANKED | **49** | **D** | 50 | 49.2 | LOW_MEDIUM | Low movement and extreme geometry dependence become much harder to hide from a coordinated team. |

**COORDINATED SWF UNRANKED:** `K1-HEX-DEF Active Hex Defense`.

**COORDINATED SWF NOT APPLICABLE:** the same 54 current supporting objects as in General Matchmaking.

**COORDINATED SWF NOT CURRENT:** the six Legacy objects.

**Environment difference analysis**

No Strategy receives a higher overall K2 Power score against coordinated SWF. That does **not** mean coordination never creates exploitable Survivor behavior; rather, any extra predictability from coordinated rescue/cleanse/grouping is outweighed by the information, role allocation and denial benefits that communication provides.

| Pattern | Strategies most affected | Why |
|---|---|---|
| **Largest information-asymmetry loss** | Stalk-to-Expose **77→62**; Ambush Rotation **74→60**; Scratched Mirror **62→49** | Continuous Killer-location and target-state callouts attack the exact uncertainty these plans monetize. |
| **Target-state confusion loss** | Condemn **78→65**; Pig RBT **73→62**; Cenobite **82→72** | Tape, trap, box and high-risk target responsibilities become assignable rather than ad hoc. |
| **Recovery-coordination loss** | Sustained Down-State **65→52**; Chain-Down **85→77** | SWF can call safe pickups, recovery progress, Killer direction and which Survivor must remain standing. |
| **Healing-policy loss** | Hit-and-Run **76→67** | Coordinated teams can explicitly schedule heals and communicate which injuries are safe to leave unresolved. |
| **Rescue-policy loss** | Proxy **76→69**; Hook Anchor **78→71**; Basement **71→63** | Rescue timing, bodyblocks and generator/rescue role splits are coordinated. |
| **Hook-state-management loss** | Committed Elimination **83→77** | Shoulder the Burden is much easier to deploy deliberately when hook states and roles are continuously shared. The live perk permits each eligible user one transfer rather than a single team-wide use. fileciteturn0file1 |
| **Side-objective role loss** | Cenobite, Pig, Onryō | One player can be designated as solver/tape carrier while others maintain repair pressure. |
| **Coordination-resilient** | Executioner Cage **77→76**; Rapid Rotation **85→82**; Active Regression **79→76**; Plague **84→79** | Their core value is less dependent on Survivor ignorance: travel compression, direct progress loss, alternate sacrifice routing, and the infection/fountain dilemma survive communication. |
| **Can exploit predictable coordinated behavior** | Chain-Down, Plague, Proxy/Hook Anchor | SWFs still must physically group for some rescues, heals and pickups. A compatible Killer can punish those predictable convergence points, partially offsetting the broader coordination advantage. |
| **Survivor Intent effect in public queue** | Mostly Ambush, rescue, target-state and side-objective strategies | Intent should narrow some public information gaps, but predefined optional messages are not voice comms; with only one clean day, K2 does not invent a numerical “Intent adjustment.” fileciteturn0file1 |

## Stability, analytical profiles, and compatibility

**Meta Stability**

| Strategy | Structural Independence /25 | Core Durability /20 | Replacement Depth /15 | Environmental Breadth /15 | Counter-Meta Independence /10 | Patch Durability /15 | Total | Label | K2 interpretation |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|
| Active Regression Conversion | 23 | 18 | 14 | 13 | 8 | 13 | **89** | VERY STABLE | Regression is fundamental and has many replacements; caps constrain implementation, not identity. |
| Hook-to-Generator Conversion | 22 | 18 | 13 | 12 | 8 | 12 | **85** | VERY STABLE | Structural hook→objective conversion survives individual perk changes. |
| Generator-Cluster Defense | 22 | 18 | 12 | 10 | 8 | 12 | **82** | STABLE | Durable identity, but layout and anti-three-gen rules narrow environmental breadth. |
| Committed Elimination Focus | 25 | 20 | 15 | 13 | 9 | 15 | **97** | VERY STABLE | Fundamentally tied to asymmetric elimination structure rather than one perk. |
| Proxy Hook-Zone Control | 24 | 19 | 14 | 12 | 8 | 14 | **91** | VERY STABLE | Rescue interception remains durable even as close-camp rules change. |
| Hook + Objective Anchor | 23 | 18 | 13 | 10 | 8 | 13 | **85** | VERY STABLE | Durable dual-pressure idea, more geometry-dependent. |
| Basement / Fixed Anchor | 23 | 19 | 13 | 8 | 8 | 13 | **84** | STABLE | Basement/fixed-anchor structure is durable but map/hook placement is restrictive. |
| Chain-Down Pressure | 24 | 19 | 14 | 12 | 8 | 14 | **91** | VERY STABLE | Fundamental multi-down conversion on appropriate Powers. |
| Sustained Down-State Control | 18 | 16 | 10 | 8 | 6 | 10 | **68** | WATCH | Identity survives; old concealment support did not. |
| Hit-and-Run Injury Attrition | 23 | 18 | 13 | 11 | 7 | 13 | **85** | VERY STABLE | Core injury/recontact loop is Power-structural. |
| Ambush Rotation | 23 | 18 | 13 | 11 | 7 | 13 | **85** | VERY STABLE | Stealth/approach loop is durable, although comms and sightlines modulate value. |
| Setup-Zone Lockdown | 24 | 19 | 13 | 9 | 8 | 14 | **87** | VERY STABLE | Native deployable setup is highly durable; maps limit breadth. |
| Network Surveillance / Teleport | 23 | 18 | 12 | 11 | 8 | 13 | **85** | VERY STABLE | Multiple Powers instantiate the same node-network logic. |
| Rapid Rotation Pressure | 25 | 20 | 14 | 14 | 9 | 15 | **97** | VERY STABLE | Mobility-to-pressure conversion is among the most structurally durable Killer plans. |
| Active Hex Defense | 10 | 11 | 6 | 7 | 4 | 6 | **44** | VOLATILE | Current identity leans heavily on the just-reworked 10.2 Totem ecosystem. |
| Deliberate Endgame Conversion | 23 | 19 | 13 | 10 | 8 | 14 | **87** | VERY STABLE | Powered-gate planning is structural and has many implementation replacements. |
| Stalk-to-Expose Ambush | 24 | 19 | 13 | 10 | 7 | 14 | **87** | VERY STABLE | Native stalk/expose mechanic is durable; environmental breadth is narrower. |
| Cenobite Chain-Hunt Control | 23 | 18 | 12 | 11 | 8 | 13 | **85** | VERY STABLE | Box/Chain-Hunt loop is native and structurally distinct. |
| Pig RBT Objective Tax | 23 | 18 | 12 | 10 | 7 | 13 | **83** | STABLE | Native trap economy is durable but coordination-sensitive. |
| Onryō Condemn Pressure | 22 | 17 | 11 | 10 | 7 | 12 | **79** | STABLE | Native identity is stable now, though historical reworks reduce patch-durability confidence. |
| Plague Infection / Fountain Economy | 24 | 20 | 13 | 12 | 9 | 14 | **92** | VERY STABLE | One of the strongest structural identities in the catalog. |
| Executioner Torment / Cage | 24 | 19 | 12 | 11 | 8 | 14 | **88** | VERY STABLE | Alternate sacrifice routing is native and perk-independent. |
| Judgment Heresy / Exile | 16 | 14 | 8 | 10 | 6 | 8 | **62** | WATCH | Genuine identity, but very recent and already hotfixed. |
| Scratched-Mirror Ambush | 9 | 18 | 3 | 5 | 6 | 9 | **50** | WATCH | Stable gameplay concept while the add-on exists, but structurally dependent on one add-on and favorable geometry. |

Scratched Mirror remains live and still reveals Survivor auras within 32 m while Stalking and prevents normal progression out of its Stalker state; that is enough transformation to justify a separate Strategy despite its mediocre current Power. citeturn20search4

**Analytical profiles**

Abbreviations: `SF` Skill Floor, `SC` Skill Ceiling, `OC` Opportunity Cost, `MD` Map Dependence, `WC` Win Condition Contribution, `AR` Activation Reliability, `AP` Activation Payoff, `DR` Denial Risk, `CM` Strategic Commitment.

| Strategy | SF | SC | OC | MD | WC | AR | AP | DR | CM | Material dependencies | Major map factors | Major counters | Major synergies |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|
| Active Regression | 2 | 4 | 3 | 2 | 5 | 4 | 4 | 2 | 3 | GAME_STATE, POSITIONING, TIMING | gen spacing, size, verticality | split repair, pre-run, regression caps | mobility, info, hook conversion |
| Hook-to-Gen | 3 | 4 | 3 | 2 | 5 | 4 | 4 | 2 | 4 | GAME_STATE, POSITIONING, TIMING | hook↔gen spacing, traversal | pre-leave, split repair | mobility, Scourge routing, info |
| Cluster Defense | 3 | 5 | 4 | 5 | 4 | 3 | 4 | 3 | 5 | MAP, RNG, GAME_STATE, POSITIONING | clustering, size, tiles | break cluster early, split, regression cap | setup, anchors, mobility |
| Committed Elimination | 2 | 5 | 4 | 2 | 5 | 4 | 5 | 3 | 5 | TARGET_STATE, GAME_STATE, POSITIONING, TIMING | hooks, tile safety, size | Shoulder the Burden, bodyblocks, protection, hiding | chase conversion, mobility, rescue info |
| Proxy Hook | 2 | 4 | 3 | 3 | 4 | 4 | 4 | 3 | 4 | POSITIONING, TIMING, TARGET_STATE, MAP | hook lanes, LOS, nearby gens | coordinated rescue, split gens, Resolve pressure | range, mobility, territory |
| Hook + Objective Anchor | 3 | 5 | 4 | 4 | 5 | 3 | 5 | 3 | 5 | MAP, RNG, POSITIONING, GAME_STATE | hook-gen proximity, approach lanes | work elsewhere, stagger rescue, deny destination | setup, Scourge, carry |
| Basement Anchor | 3 | 4 | 5 | 5 | 4 | 2 | 5 | 4 | 5 | MAP, RNG, POSITIONING, GAME_STATE | basement location, access, nearby objective | avoid area, bodyblock/sabotage transport, coordinated rescue | carry, traps, high rescue threat |
| Chain-Down | 4 | 5 | 4 | 3 | 5 | 4 | 5 | 3 | 4 | KILLER_POWER, POSITIONING, TARGET_STATE, TIMING | Survivor spacing, LOS, travel | spread, rapid pickups, recovery, deny next-target info | mobility, info, multi-down Power |
| Sustained Down-State | 3 | 4 | 5 | 3 | 4 | 3 | 4 | 4 | 5 | KILLER_POWER, SURVIVOR_COMPOSITION, TARGET_STATE, POSITIONING | size, recovery routes | coordinated pickups, recovery perks, spread | re-down, mobility, info |
| Hit-and-Run | 3 | 5 | 4 | 3 | 4 | 4 | 4 | 4 | 4 | KILLER_POWER, OPPONENT_BEHAVIOR, TARGET_STATE, TIMING | size, healing cover, travel lanes | efficient heals, comms, pre-run | stealth, mobility, healing suppression |
| Ambush Rotation | 3 | 5 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | KILLER_POWER, MAP, OPPONENT_BEHAVIOR, POSITIONING | LOS, indoor/outdoor, cover | callouts, pre-run, open maps | stealth, mobility, info denial |
| Setup-Zone | 4 | 5 | 5 | 5 | 4 | 3 | 5 | 3 | 5 | KILLER_POWER, MAP, RESOURCE_AVAILABILITY, TIMING | geometry, chokepoints, setup space | disarm/avoid, split map, rush early gens | anchors, clusters, info |
| Network Control | 4 | 5 | 4 | 4 | 4 | 4 | 5 | 3 | 5 | KILLER_POWER, MAP, RESOURCE_AVAILABILITY, POSITIONING | node LOS, size, verticality | disable/EMP/seal/dispel, force rebuilds | rotation, info, generator control |
| Rapid Rotation | 4 | 5 | 2 | 2 | 5 | 5 | 4 | 2 | 4 | KILLER_POWER, POSITIONING, GAME_STATE, TIMING | size, traversal, verticality | spread, pre-run, hide, recharge windows | info, hook→gen, regression |
| Active Hex Defense | 3 | 5 | 5 | 5 | 4 | 3 | 5 | 5 | 5 | MAP, RNG, RESOURCE_AVAILABILITY, TIMING | Totem placement, size, LOS | early cleanse windows, split Totem pressure | mobility, Totem info, hook tempo |
| Endgame Conversion | 2 | 4 | 5 | 4 | 4 | 4 | 5 | 3 | 5 | GAME_STATE, MAP, RESOURCE_AVAILABILITY, TIMING | gate spacing/sightlines, hooks | split gates, pre-position, coordinated rescue | gate mobility, saved resources |
| Stalk-to-Expose | 4 | 5 | 4 | 5 | 4 | 3 | 5 | 4 | 4 | KILLER_POWER, MAP, OPPONENT_BEHAVIOR, POSITIONING | LOS, cover, openness | deny stalk, callouts, pre-run | Ambush Rotation, target tracking |
| Cenobite Box Control | 4 | 5 | 3 | 3 | 5 | 4 | 5 | 3 | 5 | KILLER_POWER, OPPONENT_BEHAVIOR, TIMING, POSITIONING | box search geometry, size | dedicated solver, solve timing, callouts | info, interception, gen pressure |
| Pig RBT Tax | 3 | 5 | 3 | 3 | 4 | 4 | 4 | 4 | 4 | KILLER_POWER, RESOURCE_AVAILABILITY, OPPONENT_BEHAVIOR, GAME_STATE | Box routes, size | generator timing, efficient searches, role assignment | gen pressure, info, Video Tape |
| Onryō Condemn | 4 | 5 | 4 | 3 | 5 | 3 | 5 | 4 | 5 | KILLER_POWER, TARGET_STATE, OPPONENT_BEHAVIOR, TIMING | TV distribution, size | tape assignments, TV management, Condemn calls | rotation, target focus |
| Plague Economy | 3 | 5 | 2 | 2 | 5 | 5 | 5 | 3 | 4 | KILLER_POWER, OPPONENT_BEHAVIOR, RESOURCE_AVAILABILITY, TIMING | fountain placement, LOS | coordinated cleanse policy/timing | info, gen pressure, chain-down |
| Executioner Cage | 4 | 5 | 3 | 3 | 4 | 3 | 4 | 3 | 4 | KILLER_POWER, TARGET_STATE, POSITIONING, TIMING | trail space, tile geometry | avoid Torment, force low-value ordinary routing | non-hook pressure, zoning |
| Judgment Exile | 4 | 5 | 3 | 3 | 4 | 3 | 5 | 3 | 4 | KILLER_POWER, TARGET_STATE, TIMING, POSITIONING | Shrine routes, size, attack geometry | Repent, coordinate liberation, avoid Heresy | Zealous conversion, target tracking |
| Scratched Mirror | 4 | 5 | 5 | 5 | 3 | 4 | 3 | 5 | 5 | ADD_ON, MAP, OPPONENT_BEHAVIOR, POSITIONING | indoor/outdoor, walls, size | open maps, comms, pre-run, distance | indoor geometry, ambush routing |

**Raw Power dimensions**

Each cell is `General Matchmaking / Coordinated SWF`. `Cns` Consistency; `Ceil` Ceiling; `Ag` Agency; `PI` Power Integration; `MU` Matchup Coverage; `Map` Map Coverage; `Tmp` Tempo Efficiency; `Slot` Slot Efficiency; `Rec` Recovery; `Snow` Snowball; `CR` Counterplay Resilience; `Exec` Execution Reliability.

| Strategy | Cns | Ceil | Ag | PI | MU | Map | Tmp | Slot | Rec | Snow | CR | Exec |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Active Regression | 8.5/8 | 8/8 | 8.5/8.5 | 7.5/7.5 | 8/7.5 | 7.5/7.5 | 8.5/8 | 7/7 | 7.5/7 | 6.5/6.5 | 7.5/7 | 8/8 |
| Hook-to-Gen | 8/7.5 | 8.5/8 | 8/8 | 8/8 | 8/7 | 7.5/7.5 | 8.5/8 | 7/7 | 7/6.5 | 8/7.5 | 7.5/6.5 | 8/7.5 |
| Cluster Defense | 7/6 | 8/7.5 | 7.5/7 | 8/8 | 7/5.5 | 5.5/5 | 7/6.5 | 8/8 | 8/7.5 | 7/6.5 | 6.5/5 | 7/6.5 |
| Committed Elimination | 8.5/7.5 | 9/8.5 | 8.5/8 | 8/8 | 8/6.5 | 8/8 | 9/8.5 | 9/9 | 7.5/7 | 8/7.5 | 7.5/6 | 8/7.5 |
| Proxy Hook | 7.5/6.5 | 8/7.5 | 7.5/7 | 7.5/7.5 | 7.5/6 | 7/6.5 | 8/7.5 | 9/9 | 7/6.5 | 8/7 | 6.5/5.5 | 7.5/7 |
| Hook Anchor | 7.5/6.5 | 8.5/8 | 7.5/7 | 8.5/8.5 | 8/6.5 | 6/5.5 | 8.5/7.5 | 8.5/8.5 | 8/7.5 | 8.5/7.5 | 7.5/6 | 7/6.5 |
| Basement Anchor | 6.5/5.5 | 9/8.5 | 6.5/6 | 8/8 | 7.5/6 | 5/4.5 | 7/6 | 7/7 | 7/6 | 9/8 | 7/5.5 | 6.5/6 |
| Chain-Down | 8/7 | 9.5/9 | 8.5/8 | 9/9 | 8/6.5 | 7.5/7 | 9/8 | 9/9 | 8.5/7.5 | 10/9 | 7.5/6 | 7.5/7 |
| Sustained Down-State | 5.5/3.5 | 8/7 | 6/4.5 | 7.5/7.5 | 5.5/3.5 | 6/5.5 | 6/4.5 | 9/9 | 6.5/4.5 | 9/7.5 | 5.5/3.5 | 6/5 |
| Hit-and-Run | 7/5.5 | 8/7.5 | 8/7.5 | 9/9 | 7/5.5 | 7.5/7 | 8/6.5 | 8.5/8.5 | 7.5/6.5 | 7/6.5 | 6.5/4.5 | 8/7.5 |
| Ambush Rotation | 7/5 | 8/7 | 7.5/6.5 | 9/9 | 7/4.5 | 7/6 | 8/6 | 8.5/8.5 | 6.5/5.5 | 7/6 | 6/3.5 | 7/6 |
| Setup-Zone | 7/6 | 8.5/8 | 7.5/7 | 9.5/9.5 | 7/5.5 | 5/4.5 | 7/6 | 8.5/8.5 | 7.5/6.5 | 8.5/7.5 | 7/5.5 | 6.5/6 |
| Network Control | 7.5/6.5 | 8.5/8 | 8/7.5 | 9.5/9.5 | 7.5/6 | 6.5/6 | 8/7 | 8.5/8.5 | 7.5/6.5 | 8.5/7.5 | 7/5.5 | 7/6.5 |
| Rapid Rotation | 8.5/8 | 9.5/8.5 | 8.5/8.5 | 9.5/9 | 8/7.5 | 8.5/8.5 | 9/9 | 9/9 | 8/7 | 8/7.5 | 7.5/7 | 8/8 |
| Active Hex Defense | — | — | — | — | — | — | — | — | — | — | — | — |
| Endgame Conversion | 6.5/5.5 | 8.5/8 | 8/7 | 7/7 | 7.5/6 | 6.5/6 | 6.5/5.5 | 7/7 | 9/8 | 9/8 | 7/5.5 | 7/6.5 |
| Stalk-to-Expose | 7/5 | 9/8 | 7.5/6.5 | 10/10 | 7/4.5 | 6.5/5.5 | 8/6 | 9.5/9.5 | 7/5.5 | 8/6.5 | 6.5/4 | 6.5/5.5 |
| Cenobite Box | 8/6.5 | 8.5/8 | 8/7.5 | 9.5/9.5 | 8/6 | 8/7.5 | 8.5/7 | 9.5/9.5 | 7.5/6 | 8.5/7.5 | 7.5/5.5 | 7/6.5 |
| Pig RBT | 6.5/5 | 7.5/7 | 7/6 | 9.5/9.5 | 7/5 | 8/7.5 | 6.5/5 | 9.5/9.5 | 6.5/5 | 7/5.5 | 6.5/4.5 | 7.5/7 |
| Onryō Condemn | 7/5 | 8.5/8 | 7.5/6.5 | 9.5/9.5 | 7.5/5 | 7.5/7 | 8/6 | 9.5/9.5 | 7.5/6 | 8/6.5 | 7/4.5 | 7/6.5 |
| Plague Economy | 8/7 | 9/8.5 | 8.5/8.5 | 9.5/9.5 | 8.5/7.5 | 8/8 | 8/7.5 | 9.5/9.5 | 8/7.5 | 8.5/8 | 8/6.5 | 8/7.5 |
| Executioner Cage | 7/7 | 8/8 | 7.5/7.5 | 9.5/9.5 | 7.5/7 | 7.5/7.5 | 7.5/7.5 | 9.5/9.5 | 7.5/7 | 7/7 | 7.5/7 | 7/7 |
| Judgment Exile | 7/6 | 8.5/8 | 8/7.5 | 9.5/9.5 | 7.5/6.5 | 7.5/7 | 8/7 | 9.5/9.5 | 7.5/6.5 | 8/7 | 7/5.5 | 6/5.5 |
| Scratched Mirror | 5.5/3.5 | 8.5/7.5 | 7/5.5 | 10/10 | 5.5/3 | 3/2.5 | 6/4.5 | 7/7 | 5/3.5 | 6.5/5 | 5.5/3.5 | 6/5 |

The null Hex row is intentional. Supplying twelve raw numbers and then claiming the Strategy is `UNRANKED` would be internally inconsistent.

**Confidence and prevalence**

Strategy-level prevalence is `UNKNOWN` for the 24 current Strategies. K1's perk statistics establish that slowdown, information and chase ecosystems are widely represented; they do **not** identify the strategy a player was actually executing. fileciteturn0file0

| Strategy | Mechanics | Prevalence | Power | General | Coordinated SWF | Compatibility |
|---|---|---|---|---|---|---|
| Active Regression | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | MEDIUM_HIGH |
| Hook-to-Gen | HIGH | LOW | MEDIUM | MEDIUM | LOW_MEDIUM | MEDIUM_HIGH |
| Cluster Defense | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | MEDIUM_HIGH |
| Committed Elimination | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | MEDIUM_HIGH |
| Proxy Hook | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | MEDIUM_HIGH |
| Hook Anchor | HIGH | LOW | MEDIUM | MEDIUM | LOW_MEDIUM | MEDIUM_HIGH |
| Basement Anchor | HIGH | LOW | MEDIUM | MEDIUM | LOW_MEDIUM | MEDIUM_HIGH |
| Chain-Down | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | HIGH |
| Sustained Down-State | HIGH | LOW | LOW_MEDIUM | LOW_MEDIUM | LOW | HIGH |
| Hit-and-Run | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | HIGH |
| Ambush Rotation | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | HIGH |
| Setup-Zone | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | HIGH |
| Network Control | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | HIGH |
| Rapid Rotation | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM_HIGH | HIGH |
| Active Hex Defense | HIGH | LOW | LOW | LOW | LOW | MEDIUM |
| Endgame Conversion | HIGH | LOW | MEDIUM | MEDIUM | LOW_MEDIUM | MEDIUM_HIGH |
| Stalk-to-Expose | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | HIGH |
| Cenobite Box | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | HIGH |
| Pig RBT | HIGH | LOW | MEDIUM | MEDIUM | LOW_MEDIUM | HIGH |
| Onryō Condemn | HIGH | LOW | MEDIUM | MEDIUM | LOW_MEDIUM | HIGH |
| Plague Economy | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | HIGH |
| Executioner Cage | HIGH | LOW | MEDIUM_HIGH | MEDIUM_HIGH | MEDIUM | HIGH |
| Judgment Exile | MEDIUM_HIGH | LOW | LOW_MEDIUM | LOW_MEDIUM | LOW | HIGH |
| Scratched Mirror | HIGH | LOW | MEDIUM | MEDIUM | LOW_MEDIUM | HIGH |

**Killer compatibility**

`BEST_FIT` here means strategically natural fit, not “strongest Killer overall.” Absence from a row means **not evaluated**.

| Strategy | Scope | BEST_FIT | STRONG_FIT | VIABLE | Important weak/incompatible examples | Boundary / confound control |
|---|---|---|---|---|---|---|
| Active Regression | BROAD_ROSTER | Wraith, Demogorgon | Dredge, Mastermind, Doctor | Nemesis, Clown, Legion | — | Scored around ordinary compatible Killers, not elite mobility outliers. |
| Hook-to-Gen | BROAD_ROSTER | Wraith, Dredge, Demogorgon | Xenomorph, Hillbilly, Mastermind | Doctor, Nemesis | — | Requires reliable post-hook reach to a chosen objective. |
| Cluster Defense | BROAD_ROSTER | Hag, Trapper, Singularity | Demogorgon, Knight, Doctor | Skull Merchant | Huntress WEAK_FIT | Fit derives from short territorial patrols, not roster tier. |
| Committed Elimination | BROAD_ROSTER | Mastermind, Spirit, Ghoul | Wraith, Demogorgon, Clown | Doctor, Nemesis, Pig | — | Broad strategy; fit is re-acquisition/chase conversion. |
| Proxy Hook | BROAD_ROSTER | Cannibal, Hag, Artist | Huntress, Deathslinger, Demogorgon | Doctor, Knight | — | Threat must reach rescue lanes without requiring stationary close proximity. |
| Hook Anchor | BROAD_ROSTER | Hag, Trapper, Singularity | Demogorgon, Doctor, Knight | Wraith | — | Best when one route can contest hook and objective. |
| Basement Anchor | BROAD_ROSTER | Trapper, Hag, Cannibal | Knight, Demogorgon, Huntress | Doctor | — | Requires transport feasibility and anchor geometry. |
| Chain-Down | POWER_FAMILY | Oni, Twins, Spirit | Hillbilly, Blight, Ghoul | Xenomorph, Wraith | Trapper WEAK_FIT | Family boundary: second target can be reached before pickup delay loses value. |
| Sustained Down-State | POWER_FAMILY | Twins, Oni | Nurse, Blight | Wraith, Ghoul | Trapper WEAK_FIT | Requires reliable re-down/recontact; old Knock Out concealment is excluded. |
| Hit-and-Run | POWER_FAMILY | Wraith, Legion, Onryō | Dredge, Ghost Face, Skull Merchant | Demogorgon, Good Guy | Cannibal WEAK_FIT | Cheap first hits plus economical recontact. |
| Ambush Rotation | POWER_FAMILY | Ghost Face, Wraith, Dredge | Onryō, Good Guy, Slasher, Xenomorph | Animatronic | Huntress WEAK_FIT | Native approach denial must repeatedly reduce warning. |
| Setup-Zone | POWER_FAMILY | Hag, Trapper | Skull Merchant | Singularity | Nurse WEAK_FIT | Pre-invest finite hazards/resources in a local region. |
| Network Control | POWER_FAMILY | Singularity, Demogorgon, Unknown | Xenomorph, Dredge, Animatronic | Onryō | — | Persistent nodes/stations create travel, information or disablement counterplay. |
| Rapid Rotation | POWER_FAMILY | Hillbilly, Dredge, Xenomorph, Blight | Wraith, Demogorgon, Onryō, Unknown | First, Ghoul, Spirit, Animatronic | Trapper WEAK_FIT | Mobility must alter commitment policy, not merely traversal. |
| Active Hex Defense | BROAD_ROSTER | Hag, Demogorgon, Wraith | Dredge, Singularity | Doctor | — | Killer must actually contest cleanse windows; Hex perks alone do not qualify. |
| Endgame Conversion | BROAD_ROSTER | Dredge, Wraith, Nightmare, Demogorgon | Trapper, Hag, Doctor | Clown, Pig | — | Fit rises with gate coverage/resource banking. |
| Stalk-to-Expose | POWER_FAMILY | Ghost Face | Shape | — | Other Killers INCOMPATIBLE | Only stalk/expose Powers belong to the family. |
| Cenobite Box | KILLER_SPECIFIC | Cenobite | — | — | All others INCOMPATIBLE | Lament Configuration/Chain Hunt required. |
| Pig RBT | KILLER_SPECIFIC | Pig | — | — | All others INCOMPATIBLE | Reverse Bear Traps/Jigsaw Boxes required. |
| Onryō Condemn | KILLER_SPECIFIC | Onryō | — | — | All others INCOMPATIBLE | TVs/tapes/Condemned required. |
| Plague Economy | KILLER_SPECIFIC | Plague | — | — | All others INCOMPATIBLE | Infection/fountains required. |
| Executioner Cage | KILLER_SPECIFIC | Executioner | — | — | All others INCOMPATIBLE | Torment/Cage required. |
| Judgment Exile | KILLER_SPECIFIC | Judgment | — | — | All others INCOMPATIBLE | Heresy/Exile/Zealous required. |
| Scratched Mirror | KILLER_SPECIFIC | Shape + Scratched Mirror | — | — | Shape without add-on; all others INCOMPATIBLE | Removing the add-on removes the strategic identity. |

## Add-on audit, implementations, parent families, and supporting objects

The targeted add-on audit used the **44-Killer live-playable roster** established in K1 and screened for effects that disable or replace a core Power function, front-load a side objective, materially alter teleport/setup rules, change target state, create a persistent alternate resource loop, or substantially change hook/down/objective policy. This was intentionally **not** a numerical catalog of every add-on. fileciteturn0file0

The audit found **no additional Strategy-level object** missing from K1. It did find one worthwhile new support-level candidate: **K2-ADD-HAG-SHOE No-Teleport Trap-Zone Hag**. Waterlogged Shoe raises Hag's movement speed to 4.73 m/s, applies a 9% Hindered effect within trap trigger range, and disables teleporting to triggered traps. That clearly changes recurring Power usage, but the objective remains Setup-Zone Lockdown; scoring it separately would double-count the same territorial strategy. citeturn20search2turn20search8

**Targeted add-on audit**

| Add-on / variant | Killer | Audit classification | Strategic judgment |
|---|---|---|---|
| **Scratched Mirror** | Shape | **STRATEGY DEFINER** | Permanent aura-led Stalker-mode hunting changes approach, map preference and chase economics enough to sustain K1-ADD-MIRROR. Current effect reveals nearby Survivor auras and prevents normal Stalker-state progression. citeturn20search4 |
| **Waterlogged Shoe** | Hag | **SUBTYPE ENABLER** | K2-new support object. Teleport is removed; speed/Hindered turn the trap web toward local movement denial. Same Setup-Zone objective, so no independent Power. citeturn20search2 |
| **Scarred Hand** | Hag | **SUBTYPE ENABLER** | Trap/Mud-Phantasm collision plus disabled teleport similarly transforms how the web converts territory, but not its strategic objective. citeturn20search8 |
| **Mint Rag** | Hag | IMPLEMENTATION DETAIL / SUBTYPE ENABLER | Teleport to untripped traps changes network reaction flexibility; still Setup-Zone. citeturn20search8 |
| **Trapper Sack** | Trapper | **SUBTYPE ENABLER** | All traps start in inventory, but placed traps cannot be picked back up; substantially changes setup timing and relocation commitment, not the objective. citeturn21search0 |
| **Video Tape** | Pig | **SUBTYPE ENABLER** | All Survivors start with RBTs, front-loading the same Objective-Tax strategy rather than creating another one. citeturn21search13 |
| **Matchbox** | Nurse | IMPLEMENTATION DETAIL | One Blink plus 4.4 m/s changes chase execution dramatically, but does not create an independent macro objective. citeturn21search3turn21search14 |
| **Obsidian Feather** | Judgment | IMPLEMENTATION DETAIL / MECHANIC BUILD | Very transformative Divine Light handling, but its transformation is projectile execution rather than target/hook/objective policy. fileciteturn0file1 |
| **Current Tombstone Piece** | Shape | **REJECTED FALSE POSITIVE** | No current direct-kill Strategy: the present add-on grants Undetectable after Evil Incarnate activates; direct-kill text belongs to its history. citeturn21search1 |
| **Current Judith's Tombstone** | Shape | **REJECTED FALSE POSITIVE** | Current form refreshes/caps Evil Incarnate duration through hooking; its historical direct-kill form is not live. citeturn21search9 |

The audit therefore leaves the K1 Strategy catalog **complete at Strategy level**. It expands the supporting implementation layer by one K2 candidate, exactly where K1 predicted the remaining coverage risk.

**Representative implementations**

An exact four-perk loadout is provided only where evidence supports one. Otherwise the entry is explicitly a framework.

| Strategy | Killer | Environment | Current implementation | Rationale | Strengths | Weaknesses | Confidence |
|---|---|---|---|---|---|---|---|
| Active Regression | Wraith example | General | **Observed mixed-window example:** Pop Goes the Weasel + Corrupt Intervention + Eruption + Pain Resonance; no mandatory add-on/offering | K1 recorded this as a tracked four-perk implementation since 10.1, not as clean 10.2 strategy telemetry. fileciteturn0file0 | Multiple objective-conversion triggers | Mixed-patch evidence; a loadout does not itself prove the Strategy | MEDIUM |
| Hook-to-Gen | Demogorgon | General | **Framework:** Dead Man's Switch + Pain Resonance **or** Undone; remaining slots flexible | DMS's live rework explicitly gives time to pressure the generator the Killer wants blocked. fileciteturn0file1 | Clear hook→travel→gen loop | 10.2 exact optimum unsettled | MEDIUM |
| Chain-Down | Oni | Both | **Framework:** native Fury window + optional information; no mandatory four-perk package | Continue to second target only when additional-down value exceeds pickup delay | Very high snowball | Recovery calls punish overextension | MEDIUM_HIGH |
| Setup-Zone | Hag | Both | Base teleporting trap web; Waterlogged Shoe kept as separate support variant | Build a compact high-value web and fight through invested territory | Prepared-zone conversion | Setup/relocation cost | HIGH |
| Network Control | Singularity | Both | Native Biopod network; perk package flexible | Seed useful sightlines, convert Slipstream/network reactions, rebuild around disablement | Info + traversal | Counter-network resource economy | HIGH |
| Pig RBT Tax | Pig | General | **Add-on variant:** Video Tape; perks flexible | Front-loads RBT side-objectives while preserving the same strategy | Immediate objective tax | Coordinated teams can assign roles | HIGH |
| Plague Economy | Plague | Both | Native infection/fountain framework; perks flexible | Optimize infection and Corrupt conversion around cleanse policy | Survivor cannot avoid making a policy choice | Coordinated cleanse timing lowers surprise | HIGH |
| Judgment Exile | Judgment | Both | **Framework:** selective Exile; no definitive four-perk package | Choose Exile when saved transport/hook-trigger bypass + Zealous exceeds alternate rescue downside | Unique sacrifice routing | Fresh hotfix ecosystem | LOW_MEDIUM |
| Scratched Mirror | Shape | General | **Mandatory add-on:** Scratched Mirror; no Realm offering assumed | Aura-led hidden routing becomes the core plan | Strong information in dense indoor geometry | Extreme open-map dependence | HIGH |

Map offerings are deliberately not treated as reliable build components because Realm influence is no longer deterministic. citeturn14search1

**Parent Family resolution**

| Parent Family | Definition | Current Strategy children | Shared counterplay | Cross-family relationships | Strongest General child | Strongest SWF child |
|---|---|---|---|---|---|---|
| Generator Control | Convert Killer time/actions/position into delayed, removed or redirected repair progress | Active Regression; Hook-to-Gen; Cluster Defense | split repairs, pre-run, avoid repeated high-value regression states | Territorial Control; Hook Anchor | Active Regression / Hook-to-Gen **79** | Active Regression **76** |
| Target Focus / Elimination Sequencing | Convert target identity/hook state into faster removal | Committed Elimination; Hook-State Prioritization remains Module | protection, hiding, hook-state redistribution, bodyblocks | Hook-Zone Pressure; Onryō target states | Committed Elimination **83** | Committed Elimination **77** |
| Hook-Zone / Rescue Pressure | Convert a hooked Survivor into secondary pressure on rescuers/objectives | Proxy Hook; Hook + Objective Anchor; Basement Anchor | rescue timing, bodyblocks, work elsewhere, Resolve constraints | Generator Control; Territorial | Hook Anchor **78** | Hook Anchor **71** |
| Territorial Control | Pre-invest in a region/network and convert Survivor interaction with it into pressure | Setup-Zone; Network Control; cross-parent Cluster/Hook Anchor | avoid/disarm/disable zone, split map, force relocation | Generator Control; Hook pressure; Rapid Rotation | Network Control **78** | Network Control **70** |

No Parent Family receives aggregate Power.

**Current Strategic Modules**

| Object | Supports | Why no independent Power | Promotion condition |
|---|---|---|---|
| Generator Blocking / Repair Denial | Regression, Hook-to-Gen, Cluster | No independent objective beyond creating downtime | Evidence of a distinct blocking-centered full-match decision loop |
| Repair-Speed Suppression | Generator/Attrition | Supplies time rather than defining its use | Distinct target/movement policy caused by suppression itself |
| Hook-State Prioritization | Committed Elimination | Usually rational state-aware target selection | Demonstrably independent target-switch loop beyond ordinary optimization |
| Healing Suppression | Hit-and-Run, injury strategies | Changes healing economics only | Independent target/movement/payoff cycle |
| Pallet / Resource Attrition | Chase/territory | Too close to universal chase resource management | Repeatable full-match consume-now/harvest-later policy with distinct counterplay |
| Chase Optimization Suite | nearly all | Universal efficiency layer | Unlikely without a more specific objective |
| Information Chaining | Rotation, Chain-Down, Ambush | Information is input, not win state | Independent routing plan with unique costs/counterplay shown |
| Gate Control | Endgame Conversion | Late-phase support only | Independent pre-endgame commitment loop |
| Oni Blood/Fury Timing | Chain-Down | Native resource execution | Separate macro objective beyond Chain-Down demonstrated |
| Twins Split-Body Sequencing | Chain-/Down-State | Native pickup/down implementation | Distinct strategic win loop independent of multi-down policy |
| Singularity Biopod Implementation | Network | Same network objective | Evidence of strategically separate network subtype worth independent score |
| Hag Trap-Web Implementation | Setup-Zone | Same setup objective | Separate strategy beyond setup territory |
| Trapper Trap-Zone Implementation | Setup-Zone | Same setup objective | Same |
| Skull Merchant Drone Module | Territorial/chase | Current drones serve zone/chase pressure; old three-gen identity invalid | New persistent macro loop under current Power |
| Demogorgon Portal Module | Network/Rotation | Portal mechanics implement broader loops | Separate objective appears |
| Unknown Hallucination Module | Network/Rotation | Node implementation | Separate objective appears |
| Xenomorph Tunnel Module | Rapid Rotation/Ambush | Fixed network primarily changes travel | Persistent distinct target/objective loop beyond rotation |
| Dredge Locker/Nightfall Module | Ambush/Rotation | Native implementation of both | Separate macro objective appears |
| Knight Guard Pincer | Territorial/chase | Predominantly local zoning/remote chase | Persistent map-level patrol objective shown |
| Artist Remote Probe | Information/chase | Supports routing/zoning | Probe itself becomes independent objective |
| Doctor Madness Disruption | info/skill-check/chase | Persistent native state but not independent macro plan | Distinct Madness-economy target loop demonstrated |
| Legion Injury Spread | Hit-and-Run | Native implementation | Strategy-level loop differing materially from Hit-and-Run |
| Animatronic Axe + Door Modules | Rapid Rotation/Ambush/injury | K1 combined two separable mechanics | One component proves independent macro plan |
| Slasher Omnipresent-Evil Module | Ambush | Native implementation | Distinct objective beyond ambush routing |
| Krasue Leech/Form Cycle | chase conversion | Native Power execution | Independent macro target-state economy demonstrated |
| First Worldbreaker/Upside-Down | Rotation/target pressure | Native state/travel execution | Persistent alternative strategic route demonstrated |
| Ghoul Mark/Enraged | Rotation/chase | Native Power optimization | Macro plan independent of Power use demonstrated |
| Houndmaster Search-to-Chase | Information/chase | Routing input | Independent macro routing objective demonstrated |
| Nightmare Projection Pressure | Rotation/Generator Control | Native teleport/objective implementation | Independent decision loop beyond broader families |

**Current Mechanic-Centered Builds**

| Object | Supports | Why no independent Power | Promotion condition |
|---|---|---|---|
| Compromised-Generator Framework | Generator Control, M1 tempo | 10.2 mechanics are fresh and perk-defined | Clean evidence of deliberate gen-completion manipulation as a match plan |
| Scourge-Hook Routing | Hook-to-Gen, Hook Anchor, info | Hook-location mechanic shared by several Strategies | Independent objective beyond effect delivery |
| Skill-Check / Interaction Pressure | Doctor, Generator Control | Package recognition exceeds strategic independence | Persistent macro plan beyond interaction difficulty |
| Carry / Hook-Transport Optimization | Basement, Hook Anchor, Scourge | Delivery mechanism | Destination policy becomes independent win loop |
| Basic-Attack Tempo Framework | chase/rotation | 10.2 M1 package does not determine macro objective | Stable full-match M1-specific strategic loop |
| Obsidian-Feather Judgment Variant | Judgment | Projectile-control transform only | Evidence it changes target/exile/map policy persistently |
| **K2-ADD-HAG-SHOE No-Teleport Trap-Zone Hag** | Setup-Zone | Major Power-use transformation, same strategic objective | Only promote if no-teleport Hag develops independent objective/counterplay beyond Setup-Zone |

**Tactics**

| Tactic | Common Strategies supported | Why no Power |
|---|---|---|
| Temporary Slug | Chain-/Down-State, Generator Control | Local pickup timing |
| Leave Chase | Rotation, Generator Control, Hit-and-Run | Universal tempo decision |
| Return to Hook | Hook pressure, Target Focus | One return is not a persistent strategy |
| Force Trade | Hook pressure | Local rescue conversion |
| Defend Critical Generator | Generator/Territorial | Local objective priority |
| Chase Death-Hook Survivor | Target Focus | Situational target choice |
| Delay Pickup | Down-State/Chain-Down | Temporary pickup timing |
| Zone Survivor | Chase/Territorial | Local positional denial |
| Bodyblock Escape Route | Chase/Ambush/Territorial | Local collision maneuver |
| Rescue Interception | Proxy/Hook Anchor | Local interception |
| Fake Objective Commitment | Generator/teleport strategies | Feint |
| Break-and-Leave | Resource attrition/chase | Local resource conversion |
| Hook-Destination Selection | Basement/Anchor/Scourge | Delivery decision |
| Target Switch on Contact | Target Focus/Hit-and-Run/Rotation | Local switching decision |

General principles—chase efficiency, map knowledge, generator-value recognition, resource awareness, adaptive target selection, pressure maintenance, and adapting to Survivor behavior—remain educational primitives rather than tier-list objects.

## Legacy boundaries and research debt

Current Resolve mechanics make historical close-hook play particularly prone to terminology drift: the live system monitors a 16 m anti-camp zone, proximity changes fill behavior, and the system deactivates once exit gates are powered. That does not make all hook pressure obsolete; it is exactly why K2 separates current Proxy Hook-Zone Control from historical static close-facecamp forms. citeturn14search0turn14search2

Likewise, the live anti-three-gen system gives each generator a finite qualifying regression-event budget, so “three-gen” can no longer be used as if it meant indefinite regression cycling. citeturn15search0

**Legacy catalog**

| Legacy object | Historical function / implementation | Why not current | Transition | Current successor / closest object | Terminology warning |
|---|---|---|---|---|---|
| K1-LEG-KO Knock Out Slug-Concealment Shell | Conceal/inhibit recovery information around downed Survivors to sustain down-state pressure | 10.2 Knock Out is now a pallet/Hindered perk | Patch 10.2.0 rework fileciteturn0file1 | Sustained Down-State / Chain-Down without old shell | “Knock Out slug build” now describes obsolete mechanics unless explicitly historical |
| K2-LEG-DEER Old Deerstalker Slug-Tracking Shell | Track downed Survivors to manage extended slug states | 10.2 Deerstalker now periodically creates mutual Killer/Survivor aura reading rather than its historical downed-survivor tracking role | Patch 10.2.0 fileciteturn0file1 | Generic Information Chaining | Old Deerstalker references are not live descriptions |
| K1-LEG-3G Indefinite Repeated-Kick Three-Gen | Recycle regression indefinitely on same cluster | Current regression-event limit prevents indefinite loop | Anti-three-gen system | Generator-Cluster Defense | “Three-gen” does not automatically mean the old infinite-kick implementation |
| K2-LEG-FACECAMP Pre-Resolve Close Facecamp | Remain immediately adjacent to hook to prevent/force rescue | Current Resolve anti-facecamp mechanics specifically impose escalating consequences on prolonged close proximity | Resolve system/current tuning citeturn14search0turn14search2 | Proxy Hook-Zone Control | “Camping” should not collapse proxy and obsolete close-facecamp forms |
| K2-LEG-THRILL Passive Thrill Totem Defense | Passive cleanse/bless slowdown from remaining Totems | 10.2 Thrill now ignites after first hook and blocks lit Hex Totems on hooks | Patch 10.2.0 fileciteturn0file1 | Active Hex Defense | Old “Thrill defense” guides are mechanically stale |
| K2-LEG-TOMB Historical Tombstone-Piece Direct-Kill Shape | Directly kill a healthy/injured Survivor during Evil Within III | Current Tombstone Piece instead grants Undetectable when Evil Incarnate activates; direct-kill text is historical. citeturn21search1 | Current Shape add-on redesign | Stalk-to-Expose Ambush/current Evil Incarnate implementations | “Tombstone Myers” is especially ambiguous because the historical direct-kill add-ons no longer match old guides |

**Provisional and unranked research debt**

| Object | Missing evidence | Mechanics confidence | Power confidence | General confidence | SWF confidence | Likely bias | Exact recheck condition |
|---|---|---|---|---|---|---|---|
| Hook-to-Generator Conversion | Clean 10.2 implementation distribution and optimized DMS/Undone/Monstrous Shrine sequencing | HIGH | MEDIUM | MEDIUM | LOW_MEDIUM | Current estimate may move a few points as optimal hook→gen package settles | Re-evaluate after a clean post-10.2 window large enough to isolate the reworked ecosystem from pre-10.2 matches |
| Sustained Down-State Control | Actual persistence after loss of old Knock Out concealment; recovery-counterplay frequency | HIGH | LOW_MEDIUM | LOW_MEDIUM | LOW | Most plausible bias is **upward** if old slugging habits contaminate community discussion | Recheck when post-10.2 data can separate intentional sustained control from temporary/chain-down slugs |
| Judgment Heresy / Exile | Mature Exile-vs-hook criteria, optimized add-on/perk interaction, post-10.1.2a stability | MEDIUM_HIGH | LOW_MEDIUM | LOW_MEDIUM | LOW | Either direction; recent Killer optimization can rapidly move value | Recheck after a stable post-10.1.2a/10.2 window without another material Power hotfix |
| Active Hex Defense | Stable builds, cleanse behavior, Totem-defense payoff and whether new Thrill ecology persists | HIGH | LOW | LOW | LOW | Launch-week novelty could overstate prevalence/power; early counters could also understate mature implementation | Remain UNRANKED until a clean 10.2 evidence window and stable implementations exist |

The Judgment correction is particularly important: Patch 10.1.2 increased Zealous curvature to 0.8 seconds and added non-Zealous curvature, but **10.1.2a reversed both changes**, restoring 0.6 seconds while Zealous and eliminating the non-Zealous curve. K2 uses the latter state. citeturn20search0turn20search3

No post-October 7 performance/prevalence evidence is incorporated into those placements. Later-accessed reference pages are used only to corroborate mechanics/add-on descriptions already in force by the cutoff, not to import later match outcomes.

## K3A handoff ledger and final researcher audit

The full machine-readable K3A ledger contains **84 records**: all 79 K1 Candidate IDs, the K2-discovered Waterlogged-Shoe support candidate, and four explicitly materialized Legacy objects that K1 had carried as research flags rather than Candidate IDs. Every record contains the requested fields, including environment evaluations, raw Power dimensions, Stability components, diagnostics, descriptive fields, dependencies, prevalence, multidimensional confidence, compatibility, perk/add-on ecosystem, counters, synergies, implementation notes, research flags and recheck conditions.

[Download the full K3A JSON handoff ledger](sandbox:/mnt/data/dbd_killer_meta_stage_k2_handoff.json)

[Download the K2 audit workbook with dispositions, both rankings, Stability, analytical profiles, raw Power dimensions, and compatibility](sandbox:/mnt/data/dbd_killer_meta_stage_k2_tables.xlsx)

The final audit passes the requested methodological checks: all 79 K1 IDs have a disposition; no second broad-discovery stage was performed; the add-on audit did not manufacture a new Strategy; character strength and applicability breadth are excluded from Power; Parent Families, Modules, Mechanic Builds and Tactics receive no aggregate Power; General Matchmaking and Coordinated SWF were scored independently; competitive restrictions were kept secondary; weights remained fixed; Power is not a kill-rate proxy; Stability is separate from Confidence; prevalence is not inferred from perk prevalence; D is distinct from Legacy; descriptive skill/map fields and raw dimensions are populated; current mechanics are separated from historical terminology; and 10.1.2a—not stale 10.1.2 Judgment values—is canonical. fileciteturn0file0 fileciteturn0file1 citeturn20search0

The compact ledger index below ends the research report. `GM` and `SWF` are `status:Power/Tier`; null scores are shown as `—`.

| Candidate ID | Canonical K2 object | Structural class | Scope | Current status | Parent | GM | SWF | Stability |
|---|---|---|---|---|---|---|---|---:|
| K1-GEN-FAM | Generator Control | PARENT STRATEGY FAMILY | BROAD_ROSTER | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-GEN-REG | Active Regression Conversion | META | BROAD_ROSTER | ESTABLISHED | K1-GEN-FAM | RANKED:79/A | RANKED:76/B | 89 |
| K1-GEN-HOOK | Hook-to-Generator Conversion | META SUBTYPE | BROAD_ROSTER | ESTABLISHED | K1-GEN-FAM | PROVISIONAL:79/A | PROVISIONAL:75/B | 85 |
| K1-GEN-BLOCK | Generator Blocking / Repair Denial | STRATEGIC MODULE | BROAD_ROSTER | ESTABLISHED | K1-GEN-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-GEN-3G | Generator-Cluster Defense | NICHE STRATEGY | BROAD_ROSTER | ESTABLISHED | K1-GEN-FAM | RANKED:72/B | RANKED:65/C | 82 |
| K1-GEN-DEBUFF | Repair-Speed Suppression | STRATEGIC MODULE | BROAD_ROSTER | ESTABLISHED | K1-GEN-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-GEN-COMP | Compromised-Generator Payoff Framework | MECHANIC-CENTERED BUILD | BROAD_ROSTER | EMERGING | K1-GEN-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TGT-FAM | Target Focus / Elimination Sequencing | PARENT STRATEGY FAMILY | BROAD_ROSTER | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TGT-COM | Committed Elimination Focus | META | BROAD_ROSTER | ESTABLISHED | K1-TGT-FAM | RANKED:83/A | RANKED:77/B | 97 |
| K1-TGT-HOOK | Hook-State Prioritization | STRATEGIC MODULE | BROAD_ROSTER | ESTABLISHED | K1-TGT-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-HOOK-FAM | Hook-Zone / Rescue Pressure | PARENT STRATEGY FAMILY | BROAD_ROSTER | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-HOOK-PROXY | Proxy Hook-Zone Control | META | BROAD_ROSTER | ESTABLISHED | K1-HOOK-FAM | RANKED:76/B | RANKED:69/B | 91 |
| K1-HOOK-ANCHOR | Hook + Objective Anchor Control | META SUBTYPE | BROAD_ROSTER | ESTABLISHED | K1-HOOK-FAM | RANKED:78/A | RANKED:71/B | 85 |
| K1-HOOK-BSMT | Basement / Fixed-Anchor Control | NICHE STRATEGY | BROAD_ROSTER | ESTABLISHED | K1-HOOK-FAM | RANKED:71/B | RANKED:63/C | 84 |
| K1-DOWN-CHAIN | Chain-Down Pressure | META | POWER_FAMILY | ESTABLISHED | — | RANKED:85/A | RANKED:77/B | 91 |
| K1-DOWN-SUST | Sustained Down-State Control | NICHE STRATEGY | POWER_FAMILY | ESTABLISHED | — | PROVISIONAL:65/C | PROVISIONAL:52/C | 68 |
| K1-ATTR-HR | Hit-and-Run Injury Attrition | META | POWER_FAMILY | ESTABLISHED | — | RANKED:76/B | RANKED:67/B | 85 |
| K1-ATTR-AH | Healing Suppression | STRATEGIC MODULE | BROAD_ROSTER | ESTABLISHED | K1-ATTR-HR | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-CHASE-RES | Pallet / Resource Attrition | STRATEGIC MODULE | BROAD_ROSTER | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-CHASE-MOD | Chase Optimization Suite | STRATEGIC MODULE | BROAD_ROSTER | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-INFO-CHAIN | Information Chaining | STRATEGIC MODULE | BROAD_ROSTER | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-AMBUSH | Ambush Rotation | META | POWER_FAMILY | ESTABLISHED | — | RANKED:74/B | RANKED:60/C | 85 |
| K1-TERR-FAM | Territorial Control | PARENT STRATEGY FAMILY | POWER_FAMILY | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TERR-SETUP | Setup-Zone Lockdown | META SUBTYPE | POWER_FAMILY | ESTABLISHED | K1-TERR-FAM | RANKED:74/B | RANKED:66/B | 87 |
| K1-TERR-NET | Network Surveillance / Teleport Control | META SUBTYPE | POWER_FAMILY | ESTABLISHED | K1-TERR-FAM | RANKED:78/A | RANKED:70/B | 85 |
| K1-MOB-ROT | Rapid Rotation Pressure | META | POWER_FAMILY | ESTABLISHED | — | RANKED:85/A | RANKED:82/A | 97 |
| K1-HEX-DEF | Active Hex Defense | NICHE STRATEGY | BROAD_ROSTER | EMERGING | — | UNRANKED:— | UNRANKED:— | 44 |
| K1-END-CONV | Deliberate Endgame Conversion | NICHE STRATEGY | BROAD_ROSTER | ESTABLISHED | — | RANKED:74/B | RANKED:65/C | 87 |
| K1-END-GATE | Gate Control | STRATEGIC MODULE | BROAD_ROSTER | ESTABLISHED | K1-END-CONV | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-SCOURGE | Scourge-Hook Routing | MECHANIC-CENTERED BUILD | BROAD_ROSTER | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-SKILL | Skill-Check / Interaction Pressure | MECHANIC-CENTERED BUILD | BROAD_ROSTER | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-CARRY | Carry / Hook-Transport Optimization | MECHANIC-CENTERED BUILD | BROAD_ROSTER | ESTABLISHED | K1-HOOK-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-M1 | Basic-Attack Tempo Framework | MECHANIC-CENTERED BUILD | BROAD_ROSTER | EMERGING | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-LEG-KO | Knock Out Slug-Concealment Shell | MECHANIC-CENTERED BUILD | BROAD_ROSTER | LEGACY | — | NOT_CURRENT:— | NOT_CURRENT:— | — |
| K1-LEG-3G | Indefinite Repeated-Kick Three-Gen | META SUBTYPE | BROAD_ROSTER | LEGACY | K1-GEN-FAM | NOT_CURRENT:— | NOT_CURRENT:— | — |
| K1-PF-STALK | Stalk-to-Expose Ambush | META SUBTYPE | POWER_FAMILY | ESTABLISHED | K1-AMBUSH | RANKED:77/B | RANKED:62/C | 87 |
| K1-KS-CENO | Lament Configuration / Chain-Hunt Control | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | — | RANKED:82/A | RANKED:72/B | 85 |
| K1-KS-PIG | Reverse-Bear-Trap Objective Tax | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | — | RANKED:73/B | RANKED:62/C | 83 |
| K1-KS-ONRYO | Condemn Pressure | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | — | RANKED:78/A | RANKED:65/C | 79 |
| K1-KS-PLAGUE | Infection / Fountain Economy | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | — | RANKED:84/A | RANKED:79/A | 92 |
| K1-KS-ONI | Blood Economy / Fury Timing | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-DOWN-CHAIN | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-TWINS | Split-Body Chain Sequencing | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-DOWN-CHAIN | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-SING | Biopod Network Implementation | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-TERR-NET | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-HAG | Trap-Web Implementation | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-TERR-SETUP | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-TRAP | Bear-Trap Zone Implementation | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-TERR-SETUP | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-SKULL | Drone Surveillance / Chase-Zone Module | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-TERR-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-DEMO | Portal Network Implementation | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-TERR-NET | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-UNKNOWN | Hallucination Network Implementation | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-TERR-NET | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-XENO | Tunnel Rotation Implementation | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-MOB-ROT | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-DREDGE | Locker / Nightfall Rotation Module | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-AMBUSH | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-KNIGHT | Guard Pincer / Remote Patrol | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-TERR-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-ARTIST | Crow Zoning / Remote Probe | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-INFO-CHAIN | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-DOCTOR | Madness / Interaction Disruption | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-SKILL | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-LEGION | Feral-Frenzy Injury-Spread Module | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-ATTR-HR | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-EXEC | Torment / Cage Sequencing | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | — | RANKED:77/B | RANKED:76/B | 88 |
| K1-KS-JUDGE | Heresy / Exile / Zealous Sequencing | NICHE STRATEGY | KILLER_SPECIFIC | EMERGING | — | PROVISIONAL:78/A | PROVISIONAL:71/B | 62 |
| K1-KS-ANIM | Axe-Impale + Security-Door Modules | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-MOB-ROT | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-SLASH | Omnipresent-Evil Ambush Module | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-AMBUSH | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-KRASUE | Leech / Form-Cycle Module | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-FIRST | Worldbreaker / Upside-Down Module | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-MOB-ROT | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-GHOUL | Kagune-Mark / Enraged Module | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-MOB-ROT | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-HOUND | Search-to-Chase Routing Module | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-INFO-CHAIN | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-KS-NIGHT | Dream Projection Pressure Module | STRATEGIC MODULE | KILLER_SPECIFIC | ESTABLISHED | K1-MOB-ROT | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-ADD-MIRROR | Scratched-Mirror Ambush | NICHE STRATEGY | KILLER_SPECIFIC | ESTABLISHED | K1-AMBUSH | RANKED:62/C | RANKED:49/D | 50 |
| K1-ADD-JUDG | Obsidian-Feather Forced-Cast Variant | MECHANIC-CENTERED BUILD | KILLER_SPECIFIC | EMERGING | K1-KS-JUDGE | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-01 | Temporary Slug | TACTIC | BROAD_ROSTER | ESTABLISHED | Down-State | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-02 | Leave Chase | TACTIC | BROAD_ROSTER | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-03 | Return to Hook | TACTIC | BROAD_ROSTER | ESTABLISHED | K1-HOOK-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-04 | Force Trade | TACTIC | BROAD_ROSTER | ESTABLISHED | K1-HOOK-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-05 | Defend Critical Generator | TACTIC | BROAD_ROSTER | ESTABLISHED | K1-GEN-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-06 | Chase Death-Hook Survivor | TACTIC | BROAD_ROSTER | ESTABLISHED | K1-TGT-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-07 | Delay Pickup | TACTIC | BROAD_ROSTER | ESTABLISHED | Down-State | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-08 | Zone Survivor | TACTIC | BROAD_ROSTER | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-09 | Bodyblock Escape Route | TACTIC | BROAD_ROSTER | ESTABLISHED | — | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-10 | Rescue Interception | TACTIC | BROAD_ROSTER | ESTABLISHED | K1-HOOK-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-11 | Fake Objective Commitment | TACTIC | BROAD_ROSTER | ESTABLISHED | K1-GEN-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-12 | Break-and-Leave | TACTIC | BROAD_ROSTER | ESTABLISHED | chase-resource | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-13 | Hook-Destination Selection | TACTIC | BROAD_ROSTER | ESTABLISHED | K1-HOOK-FAM | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K1-TAC-14 | Target Switch on Contact | TACTIC | BROAD_ROSTER | ESTABLISHED | Target/Rotation | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K2-ADD-HAG-SHOE | No-Teleport Trap-Zone Hag | MECHANIC-CENTERED BUILD | KILLER_SPECIFIC | ESTABLISHED | K1-TERR-SETUP | NOT_APPLICABLE:— | NOT_APPLICABLE:— | — |
| K2-LEG-DEER | Old Deerstalker Slug-Tracking Shell | MECHANIC-CENTERED BUILD | BROAD_ROSTER | LEGACY | K1-DOWN-SUST | NOT_CURRENT:— | NOT_CURRENT:— | — |
| K2-LEG-FACECAMP | Pre-Resolve-Bar Close Facecamp Form | NICHE STRATEGY | BROAD_ROSTER | LEGACY | K1-HOOK-PROXY | NOT_CURRENT:— | NOT_CURRENT:— | — |
| K2-LEG-THRILL | Passive Thrill Totem-Defense Form | MECHANIC-CENTERED BUILD | BROAD_ROSTER | LEGACY | K1-HEX-DEF | NOT_CURRENT:— | NOT_CURRENT:— | — |
| K2-LEG-TOMB | Historical Tombstone-Piece Direct-Kill Shape | NICHE STRATEGY | KILLER_SPECIFIC | LEGACY | K1-PF-STALK | NOT_CURRENT:— | NOT_CURRENT:— | — |