# Survivor Meta Research

This folder contains the canonical Survivor Meta research pipeline for **Dead by Daylight**, organized by live patch baseline and research revision.

## Current Baseline

**Patch:** 10.2.0  
**Research Revision:** r1  
**Research Cutoff:** October 7, 2026

The Survivor Meta project is designed to preserve both current rankings and long-term historical strategy evolution without overwriting prior research.

---

# Research Pipeline

The Survivor research process is divided into the following stages.

## Stage 1: Meta Discovery

Broad discovery of the major Survivor strategic archetypes currently present in the live game.

Purpose:

- Identify major current metas
- Distinguish metas from tactics, mechanics, and individual perks
- Identify likely Solo Q and SWF differences
- Establish the first candidate strategy set

## Stage 1.5: Comprehensive Strategy Catalog

High-recall catalog of the broader Survivor strategy ecosystem.

Purpose:

- Capture major metas
- Identify subtypes
- Identify strategic modules
- Identify role specializations
- Identify mechanic-centered builds
- Identify niche and experimental strategies
- Preserve legacy strategies
- Avoid losing recognizable playstyles simply because they are not top-tier

## Stage 2: Adversarial Verification and Ranking

Deep verification and ranking of the Stage 1 and Stage 1.5 findings.

Purpose:

- Challenge previous conclusions
- Verify whether strategies deserve their classifications
- Independently evaluate Solo Q and coordinated SWF
- Establish current Power scores and tiers
- Measure Meta Stability
- Evaluate confidence, trend, prevalence, counters, dependencies, and opportunity cost
- Identify Provisional, Unranked, and Legacy strategies

## Stage 3A: Canonical Structured Database

Converts the completed research into canonical machine-readable records.

Stage 3A is the authoritative structured research layer.

It defines:

- Persistent Strategy identities
- StrategyPatchSnapshot records
- Solo Q and SWF evaluations
- Power
- Tier
- Ranking Status
- Meta Stability
- Stability components
- Evidence confidence
- Strategic diagnostics
- Dependencies
- Perk ecosystems
- Representative BuildImplementations
- Research flags
- Recheck conditions
- Parent and subtype relationships

Stage 3A should be treated as the primary structured source of truth for website ingestion.

## Stage 3B: Human-Readable Strategy Encyclopedia

Converts the canonical Stage 3A research into publication-ready strategy pages.

Purpose:

- Explain each strategy in readable form
- Provide current rankings
- Explain Solo Q vs SWF differences
- Describe builds, counters, strengths, weaknesses, and use cases
- Preserve parent-family and Legacy pages
- Provide finished editorial content suitable for the website

Stage 3B is downstream of Stage 3A and should not replace or override the canonical structured data.

---

# Current Folder Structure

```text
survivor-meta
└── 10.2.0-r1
    ├── stage1
    ├── stage1.5
    ├── stage2
    ├── stage3a
    ├── stage3b
    └── archives
```

---

# Stage 3A Canonical Files

The Stage 3A folder contains:

```text
strategies.json
strategy-snapshots.json
validation.json
stage3a-report.md
```

The canonical 10.2.0-r1 dataset contains:

- **57 Strategy records**
- **57 StrategyPatchSnapshot records**
- **55 original Stage 1.5 catalog entries**
- **2 Parent Strategy Family records**
- **2 Legacy strategies**

All canonical integrity checks passed for the 10.2.0-r1 release.

---

# Historical Preservation

Research releases are patch-versioned.

Do not overwrite historical baselines when the game changes.

Future patches should create new snapshots or research revisions rather than replacing old evaluations.

Example:

```text
survivor-meta
├── 10.2.0-r1
├── 10.3.0-r1
└── 10.3.0-r2
```

A Strategy may persist across many patches while its:

- Power
- Tier
- Stability
- Trend
- Prevalence
- Builds
- Counters
- Perk ecosystem
- Evidence confidence

change over time.

Historical snapshots should remain available for comparison, auditing, and future meta-history features.

---

# Strategy Identity

A Strategy is not defined by one exact four-perk loadout.

A persistent Strategy represents a strategic plan or gameplay identity.

Exact perk combinations belong to patch-specific BuildImplementations.

This distinction allows strategies such as:

- General Chase / Looping
- General Generator Pressure
- Anti-Tunnel Package
- Hook-State Transfer
- Solo-Q Generalist

to remain historically continuous even when their optimal perks change.

A changing perk package does not automatically create a new Strategy identity.

A new Strategy identity should normally be created only when the strategic objective, gameplay pattern, resource manipulation, or player decision-making changes substantially enough that the old identity no longer describes the plan.

---

# Structural Classification

Structural Classification describes what kind of strategic object an entry represents.

Current classifications include:

- `META`
- `META SUBTYPE`
- `PARENT STRATEGY FAMILY`
- `STRATEGIC MODULE`
- `ROLE SPECIALIZATION`
- `MECHANIC-CENTERED BUILD`
- `GENERALIST SHELL`
- `NICHE STRATEGY`

Classification is separate from current strength.

A Strategic Module can be stronger than a Meta Subtype.

A Niche Strategy can remain competitively useful.

A Generalist Shell can be S Tier in one environment without becoming a major standalone meta archetype.

---

# Current Status

Current Status describes the Strategy's relationship to the live game.

Current values include:

- `ESTABLISHED`
- `EMERGING`
- `EXPERIMENTAL`
- `LEGACY`

Legacy strategies remain in the encyclopedia and historical database but are excluded from current S-D tier lists.

---

# Trend

Trend describes the current direction of a Strategy rather than its structural identity or strength.

Examples include:

- `RISING`
- `STABLE`
- `DECLINING`
- `RE-FORMING`
- `TOO EARLY TO TELL`

Trend should not be confused with Current Status.

---

# Ranking Environments

Survivor strategies are evaluated independently for:

- **Solo Q**
- **Coordinated SWF**

A Strategy may have different:

- Power
- Tier
- Ranking Status
- Confidence

in each environment.

Possible ranking states include:

- `RANKED`
- `PROVISIONAL`
- `UNRANKED`
- `NOT_APPLICABLE`
- `NOT_CURRENT`

## RANKED

Enough evidence exists for a defensible current competitive placement.

## PROVISIONAL

A reasonable current estimate exists, but post-patch evidence, optimization certainty, or sample maturity remains incomplete.

## UNRANKED

The Strategy is current and strategically meaningful, but available evidence does not support assigning a responsible Power score.

## NOT_APPLICABLE

A unified competitive score is conceptually inappropriate for the entry.

This is commonly used for Parent Strategy Families whose children are ranked independently.

## NOT_CURRENT

The Strategy is Legacy and therefore excluded from current competitive rankings.

---

# Current Power

Power represents current comparative competitive strength.

It is **not** an observed escape probability.

Solo Q and coordinated SWF Power are evaluated independently.

Current tier thresholds are:

| Tier | Power |
|---|---:|
| S | 88-100 |
| A | 78-87 |
| B | 66-77 |
| C | 50-65 |
| D | 0-49 |

Letter tier represents current Power.

---

# Meta Stability

Meta Stability is separate from current Power.

Power answers:

> How strong is this strategy right now?

Meta Stability answers:

> How likely is this strategy to remain strategically relevant through reasonable balance changes and shifts in the surrounding meta?

Meta Stability is scored from 0-100 using:

- Structural Independence
- Core Mechanic Durability
- Replacement Depth
- Environmental Breadth
- Counter-Meta Independence
- Patch Durability

Stability labels are:

| Stability | Label |
|---|---|
| 85-100 | VERY STABLE |
| 70-84 | STABLE |
| 50-69 | WATCH |
| 30-49 | VOLATILE |
| 0-29 | HIGHLY EXPERIMENTAL / UNSTABLE |

High Stability does not automatically mean high current Power.

A low-tier niche strategy may remain structurally durable across many patches.

A powerful newly changed strategy may have lower Stability.

---

# Meta Ranking Index

Survivor Ranking Indices are environment-specific.

## Solo Q Meta Ranking Index

```text
(Solo Q Power × 0.80)
+
(Meta Stability × 0.20)
```

## Coordinated SWF Meta Ranking Index

```text
(SWF Power × 0.80)
+
(Meta Stability × 0.20)
```

Ranking Index is a secondary tool.

It may help:

- Order close entries
- Compare durable recommendations
- Support future Long-Term Value sorting

Ranking Index does **not** determine the letter tier.

Current Power remains the primary measure of current competitive strength.

If Power is not established, Ranking Index should remain null rather than being manufactured from Stability.

---

# Strategic Diagnostics

StrategyPatchSnapshots may contain additional descriptive ratings such as:

- Win Condition Contribution
- Activation Reliability
- Activation Payoff
- Denial Risk
- Role Commitment
- Dependency Types

These values describe how a Strategy behaves.

They are not automatically incorporated into Current Power unless the scoring methodology is explicitly redesigned and all affected strategies are recalculated.

## Win Condition Contribution

Measures how directly successful use of the Strategy advances the Survivor side toward winning.

## Activation Reliability

Measures how often the Strategy realistically obtains opportunities to produce its intended value.

## Activation Payoff

Measures how much strategic value successful activation usually creates.

Activation Payoff is separate from Activation Reliability.

A Strategy may activate rarely but have an enormous payoff when it does.

## Denial Risk

Measures how easily the Killer can avoid, bypass, refuse, or invalidate the Strategy.

Higher values indicate greater denial risk.

## Role Commitment

Measures how much adopting the Strategy changes the player's positioning, priorities, travel patterns, or normal gameplay.

This field may later be normalized to the shared Survivor/Killer term `Strategic Commitment` at the website or shared-schema layer.

---

# Dependency Types

Strategies may depend on one or more external conditions.

Examples include:

- `SELF`
- `TEAMMATES`
- `COMMUNICATION`
- `OPPONENT_BEHAVIOR`
- `MAP`
- `ITEM`
- `RNG`
- `GAME_STATE`
- `POSITIONING`
- `TIMING`
- `RESOURCE_AVAILABILITY`

Dependencies help explain why two strategies with similar Power may have very different reliability.

---

# Build Implementations

A Strategy is not permanently tied to one exact build.

Patch-specific BuildImplementations may contain:

- Environment
- Target skill level
- Perk IDs
- Alternative perk slots
- Items
- Add-ons
- Build rationale
- Strengths
- Weaknesses
- Build confidence
- Content validity

BuildImplementations belong to the patch-specific Strategy evaluation rather than the persistent Strategy identity.

This allows optimal builds to change without creating unnecessary new Strategy IDs.

Canonical `perkIds` inside BuildImplementations may be linked directly to the website's perk database.

Descriptive perk names found only in general perk-ecosystem text should not automatically be treated as canonical IDs unless they can be resolved deterministically.

---

# Parent Strategy Families

Some strategic concepts are useful as organizational families but are too internally diverse to receive one honest aggregate Power score.

Current Parent Strategy Families include:

- Pickup Interception / Save Family
- Rescue-and-Reset Support Family

Parent Strategy Families primarily serve as:

- Encyclopedia navigation pages
- Strategy comparison hubs
- Shared strategic definitions
- Containers for related child strategies

Their children are ranked independently.

Do not manufacture aggregate Power scores for Parent Strategy Families merely for completeness.

---

# Legacy Strategies

Legacy Strategies preserve historically meaningful strategies whose defining competitive form is no longer current.

Legacy does not mean the Strategy should be deleted.

Legacy records remain useful for:

- Historical explanation
- Patch comparison
- Strategy evolution
- Old guide interpretation
- Identifying modern successors

Legacy strategies are excluded from current tier lists and use `NOT_CURRENT` ranking semantics.

Current 10.2.0-r1 Legacy entries include:

- Luck-Based Self-Unhook
- Classic Stake Out-Hyperfocus Engine

Legacy records should remain part of the same canonical Strategy catalog rather than being moved into a disconnected database.

---

# Evidence and Confidence

The database preserves separate confidence dimensions where relevant.

These may include:

- Mechanics Confidence
- Prevalence Confidence
- Power Confidence
- Solo Confidence
- SWF Confidence
- Build Confidence

Confidence is separate from both Power and Meta Stability.

A Strategy may have:

- High Power
- Low Stability
- High Confidence

or:

- High Stability
- Low current evidence confidence

These are different statements and should remain distinguishable.

The project should not create a mathematically precise overall confidence score unless it has a clear and defensible interpretation.

---

# Patch Timing and Evidence Limits

The 10.2.0-r1 research cutoff occurred approximately one day after Patch 10.2.0 went live.

Official Behaviour Interactive material can establish live mechanics, but rolling community statistics may still contain pre-10.2 matches.

For that reason, some strategies are deliberately marked:

- PROVISIONAL
- UNRANKED
- TOO EARLY TO TELL
- EMERGING
- EXPERIMENTAL

rather than being assigned false precision.

Uncertainty is part of the canonical research record.

---

# Website Use

The Survivor Meta website should consume **Stage 3A** for:

- Structured data
- Rankings
- Filtering
- Relationships
- Build IDs
- Status
- Trend
- Stability
- Confidence
- Patch history

The website should consume **Stage 3B** for:

- Publication-ready encyclopedia prose
- Detailed explanations
- Human-readable Strategy pages

The website presentation layer may normalize research terminology into controlled UI filters, but it should not rewrite canonical research records merely for display convenience.

The intended information flow is:

```text
RESEARCH TRUTH
Stage 3A
Strategy
→ StrategyPatchSnapshot
→ BuildImplementation

        ↓

PUBLICATION TRUTH
Stage 3B
Strategy Encyclopedia Content

        ↓

SITE PRESENTATION
Controlled Taxonomy
→ Filters
→ Search
→ Navigation
→ UI
```

---

# Website Taxonomy

Canonical research terminology and website filter terminology do not have to be identical.

For example, Stage 3A may describe a role as `Repair`, while the website may group it beneath the controlled filter `Generator`.

This should be implemented through a separate presentation taxonomy rather than rewriting the canonical research.

Potential website dimensions include:

## Roles

- Chase
- Generator
- Healing
- Rescue
- Information
- Protection
- Pickup Denial
- Self-Sustain
- Recovery
- Stealth
- Endgame
- Team Support
- Utility

## Strategic Modules

Examples:

- Anti-Tunnel
- Anti-Slug
- Anti-Camp
- Hook-State Transfer
- Objective Routing
- Chase Information
- Endgame Insurance

## Mechanics

Examples:

- Exhaustion
- Vault
- Pallet
- Aura Reading
- Skill Check
- Toolbox
- Med-Kit
- Flashlight
- Flashbang
- Chest
- Boon
- Totem
- Invocation
- Locker
- Haste
- Obsession
- Misdirection

The website taxonomy is a presentation and discovery layer.

Stage 3A remains the research authority.

---

# Filtering

The website should eventually support filters such as:

- Environment
- Tier
- Structural Classification
- Current Status
- Role
- Strategic Module
- Mechanic
- Stability
- Trend
- Evidence Confidence
- Dependency
- Prevalence
- Experimental
- Provisional
- Legacy

Filter visibility may be customizable.

Potential presets include:

- Recommended
- Solo Q
- SWF
- All
- Custom

Hiding a filter in the interface should not remove the underlying metadata from the canonical Strategy record.

---

# Fields Not Yet Canonically Established

Some useful website dimensions have not yet been fully established as canonical Stage 3A data.

These include:

- Skill Floor
- Skill Ceiling
- Execution Reliability
- Map Dependence
- Matchup Coverage

These should remain on the research/schema backlog until they are explicitly researched and normalized.

Do not invent these values merely to enable a filter.

---

# Future Updates

When a new Dead by Daylight patch releases:

1. Identify materially affected Strategies.
2. Determine whether each requires:
   - No material update
   - Targeted update
   - Full re-research
3. Preserve persistent Strategy identity where the core strategic plan remains intact.
4. Create new StrategyPatchSnapshot records where necessary.
5. Preserve previous snapshots.
6. Re-evaluate affected Power, Stability, Trend, Builds, counters, and confidence.
7. Regenerate current ranking views dynamically.
8. Produce updated Stage 3B publication content where required.
9. Preserve previous research releases for historical comparison.

The goal is to maintain a living Strategy database rather than rebuild the entire Survivor encyclopedia from scratch after every patch.

---

# Material Change Triggers

A Strategy should be reconsidered when events such as the following occur:

- Rework or major numerical change to a defining perk
- New perk directly enabling or countering the Strategy
- Killer changes materially affecting its matchup coverage
- Survivor system changes
- Item or add-on changes
- Map-system changes
- Major opposing-behavior changes
- Clear prevalence shifts
- Newly discovered interactions
- Bug fixes removing important interactions
- Emergence of a clearly superior implementation

Not every patch requires every Strategy to receive a new snapshot.

---

# Historical Snapshot Philosophy

Previous Strategy evaluations should be preserved.

Example:

```text
Flashbang Save

Patch 10.2.0
SWF Power: 79
Tier: A

Future Patch
SWF Power: 73
Tier: B
```

Both evaluations should remain available.

This enables:

- Patch-history pages
- Ranking timelines
- Rise/fall analysis
- Historical meta reconstruction
- Editorial auditing
- Future charts
- Debugging ranking changes

Historical research should be append-oriented rather than destructively overwritten.

---

# Rank Position

Canonical data should not permanently store ordinal positions such as:

```text
#1 Solo Q Strategy
#4 SWF Strategy
```

Ordinal position should be calculated dynamically from the selected environment and current eligible Strategy records.

Power, Stability, Ranking Status, and available evidence may change independently.

Stored rank positions would become stale too easily.

---

# Relationship to Killer Meta Research

Survivor and Killer Meta research remain separate ranking systems.

However, both are intended to share the broader architecture:

```text
Strategy
→ StrategyPatchSnapshot
→ BuildImplementation
```

Future shared schema work may normalize:

- Environment evaluations
- Structural classifications
- Current statuses
- Ranking statuses
- Confidence
- Meta Stability
- Strategic diagnostics
- Dependencies
- Historical snapshots

while preserving side-specific ranking logic.

Survivor environments are:

- Solo Q
- Coordinated SWF

Killer environments will be determined by the Killer research architecture and should not be assumed to use the same environment model.

Every canonical Survivor Strategy record should remain explicitly marked:

```text
side = SURVIVOR
```

Survivor and Killer Strategy rankings should never be merged into one combined tier list.

---

# Frozen Research Baselines

Completed historical research releases should be treated as frozen artifacts.

Do not silently edit a historical release in place.

If a correction or revision is required:

1. Create a new research revision.
2. Document the change.
3. Preserve the previous release.
4. Link the new snapshot or revision to what it supersedes where applicable.

Example:

```text
10.2.0-r1
10.2.0-r2
```

The objective is historical traceability and reproducibility.

---

# Source-of-Truth Hierarchy

The intended hierarchy is:

1. **Stage 3A**
   - Canonical structured research truth

2. **Stage 3B**
   - Publication-ready interpretation of Stage 3A

3. **Website Runtime Data**
   - Generated/adapted data optimized for the application

4. **Website UI**
   - Filters, cards, navigation, search, and display

Downstream layers should never silently override upstream canonical research.

---

# Core Principle

The Survivor Meta project is intended to be both:

**A Meta Tier List**

and

**A Strategy Encyclopedia**

The Tier List answers:

> What is strongest right now?

The Strategy Encyclopedia answers:

> What is this Strategy, how does it work, why does it work, when should I use it, what does it require, what counters it, and how appropriate is it for my environment?

Both views should ultimately be generated from the same canonical Strategy system.