# Dead by Daylight Survivor Strategy Catalog: Stage 1.5

**Evidence cutoff:** October 7, 2026  
**Verified live baseline:** **Patch 10.2.0**  
**Scope:** Current Survivor strategy/build ecology, including major approaches, subtypes, specialist roles, cross-build modules, mechanic-centered builds, generalist shells, emerging experiments, and a small number of still-relevant legacy strategies.

## Executive landscape

### Baseline verification and evidence limits

The expected baseline is correct: **Dead by Daylight 10.2.0 is the current live version at the October 7, 2026 cutoff.** Behaviour Interactive's live patch notes identify the release as **“10.2.0 | Mid-Chapter,”** and the update went live on **October 6, 2026**; SteamDB independently records the October 6 build. The official patch index places 10.2.0 after 10.1.2. There is therefore **no baseline discrepancy** to flag. citeturn16view0turn23view4turn22view9

There is, however, an unusually important **evidence-timing problem**: 10.2.0 had been live for only about one day at cutoff. That means mechanics can be established confidently from Behaviour's notes, but almost no source can yet establish *settled post-10.2 prevalence or outcomes*. NightLight aggregates thousands of voluntarily uploaded matches and refreshes its data roughly daily, so even its “current” rolling windows on October 7 are dominated by 10.1.x play. Community-build databases likewise still identified **10.1.0** as their current patch at cutoff. Accordingly, this report treats post-10.2 prevalence as **Unknown** or **Too Early to Tell** where the patch directly altered the strategy. citeturn23view3turn22view1

That distinction matters. NightLight, for example, had Decisive Strike at roughly the mid-teens in usage in its recent rolling data and Background Player at only a few percent; its co-use data also shows DS embedded inside chase/survival shells and Background Player repeatedly paired with save-oriented perks such as Breakout, Saboteur, Bond and Flashbang. Those are useful signals that **anti-tunnel** and **pickup-interception** ecosystems are real and recurring. They are not measurements of a settled 10.2 meta. citeturn7search4turn7search8

### The ecosystem is modular, not a collection of four-perk archetypes

The current Survivor ecosystem is best understood as a set of **overlapping strategic layers**. A player may simultaneously be running a chase subtype, an anti-tunnel module and an information package, or a repair specialization with a self-sustain contingency. Community loadouts explicitly mix tags such as Looping, Info, Gen Rush, Stealth, Solo Queue, Anti-Tunnel, Anti-Slug, Totems, Loot, Lockers and Sabotage, which is strong evidence that actual build construction does not respect a simple one-build/one-role taxonomy. citeturn22view1

Patch 9.6.0 strengthened that modular tendency by introducing **diminishing returns for repeated modifiers**: the strongest matching modifier applies fully, then subsequent values are reduced to 50%, 25%, 12.5% and ultimately 5%; item add-on modifiers are excluded. This makes “stack every repair-speed perk” or “stack every healing-speed perk” structurally less attractive than before and increases the relative appeal of combining a large speed modifier with information, item economy, contingency or a mechanically different source of value. That last point is a researcher inference from the official DR rules, not a measured population shift. citeturn23view8

The other major structural change is **10.2's Survivor Intent System**. Survivors can now send a configurable set of predefined messages visible to the whole team. This does not make Solo Q equivalent to voice-coordinated SWF, but it does remove part of the historical communication deficit for rescue calls, intentions and simple role signaling. Consequently, several strategies that were formerly sharply SWF-skewed should be re-tested rather than assumed to retain exactly the same Solo Q penalty. citeturn23view4

### The largest current strategy ecosystems

The broadest recurring ecosystems are:

**Chase/survival.** Dedicated looping remains recognizable, but it divides into Exhaustion mobility, vault/window specialization, pallet-resource management, chase-information builds, stealth avoidance and post-hit disappearance. Current community builds independently tag and construct all of these behaviors rather than treating “chase build” as one homogeneous object. citeturn22view1turn22view0

**Generator/objective pressure.** This contains generic gen specialists, toolbox builds, critical-generator/three-gen breakers, cooperative repair, skill-check builds and objective-to-other-role hybrids. DR makes raw perk-speed stacking less straightforward, while toolbox add-ons retain an important structural exception from DR. citeturn23view8turn22view1

**Altruism and rescue.** Hook rescuers, post-unhook healers, anti-camp packages, healer/triage specialists, protection-hit players and hook-state management are distinct practical roles. 10.2 materially strengthens the need to separate these because Shoulder the Burden now supports a very particular **hook-state redistribution** plan rather than being merely another generic rescue perk. Behaviour's own balancing notes and live community debate emphasize its stronger implications for coordinated groups. citeturn22view7turn22view8

**Pickup and hook denial.** Flashlight saves, Flashbang saves, sabotage, Breakout/carry interference, pallet saves, carry bodyblocking and self-oriented wiggle/carry-escape builds share the parent objective of preventing a successful hook, but their positioning, resource needs, timing and Killer counterplay differ enough that they should not be collapsed into one “save build.” NightLight's Background Player co-use patterns are especially strong evidence for this ecosystem. citeturn7search8turn22view1

**Information.** There is a meaningful difference between Solo-Q team-state information, direct Killer tracking, teammate tracking and objective/resource routing. 10.2 further changes the map: Premonition is now an aura-reading tool, Dark Sense has broader routing information, Kindred is stronger, and Windows of Opportunity has been narrowed toward windows/vaulting rather than being the old all-purpose pallet-and-window learning perk. citeturn22view8

**Items and secondary objectives.** Chest scavenging, Pharmacy/Med-Kit farming, item recharge, Boons, Totem interaction, Invocations and Locker builds remain real strategic families even though most are not top-level meta strategies. 10.2's enormous Plunderer's Instinct and Pharmacy speed increases make the chest economy one of the clearest fresh experimentation zones. citeturn23view6

**Generalists.** There is a genuine Solo-Q generalist philosophy—one mobility/chase answer, one objective or information perk, one rescue/reset tool and one personal contingency is a common construction logic even when the exact four perks vary. SWFs also use generalists, but voice coordination permits more aggressive specialization and distribution of team functions. Current community builds explicitly label “Solo Queue” alongside mixed Info, Stealth, Gen Rush and survival packages. citeturn22view1

### The most consequential 10.2 disruptions

Several pre-10.2 assumptions should not be carried forward.

First, the familiar **Stake Out → Hyperfocus** automated skill-check engine has been materially invalidated: 10.2's special Skill Checks no longer activate other Skill Check perks. Stake Out remains a perk, and Hyperfocus remains a skill-check strategy, but the classic interaction should now be treated as a **legacy build**, not a current recommendation. This is particularly important because 10.1 community databases were still publishing Hyperfocus–Stake Out “gen rush” builds immediately before 10.2. citeturn22view8turn22view1

Second, **Windows of Opportunity has changed strategic identity**. Its current version focuses on windows and grants vault speed rather than supplying the former broad pallet/window aura network. The old generic “Windows resource map” build therefore needs to be split into a current **vault/window specialist** and separate pallet/routing strategies. citeturn22view8

Third, **Road Life** has become a genuine repair-to-self-sustain mechanic: while injured and repairing, Great basic Skill Checks build tokens that can unlock a self-heal. That is a coherent new hybrid rather than merely a repair perk. citeturn23view6

Fourth, **chest strategy is newly credible as an intentional economy**. Pharmacy now guarantees a rare Med-Kit from opened chests, sharply accelerates opening/rummaging and permits a rummage per chest; Plunderer's Instinct has global chest/item aura information, very high chest-opening speed and better rarity odds. Whether this becomes *strong* is unresolved, but it plainly exists as a coherent current strategy. citeturn23view6

Fifth, Aurora's 10.1 perks created three still-new strategic directions just before the 10.2 pass: **Boon: Steadfast repair zones**, **Salvation's Cry chase broadcasting**, and **Fruits of Your Labor objective-to-reset hybrids**. With only a few weeks of 10.1 evidence and one day of 10.2, all three deserve representation without pretending their final standing is established. citeturn23view9

## Comprehensive strategy catalog

**Classification abbreviations:** MMA = Major Meta Archetype; MS = Meta Subtype; RS = Role Specialization; SMP = Strategic Module/Package; MCB = Mechanic-Centered Build; GS = Generalist Shell; NSS = Niche/Specialist Strategy; EE = Emerging/Experimental; LO = Legacy/Outdated.

“Prevalence” is deliberately conservative. Where 10.2 materially changed a family, **Unknown** means “no defensible post-10.2 prevalence estimate yet,” not “nobody plays it.” Pre-10.2 community-build evidence is used to establish recognition, while official sources establish live mechanics. citeturn23view3turn22view1

| ID | Strategy Name | Alternative / Community Names | Classification | Parent Strategy / Archetype | Primary Role | Secondary Roles | Defining Mechanics | Core Gameplay Idea | Typical Defining Perks | Relevant Items / Add-ons | Solo Q / SWF Orientation | Current Standing | Prevalence | Trend | Confidence | Why Players Run It | Major Limitation / Counterplay | Distinguishing Feature | Stage 2 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C01 | General Chase / Looping | Chase build, looper, runner | MMA* | Chase/survival | Chase | Time-buying, aggro | Mobility, vaults, tile/resource use | Intentionally maximize time before down | Lithe, Finesse, Resilience, Dead Hard, chase info | Usually none | Neutral; stronger role assignment in SWF | **Strong** | Common | Stable | High | Extend chases and team repair time | Can become four dead perk slots when Killer refuses chase | Match plan is explicitly built around taking/lasting in chase | Deep |
| C02 | Exhaustion Mobility Chase | Exhaustion build, distance build | MS / MCB | C01 | Chase | Escape, positioning | One large burst of mobility per Exhaustion cycle | Convert a trigger into distance or another loop | Lithe, Sprint Burst, Balanced Landing, Dead Hard, Overcome; Vigil sometimes | None | Roughly neutral | **Strong** | Common | Stable / reshuffled | High | Reliable chase extension without total build commitment | Exhaustion management; trigger conditions; Sprint Burst was shortened in 10.1 | Mobility trigger defines routing decisions | Standard |
| C03 | Vault / Window Specialist | Window build, vault build | MCB | C01 | Chase | Routing | Windows, fast vaults, vault-speed modifiers | Route toward reusable windows and win marginal vault timings | Windows of Opportunity, Finesse, Resilience, Spine Chill | None | Neutral | **Viable** | Unknown post-10.2 | Emerging in new form | High mechanics / Medium standing | Exploit strong window structures | Window blocking, anti-vault powers, DR on stacked modifiers | **Current Windows is a window/vault perk, not the old pallet map perk**. citeturn22view8 | Deep |
| C04 | Pallet / Resource Specialist | Pallet build, resource build | MCB | C01 | Chase | Team resource management | Pallet location/state, resetting/reuse | Preserve, identify or maximize pallet resources | Five Moves Ahead, Any Means Necessary, Alert-type information | None | Solo Q viable; communication helps resource accounting | **Viable** | Moderate | Rising relative to old Windows | Medium | Avoid dead zones and waste fewer pallets | Map RNG; Killer can rapidly destroy resources | Pallet economy rather than generic looping | Standard |
| C05 | Fragile-Pallet Restoration | Rebuild build, Apocalyptic pallet build | EE / MCB | C04 / item economy | Chase utility | Loot | Open/rummage chest, rebuild broken pallet | Convert chest investment into a new tactical pallet | Apocalyptic Ingenuity, often chest/info support | Chest interaction | Solo Q viable | **Experimental** | Rare / Unknown | Emerging | High mechanics / Low prevalence | Restore otherwise exhausted tiles | Setup time; Fragile Pallet limitations; Killer can pre-empt | Creates a new pallet rather than conserving an existing one; 10.1 reduced setup to one chest. citeturn18view1 | Standard |
| C06 | Chase Information / Routing | Chase aura, tile-reading | SMP | C01 / information | Chase | Info | Killer/resource/window/pallet information | Pre-plan routes rather than react blind | Dark Sense, Alert, Premonition, Five Moves Ahead; situational Windows | Map occasionally | Solo Q favored | **Viable** | Moderate | Rising | High mechanics / Medium prevalence | Reduce pathing mistakes and teach map/resource state | Info may duplicate player knowledge at high skill | Information changes route selection rather than raw speed | Standard |
| C07 | Stealth / Chase Avoidance | Immersion, stealth build | RS / MCB | Survival | Avoidance | Objectives, hatch/endgame | Aura denial, noise suppression, low visibility | Prevent chase from starting | Distortion, Calm Spirit, Iron Will, Light-Footed, movement/stealth perks | None | Solo Q favored | **Viable** | Moderate | Stable | Medium | Stay productive while avoiding Killer attention | Can shift pressure onto teammates; Killer tracking may bypass chosen stealth layer | Goal is **not entering chase**, unlike C08 | Standard |
| C08 | Chase Reset / Disappearance | Lose-the-Killer, vanishing build | MS | C01 / stealth | Escape chase | Healing/reset | Hide scratch marks/blood/noise after contact | Take a hit or break LOS and disappear | Lucky Break, Iron Will, Quick & Quiet, Lightweight/Dance With Me-type effects | Med-Kit sometimes | Neutral | **Viable** | Uncommon | Stable | Medium | Turn one LOS break into a full reset | Duration/resource limits; tracking powers | Starts with accepted chase, then tries to terminate it abruptly | Light |
| C09 | Anti-Tunnel Package | Tunnel protection, second chance | SMP | Cross-cutting survival module | Personal survival | Chase, team tempo | Post-unhook protection and pickup punishment | Make immediate re-targeting expensive | Decisive Strike, Off the Record, Resurgence, Dead Hard-type follow-up | Usually none | Solo Q viable; SWF maximizes bodyblocks/tempo | **Strong** | Common pre-10.2 signal | Stable | High | Punish or survive repeat targeting | Killer may wait effects out, slug or switch targets | Attaches cleanly to almost any main build. NightLight shows DS embedded with chase/generalist perks. citeturn7search4 | Deep |
| C10 | Anti-Slug / Self-Recovery Package | Slug counter, recovery build | SMP | Cross-cutting survival module | Recovery | Pickup rescue, chase | Recovering from Dying, self-pickup or fast teammate pickup | Deny pressure from leaving Survivors down | Unbreakable, Plot Twist, We're Gonna Live Forever, Boon: Exponential, Soul Guard-type effects | None | Solo Q viable; SWF stronger for timing | **Viable–Strong** | Moderate | Stable | High | Force Killer to respect downed Survivors | May never activate if Killer hooks immediately | Activated specifically by Dying-state macro; community databases independently tag Anti-Slug builds. citeturn22view1 | Deep |
| C11 | Hook-State Transfer | Shoulder the Burden, hook-state redistribution | SMP | Rescue / anti-tunnel | Death prevention | Bodyblocking, anti-tunnel | Remove target hook state and assume one yourself | Keep a vulnerable teammate alive by redistributing hook economy | Shoulder the Burden plus flexible survival/support shell | None | **SWF favored** | **Strong** | Unknown post-10.2 | Rising / Too early | High mechanics / Medium meta | Preserve fourth player and deny early elimination | User takes hook state plus injury/Broken cost; requires good target selection | Directly moves hook-state risk between players. citeturn23view6turn22view7 | Deep |
| C12 | Deterministic Self-Unhook | Deliverance build | NSS / SMP | Rescue → survival | Self-rescue | Altruism | Safely rescue another first, then self-unhook once | Bank independence before first hook | Deliverance, information/rescue perks | None | Solo Q viable; SWF favored for controlling first rescue | **Viable** | Uncommon–Moderate | Stable / slightly pressured | High | Save team travel/time when hooked | Fails if hooked before activation; long Broken penalty was increased in 10.1 | Requires a prior altruistic action rather than luck. citeturn18view1 | Standard |
| C13 | Luck-Based Self-Unhook | Kobe build, luck build, old Slippery Meat | LO | Self-unhook | Self-rescue | Meme/high variance | Old escape-attempt/luck stacking | Try to escape hook through probability | Historically Slippery Meat + luck effects | Luck offerings historically | SWF synergy existed but unreliable | **Legacy / Outdated** | Rare | Legacy | High | Historical self-unhook identity | 10.2 reworked Slippery Meat away from the classic core interaction | Retained because “luck/Kobe build” remains recognizable terminology | None |
| C14 | Self-Sustain / Self-Heal | Self-care build, independent healing | RS / SMP | Survival | Healing self | Objective uptime | Self-heal access without teammate | Reset independently when team cannot or should not rotate | Self-Care/Botany variants, Strength in Shadows, Inner Strength, Plot Twist; now Road Life variant | Med-Kit common | **Solo Q favored** | **Viable** | Moderate | Stable / branching | Medium | Independence and reduced teammate travel | Time efficiency varies drastically; anti-heal counters | Primary beneficiary is the user, unlike healer builds | Standard |
| C15 | Haste / Movement Stack | Speed build, zoomies | MCB / NSS | Chase / endgame | Mobility | Rescue, endgame | Multiple conditional Haste sources | Chain or overlap movement buffs to alter pathing | Blood Pact, Made for This, Hope, Teamwork-style Haste, Dark Theory-type effects | None | SWF favored where partner-dependent | **Situational** | Rare | Emerging after Blood Pact change | Medium mechanics / Low prevalence | Unusual rotations and chase spacing | Setup, conditions, DR/caps and anti-Haste Killer tools | Built around the Haste mechanic rather than one Exhaustion burst | Standard |
| G01 | General Generator Pressure | Gen build, gen rush | MMA* | Objective play | Repair | Routing | Repair bonuses, uptime, gen selection | Maximize useful generator progress across match | Deja Vu, Resilience, Hyperfocus/manual variants, Fast Track, objective info | Toolbox optional | Roughly neutral | **Strong** | Common | Stable | High | Advance win condition directly | Vulnerable to chase pressure; speed stacking now DR-limited | Repair is the central match plan, not merely one perk. citeturn23view8turn22view1 | Deep |
| G02 | Toolbox Generator Specialist | Toolbox gen, item gen build | MS | G01 / resource economy | Repair burst | Critical gens | Toolbox charges and add-ons, recharge/efficiency | Spend item resources where immediate progress matters | Built to Last, Streetwise/Scavenger-type support, objective info | **Toolbox central**; repair add-ons | Neutral; SWF improves timing | **Strong** | Moderate | Stable | High | Concentrated repair tempo; add-ons are excluded from DR | Finite charges, Franklin/item denial, recharge downtime | Item resource is indispensable, unlike generic G01. citeturn23view8 | Deep |
| G03 | Critical-Generator / Three-Gen Breaker | 3-gen breaker, gen prio | MS / RS | G01 | Strategic repair | Information | Identify dangerous generator clusters, commit resources selectively | Do the generators that matter, not simply the nearest ones | Deja Vu, objective info, Fast Track/repair burst; toolbox often | Toolbox optional | SWF favored but Solo Q viable | **Strong** | Moderate | Stable | Medium–High | Prevent late-game positional lock | Requires macro understanding and sometimes dangerous positioning | Generator **selection** is more important than raw speed | Deep |
| G04 | Cooperative Repair / Gen Duo | Prove gen, co-op gen | MS / RS | G01 | Cooperative repair | Team support | Shared repair bonuses triggered by teammates | Pair on selected generators for tempo/synergy | Prove Thyself, Friendly Competition, Leader-type support | Toolboxes optional | **SWF favored** | **Viable** | Moderate | Stable / altered by DR | Medium | Burst key gens and exploit partner effects | Multiple Survivors on one gen reduce map-wide labor; coordination needed | Requires another repairer as part of the engine | Standard |
| G05 | Manual Skill-Check Generator | Hyperfocus build, skill-check gen | MCB | G01 | Repair | Skill expression | Repeated **basic Great** checks | Convert reliable manual Great checks into extra progress | Hyperfocus and basic-skill-check support; Deja Vu/objective info | Toolbox optional | Neutral; player-skill dependent | **Viable / Experimental post-10.2** | Unknown | Re-forming | High mechanic / Low settled-meta | High ceiling without relying on old Stake Out automation | Mechanical difficulty and lost consistency | The current version requires genuine compatible basic checks | Deep |
| G06 | Classic Stake Out–Hyperfocus Engine | Stakefocus, auto-Hyperfocus | LO | G05 | Repair | — | Stake Out converted checks feeding Hyperfocus | Historically made Hyperfocus much more consistent | Stake Out + Hyperfocus, often Deja Vu/Built to Last | Toolbox often | Neutral | **Legacy / Outdated** | Was recognizable pre-10.2 | Legacy | High | Previously lowered skill requirement of Hyperfocus | 10.2 special Skill Checks no longer activate other Skill Check perks | A **mechanically invalidated interaction**, not merely a nerfed build; 10.1 databases were still recommending it. citeturn22view8turn22view1 | None |
| G07 | Boon: Steadfast Repair Zone | Gen boon, Steadfast zone | EE / MCB | G01 / Boons | Local generator pressure | Totems, team support | 10% repair bonus and slower regression in Boon radius | Establish a defended repair zone around selected gens | Boon: Steadfast, often Illumination, Overzealous/Flow State-type totem support | None | **SWF favored** | **Experimental / Viable** | Unknown | Emerging | High mechanics / Low outcomes | Teamwide localized objective value | Totem setup/location; Killer snuff/destruction; locality | Generator strategy is spatially anchored to a Boon. citeturn23view9turn22view1 | Deep |
| G08 | Road Life Repair-to-Self-Heal | Road Life gen-heal | EE / MCB | G01 / self-sustain | Repair | Self-heal | Great checks while injured produce self-heal access | Stay on gens while building the next reset | Road Life + repair/basic-check shell | Med-Kit unnecessary for core | Solo Q favored | **Experimental** | Unknown | Emerging | High mechanic / Low outcomes | Combines objective time with future independence | Must remain injured and hit Great checks; healing interrupts tempo | Repair performance directly generates healing capability. citeturn23view6 | Deep |
| G09 | Fast Track Rescue-to-Repair Tempo | Rescue-gen hybrid | MS / SMP | G01 / rescue | Repair burst | Unhooking | Safe rescues bank permanent-gen-progress tokens | Convert necessary altruism into later objective progress | Fast Track plus rescue/info shell | None/toolbox optional | Neutral; SWF helps allocate unhooks | **Viable** | Uncommon | Rising since rework | High mechanics / Medium prevalence | A rescue does double strategic duty | Must secure unhooks and then hit the needed Great check | Explicit altruism → generator conversion | Standard |
| G10 | Fruits of Your Labor Objective-to-Reset Hybrid | Fruits build, gen-to-heal | EE | G01 / generalist | Repair | Healing, mobility | Generator completions bank tokens; finishing repair grants short Haste and healing progress | Let objective completion accelerate next rotation/reset | Fruits of Your Labor plus repair/generalist shell | Flexible | Solo Q viable | **Experimental** | Unknown | Emerging | High mechanics / Low outcomes | Rewards doing the main objective without full specialization | Dependent on generator completions and being able to use heal progress | Generator success feeds both movement and healing. citeturn23view9 | Standard |
| A01 | Hook Rescue / Post-Unhook Reset | Rescuer, hook support | RS | Altruistic support | Unhooking | Healing, info | Rescue access plus rapid follow-up heal/protection | Own the rescue-and-reset sequence | Kindred, We'll Make It, Borrowed Time-type support, Babysitter, Aftercare | Med-Kit optional | Solo Q viable; SWF improves role allocation | **Strong** | Common | Rising after 10.2 buffs | High | Prevent hooks from snowballing | Can waste travel/time if teammates duplicate rescue | Unhook **plus post-hook stabilization**, not generic altruism | Deep |
| A02 | Anti-Camp / Hook-Timer Control | Reassurance build, camp counter | SMP | A01 | Hook-state preservation | Rescue coordination | Pause/extend hook-state pressure or coordinate delayed rescue | Buy time instead of forcing bad immediate rescue | Reassurance, Kindred, Kinship-type support | None | **SWF favored**, Solo Q viable | **Viable** | Uncommon | Stable | High | Counter proxy/camp pressure without suicidal trade | Range/timing restrictions; no value if Killer leaves hook | Manipulates rescue timing rather than rescue speed | Standard |
| A03 | Dedicated Healer / Triage | Medic, healing build | RS | Altruistic support | Healing others | Tracking, recovery | Find injured players and heal quickly | Rotate to damage and restore health states | Empathy, Empathic Connection, We'll Make It, Botany, WGLF-type support | Med-Kit useful | Solo Q viable; SWF improves triage calls | **Viable–Strong** | Moderate | Rising after 10.2 healing buffs | High | Restore team health efficiently | Healing can be strategically wrong against heavy slowdown/pressure; speed stacking has DR | Intentionally spends time seeking injured teammates | Deep |
| A04 | Hook-State-Scaled Fast Healing | Do No Harm build, crisis healer | EE / MCB | A03 | Healing others | Skill checks | Heal speed and skill-check benefits scale with target hook states | Prioritize endangered teammates for faster resets | Do No Harm plus Empathy/support/basic-check perks | Med-Kit optional | SWF favored for target triage | **Experimental** | Unknown | Emerging | High mechanics / Low outcomes | Stronger assistance where death risk is greatest | Little value on low-hook-state targets; fresh patch | Healing priority is explicitly based on hook-state danger. citeturn22view8 | Standard |
| A05 | Protection-Hit / Tank | Tank build, Mettle build | RS / NSS | Altruistic support | Protection | Chase, rescue | Deliberately absorb hits for teammates | Trade personal health for teammate escape/progress | Mettle of Man, WGLF, Made for This-type support, healing/recovery | Med-Kit sometimes | **SWF favored** | **Situational / Viable** | Uncommon | Stable | Medium | Save vulnerable teammates and force extra Killer hits | Can feed downs or waste healthy states | Taking a hit is the planned value, not an accident | Standard |
| A06 | Hook-Trade / Carry Bodyblock Protector | Trade build, bodyblock role | RS | A01 / pickup denial | Rescue denial | Protection hits | Occupy path, take hits, force awkward carries/trades | Interpose between Killer and hook/rescued player | Empathy/Bond, protection perks; sometimes Breakout/Saboteur | None or toolbox | **Strongly SWF favored** | **Viable** | Uncommon–Moderate | Stable | Medium | Convert health states into prevented hook tempo | Killer can switch targets, drop carried Survivor or exploit overcommit | Physical pathing/body presence is the resource | Standard |
| A07 | Endgame Rescue | Endgame save, NOED-rescue shell | RS / SMP | A01 / endgame | Rescue | Gate, healing | Post-generator rescue/heal/Haste bonuses | Turn a late hook into multi-Survivor escape | No One Left Behind, Borrowed Time-type support, Reassurance, Hope | Med-Kit optional | **SWF favored** | **Strong when activated** | Uncommon | Rising after 10.2 buffs | High mechanics / Medium prevalence | Dramatically improve exit-stage saves | Dead perks if team never reaches powered gates | Rescue value is concentrated after generators complete | Standard |
| P01 | Flashlight Save | Beam save, flashlight saver | RS | Pickup interception | Pickup denial | Chase distraction | Blind during pickup/carry window | Shadow chase, predict pickup, blind for drop | Background Player, Champion of Light, Bond/Empathy-type tracking | **Flashlight central**; battery/lens add-ons | **SWF favored**, Solo Q viable | **Viable–Strong** | Moderate | Stable | High | Convert a down into no hook and force pickup caution | Facing walls, light denial, baiting, slugging | Requires a carried item and line-of-sight blind timing | Deep |
| P02 | Flashbang Save | Flashbang saver, grenade save | RS | Pickup interception | Pickup denial | Objective hybrid | Crafted Flashbang, dropped/blast-timed pickup save | Earn grenade from objectives then stage close-range save | Flashbang, Background Player, Bond/Empathy | No carried flashlight required | **SWF favored** | **Viable** | Uncommon–Moderate | Stable | High | Save without dedicating hand slot to flashlight | Timing/positioning; Killer can look away/reposition | Save resource is generated rather than brought into Trial. Background Player users recurrently pair it with Flashbang. citeturn7search8 | Deep |
| P03 | Sabotage / Hook Denial | Sabo build, hook breaker | RS / MS | Pickup interception | Hook denial | Information, protection | Remove intended hooks during carry | Read pickup route and break the hook before arrival | Saboteur, Breakdown, Resilience, Empathy/Bond-type info | **Toolbox often central** | **SWF favored** | **Viable** | Uncommon–Moderate | Stable | High | Force drop/wiggle or longer carry route | Killer can change hook, hit saboteur or slug | Attacks **hook availability**, not pickup itself. citeturn22view1turn7search8 | Deep |
| P04 | Breakout / Carry Interference | Escort build, breakout build | RS | Pickup interception | Carry denial | Bodyblock, sabotage | Stay near carried teammate and accelerate escape pressure | Escort carry, bodyblock and force extended route | Breakout, often Background Player, Saboteur/Empathy/Bond | Toolbox optional | **Strongly SWF favored** | **Situational** | Rare–Uncommon | Stable | High existence / Medium strength | Turn marginal carry distances into escapes | Extremely risky proximity; Killer can hit escort/drop | Works **during the carry**, rather than before pickup | Standard |
| P05 | Teammate Pallet Save | Pallet save, stun save | NSS | Pickup interception / pallets | Pickup denial | Chase/resource use | Time Killer carry through a standing pallet and stun | Pre-position near usable pallet and force/drop carried Survivor | No mandatory perk; mobility/info support common | None | **SWF favored** | **Situational** | Rare | Stable | Medium | Itemless save opportunity | Requires exact pickup/pallet geometry and timing | Distinct resource and positioning from light/sabo saves | Light |
| P06 | Carry-Escape / Wiggle Denial | Boil Over build, Flip-Flop/Power Struggle | NSS / MCB | Pickup/hook denial | Self-preservation | Anti-slug | Wiggle pressure, recovery conversion, pallet self-save | Make hooking you locally difficult or unsafe | Boil Over, Flip-Flop, Power Struggle, Unbreakable/Tenacity-type support | Map offering sometimes strategically relevant | Neutral; coordinated teams can amplify | **Situational** | Uncommon | Stable | High existence / Medium strength | Exploit hook geometry and Killer carry decisions | Countered by nearby hooks, slugging and smart pathing; highly map-dependent | **Self-oriented** carry denial rather than saving a teammate. citeturn22view1 | Standard |
| I01 | Solo-Q Information Shell | Solo info, aura generalist | GS / SMP | Information | Decision support | Rescue, objectives | Teammate/Killer/hook/gen auras | Replace missing voice information with passive game-state visibility | Kindred, Bond, Premonition, Deja Vu, Open-Handed combinations | Map optional | **Solo Q favored** | **Strong** | Common | Rising | High | Avoid duplicated rescues, find work and read danger | Multiple info perks can overinvest in knowledge over direct tempo | Explicitly compensates for uncertainty in Solo Q; community builds label this directly. citeturn22view1turn23view4 | Deep |
| I02 | Killer Tracking / Aura Seer | Aura build, Killer reader | MCB | Information | Killer tracking | Chase, stealth | Recurrent Killer aura/heading information | Keep track of Killer before committing to objectives/routes | Alert, Premonition, Bound by Obsession/Object, Dark Sense, Eyes of Belmont-type extension | None | Solo Q favored | **Viable** | Moderate | Rising after 10.2 | High | Make earlier rotation/stealth/chase decisions | Aura-blocking/Undetectable effects; opportunity cost | Tracks **Killer**, not merely team or objectives | Standard |
| I03 | Teammate Tracking / Support Information | Bond build, Empathy info | SMP | Information / support | Team tracking | Healing, rescue | Aura locations of teammates/injured players | Find teammates for heals, co-op objectives or avoidance | Bond, Empathy, Aftercare, Empathic Connection | None | Solo Q favored | **Viable** | Moderate | Stable | High | Enables support without voice | Information can be redundant in coordinated SWF | Team-location layer specifically | Light |
| I04 | Objective / Resource Routing | Gen info, map-awareness shell | SMP | Information / G01 | Routing | Totems, chase | Generator/totem/resource aura information | Minimize search time and choose higher-value objectives | Deja Vu, Dark Sense, Detective's Hunch/Visionary-type tools | Map can substitute/extend | **Solo Q favored** | **Strong** | Common | Reconfiguring after 10.2 | High | Reduce dead travel and dangerous gen choices | Less value for players with perfect map knowledge | Information targets **where to work next** | Standard |
| I05 | Chase Broadcast / Salvation's Cry | Chase comms build | EE / SMP | Information / C01 | Team coordination | Chase, repair | Chase start reveals team to runner and runner/Killer to others | Turn being chased into automatic teamwide information | Salvation's Cry plus chase/flex shell | None | Solo Q favored in theory; useful in SWF too | **Experimental / Viable** | Unknown | Emerging | High mechanics / Low settled usage | Communicate chase state without voice | Trigger-specific and may duplicate SWF calls | Information is broadcast **because a chase starts**. citeturn23view9 | Standard |
| R01 | Chest / Loot Scavenger | Loot goblin, chest build | MCB | Resource economy | Item acquisition | Flex support | Global chest/item auras, very fast chest opens, rarity manipulation | Convert secondary-objective time into multiple usable items | Plunderer's Instinct, Appraisal/Ace in the Hole/Exultation-type support | Found items | Solo Q viable | **Experimental / Viable** | Unknown post-10.2 | Rising sharply | High mechanics / Low outcomes | Flexible item economy without committing lobby item | Opportunity cost of opening chests; RNG | **10.2 substantially buffed the chest transaction itself**. citeturn23view6 | Deep |
| R02 | Pharmacy / Med-Kit Farming | Chest medic, med-kit farmer | EE / RS | R01 / healing | Item supply | Healing, team resource | Guaranteed rare Med-Kit plus rapid chest opening/rummage | Turn chests into predictable healing inventory | Pharmacy, often Plunderer's Instinct/Appraisal/support perks | **Rare Med-Kits generated in match** | Neutral; SWF better for redistribution | **Experimental** | Unknown | Emerging | High mechanics / Low outcomes | Produce repeatable healing resources for self/team | Chest access and time cost; Killer pressure | Loot has a **specific guaranteed medical output**. citeturn23view6 | Deep |
| R03 | Item Recharge / Recursion | Infinite-item, recharge build | MCB | Resource economy | Resource extension | Repair/healing/saves | Restore or conserve item charges | Reuse a high-value item instead of replacing it | Built to Last, Streetwise, item-specific support; Scavenger for relevant toolbox variants | Toolbox, Med-Kit or flashlight depending build | Roughly neutral | **Viable** | Uncommon | Stable | Medium–High | Multiply value of strong item/add-ons | Locker/recharge downtime; item denial | Optimizes **one item's lifecycle** rather than finding new items | Standard |
| R04 | Boon Support Network | Boon build, Booner | MCB | Totem economy | Zone support | Healing, stealth, recovery, objectives | Bless Totems to create shared area effects | Establish one or several team-benefit zones | Circle/Exponential/Shadow Step/Illumination/Steadfast combinations | None | **SWF favored**, Solo Q viable | **Situational / Viable** | Uncommon | Rising / reconfiguring | High existence / Medium current standing | Teamwide effects can serve several roles | Snuffing, Shattered Hope, setup/location cost | The **Boon infrastructure itself** is the build; 10.2 Illumination also accelerates blessing while a Boon is active. citeturn23view5turn22view8 | Deep |
| R05 | Totem Hunter / Cleanser | Totem build, Hex hunter | MCB | Totem economy | Counter-Hex | Healing/objective bonuses | Locate and cleanse Totems, convert cleanses into other value | Deliberately spend time neutralizing/using Totems | Small Game, Counterforce, Inner Strength, Overzealous, Detective's Hunch-type info | Map optional | Solo Q viable | **Situational** | Rare–Uncommon | Rising slightly after Small Game rework | Medium | Answer dangerous Hexes and trigger cleanse rewards | Dead investment against low-totem Killer build; can conflict with Boons | **Cleansing/searching**, not blessing | Light |
| R06 | Invocation Ritual | Invocation build, basement ritual | MCB / NSS | Secondary objectives | Teamwide ritual | Generator/info effects depending Invocation | Spend prolonged ritual time in basement for global/large effect | Sacrifice immediate labor and often personal safety for Invocation payoff | Invocation perks such as Weaving Spiders / Treacherous Crows family | None | **SWF favored** | **Situational / Experimental** | Rare | Stable / uncertain | Low–Medium current evidence | Obtain effects unavailable through ordinary actions | Large time/opportunity cost; interruption and downside conditions | Basement ritual is a distinct action economy rather than normal perk activation | Deep |
| R07 | Locker Utility / Head On | Locker build, Head On build | MCB / NSS | Secondary mechanics | Chase utility | Stealth, item recharge, healing | Enter/exit lockers for stun, concealment or perk activation | Treat lockers as repeatable tactical stations | Head On, Quick & Quiet, Deception, Inner Strength/Built to Last-type utilities | Rechargeable item sometimes | Roughly neutral; SWF enables bait plays | **Situational** | Rare | Stable | Medium | Ambushes, resets and multi-purpose utility | Predictable lockers; entering locker costs tempo | Multiple parts of the build deliberately depend on lockers | Light |
| R08 | Distraction / Misdirection | Meme stealth, deception build | NSS | Stealth/information denial | Misdirection | Chase avoidance | False notifications, decoys, fake locations | Make Killer investigate the wrong place | Diversion, Deception, Red Herring, Blast Mine, Mirrored Illusion-type effects | None | SWF favored for coordinated distractions; Solo Q usable | **Situational** | Rare | Stable | Medium | Create rotations or waste Killer time indirectly | Experienced Killers can recognize tells; inconsistent value | Wins through **false information**, not invisibility | Light |
| R09 | Obsession / High-Risk Aggro-Info | Object build, Obsession build, chase magnet | MCB / NSS | Chase / information | Killer attention | Aura reading, speed/support | Reciprocal aura exposure, Obsession swapping/link effects | Accept information risk to attract or read Killer | Bound by Obsession/Object, Blood Pact, Come-and-Get-Me/chase support variants | None | SWF favored for designated runner; Solo Q viable | **Experimental / Viable** | Unknown | Rising after 10.2 reworks | High mechanics / Low settled usage | Turn Obsession state and mutual information into intentional macro | Reveals user or depends on partner/Obsession state | **Exposure to the Killer is deliberately part of the engine** | Deep |
| R10 | Endgame Gate / Escape Shell | Endgame build, gate build, Hope build | RS / SMP | Endgame | Exit | Rescue, chase | Powered-gate triggers, gate speed, late Haste/heal effects | Save perk value for last generator onward | Wake Up!, Hope, Adrenaline, No One Left Behind, Down to the Last/Sole Survivor variants | Key rarely relevant to some variants | SWF favored but Solo Q viable | **Strong if reached** | Moderate | Rising / reconfigured | High | Convert close endgames into escapes/rescues | Multiple dead perks before endgame; no value in early collapse | Explicitly accepts early opportunity cost for late power | Standard |
| X01 | Solo-Q Generalist | Solo build, all-rounder, comfort build | GS | Cross-cutting | Flex | Info, chase, objectives, rescue | One answer to several independent failure modes | Stay useful without knowing teammates/builds/Killer | Common pattern: mobility + info/objective + rescue/reset + anti-tunnel/sustain | Any versatile item | **Solo Q favored** | **Strong** | Very Common as philosophy | Rising | High | Resilience to uncertainty and bad role allocation | Lower ceiling than full specialization in ideal conditions | Diversification is intentional, not lack of build identity | Deep |
| X02 | Coordinated SWF Flex Generalist | SWF flex, team flex shell | GS | Cross-cutting | Flex | Any | Build slots chosen relative to teammates rather than independently | Cover essentials across four players while retaining personal chase value | Flexible mix; anti-tunnel, chase, gen and rescue tools distributed across team | Items deliberately distributed | **SWF favored** | **Strong** | Common as philosophy | Stable / adapting to Intent System | Medium–High | Avoid redundant team tools while preserving flexibility | Depends on pre-match/voice coordination; difficult to define by one four-perk set | Unit of optimization is partly **the four-player team**, not one Survivor | Deep |

\*The two MMA labels are **provisional Stage 1.5 organizational judgments**, not substitutes for the separate Stage 1 major-archetype determination.

Several standing calls above are deliberately more conservative than common tier-list language. For example, the table calls Flashlight Save “Viable–Strong” rather than “meta” because NightLight's Background Player signal is only a few percent in the transitional window; rarity does not imply weakness, but it does argue against casually equating a recognizable saver role with broad population dominance. Conversely, DS's much larger transitional usage supports calling anti-tunnel a common cross-build module without requiring anti-tunnel to be a standalone major archetype. citeturn7search4turn7search8

## Strategy profiles

### Chase, survival, and personal contingency

**C01 — General Chase / Looping.**  
**Definition:** a build whose primary payoff occurs while personally occupying Killer attention, rather than merely carrying one escape perk. **Gameplay:** the user deliberately accepts or seeks chases and routes through strong structures to consume Killer time. **Structure:** mobility, vault efficiency, chase information and injured-state value are mixed rather than requiring one exact four-perk template. **Why:** extending one chase can buy multiple teammate actions. **Solo Q vs SWF:** fully playable solo; SWF makes deliberate “designated runner” macro more reliable. **Status:** strong and enduring. Community databases continue to publish explicitly tagged looping/chase builds, including combinations around Finesse, Resilience and chase information. citeturn22view1turn22view0

**C02 — Exhaustion Mobility Chase.**  
The defining choice is a planned Exhaustion trigger—window vault, run start, drop, injured activation or similar—that creates distance. The player routes partly around availability of that trigger and manages Exhaustion between chases. It is environment-neutral at baseline, although SWF can deliberately put the equipped player in chase. Sprint Burst itself was shortened from three seconds to two in 10.1, so the balance among individual Exhaustion perks should be re-verified rather than inherited from early-2026 guides. citeturn18view1

**C03 — Vault / Window Specialist.**  
This is now more distinct than it was before 10.2. Current Windows of Opportunity is specifically window-oriented and supplies vault-speed value; Spine Chill was also redesigned around warning plus temporary vault speed. A current “window build” therefore routes to repeatable vaults and attempts to win marginal vault timings, whereas the former Windows all-resource learning shell is no longer mechanically the same build. Solo and SWF both work; Killer anti-vault powers and blocked windows are natural counters. citeturn22view8

**C04 — Pallet / Resource Specialist.**  
Rather than maximizing vaults, this family manages finite pallet resources: finding usable pallets, knowing which have been consumed and sometimes resetting dropped resources. Its strategic value is avoiding dead zones and wasting fewer strong pallets. It is more communication-sensitive than a pure chase build because teammates alter the shared resource state. The loss of pallet information from Windows makes this distinction more practically important after 10.2. citeturn22view8turn22view1

**C05 — Fragile-Pallet Restoration.**  
Apocalyptic Ingenuity creates a genuinely different mechanic-centered plan: interact with a chest, then convert a broken pallet location into a Fragile Pallet. 10.1 reduced its setup from two chests to one and shortened the creation interaction, making it much more plausible as a deliberate build. It remains niche because secondary-objective setup is substantial and a Fragile Pallet is not equivalent to an untouched normal resource. citeturn18view1

**C06 — Chase Information / Routing.**  
This family purchases information rather than raw movement: Killer aura, resource state and nearby route options help the player decide where to take a chase before reaching a bad tile. Dark Sense and Premonition were both substantially repurposed in 10.2, increasing the pool of direct routing tools. The family is particularly useful in Solo Q and for players who do not already have perfect map-state knowledge. citeturn23view6turn22view8

**C07 — Stealth / Chase Avoidance.**  
The user plans to minimize Killer acquisition through aura denial, reduced sound and cautious positioning while continuing objectives. That makes it strategically different from chase-reset C08: C07 tries to prevent chase; C08 accepts contact and then vanishes. Current community builds still combine Stealth, Info, Gen Rush and Solo Queue tags, so “stealth” is not merely a meme category, although heavy avoidance can become harmful when it permanently transfers Killer pressure to weaker teammates. citeturn22view1

**C08 — Chase Reset / Disappearance.**  
Lucky Break/Quick & Quiet/Iron Will-type shells use a hit or LOS break as the moment to remove tracking cues and terminate pursuit. Their reward is not necessarily winning a long loop; it is making the Killer lose enough time searching that pursuit becomes irrational. The family is viable but less universal than conventional chase because it depends on terrain, tracking suppression and the Killer committing to the search. citeturn22view1

**C09 — Anti-Tunnel Package.**  
This is one of the clearest examples of a **module rather than a top-level archetype**. DS, Off the Record, Resurgence and related survivability pieces can be inserted into chase, repair, Solo-Q generalist and support builds. NightLight's recent DS co-use distribution includes Dead Hard, Resilience, Lithe, Windows, Deja Vu, Unbreakable and other unrelated roles, empirically supporting the cross-build interpretation. Its purpose is to make rapid repeat targeting costly; its counterplay is waiting, slugging or switching targets. citeturn7search4

**C10 — Anti-Slug / Self-Recovery Package.**  
Unbreakable, Plot Twist, WGLF and Boon: Exponential produce a coherent contingency ecosystem around the Dying state. A Survivor equipped for this can recover independently, accelerate pickup recovery or create an area where slugging is dangerous. The package is powerful only when the Killer's macro exposes it, which is exactly why it belongs as a module: it can be crucial without controlling the rest of the user's Trial. Current community databases explicitly maintain Anti-Slug as a build tag and show complete anti-slug shells. citeturn22view1

**C11 — Hook-State Transfer.**  
Shoulder the Burden deserves its own entry because its resource is **team hook-state distribution**. The user can remove a hook state from the rescued Survivor by accepting one personally, allowing a team to keep a tunneled or strategically important player alive longer. Current debate on Behaviour's forums explicitly centers on its unusually high coordinated-team leverage, and 10.2's live implementation does not use the proposed PTB-wide shared lockout. This makes it SWF-favored and strategically consequential, although one day of post-patch evidence is far too little to determine prevalence. citeturn22view7turn22view8

**C12 — Deterministic Self-Unhook.**  
Deliverance is not properly grouped with luck builds. The player first performs a safe rescue, thereby banking a guaranteed later self-rescue if hooked. It rewards controlling early altruism and changes how much teammate travel will be necessary. 10.1 increased its Broken penalty substantially, preserving the strategy while raising its post-escape cost. citeturn18view1

**C13 — Luck-Based Self-Unhook.**  
The historical “Kobe/luck” shell is retained only as legacy terminology. Its old identity depended on manipulating self-unhook attempts/probability through Slippery Meat/luck investment; 10.2 reworked Slippery Meat into a different rescue-related function. A current guide should therefore not present the old luck shell alongside Deliverance as if both remain parallel live self-unhook archetypes. citeturn22view8

**C14 — Self-Sustain / Self-Heal.**  
These builds spend slots or an item on independence: Self-Care/Botany-style healing, basement healing through Strength in Shadows, Inner Strength, Plot Twist or a Med-Kit can all express the same higher-level goal. They matter more in Solo Q because teammate location and willingness to heal are uncertain. The strategic argument is not that self-healing is always efficient; it is that access to a reset without teammate labor can solve match states other builds cannot. Road Life now creates a new generator-linked subtype rather than replacing this broader family. citeturn23view6turn22view1

**C15 — Haste / Movement Stack.**  
Conditional Haste perks such as Blood Pact, Made for This, Hope and partner/zone effects can form a recognizable “speed” shell distinct from one-shot Exhaustion. 10.2's Blood Pact rework gives the linked pair Haste after healing each other, making partner movement builds newly worth testing; however, stacking repeated modifier categories is now subject to the game's DR framework, and specific Killers/perks can constrain Haste further. Current prevalence is too poorly established for anything stronger than niche/experimental status. citeturn22view8turn23view8

### Generator and objective strategies

**G01 — General Generator Pressure.**  
A true gen specialist allocates multiple build or item resources to maintaining repair uptime and finishing strategically useful generators. Current user-built loadouts repeatedly label themselves “Gen Rush” and combine Deja Vu, Hyperfocus, objective information, item recursion and chase escape. The category is unquestionably real; what changed is the optimization problem, because 9.6 DR penalizes repeatedly stacking the same action-speed modifier. citeturn22view1turn23view8

**G02 — Toolbox Generator Specialist.**  
This deserves separation from generic gen speed because a Toolbox introduces finite charges, add-on selection, refill decisions and burst timing. Item add-on modifiers are explicitly excluded from DR, which gives item-centered repair a structurally different optimization profile from stacking several same-category perk modifiers. Built to Last and similar resource tools turn the build into an item-economy problem as much as a repair-speed problem. citeturn23view8turn22view1

**G03 — Critical-Generator / Three-Gen Breaker.**  
The player is optimizing **generator location**, not just completion time. Deja Vu and similar objective information identify dangerous clusters; repair burst or a Toolbox is then saved for the generator whose loss would leave the team trapped in an easily patrolled endgame. Communication improves the strategy because teammates can avoid accidentally creating the cluster, but it remains Solo-Q viable. It should not be merged into G01 because a raw-speed player can make objectively bad generator choices. citeturn22view1

**G04 — Cooperative Repair / Gen Duo.**  
Prove Thyself, Friendly Competition and allied support effects form a distinct team-pairing approach. The build deliberately seeks a teammate and converts co-repair into a temporary or local advantage rather than maximizing independent gen uptime. That creates different positioning and coordination requirements from G02/G03. DR makes extreme speed stacking less efficient, but does not erase the cooperative role. citeturn23view8turn22view8

**G05 — Manual Skill-Check Generator.**  
Hyperfocus still supports a real skill-check specialist, but its current identity is **manual**: the player needs compatible basic Great Skill Checks rather than relying on 10.1's familiar Stake Out conversion loop. This potentially raises the skill ceiling while lowering consistency. Because 10.2 has existed for only a day, the optimal replacement shell—and whether players abandon Hyperfocus rather than adapt—is unresolved. citeturn22view8

**G06 — Classic Stake Out–Hyperfocus Engine.**  
This is the report's clearest legacy entry. Immediately before 10.2, current community-build pages were still publishing Stake Out + Hyperfocus + Deja Vu/Built to Last combinations and explicitly describing Stake Out as the way to secure Hyperfocus checks. 10.2's special-check rule breaks that defining interaction. It should remain searchable on a website because players will continue encountering old “gen rush” guides, but it should be labelled **outdated**, not weak-but-current. citeturn22view1turn22view8

**G07 — Boon: Steadfast Repair Zone.**  
Steadfast turns a Boon into localized generator infrastructure: affected generators regress more slowly and Survivors repair them faster while the zone is active. Community builds were already combining it with Boon: Illumination, Overzealous and Flow State during 10.1. This is real enough for the catalog but too new for a strength verdict beyond viable/experimental; Totem placement and Killer snuffing are fundamental counterplay. citeturn23view9turn22view1

**G08 — Road Life Repair-to-Self-Heal.**  
Road Life's 10.2 rework creates a coherent hybrid loop: stay injured, repair generators, hit basic Great checks, then spend accumulated tokens to self-heal. Its strategic question is whether the future reset is worth remaining injured and investing attention into checks. That is an actual new play pattern and merits separate representation even if its eventual adoption is low. citeturn23view6

**G09 — Fast Track Rescue-to-Repair Tempo.**  
Fast Track now rewards successful unhooks with tokens that are converted into permanent generator progress on a later Great check. This differs from “repair speed” because the build's repair resource is generated through altruism. In a coordinated team, one player can intentionally own rescues and convert them into objective tempo; in Solo Q, competing rescuers make activation less predictable. citeturn16view2

**G10 — Fruits of Your Labor Objective-to-Reset Hybrid.**  
Aurora's Fruits of Your Labor banks generator-completion tokens and turns finishing a generator into short movement speed plus healing progress. The user therefore sequences generators and resets rather than simply chasing repair percentage. It is an emerging hybrid with confirmed mechanics but little mature adoption evidence. citeturn23view9

### Rescue, healing, and protection strategies

**A01 — Hook Rescue / Post-Unhook Reset.**  
This role owns two linked actions: reach the hook safely, then stabilize the rescued teammate. Kindred-type information helps choose the rescue; We'll Make It and similar tools make the subsequent heal efficient. 10.2 buffed several rescue/healing perks, so this should be treated as a live specialization rather than an old beginner archetype. It is Solo-Q viable because the role can be performed without voice, though duplicate rescue rotations remain a common coordination cost. citeturn22view8turn22view1

**A02 — Anti-Camp / Hook-Timer Control.**  
Reassurance and allied hook-state tools buy time when an immediate rescue would be strategically bad. The distinctive behavior is *delaying* rescue while teammates repair or reposition rather than charging the hook. Coordination strongly improves it, since teammates need to understand that the hook is being managed rather than abandoned. citeturn6search22

**A03 — Dedicated Healer / Triage.**  
A healer runs enough information and healing assistance that finding and resetting injured teammates is an intentional job. Empathy, Empathic Connection, We'll Make It and Botany-style perks are typical pieces; current community discussion treats “healing build” as a recognizable construction family rather than an isolated perk choice. DR means piling every healing-speed modifier together no longer produces the old linear return, encouraging information or utility in remaining slots. citeturn20search5turn23view8

**A04 — Hook-State-Scaled Fast Healing.**  
Do No Harm now directly scales its healing benefit with the target's hook states and rewards Great healing checks, creating a specialized **triage** logic: the closer a teammate is to death, the stronger the healer's investment becomes. This differs enough from generic A03 to deserve a subtype. Its actual strength cannot yet be established from one day of live evidence. citeturn22view8

**A05 — Protection-Hit / Tank.**  
The protection specialist deliberately spends personal health to preserve a teammate's chase, rescue or carry outcome. Mettle of Man and related protection/recovery perks can reward this repeatedly, but the build is inherently situational: a mistimed “tank” interaction can simply hand the Killer another down. SWF callouts improve target selection and make it easier to know when a body hit actually changes the outcome. Community build databases continue to tag altruistic/endurance shells consistent with this role. citeturn22view1

**A06 — Hook-Trade / Carry Bodyblock Protector.**  
This family specializes further into physical interference: blocking the Killer's path to a hook, taking a hit during rescue or deliberately exchanging who is chased/downed. It overlaps with Breakout and sabotage but is not identical; the resource being spent is principally **health state and collision space**, not hook destruction or a carried item. It is one of the most communication-sensitive roles in the catalog. citeturn7search8turn22view1

**A07 — Endgame Rescue.**  
This concentrates altruistic investment after generators are completed. No One Left Behind received substantial 10.2 buffs to late healing/unhooking and post-unhook Haste support, making a dedicated endgame rescuer more credible, while Hope/Wake Up-type pieces can handle the exit sequence. The limitation is straightforward: several slots may contribute almost nothing if the team never reaches endgame. citeturn22view8

### Pickup and hook-denial strategies

**P01 — Flashlight Save.**  
A flashlight saver shadows an endangered chase, preserves an angle on the pickup and times a blind during the Killer's animation. Background Player solves much of the positioning problem, while Bond/Empathy-type information helps the saver arrive before the pickup. NightLight's Background Player data show a recurring save ecosystem rather than random perk pairing. Skilled Killers can face walls, fake pickups, chase the saver first or leave the Survivor down. citeturn7search8

**P02 — Flashbang Save.**  
The objective is similar but the mechanics are sufficiently different to split. Flashbang does not require entering the Trial holding a flashlight, its resource is generated through generator work, and the save is based on placement/explosion timing rather than maintaining a beam angle. Background Player's co-use with Flashbang gives measurable support for the family. citeturn7search8

**P03 — Sabotage / Hook Denial.**  
The saver identifies the Killer's likely hook and destroys it before the carry arrives, often with Saboteur or a Toolbox. The Killer can counter by changing hook, hitting the saboteur first or dropping/slugging. Current community databases both tag Sabotage separately and publish Breakout/Saboteur/Boil Over/item-recursion shells, supporting treatment as a real role rather than an arbitrary perk combo. citeturn22view1

**P04 — Breakout / Carry Interference.**  
Breakout builds operate after pickup: the user stays dangerously close to the carry, improves the carried Survivor's escape pressure and frequently combines the effect with bodyblocking or sabotage. That creates a different risk profile from P03—the saver must follow the Killer rather than simply beat them to one hook. NightLight also finds Breakout frequently among Background Player users, reinforcing the overlap among current save roles. citeturn7search8

**P05 — Teammate Pallet Save.**  
Pallet saves require the Killer to carry a Survivor through a live pallet while another Survivor is positioned to stun. There is no mandatory perk core, which is why this is a niche **strategy** rather than a perk archetype, but the gameplay, positioning and counterplay are distinct from light-based saves. It remains rare because pickup geometry and remaining pallet state must align; communication makes those conditions much easier to manufacture.

**P06 — Carry-Escape / Wiggle Denial.**  
Boil Over, Flip-Flop and Power Struggle belong to a self-oriented branch of pickup denial: the downed Survivor tries to make the Killer's carry unsafe or convert recovery progress into a pallet escape. A current community build explicitly combines Boil Over with looping/anti-slug concepts, while other user builds pair Breakout, Saboteur and Boil Over around carry pressure. The strategy is real but heavily map-, hook- and Killer-decision-dependent. citeturn22view1

### Information, items, and secondary mechanics

**I01 — Solo-Q Information Shell.**  
This is not simply “run Bond.” The build deliberately spends several slots on information that voice communication would otherwise supply: who is rescuing, where teammates are, which generator is dangerous and where the Killer is operating. Kindred/Bond/Open-Handed/Premonition/Deja Vu combinations are currently published under explicit Solo Queue and Info tags. 10.2's Intent System reduces—but does not eliminate—the need for this philosophy. citeturn22view1turn23view4

**I02 — Killer Tracking / Aura Seer.**  
Premonition now reveals the Killer's aura after the user looks toward them outside chase; Bound by Obsession/Object supplies reciprocal exposure; Alert and Dark Sense cover other trigger patterns. These can be stacked into an aura-reader shell whose purpose is early threat detection, safer objective commitment and better chase routing. Undetectable/aura suppression remain natural counters. citeturn23view6turn22view8

**I03 — Teammate Tracking / Support Information.**  
Bond, Empathy, Aftercare and Empathic Connection solve a different information problem: locating the people who need or can provide support. The shell is especially valuable to healers and Solo-Q players because it cuts search time. It should be represented as a package rather than a major archetype; its output feeds another job. citeturn22view1

**I04 — Objective / Resource Routing.**  
Deja Vu and related tools tell the player where work matters. This can be attached to gen pressure, Solo-Q generalism, stealth or critical-gen builds and therefore behaves as another cross-cutting package. Current community loadouts repeatedly pair Deja Vu with otherwise different identities—Stealth, Looping, Totems and Gen Rush—which supports the modular classification. citeturn22view1

**I05 — Salvation's Cry Chase Broadcast.**  
On chase start, Salvation's Cry reveals teammate auras to the chased player and broadcasts the chased Survivor/Killer information to others. That automatically performs a communication function which historically required voice or careful HUD interpretation. It has obvious Solo-Q potential, but the available evidence is too new to establish adoption or whether one slot is worth information that competent SWFs already call out. citeturn23view9

**R01 — Chest / Loot Scavenger.**  
10.2 turns chest play from primarily a novelty/economy gamble into a much more credible specialist loop. Plunderer's Instinct now provides unrestricted chest/item aura information, huge chest-opening speed and improved rarity odds. Appraisal/Ace in the Hole/Exultation-style tools can then broaden item yield or quality. The opportunity-cost question—whether opening chests beats repairing—remains unresolved, so “rising” should not be confused with “top meta.” citeturn23view6

**R02 — Pharmacy / Med-Kit Farming.**  
This is important enough to split from generic loot because **output is deterministic**: Pharmacy makes the chest produce a rare Med-Kit and now accelerates both opening and rummaging. In a coordinated team this can function as a resource-supply role, while Solo Q can use it for personal sustain. It is one of the highest-priority 10.2 experiments because the mechanics changed dramatically but no mature usage data yet exist. citeturn23view6

**R03 — Item Recharge / Recursion.**  
Built to Last and item-specific recursion shells aim to extract several “lives” from one good Toolbox, Med-Kit or flashlight. That produces different decision-making from R01: the player protects and recharges a known valuable item instead of rolling new items. Current community gen builds still repeatedly use Built to Last with repair packages, confirming that the resource-recursion identity persists. citeturn22view1

**R04 — Boon Support Network.**  
A multi-Boon build creates shared zones rather than personal buffs. Depending on composition those zones can support healing, anti-slugging, stealth, information or generators. 10.1's Steadfast added a serious objective option; 10.2's Illumination rework makes repeated blessing significantly faster while a Boon is already active, while Killer Shattered Hope now has stronger anti-Boon implications. That simultaneously increases Boon infrastructure's coherence and its counterplay. citeturn23view9turn23view5turn22view8

**R05 — Totem Hunter / Cleanser.**  
This role searches for Totems specifically to remove Hexes or activate cleanse-linked benefits such as healing/objective effects. 10.2 Small Game now gives direct nearby Totem aura information, strengthening the mechanic-centered identity. It remains situational because some Trials present little valuable cleansing and because cleansing a Dull Totem can conflict with a teammate's intended Boon. citeturn22view8

**R06 — Invocation Ritual.**  
Invocation builds are strategically recognizable because they replace ordinary repair/rescue labor with a long basement ritual that trades personal time/risk for a broader effect. Weaving Spiders/Treacherous Crows-style Invocation investments are therefore not arbitrary individual perks; using one changes where the Survivor goes and what they do for an extended interval. Current evidence for adoption and optimization is comparatively thin, so this report keeps the family but assigns low-to-medium confidence and **Deep** Stage 2 verification.

**R07 — Locker Utility / Head On.**  
Head On, Quick & Quiet, Deception, Inner Strength and Built to Last can make lockers into a network of stun points, disappearance tools, heals or item-recharge stations. Not every perk must be present: the common identity is intentional repeated locker interaction. It remains niche because locker positioning is map-dependent and experienced Killers can anticipate the play; current build databases nevertheless maintain Lockers as a distinct playstyle tag. citeturn22view1

**R08 — Distraction / Misdirection.**  
Diversion, Deception, Red Herring, Blast Mine and visual decoys target the Killer's information rather than the Survivor's visibility. The player tries to create a false reason to rotate, inspect a locker or check a generator. Current community builds even combine Red Herring with locker/Technician-style deliberate notification play, demonstrating that “misdirection” has a coherent behavioral identity despite being weak or meme-adjacent in many implementations. citeturn22view1

**R09 — Obsession / High-Risk Aggro-Info.**  
Object/Bound by Obsession-style play deliberately accepts reciprocal information or Killer attention, often paired with chase perks so the designated player is prepared for the consequence. 10.2 also reworked Blood Pact around a non-Obsession link and paired Haste, increasing the number of builds that care materially about Obsession state. It is currently better characterized as an experimental mechanic family than as a settled meta. citeturn22view8turn22view1

**R10 — Endgame Gate / Escape Shell.**  
Wake Up!, Hope, Adrenaline, No One Left Behind and the reworked Sole Survivor/Down to the Last represent several versions of the same macro wager: sacrifice early-game slot efficiency for a disproportionate advantage after generators are powered or the team collapses. 10.2 notably buffs Wake Up!'s team-scaled gate opening and changes the old Sole Survivor concept, so older “last Survivor gate rat” guides should not be assumed current verbatim. citeturn22view8

### Generalist philosophies

**X01 — Solo-Q Generalist.**  
A Solo-Q generalist is intentionally redundant across failure modes: a mobility/chase tool, an objective or information tool, rescue/reset capability and personal tunnel/sustain insurance is a recognizable construction philosophy even though the exact four perks vary. Current user builds explicitly mix Solo Queue with Stealth, Info, Gen Rush, healing, Anti-Tunnel and Anti-Slug tags. The strategy's strength is independence; its weakness is that it cannot match a fully specialized player at any one task. The Intent System may allow future Solo-Q generalists to spend slightly fewer slots replacing missing communication, but that is a hypothesis requiring post-10.2 testing. citeturn22view1turn23view4

**X02 — Coordinated SWF Flex Generalist.**  
A coordinated team's “generalist” operates differently: the player can remain broadly capable while deliberately avoiding duplication of tools already carried by teammates. Voice lets one Survivor cover anti-camp, another carry a saver item, another specialize repair, while each retains some personal chase/anti-tunnel protection. This is a real team-building philosophy, but the exact four-perk shell is too variable to turn into a single recommended loadout. The proper unit for Stage 2 is therefore the **team allocation logic**, not one supposed canonical SWF generalist build.

## Hierarchical strategy map

The ecology does **not** fit a pure tree. Anti-tunnel, information, item recursion and endgame insurance are cross-cutting modules that attach to several parents. The following map therefore distinguishes hierarchical children from cross-links.

```text
SURVIVOR STRATEGY ECOLOGY

Chase / Survival
├─ General Chase / Looping [C01]                  ← provisional major archetype
│  ├─ Exhaustion Mobility [C02]
│  ├─ Vault / Window Specialist [C03]
│  ├─ Pallet / Resource Specialist [C04]
│  │  └─ Fragile-Pallet Restoration [C05]
│  ├─ Chase Information / Routing [C06] ──────────────┐
│  ├─ Chase Reset / Disappearance [C08]               │
│  └─ Haste / Movement Stack [C15]                    │
├─ Stealth / Chase Avoidance [C07]                    │
├─ Self-Sustain / Self-Heal [C14]                     │
└─ Deterministic Self-Unhook [C12]                    │
   └─ legacy luck/Kobe shell [C13]                    │
                                                       │
Generator / Objective                                  │
├─ Generator Pressure [G01]              ← provisional major archetype
│  ├─ Toolbox Generator [G02]                         │
│  ├─ Critical-Generator / 3-Gen Breaker [G03]        │
│  ├─ Cooperative Repair [G04]                        │
│  ├─ Manual Skill-Check Gen [G05]                    │
│  │  └─ classic Stake Out–Hyperfocus [G06] LEGACY   │
│  ├─ Boon: Steadfast Repair Zone [G07] ───────┐      │
│  ├─ Road Life Gen→Self-Heal [G08] ───────────┼──────┼─ Self-sustain
│  ├─ Fast Track Rescue→Gen [G09] ─────────────┼──┐   │
│  └─ Fruits Gen→Reset Hybrid [G10]            │  │   │
                                                │  │   │
Rescue / Support                                │  │   │
├─ Hook Rescue / Reset [A01]                   │  │   │
│  ├─ Anti-Camp / Hook-Timer Control [A02]     │  │   │
│  ├─ Dedicated Healer [A03]                   │  │   │
│  │  └─ Do No Harm Triage [A04]               │  │   │
│  └─ Endgame Rescue [A07] ────────────────────┼──┼─ Endgame
├─ Protection-Hit / Tank [A05]                 │  │
└─ Hook Trade / Carry Bodyblock [A06] ──────┐  │  │
                                             │  │  │
Pickup / Hook Interception                    │  │  │
├─ Flashlight Save [P01]                      │  │  │
├─ Flashbang Save [P02]                       │  │  │
├─ Sabotage / Hook Denial [P03]               │  │  │
├─ Breakout / Carry Interference [P04] ───────┘  │  │
├─ Teammate Pallet Save [P05]                    │  │
└─ Self Carry-Escape / Wiggle Denial [P06]       │  │
                                                   │  │
Information                                        │  │
├─ Solo-Q Information Shell [I01] ────────────────┼──┼─ Generalists
├─ Killer Tracking / Aura Seer [I02] ─────────────┘  │
├─ Teammate Tracking [I03] ──────────────────────────┼─ Healer/rescue
├─ Objective / Resource Routing [I04] ───────────────┼─ Generator
└─ Salvation's Cry Chase Broadcast [I05] ────────────┴─ Chase/team macro

Items / Secondary Mechanics
├─ Chest / Loot Scavenger [R01]
│  └─ Pharmacy / Med-Kit Farming [R02] ───────────── Healing
├─ Item Recharge / Recursion [R03] ────────────────→ Toolbox / Med-Kit / Flashlight
├─ Boon Support Network [R04] ─────────────────────→ Healing / stealth / anti-slug / G07
├─ Totem Hunter / Cleanser [R05]
├─ Invocation Ritual [R06]
├─ Locker Utility / Head On [R07]
├─ Distraction / Misdirection [R08]
├─ Obsession / High-Risk Aggro-Info [R09] ─────────→ Chase / Haste / info
└─ Endgame Gate / Escape [R10] ────────────────────→ A07

Cross-build strategic modules
├─ Anti-Tunnel [C09] ────────── attaches to Chase / Gen / Generalist / Rescue
├─ Anti-Slug [C10] ──────────── attaches to nearly any build
├─ Hook-State Transfer [C11] ── Rescue + anti-tunnel + coordinated SWF macro
├─ Chase Info [C06] ─────────── attaches to chase/generalist
├─ Objective Routing [I04] ──── attaches to gen/generalist/stealth
└─ Endgame Insurance [A07/R10] attaches to otherwise unrelated shells

Generalist Shells
├─ Solo-Q Generalist [X01]
└─ Coordinated SWF Flex [X02]
   └─ may allocate dedicated:
      Chase / Gen / Healer / Saver / Anti-Camp roles across four players
```

This map is why **Flashlight Save, Flashbang Save, Sabotage, Breakout and Pallet Save should remain distinct catalog entries** even though they all sit under pickup interception. Flashlight and Flashbang differ in resource creation and timing; sabotage targets the hook; Breakout acts during carry; pallet saving depends on map resource geometry. NightLight co-use establishes that these strategies overlap in actual builds, but overlap is not identity. citeturn7search8turn22view1

Conversely, **anti-tunnel should not be forced under chase**. NightLight's DS ecosystem reaches chase, gen, recovery and generalist perks, so its best representation is a cross-cutting package that can be mounted on several strategic parents. citeturn7search4

## Merged, rejected, and borderline candidates

The following candidate concepts were investigated but are **not** given an independent catalog row.

| Candidate | Decision | Reason |
|---|---|---|
| “Second-chance build” | **Merged** | Too broad. Current meaningful pieces divide more cleanly into anti-tunnel C09, anti-slug C10, self-unhook C12 and self-sustain C14. |
| “Survivability build” | **Merged / tag only** | Describes output rather than a unique gameplay plan. |
| Old Windows pallet+window aura build | **Obsolete form merged into C03/C04/C06** | 10.2 changed Windows' strategic identity; preserving the old package as a separate live build would be misleading. citeturn22view8 |
| Raw vault-speed stacking | **Merged into C03** | A modifier package inside the broader window/vault plan; DR further discourages treating every speed stack as an independent family. citeturn23view8 |
| “Pallet build” as one category | **Split** | Resource routing C04, pallet restoration C05 and pallet saves P05 cause materially different behavior. |
| Generic Haste perk | **Tag only** | Individual Haste perks do not create a strategy; C15 requires deliberate multi-source movement planning. |
| Dead Hard build | **Merged into C02/C09** | Dead Hard is an Exhaustion/chase or anti-tunnel component, not currently enough on its own for a separate family. |
| Decisive Strike build | **Merged into C09** | One highly used perk does not establish a separate strategic family; DS co-use demonstrates modularity. citeturn7search4 |
| Off the Record build | **Merged into C09** | Same reason; anti-tunnel is the strategic object. |
| Plot Twist build | **Merged contextually into C10/C14** | Plot Twist serves recovery/self-sustain and niche interactions; no need to promote the perk itself into a taxonomy node. |
| Plot Twist + DS pickup trap | **Borderline niche interaction** | Recognizable counterplay exists, but present evidence does not justify a full family beyond anti-tunnel/self-recovery. |
| “Raw repair-speed stack” | **Merged into G01** | DR makes the exact stack especially patch-sensitive; strategy is gen pressure, not one arithmetic stack. citeturn23view8 |
| Deja Vu build | **Merged into G03/I04** | Primarily a critical-generator/routing module. |
| Prove Thyself build | **Merged into G04** | Cooperative repair is the strategy; Prove is one implementation. |
| Leader support build | **Merged into G04/A03/X02** | NightLight shows Leader paired with Prove Thyself, Deja Vu, Bond and healing/rescue pieces; the perk supports several roles rather than a unique plan. citeturn7search12 |
| Skill-check build | **Split** | Current manual Hyperfocus G05 and mechanically invalidated Stake Out–Hyperfocus G06 cannot be presented as the same current build. |
| ONE-TWO-THREE-FOUR! build | **Mechanic/tag only for now** | It appears in skill-check and deliberate-miss community experiments, but evidence is insufficient for a stable independent strategic identity. citeturn22view1 |
| Technician build | **Rejected as standalone** | Current usage is low and the perk mostly services beginner/error-control or deliberate-miss gimmicks rather than a recurrent strategic objective. |
| “Generator information” | **Merged into I04** | Information module, not separate from objective routing. |
| Med-Kit build | **Merged / split by purpose** | Self-use belongs C14; teammate healer use A03; chest-based Med-Kit supply R02. |
| Toolbox build | **Included as G02** | Item requirement and charge-management decisions are substantial enough to split. |
| Flashlight build | **Split by purpose** | Pickup-saving flashlight play is P01; ordinary chase blinding without a save objective is not sufficiently distinct for another entry. |
| Item-sharing build | **Merged into R01/R02/X02** | Team-resource distribution is real in SWF, but current evidence does not support a stable standalone loadout family independent of what item is being supplied. |
| Exultation item-upgrade build | **Merged into R01** | Recognizable item-economy interaction, but presently too perk-specific for its own strategic node. |
| Generic “loot” | **Included as R01** | 10.2 Plunderer changes make chest/item economy coherent enough to qualify. citeturn23view6 |
| Pharmacy | **Split into R02** | Guaranteed medical output creates different resource planning from random scavenging. citeturn23view6 |
| Boon: Exponential build | **Merged into C10/R04** | Anti-slug function and Boon infrastructure are the meaningful objects. |
| Boon: Shadow Step build | **Merged into C07/R04** | Stealth zone is a subtype/module, not enough evidence for a full independent family. |
| Boon: Illumination build | **Merged into R04/G07** | Primarily Boon infrastructure/routing support; its new blessing-speed effect may change this after more 10.2 data. |
| “Boon build” | **Included as R04** | Multiple Boons produce a recognizable shared-zone playstyle. |
| “Totem build” | **Split** | Blessing R04, cleansing R05 and generator-zone G07 have different objectives. |
| Inner Strength build | **Merged into R05/C14** | Cleanse-to-heal interaction is better treated as totem/self-sustain module. |
| Generic Invocation | **Included as R06** | Ritual action, location and opportunity cost are distinctive enough even at low prevalence. |
| Individual Invocation perk families | **Not split yet** | Current evidence is insufficient to establish mature sub-metas; Stage 2 should revisit. |
| Head On | **Merged into R07** | Locker use is the coherent strategy, Head On one anchor. |
| “Locker build” | **Included as R07** | Multiple repeated locker interactions create a recognizable play pattern; current build databases use Lockers as a playstyle tag. citeturn22view1 |
| Obsession perk | **Tag only** | Merely being Obsession does not establish a build; R09 requires deliberate exploitation of the state. |
| Blood Pact | **Merged into C15/R09** | Haste/partner and Obsession mechanics matter more than the perk name itself. |
| Dedicated aggro / chase magnet | **Merged into R09/C01** | Object-style deliberate exposure is the distinct mechanic; ordinary “please chase me” behavior without investment is not a separate build. |
| Carry bodyblock | **Merged into A06 with cross-link to P04** | Behavior is sufficiently real, but a separate entry would duplicate the same collision/health-state strategy. |
| Hook trade | **Merged into A06** | Same protection macro. |
| “Protection build” | **Represented by A05** | Protection hits create enough deliberate health-state economy to qualify. |
| Fast healing | **Split by role** | General healer A03 and hook-state triage A04; a mathematical speed stack alone is not a separate strategy under DR. |
| Self-Care-only build | **Merged into C14** | Individual perk does not define strategy. |
| Anti-camp rescue | **Included as A02** | Timing and Killer behavior being countered differ materially from generic hook rescue. |
| Endgame build | **Split** | Rescue-oriented A07 and gate/escape R10 produce different late-game behavior. |
| Hatch-only build | **Merged into R10 / legacy context** | Too narrow, highly state-dependent, and 10.2's Down to the Last/Sole Survivor changes invalidate older assumptions. |
| Gate-only Wake Up build | **Merged into R10** | One implementation of broader endgame/gate strategy. |
| Dedicated SWF “runner/gen/saver/healer composition” | **Organizational pattern, not separate row** | The individual roles are already C01/G01/A03/P01–P04. The team composition belongs in the hierarchy and Stage 2 team analysis. |
| “2+2 hybrid build” | **Construction pattern, not independent family** | Two perks for one role plus two for another is widespread, but the number “2+2” does not specify a coherent objective. It is captured by X01/X02 and hybrids G08–G10. |
| Meme sabotage-the-team Technician/Red Herring builds | **Rejected as strategic meta** | Current community examples exist, but intentional self/team grief or joke interactions do not meet the recurring legitimate strategic objective standard. citeturn22view1 |

Two borderline decisions deserve emphasis. **Pallet Save is included despite limited perk identity** because its positioning and counterplay differ materially from every other pickup denial. By contrast, **2+2 hybrid** is not separately cataloged because “two perks from category A plus two from B” says nothing about what the Survivor actually does; it is a construction grammar, not a strategy.

## Coverage audit

| Broad area | Coverage result | Where represented / finding |
|---|---|---|
| Chase | **One or more catalog strategies** | C01–C06, C08, C15 |
| Generator | **One or more catalog strategies** | G01–G10 |
| Survival | **One or more catalog strategies** | C07–C14 |
| Anti-tunnel | **Catalog strategy** | C09; intentionally cross-cutting rather than a top-level archetype |
| Anti-slug | **Catalog strategy** | C10; Boon Exponential cross-linked through R04 |
| Healing | **Multiple catalog strategies** | C14, A03, A04, R02 |
| Rescue | **Multiple catalog strategies** | A01, A02, A07, C11/C12 |
| Protection | **Catalog strategies** | A05/A06 |
| Pickup denial | **Multiple catalog strategies** | P01–P06; A06 cross-cut |
| Sabotage | **Catalog strategy** | P03 |
| Information | **Multiple catalog strategies** | I01–I05 plus C06 |
| Stealth | **Multiple catalog strategies** | C07/C08; R08 is misdirection rather than ordinary stealth |
| Items | **Multiple catalog strategies** | G02, P01, R01–R03 |
| Chests | **Multiple catalog strategies** | R01/R02; C05 uses chest interaction as setup |
| Boons | **Multiple catalog strategies** | R04 and G07 |
| Totems | **Multiple catalog strategies** | R04/R05/G07 |
| Invocations | **Catalog strategy** | R06; subtypes not yet split due evidence weakness |
| Lockers | **Catalog strategy** | R07 |
| Skill checks | **Current + legacy strategies** | G05 current manual form; G06 legacy Stake Out–Hyperfocus; G08 also uses Great checks |
| Exhaustion | **Catalog strategy** | C02 |
| Pallets | **Multiple catalog strategies** | C04/C05/P05/P06 |
| Vaults | **Catalog strategy** | C03; substantially altered by 10.2 Windows/Spine Chill changes |
| Luck / self-unhook | **Current + obsolete split** | C12 deterministic current; C13 classic luck form legacy |
| Endgame | **Multiple catalog strategies** | A07/R10 |
| Gate-focused strategies | **Catalog strategy** | R10 |
| Distraction / misdirection | **Catalog strategy** | R08 |
| Aggro / Killer attention | **Included under another parent** | R09/C01 rather than free-standing “aggro” category |
| Generalist builds | **Multiple catalog strategies** | X01/X02 |
| Solo-Q strategies | **Multiple catalog strategies** | Especially X01/I01/C14; Intent System is a major 10.2 context change. citeturn23view4 |
| Coordinated SWF | **Multiple catalog strategies** | C11, A05/A06, P01–P04, G04/G07, X02 |
| Hybrid builds | **Multiple examples; generic label merged** | G08–G10 are genuine directional hybrids; arbitrary “2+2” is not a strategy |
| Haste | **Catalog strategy** | C15 |
| Obsession | **Catalog strategy** | R09 |
| Self-sustain | **Multiple catalog strategies** | C14, G08, R02 |
| Item sharing / team resources | **Included under parent** | R01/R02/X02; insufficient evidence for separate node |
| Cooperative repair | **Catalog strategy** | G04 |
| Solo generator specialization | **Included** | G03 and G02 can be executed independently |
| Critical-generator control | **Catalog strategy** | G03 |
| Generator/generalist hybrids | **Multiple catalog strategies** | G08–G10/X01 |
| Hook-state transfer | **Catalog strategy** | C11 |
| Carry bodyblock | **Included under parent** | A06/P04 cross-link |
| Pallet save | **Catalog strategy** | P05 |
| Flashlight save | **Catalog strategy** | P01 |
| Flashbang save | **Catalog strategy** | P02 |
| Item recharge | **Catalog strategy** | R03 |
| Med-Kit specialization | **Included by purpose** | C14/A03/R02 rather than one generic “Med-Kit build” |
| Toolbox specialization | **Catalog strategy** | G02/P03 depending objective |
| Flashlight specialization | **Catalog strategy where strategically distinct** | P01 |
| Emerging 10.2 strategies | **Substantial coverage** | C03 new form, G05 new form, G08, A04, R01/R02, R04 changes, R09 changes, R10 changes |
| Strategies invalidated/displaced by 10.2 | **Explicitly represented** | G06 legacy; C13 legacy; old Windows all-resource shell merged/reclassified |

The audit also exposes where evidence quality is asymmetric. Pickup saves, anti-tunnel, gen/chase shells and Solo-Q information have multiple independent contemporary signals. **Invocation subtypes, Haste stacks, pallet saves and some Obsession experiments are clearly recognizable but lack adequate current usage evidence**; inclusion here means “real enough to represent,” not “proven common.” Conversely, 10.2 chest, Road Life and Do No Harm strategies have unusually strong **mechanical evidence** but almost no post-release adoption evidence because the patch is only one day old. citeturn23view6turn22view8

Pre-10.2 guide evidence was deliberately used only for discovery and continuity. For example, July 2026 guides identify generalist, Solo-Q, chase, anti-tunnel, generator, healing, flashlight-save, stealth and endgame families, while Otzdarva's 2026 resources provide expert context from earlier patches. Neither source can override October 10.2 mechanics; where a guide conflicts with the live patch, the live patch wins. citeturn22view0turn22view2

## Handoff to Stage 2

### Deep verification priority

The highest-priority Stage 2 targets are the strategies where either competitive importance is high or 10.2 has just invalidated the evidence base.

**General Chase / Looping (C01), Exhaustion Mobility (C02), Vault/Window (C03), Anti-Tunnel (C09), Anti-Slug (C10), Hook-State Transfer (C11), Generator Pressure (G01), Toolbox Gen (G02), Critical-Generator/3-Gen Breaker (G03), Manual Skill-Check Gen (G05), Boon: Steadfast Gen Zone (G07), Road Life hybrid (G08), Hook Rescue/Reset (A01), Dedicated Healer (A03), Flashlight Save (P01), Flashbang Save (P02), Sabotage (P03), Solo-Q Info (I01), Chest Scavenger (R01), Pharmacy/Med-Kit Farming (R02), Boon Network (R04), Obsession/Aggro-Info (R09), Solo-Q Generalist (X01) and coordinated SWF Flex (X02)** all deserve substantial verification.

Within that group, the most urgent post-10.2 questions are:

**Skill-check meta:** quantify how completely the Stake Out special-check change eliminates the old Hyperfocus engine, identify the best current manual Hyperfocus shells and determine whether Hyperfocus remains strategically relevant at all. Pre-patch community guides are demonstrably stale here. citeturn22view1turn22view8

**Windows/chase routing:** establish whether 10.2 Windows remains broadly competitive as a vault specialist, whether Dark Sense/Five Moves Ahead or other tools inherit the lost pallet-information role, and whether a new window-speed sub-meta settles around Windows + Finesse/Resilience/Spine Chill. citeturn22view8

**Shoulder the Burden:** determine actual Solo-Q versus SWF efficiency, how often coordinated teams distribute multiple hook states, what anti-tunnel combinations matter, and whether the live removal of the PTB-wide restriction materially changes high-level team macro. Current forum discussion identifies the dispute but does not settle it. citeturn22view7turn22view8

**Chest economy:** measure whether 10.2's very large Plunderer's/Pharmacy transaction-speed buffs overcome the opportunity cost of leaving generators, and whether Pharmacy becomes a legitimate team Med-Kit supply role rather than merely faster personal looting. citeturn23view6

**Boon objective play:** test Steadfast + 10.2 Illumination/Flow State-style infrastructure against realistic snuffing and the reworked Shattered Hope, especially in coordinated teams. citeturn23view9turn23view5

**Road Life and Do No Harm:** both have mechanically coherent new identities, but no honest conclusion about strength or prevalence is possible from roughly one day of live play. citeturn23view6turn22view8

### Standard or light verification

The website catalog should retain **Pallet/Resource Specialist C04, Fragile-Pallet Restoration C05, Chase Information C06, Stealth C07, Chase Reset C08, Deliverance C12, Self-Sustain C14, Haste C15, Cooperative Repair G04, Fast Track G09, Fruits G10, Anti-Camp A02, Do No Harm A04 if not promoted to Deep, Protection-Hit A05, Hook Trade/Bodyblock A06, Endgame Rescue A07, Breakout P04, Pallet Save P05, Carry-Escape P06, Killer Tracking I02, Teammate Tracking I03, Objective Routing I04, Salvation's Cry I05, Item Recharge R03, Totem Hunter R05, Invocation R06, Locker R07, Misdirection R08 and Endgame Gate R10** even if later analysis concludes many are only Situational.

Their Stage 2 task is mostly **boundary verification**: confirm that each remains behaviorally distinct, identify a small number of representative perk/item structures, and test whether any should be merged after the post-10.2 environment settles. They do not need the same statistical burden as a claimed top-level meta.

### No further verification needed

**Classic Stake Out–Hyperfocus G06** needs no strength investigation as a current build; the defining interaction has been invalidated by 10.2. It should receive only a concise legacy note explaining why older guides are stale. citeturn22view8turn22view1

**Classic Slippery Meat/luck self-unhook C13** likewise needs no current optimization study unless Stage 2 specifically addresses historical terminology. The current Slippery Meat design has moved away from that old strategic identity. citeturn22view8

The rejected standalone labels—**Dead Hard build, DS build, Deja Vu build, Leader build, generic 2+2 hybrid, generic second-chance build, generic survivability build, single-perk Totem/Boon/Obsession labels and deliberate team-sabotage gimmicks**—do not merit independent verification unless new post-10.2 evidence shows that one has developed a distinct recurring gameplay plan.

The principal **classification disputes** Stage 2 should resolve are whether General Chase and Generator Pressure are indeed major standalone meta archetypes under the separate Stage 1 standard; whether Hook Rescue/Support deserves comparable top-level status; whether Pickup Interception as a whole qualifies as a major archetype or should remain a parent grouping of specialist roles; whether Boon: Steadfast creates a durable generator subtype; and whether Solo-Q Generalist is sufficiently coherent to be treated as a strategy in its own right rather than merely a loadout philosophy.

The likely overlap with Stage 1 is therefore concentrated in **chase, generator pressure, support/rescue, generalist play and possibly pickup interception**. Stage 1.5's main contribution is beneath and across those top-level objects: it establishes that anti-tunnel, anti-slug, hook-state transfer, skill-check gen, toolbox gen, critical-gen control, healer/triage, flashlight, Flashbang, sabotage, Breakout, chest economy, Boons, Invocations, lockers, Totem hunting, information shells, endgame packages and other specialist strategies should **not disappear from the final site merely because they fail the threshold for “major meta archetype.”**

The central Stage 2 methodological requirement is to **re-sample after 10.2 has accumulated meaningful live data**. On October 7, official mechanics are high-confidence, but any claim that 10.2 has already produced a settled prevalence hierarchy would be false precision. NightLight's rolling statistics and the current community-build corpus remain primarily transitional 10.1 evidence; they establish that the underlying families exist, not where every freshly reworked family will ultimately rank. citeturn23view3turn22view1turn23view4