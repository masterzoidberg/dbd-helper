# Dead by Daylight Survivor Meta — Discovery at Patch 10.2.0

## Executive finding and live baseline

**Baseline verification: Patch 10.2.0 is the correct live baseline for the October 7, 2026 evidence cutoff.** Behaviour Interactive’s current live notes are headed **“10.2.0 | Mid-Chapter”** and contain the new Survivor Intent System plus the large general-perk balance pass. A targeted search for a Dead by Daylight 10.2.1/hotfix did not surface a later official live patch as of this cutoff. citeturn1search20turn20view0

The important qualification is timing: **10.2.0 is only about a day old.** That makes this a discovery report, not a stable post-patch tier list. The best public usage dataset available here, NightLight, updates daily and its pages were updated through October 7, but its displayed “last 14 days” rates necessarily contain overwhelmingly pre-10.2.0 matches. NightLight also states that its community statistics come from scoreboard screenshots uploaded by its own user base rather than Behaviour’s full population; it reports more than 300,000 registered users and more than 3 million tracked matches. citeturn21view3turn15view0

My conclusion is that **four strategies clear the discovery threshold as distinct current Survivor meta archetypes**, though two are substantially better established than the other two:

| Supported archetype | Discovery verdict | Confidence | Strongest environment |
|---|---|---:|---|
| **Chase Extension / Loop Specialist** | Clear meta archetype | High | Both; especially valuable with SWF role allocation |
| **Generator Pressure Specialist** | Clear meta archetype | Medium-High | SWF, but self-sufficient variants work Solo Q |
| **Pickup Interception / Save Specialist** | Meta archetype | Medium | SWF |
| **Rescue-and-Reset Support** | Provisional meta archetype | Medium | SWF; 10.2 may improve Solo Q |

The wider public-match meta, however, appears **more generalist than specialist**. Transitional NightLight usage is led by Lithe at 24.97%, Resilience at 22.85%, Déjà Vu at 19.59%, Windows of Opportunity at 19.4%, and Decisive Strike at 16.26%—a mix of chase, broadly useful action speed, objective routing, chase information, and anti-tunnel insurance rather than four perks all serving one specialized job. Hens’ pre-10.2 Solo Q recommendation likewise mixes Déjà Vu, Windows, Lithe, and Kindred. citeturn18view0turn18view1turn16view0turn17view2turn17view0turn21view1

So the best description of the current strategic environment is:

> **Generalist shells are the default public-match meta structure; specialized archetypes exist around chase, repair, pickup denial, and team preservation, and specialization becomes more attractive as coordination increases.**

That is a researcher inference from the usage distribution, expert build architecture, and Behaviour’s own recognition that effects such as Shoulder the Burden become especially powerful in coordinated groups. citeturn18view0turn16view0turn17view0turn20view2

## Evidence base and what 10.2.0 changed

The most important methodological problem is that **“current mechanics” and “current measured meta” are presently on different clocks**. Behaviour’s 10.2.0 notes are authoritative for mechanics. NightLight’s October 7 usage numbers are useful as the immediate pre-patch/transitional baseline, but cannot establish what players have settled on after 10.2.0. There is even a visible synchronization issue: NightLight’s October 7 Windows of Opportunity page still describes the old pallet/window/breakable-wall aura version, while Behaviour’s live 10.2.0 notes say Windows now reveals only nearby windows, grants 10% faster window vaults, and enters a 40/35/30-second cooldown after a vault. citeturn17view2turn20view2

That means this report treats NightLight **usage rates as transitional prevalence evidence**, but uses Behaviour—not third-party tooltips—for 10.2.0 mechanics. NightLight itself states that its pick/escape/kill rates reflect its users and their uploaded scoreboards, not the complete DBD player base. citeturn21view3

The 10.2.0 changes are unusually relevant to archetype discovery because they do not merely alter numbers; several changes **separate formerly bundled functions into more specialized perks**. Windows loses pallet information and becomes a window/vault perk, while Five Moves Ahead is explicitly specialized around the five closest pallets and pallet-drop movement. Dark Sense picks up broad pallet/window/survivor/killer information following generator completions. Behaviour explicitly says Five Moves Ahead is being specialized in pallets and that some of Windows’ learning/information function has moved to Dark Sense. citeturn20view1turn20view2

Repair strategy is also in flux. Friendly Competition now gives survivors who jointly finish a generator **10% faster repairs for 80/85/90 seconds**. At the same time, the classic Stake Out interaction changes materially: Stake Out now generates special skill checks granting extra progress, but Behaviour specifically says those special checks **no longer activate other Skill Check perks**. That directly undermines the old Stake Out–Hyperfocus engine as a packaged strategy. citeturn20view1turn20view2

Team-support options received broad attention. Empathic Connection now gives up to 40% faster healing of others; Flow State scales healing, unhooking, and totem speeds as generators finish; Kindred’s lower-tier killer-reveal radius was normalized upward; We’ll Make It now gives its 100% healing bonus for 70/80/90 seconds; Solidarity was improved; and several endgame altruism tools were strengthened. Shoulder the Burden was simultaneously given a much harsher Broken/injured cost, with Behaviour explaining that its previous downside was minor **“especially in coordinated groups.”** citeturn20view1turn20view2

Finally, 10.2 introduces the **Survivor Intent System**: survivors can send predefined in-match messages visible to the whole team. This is strategically important because some builds whose weakness was “my random teammates do not know what I am doing” may become more functional in Solo Q. There is not yet enough evidence to quantify how much of the SWF coordination advantage it actually closes. citeturn20view0

## Candidate findings

**Chase Extension / Loop Specialist — Classification: Meta Archetype. Evidence confidence: High. Advance to Stage 2: Yes.**

**Definition.** This is not simply the Chase role and it is not synonymous with running an Exhaustion perk. It is a build whose perk budget and play deliberately prioritize **making each committed Killer chase last longer**: reaching favorable tiles, converting windows or pallets into distance, and preserving enough resources to chain loops.

**Core gameplay plan.** The Survivor expects or actively accepts chase, routes toward usable structures, exploits movement/vault advantages, and attempts to convert the Killer’s time investment into generator time for the other survivors. That behavior is meaningfully different from a generalist who merely carries Lithe as one safety perk.

**Evidence for current relevance.** Hens maintains a dedicated “Best Chase Build” rather than treating chase as merely a perk slot; his published version combines Dramaturgy, Finesse, Resilience, and Hope. In the immediate pre-10.2/transitional NightLight data, Lithe is the most-used Survivor perk at 24.97% and Resilience second at 22.85%; Windows was fourth at 19.4%, with Windows users frequently pairing it with Lithe, Resilience, Finesse, Dead Hard, and Sprint Burst. That is strong evidence for an established chase-oriented ecosystem, although not every user of those perks is a chase specialist. citeturn21view2turn18view0turn18view1turn17view2

10.2.0 arguably makes the archetype **more conceptually distinct even while destabilizing its exact build**. Windows is now a window/vault specialization; Five Moves Ahead is explicitly a pallet specialization. Killers simultaneously received stronger anti-vault/pallet tools through Superior Anatomy, Unbound, Nothing but Misery, and the complete Knock Out redesign, which now punishes survivors for moving away after dropping a pallet. citeturn20view1turn20view2turn21view0

**Solo Q relevance:** High. A strong chase remains individually executable, and extending one's chase gives teammates time whether or not they communicate perfectly. The main Solo Q problem is that the player cannot guarantee teammates will convert that time efficiently.

**SWF relevance:** High. It becomes easier to let the strongest looper take aggro while teammates explicitly commit to objectives, making the role specialization itself more valuable.

**Likely defining perks/mechanics:** one Exhaustion/mobility engine such as Lithe, Sprint Burst, Dead Hard, or Dramaturgy; then some combination of Finesse, Resilience, the reworked Windows of Opportunity, Five Moves Ahead, and occasionally stealth/sound tools. **Exhaustion is a mechanic within the archetype, not the archetype itself.**

**Major uncertainty:** The old Windows-based chase information package has just been dismantled. Transitional usage therefore overstates the relevance of the *old* Windows implementation and cannot tell us whether 10.2 players will prefer new Windows, Five Moves Ahead, Dark Sense, or perk slots freed for something else. citeturn17view2turn20view2


**Generator Pressure Specialist — Classification: Meta Archetype. Evidence confidence: Medium-High. Advance to Stage 2: Yes.**

**Definition.** Merely doing generators is the Generator role. The archetype begins when the build deliberately invests several resources—perks and often a toolbox—into **high repair uptime, critical-generator selection, and throughput**.

**Core gameplay plan.** Identify strategically dangerous generator clusters, spend disproportionately large portions of the match repairing, preserve or replenish item charges where applicable, and force the Killer to respond before a favorable three-generator or late-game setup develops.

**Evidence for current relevance.** Déjà Vu is the third-most-used perk in NightLight’s transitional 14-day sample at 19.59%, and it directly combines critical-generator identification with a 6% repair bonus on the three closest generators. Its most frequent co-perks include Resilience, Hyperfocus, Prove Thyself, Stake Out, and multiple chase/safety options, showing both dedicated repair packages and hybrid use. Resilience itself is second overall and continues to grant 9% faster repair while injured. citeturn16view0turn18view1

The 10.2 balance pass provides fresh support for a repair-specialist concept through Friendly Competition: jointly completing a generator now gives the participating survivors a 10% repair boost for up to 90 seconds. At the same time, Behaviour has deliberately broken the old automatic Stake Out → other skill-check-perk interaction, so **“Hyperfocus + Stake Out” should no longer be treated as the defining modern generator archetype without new testing**. citeturn20view1turn20view2

**Solo Q relevance:** Medium to High. Déjà Vu makes critical-gen selection self-sufficient, but aggressive repair specialization is less safe when teammates' chase duration, rescue behavior, and generator selection are unknown. A Solo Q gen player therefore tends to need at least one escape or information slot.

**SWF relevance:** High. A team can deliberately allocate one or more survivors to repair, coordinate Friendly Competition triggers, communicate which generator is being defended, and have another player perform rescue/chase duties.

**Likely defining perks/mechanics:** Déjà Vu; Friendly Competition; Resilience; Hyperfocus if the player can generate great checks independently; Built to Last/Streetwise or analogous item-economy tools where a toolbox is central; repair-oriented item/add-on choices. Prove Thyself can be part of the package, but the archetype should not be equated with grouping on every generator.

**Major uncertainty:** There is essentially no mature post-10.2 performance dataset, and the Stake Out redesign may substantially rearrange dedicated skill-check builds. Diminishing Returns also means historical “stack every speed effect” intuition should not be imported uncritically into 10.2. Behaviour specifically notes that the perk pass was conducted in the context of the previously introduced Diminishing Returns system. citeturn20view0turn20view2


**Pickup Interception / Save Specialist — Classification: Meta Archetype. Evidence confidence: Medium. Advance to Stage 2: Yes.**

**Definition.** This combines flashlight, Flashbang, pallet-save, sabotage, and carry-interference variants under one functional archetype because their **primary plan is the same: prevent a down from becoming a hook**. “Flashlight build” and “sabo build” are therefore better treated as mechanical subtypes of the same strategic archetype unless later evidence shows different enough match plans.

**Core gameplay plan.** Track or shadow an endangered teammate without revealing yourself, position before or immediately after the down, close distance during the pickup/carry window, then blind, stun, sabotage, bodyblock, or otherwise deny the hook. The player willingly sacrifices some generator uptime to create a high-leverage rescue opportunity.

**Evidence for current relevance.** Background Player appears on 3.49% of NightLight survivors over the transitional 14-day window, ranking 29th. More important than the raw rate is its **co-use structure**: Background Player users also disproportionately run Breakout (18.74%), Bond (17.48%), Saboteur (15.62%), Flashbang (14.33%), Empathy (11.73%), We're Gonna Live Forever (11.24%), and Champion of Light (9.84%). That is exactly the sort of clustered perk selection expected from a coherent build-and-play archetype rather than a generic role label. citeturn15view0

Flashbang independently sits at 2.9% usage/rank 32 in its surfaced transitional sample, and 17.3% of Flashbang users also carry Background Player. citeturn22search3

**Solo Q relevance:** Medium. Bond or Empathy can replace verbal callouts, but the player has much less certainty about where a chase will end, whether another teammate is already going for the save, and whether abandoning a generator is worth the attempt.

**SWF relevance:** High. Voice communication materially improves positioning, tells the save player when a teammate expects to go down, and supports coordinated sabotage/bodyblocking. This is the archetype with the clearest reason to become stronger as communication improves.

**Likely defining perks/mechanics:** Background Player is the strongest archetype marker; Bond/Empathy or comms for tracking; Flashbang, flashlight/Champion of Light/Residual Manifest, or a Saboteur/Breakout branch. **Item, blind, sabotage, and bodyblock are mechanics/tactics inside the archetype, not separate archetypes.**

**Major uncertainty:** Pick rates are materially lower than the generalist top perks, and a failed save can cost both generator time and another health state. Stage 2 therefore needs outcome evidence rather than assuming spectacular/high-salience saves are efficient merely because they are recognizable.


**Rescue-and-Reset Support — Classification: Meta Archetype, provisionally. Evidence confidence: Medium. Advance to Stage 2: Yes.**

**Definition.** “Healing” and “Rescue” by themselves are roles. The archetype is the more specific strategy of **protecting team hook-state economy and rapidly resetting injured/unhooked teammates**, with a build that makes those interventions substantially faster or changes who can safely absorb the Killer’s pressure.

**Core gameplay plan.** Monitor who is vulnerable or on death hook, take responsibility for important rescues, immediately convert rescues into efficient heals, and—where warranted—transfer hook-state pressure with Shoulder the Burden. Unlike Pickup Interception, it primarily works **after the hook/injury has occurred** rather than trying to prevent the hook.

**Evidence for current relevance.** Shoulder the Burden had 2.36% transitional usage/rank 38, and Behaviour’s 10.2 developer note is unusually revealing: the perk’s prior downside was considered minor relative to its effect **“especially in coordinated groups,”** leading Behaviour to make the user injured and Broken for 120–160 seconds after transferring a hook state. citeturn16view1turn20view2

At the same time, 10.2 strengthens a large set of complementary support tools: Empathic Connection reaches 40% faster healing of others; Kindred is improved at lower tiers; We’ll Make It now grants 100% faster healing after an unhook for 70/80/90 seconds; Solidarity is stronger and no longer excludes med-kit-assisted healing; Flow State scales heal and unhook speed as generators finish; and No One Left Behind receives stronger endgame rescue/healing values. citeturn20view1turn20view2

There was already evidence of a smaller anti-slug/reset ecosystem before the patch: We're Gonna Live Forever was at 4.67% in the surfaced NightLight snapshot and commonly paired with For the People, Botany Knowledge, Unbreakable, We’ll Make It, Shoulder the Burden, and other recovery/support perks. That particular page was last updated September 14, however, so it is strictly historical/transitional evidence. citeturn22search6

**Solo Q relevance:** Medium, potentially rising. Kindred and the new Intent System address part of support play’s information/coordination problem. Whether predefined messages are enough to make hook-state specialization efficient in random teams is not yet measured. citeturn20view0turn20view1

**SWF relevance:** High. Behaviour’s own Shoulder the Burden rationale specifically identifies coordinated groups as the environment where its effect is disproportionately valuable. citeturn20view2

**Likely defining perks/mechanics:** We’ll Make It, Empathic Connection, Shoulder the Burden, Kindred in Solo Q, Do No Harm/Solidarity/Flow State depending the branch, and potentially an anti-slug recovery perk. Healing itself remains a role/mechanic; what makes this an archetype is systematic hook-state preservation plus rapid reset behavior.

**Major uncertainty:** This is the archetype most likely to be a **10.2-created or 10.2-strengthened meta shift**, so its post-patch prevalence and actual match efficiency are presently unproven. It advances because the design support and strategic coherence are strong, not because post-patch statistics already confirm it.


**Anti-Tunnel Build — Classification: Module. Evidence confidence: High. Advance to Stage 2: No as a standalone archetype.**

**Definition and gameplay plan.** Decisive Strike, Off the Record, post-unhook Endurance/chase tools, and similar effects discourage or punish an immediate repeat chase. A player can devote an entire loadout to them, but the strategic function remains **insurance against one Killer behavior**, not a proactive match plan that naturally dictates what the survivor does while the Killer is not tunneling.

**Current relevance.** Decisive Strike is still extremely common in the transitional sample—16.26%, rank 6—and Hens’ published “Best Overall” build includes Decisive Strike alongside Dead Hard, Deliverance, and Unbreakable; he separately publishes an anti-tunnel build. That proves the package is strategically significant. It does not make it conceptually independent of chase, repair, or support archetypes: DS is routinely mixed into those shells. citeturn17view0turn21view1turn15view2

**Solo Q relevance:** Very high as insurance because the player cannot coordinate who will absorb pressure.  
**SWF relevance:** High, but teammates can supplement it with hook-state transfer, bodyblocks, and protection.

**Likely defining perks/mechanics:** Decisive Strike, Off the Record, Dead Hard or another post-unhook chase tool; occasionally Deliverance or Resurgence depending the purpose.

**Major uncertainty:** Exact tunneling incidence by MMR and post-10.2 patch is not established by the evidence gathered here. **Classification remains Module, Stage 2: No** unless Stage 2 is explicitly measuring killer tunneling counterplay rather than discovering Survivor archetypes.


**Anti-Slug / Recovery Package — Classification: Module. Evidence confidence: High. Advance to Stage 2: No as a standalone archetype.**

**Definition and gameplay plan.** Unbreakable, We're Gonna Live Forever, Soul Guard/Boon: Exponential-type effects and related pickup tools are designed to recover from the Killer leaving survivors down. They can radically swing a slugging sequence but usually sit inside broader generalist, rescue, or save builds.

**Current relevance.** The 10.2 surrender rules explicitly include the state where all Survivors are simultaneously dying, so multi-slug scenarios remain recognized by the live rules. Conversely, **Knock Out is no longer the old slug-supporting perk**: 10.2 completely repurposes it into a pallet-drop movement penalty. That removes one traditional reason to treat anti-slug as a permanent dedicated counter-build rather than modular insurance. citeturn20view0turn21view0

The pre-patch support signal still exists: We're Gonna Live Forever’s surfaced snapshot had 4.67% usage and Unbreakable remains a prominent component of Hens’ overall build. citeturn22search6turn21view1

**Solo Q relevance:** High-value insurance but difficult to coordinate.  
**SWF relevance:** More strategically exploitable because teammates know who has a pickup/recovery tool.

**Likely defining perks/mechanics:** Unbreakable, We're Gonna Live Forever, Soul Guard, Boon: Exponential or equivalent recovery effects.

**Major uncertainty:** Actual 10.2 slugging frequency. **Classification: Module; Stage 2: No** as a distinct meta archetype.


**Skill-Check Generator Engine — Classification: Mechanic/subtype of Generator Pressure; the old Stake Out engine is outdated. Evidence confidence: High. Advance to Stage 2: No separately.**

**Definition and plan.** Use great/special skill-check interactions to create extra generator progress. This has historically produced recognizable “Hyperfocus/Stake Out” builds.

**Why it is not independently promoted.** Its primary job is still repair pressure, so it is a mechanical subtype of the Generator Pressure archetype. More importantly, the legacy package has suffered a direct mechanical break: 10.2 Stake Out replaces basic checks with special checks, and Behaviour says those checks **no longer activate other Skill Check perks**. citeturn20view2

Pre-patch co-usage shows why older advice will linger: among Déjà Vu users, Hyperfocus appeared at 11.75% and Stake Out at 10.65%. Those numbers straddle a mechanics change and should **not** be taken as evidence that the same engine remains optimal after October 6. citeturn16view0

**Solo Q relevance:** Potentially useful because it is individually executable.  
**SWF relevance:** Still a repair subtype, not a separate team role.

**Likely defining mechanics/perks:** Hyperfocus, great-check generation, revised Stake Out, This Is Not Happening/Road Life variants depending testing.

**Major uncertainty:** Which new skill-check package, if any, replaces Stake Out–Hyperfocus. **Stage 2: No separately; test it inside Generator Pressure.**


**Chest / Item Scavenger — Classification: Niche or Unsupported as meta. Evidence confidence: Medium. Advance to Stage 2: No for now.**

**Definition and plan.** Spend early or midgame time opening/rummaging chests to create high-value items and convert them into later healing, repair, or utility.

**Evidence.** This is a genuinely coherent build family, not an invented label. Appraisal users strongly cluster with Moment of Glory (43.98%), Plunderer’s Instinct (42.3%), Ace in the Hole (26.61%), Specialist (20.73%), Apocalyptic Ingenuity (13.45%), and Streetwise (12.61%). But Appraisal itself appears on only 0.42% of survivors, ranking 105th in the transitional sample. That is good evidence for **a real niche package, not a current meta archetype**. citeturn15view1

10.2 makes it worth monitoring: Pharmacy now guarantees a rare Med-Kit from opened chests and dramatically speeds chest interactions/rummaging, while Plunderer’s Instinct gets global chest/item aura information, up to 200% faster chest opening, and improved item rarity. citeturn20view1

**Solo Q relevance:** Medium as a self-contained strategy, but opportunity cost is dangerous.  
**SWF relevance:** Potentially more efficient if the team deliberately assigns one scavenger, but there is no current evidence that this is competitive with simply bringing good items into the trial.

**Likely defining perks/mechanics:** Plunderer’s Instinct, Appraisal, Pharmacy, Ace in the Hole, Moment of Glory, Specialist, Streetwise; chest/item mechanics.

**Major uncertainty:** Almost the entire case for a resurgence rests on changes that went live one day before the cutoff. **Stage 2: No unless early 10.2 data shows a large adoption/outcome jump.**


**Boon-Centric Build — Classification: Mechanic/package, currently niche rather than meta archetype. Evidence confidence: Medium. Advance to Stage 2: No.**

**Definition and plan.** Invest multiple perks and time into establishing a persistent totem zone from which teammates obtain information, healing/recovery, movement, or stealth benefits.

**Evidence.** 10.2 does buff Boon: Illumination: it shows generator/chest auras within the Boon area and gives the owner dramatically faster blessing while a Boon is active. But Killer counterplay simultaneously becomes more explicit. Shattered Hope now destroys snuffed Boons and reacts whenever totems are blessed/cleansed/destroyed by blocking totems and revealing Boon auras; Dominance and the reworked Thrill of the Hunt also strengthen Killer interference with totem play. citeturn20view1turn21view0

This produces an identifiable **mechanic package**, but the discovery evidence does not establish either enough usage or a unique strategic objective separate from healing, information, or anti-slug support.

**Solo Q relevance:** Low to Medium because teammates may not exploit the zone optimally.  
**SWF relevance:** Medium where a team deliberately plays around the area.

**Likely defining perks/mechanics:** one or more Boon perks plus totem-location or blessing-speed support.

**Major uncertainty:** The simultaneous buff to Boon setup and Killer totem counterplay makes first-order theorycrafting unreliable. **Stage 2: No absent a measurable post-10.2 resurgence.**

## Solo Q, SWF, and the Killer pressures shaping Survivor strategy

The clearest Solo Q/SWF split is not “different games with completely different archetypes.” It is **different tolerance for specialization**.

Before 10.2, Hens’ published Solo Q shell—Déjà Vu, Windows, Lithe, Kindred—spread four slots across generator routing, chase, and hook information. That is a textbook generalist architecture: every perk is useful without requiring teammates to understand a specialized plan. The page has not yet been mechanically updated for 10.2—the Windows description is the old one—so it should be treated as evidence of pre-patch expert *build structure*, not current perk wording. citeturn21view1turn20view2

The NightLight distribution points the same way. The five prominent transitional perks span several jobs rather than clustering into one narrow function: Lithe 24.97%, Resilience 22.85%, Déjà Vu 19.59%, Windows 19.4%, and Decisive Strike 16.26%. By contrast, archetype-specific markers such as Background Player (3.49%) and Shoulder the Burden (2.36%) are much less common. Because NightLight is a self-selected community dataset and the period is mostly pre-10.2, this is not a population estimate, but it is reasonably strong evidence that **hybrid safety/objective/chase shells were much more common entering 10.2 than full role-specialist loadouts**. citeturn18view0turn18view1turn16view0turn17view2turn17view0turn15view0turn16view1turn21view3

The new Intent System could move Solo Q modestly toward specialization because survivors can now transmit predefined plans during a match. That plausibly helps a rescue player signal intent, a gen specialist communicate objective focus, or teammates avoid duplicate hook responses. This is an **inference**, not a measured outcome; one day of live play is nowhere near enough to establish whether it materially closes the communication gap with voice-chat SWFs. citeturn20view0

Several Killer-side pressures are particularly important:

**Tunneling and hook-state concentration remain strategically important.** Decisive Strike’s sixth-place transitional usage is strong evidence that anti-tunnel insurance remains valued, while Behaviour’s Shoulder the Burden change explicitly addresses the strength of redistributing hook states in coordinated groups. The Survivor response is therefore better modeled as an **anti-tunnel module inside generalist/chase builds**, plus a more specialized Rescue-and-Reset archetype in coordinated teams. citeturn17view0turn20view2

**Generator pressure has been strengthened in ways that punish passive or badly coordinated repair.** Dead Man’s Switch now blocks the first generator a Survivor leaves for more than two seconds after a hook for up to 40 seconds, with Behaviour explicitly saying the redesign is intended to encourage Killer pressure on the generator they want to defend. Distressing now slows repair by up to 8% for survivors in the Terror Radius, while Monstrous Shrine can make unattended generators regress at up to 200% speed when the Killer is away from a survivor on a Scourge Hook. These changes reinforce the value of deliberate generator selection and uptime, but also make blindly stacking four survivors on one objective less obviously correct. citeturn21view0turn20view1

**Chase pressure is more specialized around windows and pallets.** Superior Anatomy and Unbound were strengthened around Killer window vaults; Nothing but Misery adds a Survivor vault penalty; Knock Out now punishes moving away from a dropped pallet. Survivor-side Windows and Five Moves Ahead have likewise been separated into window and pallet functions. The likely result is not the disappearance of chase builds but a more explicit choice about *which chase resources a build is optimizing*. citeturn21view0turn20view1turn20view2

**Totem investment faces stronger counter-pressure.** Shattered Hope, Dominance, and the Thrill of the Hunt rework all increase Killer interaction with cleansing/blessing/totem defense, weakening the case for elevating “Boon” to a standalone current meta strategy merely because some Boon perks were buffed. citeturn20view1turn21view0

**Slugging remains a possible macro strategy, but one historical enabler just disappeared.** The live system still recognizes a state where all four survivors are simultaneously dying, yet Knock Out has been completely reassigned from its former slug-related identity to pallet chase control. That argues for preserving anti-slug insurance without assuming a dedicated anti-slug archetype should occupy four perk slots. citeturn20view0turn21view0

## Current Survivor Strategy Map

The critical point is that **archetypes, roles, mechanics, modules, and tactics are different layers**. Treating “Aura Reading,” “Gen,” “Anti-Tunnel,” and “Flashlight Saves” as four equivalent metas produces a misleading taxonomy.

```text
SURVIVOR STRATEGIC LANDSCAPE — PATCH 10.2.0
│
├── META ARCHETYPES
│   │
│   ├── Chase Extension / Loop Specialist
│   │   ├── primary roles: Chase
│   │   ├── mechanics: Exhaustion, vaults, pallet routing, aura/resource info
│   │   └── optional modules: anti-tunnel, endgame, stealth
│   │
│   ├── Generator Pressure Specialist
│   │   ├── primary roles: Generator / objective control
│   │   ├── mechanics: repair speed, skill checks, toolbox/item economy
│   │   └── optional modules: chase escape, anti-tunnel
│   │
│   ├── Pickup Interception / Save Specialist
│   │   ├── primary roles: Rescue / denial
│   │   ├── mechanical subtypes:
│   │   │     flashlight / Flashbang
│   │   │     sabotage / Breakout
│   │   │     pallet save
│   │   └── team tactics: bodyblocking, coordinated carry denial
│   │
│   └── Rescue-and-Reset Support
│       ├── primary roles: Rescue + Healing
│       ├── mechanics: fast healing, hook-state transfer, aura information
│       └── optional modules: anti-slug, anti-tunnel, endgame rescue
│
├── CROSS-ARCHETYPE MODULES
│   ├── Anti-tunnel
│   ├── Anti-slug / recovery
│   ├── Endgame / exit-gate
│   └── General survivability / second-chance package
│
├── MECHANICS / SUBTYPES
│   ├── Exhaustion
│   ├── Aura reading / information
│   ├── Skill checks
│   ├── Items / item recharge
│   ├── Boons / totems
│   ├── Lockers
│   └── Invocations
│
├── NICHE / EMERGING STRATEGIES
│   ├── Chest / item scavenger
│   ├── Boon-centric area control
│   ├── pure stealth / chase avoidance
│   └── Invocation-centric packages
│
└── TEAM TACTICS
    ├── split-generator pressure
    ├── bodyblocking
    ├── hook trading
    ├── pre-running / rotating away from pressure
    └── coordinated rescue timing
```

The map also explains why **Aura Reading is not a meta archetype**. Aura information appears in Solo Q generalist play, chase routing, pickup saves, generator selection, and rescue support. Kindred, Bond, Empathy, Déjà Vu, Dark Sense and similar perks answer different tactical questions. The common mechanic is information; it does not give the build one common primary gameplay plan. The 10.2 changes to Dark Sense and Kindred reinforce information’s cross-cutting nature. citeturn20view1turn21view1

Likewise, **Exhaustion is not an archetype**. Lithe being the most-used transitional perk does not mean “Exhaustion build” is the dominant meta strategy; Lithe can be the chase engine in a specialist build or simply the one escape slot in a generator/support/generalist shell. Its broad co-use with Windows, Resilience, Déjà Vu, DS, Five Moves Ahead, We’ll Make It, Kindred and other functions demonstrates precisely that modularity. citeturn18view0

**Bodyblocking and split-generator pressure are team tactics**, not builds. They matter greatly—especially in SWF—but a survivor can bodyblock while running almost any perk combination, and split pressure describes where teammates work rather than a perk-defined individual strategy.

**Invocations remain a mechanic/niche family rather than a supported meta archetype in this discovery pass.** No evidence retrieved demonstrated sufficient current prevalence or a unified post-10.2 primary plan to elevate “Invocation build” alongside the four surviving archetypes. Given the evidence standard in the prompt, absence of positive evidence is a reason **not** to promote it.

Finally, **the generalist shell should not itself be called an archetype** under the supplied definition. It has no distinct primary plan. It is better understood as a loadout architecture: commonly, one chase/mobility element + one objective or information element + one anti-tunnel/safety element + one flexible support/endgame slot. Its importance is that this architecture appears to be the *default answer to uncertainty* in public matches. The transitional usage distribution and Hens’ Solo Q build both support that interpretation. citeturn18view0turn18view1turn16view0turn17view0turn21view1

## Evidence Gaps

The dominant uncertainty is simply **post-10.2 sample size**. Usage pages current through October 7 may technically include some 10.2 matches, but a 14-day aggregation is overwhelmingly composed of games played under 10.1.x. A clean 10.2-only window is therefore the first requirement for Stage 2. NightLight’s own methodology also means the sample represents users who upload scoreboards, not a random draw from all DBD players. citeturn21view3turn15view0turn16view0

A second issue is **data-tool synchronization**. NightLight’s usage timestamps can be current even while its displayed perk description has not incorporated the 10.2 rework, as Windows of Opportunity demonstrates. Stage 2 should use Behaviour for mechanics, and treat each statistical site’s patch boundaries separately from its tooltip database. citeturn17view2turn20view2

The most important substantive gaps are:

**Chase composition after the Windows split.** We do not yet know whether old Windows users migrate to new Windows, Five Moves Ahead, Dark Sense, or simply another high-value perk. Because old Windows was fourth in transitional usage, this is potentially a major redistribution rather than a small balance adjustment. citeturn17view2turn20view2

**The new repair engine.** Stake Out’s interaction with other skill-check perks has been deliberately severed at the same time Friendly Competition was strengthened. Stage 2 needs to determine whether Hyperfocus remains part of top dedicated repair builds, whether Friendly Competition replaces some previous choices, and whether toolbox economy or simple Déjà Vu/Resilience hybrids outperform deeper specialization. citeturn20view1turn20view2

**Whether Rescue-and-Reset actually becomes meta rather than merely newly attractive.** Behaviour has buffed multiple support perks while nerfing Shoulder the Burden’s downside profile. The theoretical package is coherent, but no one-day dataset can establish whether survivors sacrifice enough generator/chase power to make a dedicated support slot optimal. citeturn20view1turn20view2

**Outcome efficiency of pickup-interception builds.** Their perk clustering is strong enough to establish an archetype, but raw use does not answer whether they outperform simply remaining on generators. Stage 2 should measure not only escape rate but hook preventions, attempted-save failure rate, generator-time opportunity cost, and performance by Solo Q versus coordinated teams. Background Player’s 3.49% usage indicates meaningful but non-mainstream adoption. citeturn15view0

**Actual tunneling and slugging incidence.** High DS usage shows perceived value, not the frequency or optimality of tunneling. Likewise, the existence of Unbreakable/WGLF and the all-dying surrender condition demonstrates relevance but does not measure how often dedicated anti-slug protection pays off. citeturn17view0turn20view0turn22search6

**Impact of the Intent System on Solo Q.** This may be one of the strategically largest changes in 10.2 because it affects coordination rather than numerical perk strength. Stage 2 should specifically test whether rescue duplication falls, whether specialized players can communicate their intent reliably, and whether the usual Solo Q premium on Kindred/Bond-style information falls. At the cutoff, any claim that Solo Q has “caught up to SWF” would be unsupported. citeturn20view0

**Specialist versus hybrid outcome data.** Current usage strongly suggests hybrids are more common, but prevalence and strength are different questions. The crucial Stage 2 comparison is not “Which perk is most popular?” but whether four-perk specialist packages produce better outcomes than a mixed shell after controlling, as far as possible, for player skill and premade status.

## Stage 2 Candidate Set

Only four archetypes merit deeper verification from this discovery pass:

1. **Chase Extension / Loop Specialist.** Strongest evidence of an established specialist archetype, but its internal perk composition has just been disrupted by the Windows/Five Moves Ahead/Dark Sense redistribution. citeturn20view1turn20view2turn18view0

2. **Generator Pressure Specialist.** Clearly coherent and strategically central, with high transitional Déjà Vu usage and a major 10.2 shake-up from Friendly Competition plus the Stake Out interaction change. Stage 2 should explicitly split simple critical-gen/toolbox builds from skill-check-engine variants. citeturn16view0turn20view1turn20view2

3. **Pickup Interception / Save Specialist.** The Background Player–Breakout/Saboteur/Flashbang/information co-use cluster is strong evidence of a genuinely distinct build-and-play pattern. Stage 2 must establish whether the archetype is merely popular/high-salience or actually efficient, and how sharply SWF performance diverges from Solo Q. citeturn15view0turn22search3

4. **Rescue-and-Reset Support.** The least settled but most important emerging candidate. Behaviour has simultaneously strengthened fast-reset tools, improved Solo Q communication, and imposed a harsher cost on Shoulder the Burden specifically because of its strength in coordinated play. It merits verification precisely because the patch may have changed its status. citeturn20view0turn20view1turn20view2

**Not advanced:** anti-tunnel and anti-slug remain cross-archetype modules; skill-check play is a Generator Pressure subtype whose legacy Stake Out engine is outdated; Boons are a mechanic/package without sufficient meta evidence; chest/item scavenging is coherent but currently niche; and Aura Reading, Exhaustion, Items, Lockers, and Invocations are mechanics rather than standalone strategic archetypes. Team behaviors such as bodyblocking and split-generator pressure remain tactics.

The discovery-stage answer is therefore deliberately narrower than a typical “top Survivor builds” list: **four supported archetypes, embedded inside a public-match environment that still appears to favor flexible generalist shells over hard specialization—especially in Solo Q.** SWF is the main exception: communication makes dedicated generator, pickup-interception, and hook-state/support assignments more viable, and Behaviour’s own 10.2 Shoulder the Burden rationale directly supports the importance of that coordination effect. citeturn21view1turn20view2