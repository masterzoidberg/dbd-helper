# Dead by Daylight Survivor Meta Research — Stage Two Adversarial Verification

**Research date:** October 7, 2026  
**Authoritative live baseline:** **Patch 10.2.0 — Mid-Chapter**  
**Environment:** Standard 1v4 Survivor play  
**Primary comparison:** Solo Q versus coordinated SWF  
**Stage-one inputs:** *Dead by Daylight Survivor Meta — Discovery at Patch 10.2.0* fileciteturn0file1 and *Dead by Daylight Survivor Strategy Catalog: Stage 1.5* fileciteturn0file0

## Live baseline, evidence quality, and scoring model

As of **October 7, 2026, 10.2.0 remains the live patch baseline**. Behaviour Interactive's current live knowledge-base article is still **10.2.0 | Mid-Chapter**; a targeted search for an official 10.2.1 live patch did not surface a later Behaviour patch. Accordingly, there is **no patch-baseline change relative to Stages 1 and 1.5**, and no Stage 1 conclusion needs invalidation merely because a newer live build has appeared. citeturn11search14turn15search0

That does **not** mean Stage 1's conclusions are safe. Patch 10.2.0 has only just gone live, and the statistical evidence is much weaker than the mechanical evidence. Behaviour's patch notes are authoritative for live mechanics; NightLight's current rolling data are generated from scoreboard screenshots uploaded by NightLight users, rather than Behaviour's full player population. NightLight itself says its community statistics are aggregated from user-uploaded scoreboards. A 14-day window observed on October 7 necessarily consists overwhelmingly of pre-10.2 play, so all such figures in this report are classified **TRANSITIONAL / MIXED PATCH DATA**, not “the 10.2 meta.” citeturn11search11turn11search13turn11search15

This distinction is already visible in the data. NightLight currently reports Lithe at **25.11%**, Resilience at **22.85%**, Déjà Vu at **19.42%**, Decisive Strike at **16.5%**, Background Player at **3.56%**, and Shoulder the Burden at **2.36%** over its last 14 days. But several NightLight pages still display pre-10.2 perk descriptions, including the old Shoulder implementation; these rates are valuable for showing what ecosystem entered 10.2, not for proving what the stable post-10.2 ecosystem has become. citeturn17search2turn18search1turn18search2turn17search3turn17search1turn17search0

### Evidence classification

| Evidence | Patch classification | How it is used here |
|---|---|---|
| Behaviour 10.2.0 live notes | **POST-10.2 / OFFICIAL MECHANICS** | Authoritative mechanics |
| Behaviour 10.2 PTB-to-live changes | **POST-10.2 / OFFICIAL MECHANICS** | Resolves PTB/live discrepancies |
| NightLight current 14-day figures | **TRANSITIONAL / MIXED PATCH DATA** | Prevalence signal only |
| NightLight “since 10.1.0” co-use | **PRE-10.2-DOMINATED / TRANSITIONAL** | Build-family recognition |
| Current NightLight escape/build samples | **TRANSITIONAL / SELECTED SAMPLE** | Too confounded for causal strategy ranking |
| Stage 1 / Stage 1.5 | **Prior hypothesis set** | Classification claims to test |
| One-day 10.2 theorycrafting | **EARLY POST-10.2** | Low-confidence directional evidence only |
| Clean post-10.2 outcome data | **INADEQUATE / NOT YET AVAILABLE** | Cannot settle close calls |

The other system-level fact that materially changes optimization is **Diminishing Returns**. Since 9.6.0, repeated modifiers are successively discounted: the strongest applies fully, then lower matching modifiers at 50%, 25%, 12.5%, and 5% from the fifth onward. Behaviour explicitly exempts add-on modifiers. This makes “four perks that all increase the same action speed” less attractive relative to combining one strong engine with mechanically different utility, information or safety. citeturn14search1

### Power-score methodology

The requested twelve dimensions are scored **1–10**, but Solo Q and SWF use different weights because independence is intrinsically more valuable without voice coordination, while coordination scaling matters more in an organized team.

| Dimension | Solo Q weight | SWF weight |
|---|---:|---:|
| Consistency | 14% | 10% |
| Ceiling | 8% | 12% |
| Independence | 15% | 5% |
| Coordination Scaling | 2% | 13% |
| Matchup Coverage | 10% | 8% |
| Map Coverage | 8% | 6% |
| Tempo Efficiency | 13% | 14% |
| Slot Efficiency | 11% | 10% |
| Recovery Value | 6% | 6% |
| Snowball Value | 3% | 7% |
| Counterplay Resilience | 6% | 5% |
| Execution Reliability | 4% | 4% |

**Power = weighted dimension mean × 10.**

For this Stage 2 report, the numerical bands are:

**S:** 88–100  
**A:** 78–87  
**B:** 66–77  
**C:** 50–65  
**D:** below 50

These numbers are **researcher inference**, not observed win-rate estimates. An 84 does not mean “84% escape rate.” It means the strategy scores 84/100 under the stated decision model.

## Adversarial verdicts and disputed classifications

The Stage 1 hypothesis set does **not** survive intact. The strongest evidence supports **two major individual meta archetypes, not four**.

| Candidate | Previous classification | Stage 2 classification | Solo / SWF | Verdict |
|---|---|---|---|---|
| **M1 Chase Extension / Loop Specialist** | Meta Archetype | **CONFIRMED MAJOR META ARCHETYPE** | A 79 / A 86 | Confirmed, but pure four-slot chase builds are overrated |
| **M2 Generator Pressure Specialist** | Meta Archetype | **CONFIRMED MAJOR META ARCHETYPE** | A 84 / S 92 | Confirmed; strongest actual specialist meta |
| **M3 Pickup Interception / Save Specialist** | Meta Archetype | **PARENT STRATEGY FAMILY** | Individual subtypes C–B / B–A | Demoted |
| **M4 Rescue-and-Reset Support** | Provisional Meta Archetype | **PARENT STRATEGY FAMILY** | Strong components, no unified score | Demoted |

These changes are not cosmetic. Stage 1 defined Pickup Interception primarily by the common outcome “stop a down becoming a hook.” Stage 2 finds that this is too broad for an independent meta archetype because Flashlight, Flashbang, sabotage, Breakout/bodyblocking and pallet saves manipulate different resources, require different positioning, have different counterplay and impose very different opportunity costs. NightLight does show that a real **save ecosystem** exists: Background Player users disproportionately pair it with Breakout, Bond, Saboteur, Flashbang, Empathy, WGLF and Champion of Light. That evidence supports a **parent family**, not a single optimized archetype. citeturn17search1

Likewise, Stage 1's Rescue-and-Reset construct bundled several strategically different things: ordinary hook rescue, rapid post-unhook healing, anti-camp timing, hook-state redistribution, anti-slug recovery and endgame rescues. Patch 10.2 strengthens several of these independently—We'll Make It now provides its 100% healing bonus for 70/80/90 seconds, Empathic Connection reaches 30/35/40%, Flow State scales healing/unhooking with completed generators, and Shoulder the Burden now directly moves hook states at the cost of injury plus a long Broken period. These mechanics make the **support ecosystem stronger**, but they also make its internal differences clearer. citeturn13search0turn15search0

### Pickup Interception is a family, not one meta

**Previous classification:** Candidate M3 — Meta Archetype  
**New classification:** **PARENT STRATEGY FAMILY**  
**Reason for change:** the only universal element is the desired outcome. Flashlight/Flashbang prevent pickup conversion through blind/stun timing; sabotage attacks hook availability; Breakout/bodyblocking interferes during the carry; pallet saves depend on map geometry. The strategic plans are not interchangeable.

**Evidence supporting the change:** Background Player's 3.56% transitional usage is substantial enough to prove that saver specialization is real but far below the broad public usage of general chase/objective/safety perks. Its co-use cluster is distributed across Breakout 18.54%, Bond 17.48%, Saboteur 15.46%, Flashbang 14.23%, Empathy 11.71%, WGLF 11.3% and Champion of Light 9.93%. citeturn17search1

**Confidence:** **MEDIUM-HIGH classification confidence; LOW post-10.2 power confidence.**

The practical disposition is:

**P01 Flashlight Save:** ROLE SPECIALIZATION  
**P02 Flashbang Save:** ROLE SPECIALIZATION  
**P03 Sabotage / Hook Denial:** ROLE SPECIALIZATION  
**P04 Breakout / Carry Interference:** ROLE SPECIALIZATION  
**P05 Pallet Save:** NICHE STRATEGY  
**P06 Self Carry-Escape:** NICHE STRATEGY

### Rescue-and-Reset is also a family

**Previous classification:** Candidate M4 — Provisional Meta Archetype  
**New classification:** **PARENT STRATEGY FAMILY**  
**Reason for change:** rescuing, healing, anti-camping and transferring hook states are complementary but not one coherent enough four-slot strategy. A Survivor can be an elite rescuer with no healing specialization, a triage healer with no hook-state tool, or a Shoulder user primarily for anti-tunnel macro.

**Evidence:** Behaviour's own 10.2 Shoulder note says its prior downside was disproportionately small **especially in coordinated groups**, then changes it to injury plus 120–160 seconds of Broken. Behaviour also removed the PTB restriction that would have deactivated the perk for other Survivors, preserving team-level repeated hook-state redistribution across different users. citeturn13search0turn15search0

**Confidence:** **MEDIUM.** Mechanics confidence is high; power confidence is low because almost no clean post-10.2 match evidence exists.

### Solo-Q Generalist is not a meta archetype

**X01 is strategically coherent as a construction philosophy, but it fails the supplied meta-definition as an independent archetype.** Its defining principle is diversification, not one match plan. That does not make it weak. In fact, Stage 2 rates it the **strongest Solo-Q loadout architecture**, because it insures against uncertainty in killer targeting, rescue behavior, teammate quality and objective allocation.

**Previous classification:** Generalist Shell  
**New classification:** **GENERALIST CONSTRUCTION PHILOSOPHY / GENERALIST SHELL — unchanged in substance**  
**Solo score:** **90, S**  
**SWF score:** **77, B**

The distinction matters: “best Solo-Q construction” and “strongest meta archetype” are not the same question.

The transitional prevalence picture supports this. Lithe, Resilience, Déjà Vu and Decisive Strike are all much more common than specialist saver markers, and they cover chase, action efficiency, objective routing and anti-tunnel rather than forming one narrow specialist package. citeturn17search2turn18search1turn18search2turn17search3

### Coordinated SWF Flex is a team-building philosophy

X02 has the inverse problem. It becomes extremely strong in coordinated SWF, but the **unit of optimization is the four-player roster**, not one player's archetype.

**Classification:** **GENERALIST CONSTRUCTION PHILOSOPHY / TEAM-COMPOSITION FRAMEWORK**  
**Solo:** B 68  
**Coordinated SWF:** **S 93**

A good SWF can distribute objective routing, hook management, anti-tunnel, a saver resource and chase capacity without forcing each person to carry all of them. That is superior to four independent Solo-style generalists, but it still is not an individual meta archetype.

### The secondary disputes

**Boon: Steadfast creates a real generator subtype, but not a proven meta.** It makes generators in the Boon radius regress 50% slower and gives Survivors a 10% repair bonus at tier III. That plainly changes generator choice, Totem setup and zone control. Yet it is spatially dependent, costs setup time and is vulnerable to current anti-Totem tools such as Shattered Hope and Dominance. It is best classified **G07 — EMERGING / EXPERIMENTAL generator subtype**, C 62 Solo / B 70 SWF. citeturn14search2turn15search0

**The 10.2 chest economy is real as a strategy but not yet real as a competitive meta.** Pharmacy and Plunderer's Instinct received extremely large transactional buffs, while the pre-10.2 chest ecosystem was demonstrably niche: Appraisal currently sits at only 0.42% transitional usage, though Appraisal users heavily cluster with Moment of Glory, Plunderer's Instinct, Ace in the Hole and Specialist. The missing evidence is whether those faster transactions beat simply bringing a good item and repairing. citeturn11search3turn15search0

**Road Life creates a meaningful Generator → Self-Sustain hybrid.** At tier III, four basic Great repair checks while injured unlock a 10%-faster self-heal. That changes sequencing enough to merit G08 as its own emerging build: work while injured, bank the reset, heal when macro demands it. It is **B 68 Solo / C 62 SWF**, with the Solo advantage coming from independence. citeturn15search0

**Manual Hyperfocus survives; Stake Out–Hyperfocus does not.** Hyperfocus still rewards Great **basic** Skill Checks and presently has 5.09% transitional usage, but 10.2 Stake Out substitutes **special** checks, and Behaviour explicitly says special checks no longer activate other Skill Check perks. That destroys the defining automation/consistency mechanism of the classic combination. G05 Manual Skill-Check Generator remains B-tier high-skill specialization; G06 Classic Stake Out–Hyperfocus becomes **LEGACY / MECHANICALLY INVALID AS AN ENGINE**. citeturn18search0turn13search0turn13search9

**Windows / Five Moves Ahead / Dark Sense does not produce three new major chase metas.** It creates clearer **mechanical subtypes**: Windows now specializes in windows and gives 10% vault speed; Five Moves Ahead specializes in nearby pallets and faster post-drop movement; Dark Sense inherits broad pallet/window/team/Killer information after generator-completion triggers. Those alter chase-routing packages but do not independently satisfy the full meta-archetype test. citeturn13search0

**Anti-Tunnel and Anti-Slug remain modules.** Decisive Strike's 16.5% transitional usage and broad co-use ecosystem are evidence of anti-tunnel importance, not of a standalone proactive archetype. Anti-slug similarly depends on the Killer choosing a slugging line. Both are strong insurance layers; neither dictates enough of ordinary match behavior to become a major archetype. citeturn17search3turn18search15

## Solo Q and coordinated SWF rankings

These are **power rankings, not prevalence rankings**. Because clean post-10.2 outcome data are inadequate, close score differences—particularly below roughly five points—should not be read as statistically established superiority.

### Final Solo Q tier list

**S:**  
**X01 Solo-Q Generalist — 90.** The strongest architecture for uncertainty; not an independent meta archetype.

**A, strongest to weakest:**  
**C09 Anti-Tunnel Package — 85**  
**G03 Critical-Generator / Three-Gen Breaker — 85**  
**I01 Solo-Q Information Shell — 85**  
**C02 Exhaustion Mobility — 84**  
**G01 General Generator Pressure — 84**  
**G02 Toolbox Generator Specialist — 84**  
**I04 Objective / Resource Routing — 82**  
**A01 Hook Rescue / Post-Unhook Reset — 80**  
**C01 General Chase / Looping — 79**

**B:**  
C03 Vault / Window Specialist — 74  
C06 Chase Information / Routing — 72  
C11 Hook-State Transfer — 72  
C10 Anti-Slug / Self-Recovery — 71  
C12 Deterministic Self-Unhook — 71  
A03 Dedicated Healer / Triage — 70  
G05 Manual Skill-Check Generator — 70  
C14 Self-Sustain — 69  
I02 Killer Tracking — 69  
C04 Pallet / Resource Specialist — 69  
G08 Road Life — 68  
I03 Teammate Tracking — 68  
X02 Coordinated-SWF Flex philosophy outside its intended environment — 68  
C08 Chase Reset / Disappearance — 67  
R03 Item Recharge / Recursion — 67  
G04 Cooperative Repair — 66

**C:**  
A02 Anti-Camp — 65  
I05 Salvation's Cry — 65  
P02 Flashbang Save — 64  
G09 Fast Track Rescue→Repair — 64  
G10 Fruits of Your Labor — 64  
C07 Stealth / Chase Avoidance — 62  
G07 Boon: Steadfast — 62  
P01 Flashlight Save — 61  
A07 Endgame Rescue — 61  
A04 Do No Harm Triage — 60  
R02 Pharmacy / Med-Kit Farming — 60  
R09 Obsession / Aggro-Info — 59  
R10 Endgame Gate Shell — 59  
P03 Sabotage — 58  
R04 Boon Network — 58  
R01 Chest Scavenger — 56  
A05 Protection-Hit — 56  
C15 Haste Stack — 55  
P06 Carry-Escape — 52

**D:**  
A06 Carry Bodyblock — 48  
P04 Breakout Specialist — 48  
R05 Totem Hunter — 48  
R07 Locker Utility — 47  
C05 Fragile-Pallet Restoration — 46  
P05 Pallet Save — 43  
R08 Misdirection — 43  
R06 Invocation — 42  
C13 Classic Luck Self-Unhook — 20  
G06 Classic Stake Out–Hyperfocus — 18

The important result is not that Solo Q has a huge top-end specialist. It does not. The highest individual specialist/meta scores cluster in the low-to-mid 80s because **every pure role can be denied by Killer targeting or teammate behavior**. The strongest Solo construction is diversification.

### Final coordinated SWF tier list

**S:**  
**X02 Coordinated SWF Flex / Team Architecture — 93**  
**G01 General Generator Pressure — 92**  
**G02 Toolbox Generator Specialist — 91**  
**G03 Critical-Generator / Three-Gen Breaker — 91**

**A:**  
**C11 Hook-State Transfer — 87**  
**C01 General Chase / Looping — 86**  
**C02 Exhaustion Mobility — 86**  
**A01 Hook Rescue / Reset — 85**  
**C09 Anti-Tunnel — 82**  
**G04 Cooperative Repair — 80**  
**P02 Flashbang Save — 79**  
**C10 Anti-Slug — 78**

**B:**  
C12 Deliverance / Deterministic Self-Unhook — 77  
P01 Flashlight Save — 77  
A02 Anti-Camp — 77  
C03 Vault / Window — 76  
A03 Healer / Triage — 74  
R03 Item Recursion — 74  
C04 Pallet / Resource Specialist — 73  
G05 Manual Skill-Check Generator — 73  
I04 Objective Routing — 73  
P03 Sabotage — 73  
G09 Fast Track — 71  
G07 Boon: Steadfast — 70  
A07 Endgame Rescue — 70  
A05 Protection-Hit — 69  
C08 Chase Reset — 69  
A06 Carry Bodyblock — 68  
P04 Breakout — 68  
R04 Boon Network — 68  
G10 Fruits of Your Labor — 67  
A04 Do No Harm — 67  
R09 Obsession / Aggro-Info — 67  
C15 Haste Stack — 64

**C:**  
R10 Endgame Gate Shell — 64  
G08 Road Life — 62  
C06 Chase Information — 61  
R02 Pharmacy — 62  
R01 Chest Scavenger — 58  
P05 Pallet Save — 58  
I01 Solo-Q Info Shell — 57  
P06 Carry-Escape — 56  
I02 Killer Tracking — 56  
C05 Fragile-Pallet Restoration — 52  
C07 Stealth — 52  
R07 Locker Utility — 52  
I03 Teammate Tracking — 50

**D:**  
I05 Salvation's Cry — 49  
R06 Invocation — 49  
R08 Misdirection — 48  
R05 Totem Hunter — 45  
C13 Classic Luck Self-Unhook — 20  
G06 Classic Stake Out–Hyperfocus — 18

### Solo Q versus SWF delta

| Strategy | Solo | SWF | Delta | Environment bias | Why |
|---|---:|---:|---:|---|---|
| X02 SWF Flex | B 68 | **S 93** | **+25** | Strongly SWF Favored | Its entire advantage is team-level role allocation |
| A06 Carry Bodyblock | D 48 | B 68 | **+20** | Strongly SWF Favored | Requires synchronized carry-route interference |
| I03 Teammate Tracking | B 68 | C 50 | **−18** | Strongly Solo Q Favored | Voice largely replaces location information |
| I05 Salvation's Cry | C 65 | D 49 | **−16** | Strongly Solo Q Favored | Automatically broadcasts information voice already supplies |
| P01 Flashlight Save | C 61 | B 77 | **+16** | Strongly SWF Favored | Down location and save intent become predictable |
| P04 Breakout | D 48 | B 68 | **+20** | Strongly SWF Favored | Carry escort is exceptionally labor-inefficient without coordination |
| C11 Hook-State Transfer | B 72 | A 87 | **+15** | Strongly SWF Favored | Team can deliberately move death-hook risk |
| P02 Flashbang Save | C 64 | A 79 | **+15** | SWF Favored | Generated resource is strong when down timing is communicated |
| P03 Sabotage | C 58 | B 73 | **+15** | SWF Favored | Hook route and bodyblocks can be coordinated |
| G04 Cooperative Repair | B 66 | A 80 | **+14** | SWF Favored | Team controls when and where co-repair happens |
| X01 Solo Generalist | **S 90** | B 77 | **−13** | Strongly Solo Q Favored | Diversification loses value when duties can be distributed |
| I02 Killer Tracking | B 69 | C 56 | **−13** | Solo Q Favored | Callouts substitute much of the information |
| A02 Anti-Camp | C 65 | B 77 | +12 | SWF Favored | Team can exploit the time bought rather than duplicate rescues |
| C06 Chase Routing Info | B 72 | C 61 | −11 | Solo Q Favored | Experienced coordinated teams externalize map/Killer information |
| G02 Toolbox Gen | A 84 | **S 91** | +7 | SWF Favored | Team can protect the item user and route burst to critical gens |
| G03 Critical Gen | A 85 | **S 91** | +6 | SWF Favored | Communication prevents teammates from creating bad clusters |
| G01 General Gen Pressure | A 84 | **S 92** | +8 | SWF Favored | Repair labor can be intentionally protected and distributed |
| G08 Road Life | B 68 | C 62 | −6 | Solo Q Favored | Self-heal independence is worth less when resets can be called |
| C09 Anti-Tunnel | A 85 | A 82 | −3 | Slightly Solo Q Favored | SWFs supplement it through bodyblocks and hook-state management |

**Largest communication gain:** carry/pickup-denial roles, especially Breakout/bodyblocking and hook-state management.

**Largest communication loss:** information packages whose central purpose is to replace missing voice.

### Prevalence versus power

The evidence does not justify turning usage into a tier list. Lithe's 25.11%, Resilience's 22.85%, Déjà Vu's 19.42% and DS's 16.5% show broad applicability; Background Player's 3.56% and Shoulder's 2.36% show more specialized ecosystems. They do not prove the first group causes higher escape rates or that the second group is weak. citeturn17search2turn18search1turn18search2turn17search3turn17search1turn17search0

**Popular but overrated:** pure old-Windows chase shells; four-speed-modifier repair/healing stacks; dedicated anti-tunnel *packages* when one insurance slot would suffice.

**Strong but underplayed:** critical-generator routing and well-timed toolbox burst. Déjà Vu is already popular, but the strategic concept of deliberately protecting/attacking the dangerous cluster is stronger than treating it as a generic 6% speed perk. citeturn18search2turn14search1

**Niche but high-ceiling:** Flashbang/flashlight saves, Shoulder the Burden team macro, manual Hyperfocus.

**Common because easy and robust:** Lithe, Déjà Vu, Resilience.

**Rare partly because difficult:** pickup-interception specialists.

**Rare because currently weak/inefficient:** full Invocation, misdirection and most dedicated chest shells—subject to a major caveat that chest power has just changed.

## Confirmed meta profiles and optimal build construction

Only **M1/C01 Chase Extension** and **M2/G01 Generator Pressure** survive Stage 2 as independent major meta archetypes. The full-profile requirement therefore applies to these two. Other high-ranked entries are modules, subtypes, roles or construction philosophies.

### Chase Extension / Loop Specialist

**META ID:** M1 / C01  
**META NAME:** Chase Extension / Loop Specialist  
**Alternative names:** Runner, Looper, Chase Specialist  
**Classification:** **CONFIRMED MAJOR META ARCHETYPE**  
**Parent strategy:** Chase / Survival  
**Primary role:** Chase  
**Secondary roles:** Aggro absorption, resource management, team tempo creation  
**Defining characteristic:** Deliberately converting Killer attention into disproportionately long chase time  
**Solo:** **A, 79/100**  
**SWF:** **A, 86/100**  
**Environment bias:** Slightly SWF Favored  
**Meta trend:** Re-forming  
**Patch volatility:** **Medium-High**  
**Power confidence:** Medium  
**Mechanics confidence:** High

Stage 1 was correct that chase specialization is strategically more than “equip Lithe.” However, Stage 2 rejects the stronger implication that **maximal perk specialization** is optimal. Lithe remains NightLight's most common transitional Survivor perk at 25.11%, and Resilience second at 22.85%, which establishes a very large chase/general-value ecosystem but not a population of pure loop specialists. citeturn17search2turn18search1

**Long definition.** A Chase Extension build deliberately changes routing, perk allocation and risk tolerance so that being selected by the Killer is a favorable team event. The user routes toward structures their loadout enhances, preserves finite resources where possible, and values another 15–30 seconds of pursuit according to how much objective labor teammates can perform during it.

**Early game:** identify strong opening routes and avoid giving a free first hit before reaching usable geometry. In SWF, the player can deliberately expose position when taking the first chase benefits the team.

**Midgame:** preserve enough pallets/windows to avoid converting one good early chase into a dead-zone collapse later. Rotate pressure away from teammates on critical generators or death hook.

**Late game:** remaining pallets, exit-gate geometry and hook states matter more than raw theoretical loop strength. Chase perks that were strong early may lose relevance if the Killer camps an objective or refuses pursuit.

**Winning state:** Killer repeatedly invests time into a Survivor whose chase duration exceeds the team's repair/rescue opportunity cost.

**Losing state:** four chase-focused slots are equipped and the Killer simply ignores that Survivor, or the player burns resources without generating enough time.

**Why it works:** it manipulates **Killer time, generator labor, map resources, Killer travel and hook conversion**. Its value is team-multiplicative: thirty seconds in chase is not merely the runner's thirty seconds if two or three teammates use it productively.

#### Score profile

| Dimension | Solo | SWF |
|---|---:|---:|
| Consistency | 8 | 9 |
| Ceiling | 9 | 10 |
| Independence | 8 | 8 |
| Coordination Scaling | 5 | 9 |
| Matchup Coverage | 8 | 8 |
| Map Coverage | 8 | 8 |
| Tempo Efficiency | 9 | 10 |
| Slot Efficiency | 8 | 8 |
| Recovery Value | 6 | 6 |
| Snowball Value | 7 | 8 |
| Counterplay Resilience | 7 | 7 |
| Execution Reliability | 7 | 8 |

The SWF increase comes primarily from **role assignment**, not from voice making the player mechanically loop better.

#### Perk structure

**Core engine:** one reliable chase-mobility or chase-resource component. Lithe remains an excellent representative Exhaustion option, while the choice among Sprint Burst, Dead Hard, Lithe and other mobility effects depends strongly on execution and routing. Transitional usage establishes Lithe's popularity but does not prove it is uniquely optimal. citeturn17search2

**Windows of Opportunity:** now **common/optional rather than universally defining**. Live 10.2 Windows sees only windows within 24m, grants 10% faster window vaulting and enters a 40/35/30-second cooldown when a window is vaulted. Any guide still describing the old continuous pallet/window resource map is obsolete. citeturn13search0

**Five Moves Ahead:** common in pallet-specialist variants, not mandatory. It sees the five closest pallets while in Terror Radius/chase and changes post-drop movement. Behaviour explicitly describes it as the newly pallet-specialized counterpart to Windows. citeturn13search0

**Resilience:** common, high slot efficiency because its injured-state 9% tier-III bonus affects repair, healing, vaults, unhooks, sabotage, chests, Totems and gates rather than chase alone. Its broad functionality partly explains why it fits hybrids so well. citeturn18search1

**Finesse:** strong supporting chase perk, especially in a window-centric shell.

**Safety / insurance:** Decisive Strike or another anti-tunnel module is often more valuable than a third narrowly overlapping chase modifier. DS itself remains sixth in NightLight's mixed 14-day usage at 16.5%. citeturn17search3

**Trap / outdated inclusions:** old Windows-as-total-resource-map recommendations; excessive vault-speed stacking without accounting for Diminishing Returns; three or four mechanically redundant chase-speed perks merely because all are “chase perks.” citeturn13search0turn14search1

#### Representative builds

**Solo Q representative:**  
**Lithe + Resilience + Finesse + Decisive Strike**

This intentionally stops at three chase-related functions and uses the fourth slot as personal tunnel insurance.

**Coordinated SWF representative:**  
**Sprint Burst or Dead Hard + Finesse + Resilience + Five Moves Ahead**

A team that can intentionally assign the runner can justify the fourth chase/resource slot more often than a Solo player.

**Beginner version:**  
**Lithe + new Windows + Resilience + Kindred**

New Windows is now specifically a window-learning/vault tool rather than the old pallet-map crutch. Kindred supplies Solo macro rather than more mechanical speed. citeturn13search0

**High-skill / ceiling version:**  
**Dead Hard + Finesse + Five Moves Ahead + Resilience**

Higher execution demand, better ability to convert close resources into repeated loops, but less independent information.

**General-perk-friendly framework:**  
**1 mobility/chase engine + 1 routing/resource slot + 1 universal efficiency/safety slot + 1 anti-tunnel/objective flex slot.**

That template is more robust than prescribing four fixed chase perks.

#### Item profile

**Best item:** usually **Med-Kit or no strategically dedicated item**. A designated runner benefits from controlling their own reset; a coordinated team often gets more value by putting the premium toolbox on a player expected to stay on generators.

**Item dependency:** **Low.**

A flashlight can add interaction after pallet stuns but changes the player's priorities enough that a dedicated Flashlight Saver should be classified separately under P01 rather than smuggled into the chase archetype.

#### Skill profile

**Skill floor:** 3/5  
**Skill ceiling:** **5/5**

Most important skills: looping, pathing, tile knowledge, map knowledge, pallet economy, Killer matchup knowledge, risk assessment and pre-running. Communication matters more for deciding **who should take pressure** than for mechanically executing the chase.

**Teammate dependence:** 2/5  
**Communication dependence:** 1/5 mechanical, 3/5 strategic  
**Role-assignment benefit:** 4/5

Solo Q can execute C01 perfectly and still lose value if teammates crouch or duplicate rescues. A 4-person SWF can explicitly tell three players to commit to generators when the runner reports a stable chase.

#### Intent System impact

**Overall impact: Minor to Moderate.** The Intent System cannot tell a Solo teammate exactly which tile the Killer is at or give continuous chase narration. It can, however, help communicate that another Survivor should remain on an objective or that someone else is handling a rescue. Behaviour's system consists of eight customizable predefined messages shown to the full Survivor team; it is not equivalent to voice. citeturn15search0

#### Matchups and maps

**Best against:** conventional basic-attack or tile-respecting Killers that must spend real time navigating windows and pallets.

**Weak against:** Killers whose powers bypass conventional tile geometry, ranged zoning that removes safe vault options, or highly mobile Killers that can quickly abandon an inefficient chase and pressure another Survivor.

10.2 also strengthens several Killer anti-vault options: Nothing but Misery adds a temporary Survivor vault penalty, while Superior Anatomy and Unbound improve Killer window interactions. That slightly increases the counterplay pressure on pure window specialization. citeturn15search0

**Map dependence:** **MEDIUM.** Window and pallet density matter, but general chase skill transfers broadly. C03's window specialization is much more map-sensitive than C01 as a whole.

#### Failure modes and opportunity cost

Common failures are burning strong pallets too quickly, routing to structures the equipped perks do not actually enhance, repeatedly trying to force the Killer to chase, greedily remaining injured for Resilience when a heal is strategically better, and using four slots on chase while contributing nothing when ignored.

**Opportunity cost: 3/5.**  
Perk slot cost 3; item cost 1; setup 1; travel 2; team labor 1; personal safety 3; generator tempo lost 3 when deliberately taking aggro; map dependence 3; communication requirement 1.

#### Counterfactual slot test

**Replace the third specialist chase perk with Déjà Vu, DS, Kindred or another universally strong tool. Does the build improve? Frequently, yes.**

This is the most important adversarial result for M1. **The archetype survives; pure perk specialization does not.** A Survivor who deliberately plays the runner role with two high-value chase perks plus universal utility can be stronger than a four-perk “looping build.”

#### Adversarial challenge

**Strongest case that Chase Extension is overrated:** the Killer chooses whom to chase. A four-slot runner can be turned into a perkless generator Survivor simply by being ignored. Good players already know tiles, reducing the value of information perks, while 10.2 and Diminishing Returns reduce the payoff of stacking multiple vault/speed modifiers.

**Response:** this is sufficient to keep C01 out of Solo S tier. It is not sufficient to reject the archetype. Chases are unavoidable over a full match, and an organized SWF can deliberately make the stronger runner an attractive or strategically necessary target. The correct adjustment is **fewer redundant chase perks**, not abandoning chase specialization. The transitional popularity of Lithe and Resilience also shows that chase capacity is valued even inside mixed builds. citeturn17search2turn18search1

### Generator Pressure Specialist

**META ID:** M2 / G01  
**META NAME:** Generator Pressure Specialist  
**Alternative names:** Gen Specialist, Objective Specialist, Gen Pressure  
**Classification:** **CONFIRMED MAJOR META ARCHETYPE**  
**Parent strategy:** Generator / Objective  
**Primary role:** Generator progress  
**Secondary roles:** Three-gen prevention, resource allocation, team tempo  
**Defining characteristic:** Build and match priorities are chosen to accelerate or protect completion of strategically important generators  
**Solo:** **A, 84/100**  
**SWF:** **S, 92/100**  
**Environment bias:** SWF Favored  
**Trend:** Stable at parent level, re-forming internally  
**Patch volatility:** Medium  
**Mechanics confidence:** High  
**Power confidence:** Medium

This is Stage 2's strongest confirmed major meta. The reasoning is not “gens are the objective, therefore gen perks are meta.” The archetype qualifies because serious specialization changes **which generators are chosen, where the player positions, how toolbox charges are spent, when they refuse a heal/rescue rotation, and which teammate should absorb pressure**.

Déjà Vu remains an especially efficient macro component: it identifies the three closest generators and adds up to 6% repair speed to them. Its current 19.42% mixed-window usage makes it one of the clearest public indicators that objective routing has broad relevance. citeturn18search2

**Early game:** identify the generator cluster most dangerous to leave for later; avoid mindlessly completing the safest edge generators.

**Midgame:** spend limited toolbox charges where breaking Killer control has the largest downstream effect, not merely on the first generator touched.

**Late game:** protect one or two critical completion lines and avoid creating a highly patrol-efficient final cluster.

**Winning state:** the Killer cannot simultaneously secure hooks and prevent critical generator completions.

**Losing state:** the specialist sits on safe low-value generators, over-stacks repair modifiers, or is tunneled while carrying an expensive toolbox and three dead objective perks.

**Resource economy manipulated:** generator charges, Survivor labor, Killer travel, repair burst, item charges and spatial generator layout.

#### Score profile

| Dimension | Solo | SWF |
|---|---:|---:|
| Consistency | 9 | 10 |
| Ceiling | 8 | 10 |
| Independence | 9 | 8 |
| Coordination Scaling | 6 | 10 |
| Matchup Coverage | 9 | 9 |
| Map Coverage | 8 | 8 |
| Tempo Efficiency | 10 | 10 |
| Slot Efficiency | 8 | 9 |
| Recovery Value | 5 | 6 |
| Snowball Value | 8 | 9 |
| Counterplay Resilience | 7 | 8 |
| Execution Reliability | 8 | 9 |

The model produces approximately **84 Solo / 92 SWF**.

#### Internal subtype hierarchy

**G03 Critical-Generator / Three-Gen Breaker — A 85 Solo / S 91 SWF.** This is arguably the most strategically important subtype because generator **selection** often matters more than a few percent of raw speed.

**G02 Toolbox Specialist — A 84 / S 91.** Strong because it adds burst and finite resource allocation. Current toolboxes are explicitly built as short repair bursts; for example, an Engineer's Toolbox has 16 charges and +100% repair speed, while Wire Spool adds 12 charges and Socket Swivels adds 30% toolbox repair speed. Add-on modifiers are exempt from the game's DR system. citeturn16search0turn16search1turn14search1

**G04 Cooperative Repair — B 66 / A 80.** More attractive in SWF because a team can manufacture Friendly Competition activation. In 10.2, jointly finishing a generator gives the participating Survivors 10% faster repairs for 80/85/90 seconds. citeturn13search0

**G05 Manual Hyperfocus — B 70 / B 73.** Still a real high-skill route, but no longer enjoys the classic Stake Out automation.

#### Perk structure

**Core:** Déjà Vu is the best general-purpose representative because it combines information with an objective bonus and directly targets bad final-gen geometry. It is **common, not mandatory**. citeturn18search2

**Toolbox economy:** Built to Last is a common resource extension option; its current version recharges a depleted item after locker time, with diminishing successive recharges. Its transitional usage is only 2.62%, illustrating that strong specialist tools need not be highly prevalent. citeturn17search5

**Resilience:** a strong hybrid complement while injured, but not a reason to remain injured in every circumstance. citeturn18search1

**Friendly Competition:** strong in a coordinated duo, mediocre when the Solo player cannot reliably control who finishes with them. The 10.2 buff raises its repair bonus to 10%. citeturn13search0

**Hyperfocus:** optional, high ceiling. It still stacks tokens by hitting Great **basic** Skill Checks; current mixed-window usage is 5.09%. citeturn18search0

**Stake Out:** **no longer Hyperfocus support.** Its current special checks add progress but do not trigger other skill-check perks. citeturn13search0turn13search9

**Safety slot:** one chase/anti-tunnel perk is often more efficient than a third repair-speed perk, especially under Diminishing Returns. citeturn14search1

#### Representative builds

**Solo Q representative:**  
**Déjà Vu + Built to Last + Resilience + Lithe**  
with **Commodious or Engineer's Toolbox**, prioritizing charge or repair-speed add-ons.

This is a 3+1 structure rather than a pure four-perk gen stack.

**Coordinated SWF representative:**  
**Déjà Vu + Built to Last + Friendly Competition + Resilience/safety flex**  
with an optimized Toolbox.

A SWF can arrange one co-repair finish to activate Friendly Competition, then split and apply its bonus separately.

**Beginner:**  
**Déjà Vu + Resilience + Lithe + Kindred**

This looks “too generalist” only if specialization is defined by having four perk names in one category. In actual play, a player who consistently prioritizes critical generators can remain a generator specialist while carrying safety tools.

**High-skill:**  
**Déjà Vu + Hyperfocus + Built to Last + mobility/safety flex**

Manual Great-check execution replaces the former Stake Out shortcut.

**Budget/general-perk-friendly:**  
**Déjà Vu + Resilience + Dark Sense + general safety perk.**

#### Items and add-ons

**Best item:** **Toolbox.**

**Recommended profiles:**  
For maximum short-window burst, Engineer's Toolbox; for greater total charge capacity, Commodious-style options. Wire Spool is a strong charge extension; Socket Swivels increases toolbox repair speed; Brand New Part can permanently reduce a generator's repair requirement by 10 charges after its difficult skill check. citeturn16search0turn16search1

**Item dependency:** G01 overall **Medium**; G02 **High**.

**Resource cost:** high if using premium Bloodweb inventory repeatedly.

**SWF effect:** substantially stronger because the team can deliberately protect the item carrier, call Killer movement and reserve burst for the generator that actually matters.

#### Skill profile

**Skill floor:** 2/5  
**Skill ceiling:** 4/5 overall; 5/5 for manual Hyperfocus

Required skills: generator macro, map knowledge, Killer travel estimation, item charge management, Great Skill Checks for G05, hook-state awareness and knowing when **not** to stay on a generator.

**Teammate dependence:** 2/5 Solo version  
**Communication dependence:** 1/5 Solo / 3/5 optimized SWF  
**Role-assignment benefit:** **5/5**

#### Intent System impact

**Moderate.** Predefined messages can help reduce duplicated rescue rotations and communicate broad objective intentions, but they cannot replace the granularity of “Killer left shack toward main, my gen is 80%, protect this side.” The system therefore narrows, rather than eliminates, the Solo/SWF gap. citeturn15search0

#### Matchups and maps

**Best against:** slower map-pressure Killers and setups where forcing the Killer to traverse between separated objectives is expensive.

**Weak against:** extreme mobility, strong generator interruption, and states where the specialist is repeatedly forced off the objective.

Patch 10.2 also introduces stronger Killer generator-pressure interactions, including Distressing's repair penalty inside Terror Radius and the reworked Monstrous Shrine's accelerated unattended regression while a Survivor is on a distant Scourge Hook. That increases the value of choosing and defending generators intelligently rather than maximizing paper repair speed. citeturn15search0

**Map dependence:** **LOW-MEDIUM** for G01 overall; **MEDIUM** for G03 because generator clustering is its defining concern.

#### Failure modes and opportunity cost

Common errors include repairing the nearest generator rather than the strategically important one; blowing all Toolbox charges on an uncontested opening generator; co-repairing when splitting labor is better; staying injured solely to preserve Resilience; stacking several matching speed effects into DR; sitting in a locker too long to recharge an item while a generator could simply be finished; and refusing a critical rescue because “I'm the gen player.”

**Opportunity cost:** 3/5 overall; G02 reaches 4/5 when premium item resources are counted.

#### Counterfactual slot test

Replacing a third repair perk with **Lithe, DS, information or rescue utility frequently improves the total build.**

This does **not** weaken the generator archetype classification. It changes what good specialization means. Generator specialization is best understood as **objective priority + one strong perk engine + item economy**, not four repair-speed modifiers.

#### Adversarial challenge

**Strongest argument that Generator Pressure is overrated:** every Survivor already repairs generators. A specialist may spend several perk slots shaving small amounts of time while a universal chase perk could prevent a 20-second-early down. DR reduces same-modifier stacking, the Killer can force the specialist into chase, and a premium Toolbox has finite charges.

**Response:** those objections defeat the naive “stack four gen perks” version. They do not defeat **critical-generator selection plus concentrated item burst**, which directly manipulates the Survivor win condition and scales unusually well with coordination. Add-ons being excluded from DR further strengthens the item-centered branch relative to perk-speed stacking. citeturn14search1turn16search0

## Strategy interactions, Solo construction, SWF composition, and counterplay

### Generalist versus specialist result

The Stage 1 proposition that public-match Survivor builds are generally more hybrid/generalist survives adversarial testing.

| Construction style | Solo Q | Casual SWF | Coordinated SWF | High-level SWF |
|---|---|---|---|---|
| **Pure specialist, four related slots** | Usually inferior | Conditional | Useful only for a few roles | Usually too brittle |
| **3+1 specialist** | Strong | Strong | Very strong | Very strong |
| **2+2 hybrid** | **Excellent** | **Excellent** | Excellent | Excellent |
| **Generalist** | **Best default** | Strong | Good | Lower ceiling than team distribution |
| **Team-distributed specialization** | N/A | Good | **Best** | **Best structural model** |

The key conclusion is **not** “specialization is bad.” It is that **role specialization and perk-slot specialization are different things**. A generator specialist can run only two objective perks and still spend most of the Trial making generator decisions. A designated runner can carry an anti-tunnel perk. A rescuer can keep one Exhaustion perk. The DR system further increases the opportunity cost of stacking several identical numerical modifiers. citeturn14search1

### Strongest Solo-Q architecture

The original Stage 1.5 structure remains essentially correct:

**Chase / mobility**  
+ **Objective / information**  
+ **Personal survival / anti-tunnel**  
+ **Rescue / flexible utility**

Patch 10.2 alters the exact perk choices but does **not** overturn that architecture.

A robust example is:

**Lithe — Déjà Vu — Decisive Strike — Kindred/We'll Make It/flex**

The Intent System slightly reduces the information premium, especially for basic rescue declarations, but predefined messages still do not tell random teammates everything voice communication would. That is why I01 remains A-tier Solo while falling to C in coordinated SWF. citeturn15search0turn18search21

**Solo construction verdict:** **2+2 and flexible generalist structures outperform pure specialists on expected match value.**

### Representative coordinated SWF architectures

**Balanced pressure architecture**

| Player | Strategic assignment | Typical structure |
|---|---|---|
| Runner / pressure absorber | Chase + anti-tunnel | 2 chase + 1 anti-tunnel + flex |
| Critical-gen specialist | Break dangerous generator clusters | Déjà Vu + item engine + safety |
| Hook-state / reset player | Rescue, Shoulder, fast post-unhook reset | Shoulder + We'll Make It/Reassurance + safety |
| Flex saver / second objective player | Remain productive until a credible save exists | saver engine + gen/chase flex |

This is the best all-purpose team model. The saver is **not** supposed to follow every chase from the start. Save specialization becomes efficient only when the team knows a down is likely and can turn proximity into a realistic hook denial.

**Objective-heavy architecture**

Two players prioritize critical generators/toolbox economy, one is the preferred chase receiver, and one is a rescue/flex player. Pickup saves are opportunistic rather than assigned as a permanent job.

This structure is especially strong because G01/G02/G03 all scale with communication, while excessive rescue shadowing has a direct labor cost.

**Anti-tunnel / hook-economy architecture**

One strong runner, one primary generator carrier, and two flexible players who collectively cover hook-state transfer, fast reset and anti-camp. One or two Shoulder the Burden copies are plausible because the final 10.2 version no longer globally disables the perk for teammates after one use, but **four copies are not justified by evidence**. Behaviour itself recognized the perk's particular strength in coordinated groups while substantially increasing its Broken penalty. citeturn13search0

### Do four pure specialists outperform hybrids?

**No.**

A team of one four-perk runner, one four-perk generator player, one four-perk healer and one four-perk pickup saver creates severe failure cases:

the runner can be ignored; the healer can face Plague or a match where healing is low priority; the saver can lose minutes shadowing a Killer who faces a wall; the gen specialist can be tunneled immediately.

A better coordinated team has **specialized responsibilities but hybridized loadouts**. The strategic role can be narrow while individual perk allocation remains resilient.

### Dedicated healer verdict

A designated **triage responsibility** can be useful. A dedicated four-perk healer is generally not.

10.2's 40% Empathic Connection, extended We'll Make It and hook-state-scaled Do No Harm make fast reset significantly stronger, but DR penalizes redundant action-speed stacking and healing itself can be the wrong macro choice. citeturn13search0turn14search1

**A03 score:** B 70 Solo / B 74 SWF.

A good healer still repairs until an injured teammate actually needs a reset. “I am the healer, therefore I seek every injured Survivor” is a failure mode.

### Dedicated generator player verdict

**Yes, worth protecting in organized SWF—particularly when that player carries the premium Toolbox and understands generator geometry.**

The role should not mean “never rescue.” Its value is that the team avoids randomly putting its strongest objective resources on the player most likely to spend the match in chase.

### Pickup-save labor test

The strongest adversarial criticism of pickup interception is **shadowing cost**.

Background Player's current co-use distribution proves that a coherent save ecosystem exists, but the perk's 3.56% mixed-window prevalence is compatible with a role that is powerful in specific hands while not broadly efficient. citeturn17search1

A saver spending 30 seconds following a chase for a save that never becomes possible has consumed 30 seconds of Survivor labor. A successful save can erase a hook conversion and be match-changing; a failed one can cost both objective time and another health state.

Therefore:

**Pickup Interception is niche/high-ceiling, not a universal major meta.**

### High-priority strategy profiles

| ID | Strategy | Solo | SWF | Classification | Central finding |
|---|---|---:|---:|---|---|
| C02 | Exhaustion Mobility | A 84 | A 86 | META SUBTYPE | Excellent one-slot chase engine; not its own major meta |
| C03 | Vault / Window | B 74 | B 76 | MECHANIC BUILD | 10.2 Windows creates a real subtype, not a meta |
| C09 | Anti-Tunnel | A 85 | A 82 | MODULE | Close to mandatory as a *function* in many Solo builds; exact perk not mandatory |
| C10 | Anti-Slug | B 71 | A 78 | MODULE | Powerful insurance when activated, too conditional for major meta |
| C11 | Hook-State Transfer | B 72 | A 87 | MODULE | Among the largest Solo→SWF gains |
| G02 | Toolbox Gen | A 84 | S 91 | META SUBTYPE | Better optimization path than blindly stacking perk speed |
| G03 | Critical Generator | A 85 | S 91 | META SUBTYPE | Generator selection is strategically elite |
| G05 | Manual Skill Check | B 70 | B 73 | MECHANIC BUILD | Competitive at high skill, no longer an easy Stake Out engine |
| G07 | Steadfast Zone | C 62 | B 70 | EXPERIMENTAL | Real subtype; insufficient outcome evidence |
| G08 | Road Life | B 68 | C 62 | EXPERIMENTAL | Real gen→self-sustain hybrid, more useful Solo |
| A01 | Hook Rescue / Reset | A 80 | A 85 | ROLE | Very strong role; not enough to rescue M4 as one archetype |
| A03 | Healer / Triage | B 70 | B 74 | ROLE | Strong when damage needs resetting; poor as permanent full-time job |
| P01 | Flashlight Save | C 61 | B 77 | ROLE | High ceiling, costly failure modes |
| P02 | Flashbang Save | C 64 | A 79 | ROLE | Best current pickup-save branch by slot/item flexibility |
| P03 | Sabotage | C 58 | B 73 | ROLE | Communication-heavy, map/hook dependent |
| I01 | Solo-Q Info | A 85 | C 57 | MODULE | Intent narrows but does not erase its value |
| R01 | Chest Scavenger | C 56 | C 58 | EXPERIMENTAL | 10.2 makes it credible, not proven strong |
| R02 | Pharmacy | C 60 | C 62 | EXPERIMENTAL | Predictable Med-Kit economy; opportunity cost unresolved |
| R04 | Boon Network | C 58 | B 68 | MECHANIC BUILD | SWF can exploit zones; current counterplay remains substantial |
| R09 | Obsession Aggro-Info | C 59 | B 67 | EXPERIMENTAL | Strategically coherent but unproven |
| X01 | Solo Generalist | S 90 | B 77 | GENERALIST SHELL | Best Solo architecture |
| X02 | SWF Flex | B 68 | S 93 | TEAM PHILOSOPHY | Best coordinated construction model |

### Intent System by strategic function

| Function | Impact | Assessment |
|---|---|---|
| Rescue coordination | **Moderate** | Can reduce duplicate rescue rotations |
| Healing coordination | Minor–Moderate | Can signal broad intentions, not precise timing/location |
| Generator assignment | Moderate | Helps “split/commit” logic |
| Specialist-role signaling | Moderate | Better than no message, far weaker than voice |
| Pickup-save attempts | Minor | Lacks continuous down-position/timing narration |
| Anti-camp timing | Moderate | Helps communicate who is managing hook |
| Item distribution | Minor | Does not provide rich inventory logistics |
| Solo information perk demand | **Moderate reduction** | Does not make aura information obsolete |

Behaviour's design is explicitly eight predefined customizable messages visible to teammates, with muting/opt-out and anti-spam; bots can react to messages as of 10.2. It should therefore be modeled as **limited structured communication**, not “Solo Q now has comms.” citeturn15search0

### Killer counterplay by major family

**Generator Pressure:** vulnerable to forced displacement, extreme mobility and generator interruption. Killer perk changes such as Distressing, Monstrous Shrine and Undone directly target generator tempo. citeturn15search0

**Chase Extension:** vulnerable to tile-bypassing powers, ranged zoning, anti-vault effects and the Killer simply switching targets.

**Pickup saves:** Light-based saves lose against line-of-sight denial and Killer pickup orientation; all save builds lose value when the Killer scouts nearby Survivors, baits pickup, slugs briefly or changes hook route.

**Sabotage:** vulnerable to nearby alternative hooks, basement, Agitation/Iron Grasp-style carry enhancement and attacking the saboteur before committing.

**Healing:** naturally poor against anti-heal environments and against strategic states where repairing while injured is preferable.

**Boons:** directly exposed to Shattered Hope, Dominance and ordinary snuffing. 10.2 strengthens Shattered Hope and Dominance at the same time Survivor Boon infrastructure is improved. citeturn15search0

### Map profiles

**Chase:** Medium. Window and pallet quality matter, but C01 retains cross-map value.

**Vault specialist C03:** High. Its value is directly related to window availability and route quality.

**Generator specialist:** Low-Medium. All maps have the objective, but generator clustering strongly affects G03.

**Pickup saves:** Medium. Indoor LOS, pickup orientation and wall geometry affect light saves.

**Sabotage / Breakout:** High. Hook density, basement position and carry route are decisive.

**Boon Steadfast:** High. Totem location relative to strategically useful generators is fundamental.

**Chest economy:** Medium-High. Chest count, travel distance and the locations generated items must be carried from matter.

### Mandatory adversarial challenge for low tiers

**Chest economy could be underrated.** The old opportunity-cost argument may no longer hold after 10.2 because Plunderer's Instinct now massively accelerates chest opening and Pharmacy supplies deterministic Med-Kit output. That is a genuine reason not to lock R01/R02 into D tier. citeturn15search0

**Boon Steadfast could be underrated.** A coordinated team able to place its repair zone over multiple strategically valuable generators can get teamwide objective value rather than personal perk value. The reason it remains B/C rather than A is missing clean outcome evidence plus Totem locality/counterplay. citeturn14search2turn15search0

**Manual Hyperfocus could be underrated.** A truly consistent Great-check player still extracts value from Hyperfocus without Stake Out. Its 5.09% mixed-window prevalence suggests the perk is not merely historical. The reason it stays B is execution variance and the loss of the old consistency engine. citeturn18search0

**Invocation could be underrated.** A global effect unavailable through normal actions can justify substantial setup in certain coordinated plans. The present D rating reflects opportunity cost and insufficient current evidence, not a claim that every Invocation has zero competitive use.

**Pallet saves could be underrated.** They require no dedicated carried flashlight and can completely erase a pickup conversion. They remain C/D because the geometry and timing are not reliably manufacturable.

## Catalog disposition, legacy audit, and website taxonomy

### Final Stage 1.5 strategy-catalog status

Every Stage 1.5 ID is retained or deliberately reclassified below.

| ID | Final disposition | Notes |
|---|---|---|
| C01 | **META** | Confirmed major archetype |
| C02 | **META SUBTYPE** | Exhaustion mobility branch of C01 |
| C03 | **MECHANIC-CENTERED BUILD** | Current window/vault specialization |
| C04 | **MECHANIC-CENTERED BUILD** | Pallet-resource specialization |
| C05 | **EMERGING / EXPERIMENTAL** | Fragile-pallet restoration |
| C06 | **STRATEGIC MODULE** | Chase information/routing |
| C07 | **NICHE STRATEGY** | Stealth/chase avoidance |
| C08 | **META SUBTYPE** | Chase-reset branch |
| C09 | **STRATEGIC MODULE** | Anti-tunnel |
| C10 | **STRATEGIC MODULE** | Anti-slug |
| C11 | **STRATEGIC MODULE** | Hook-state transfer |
| C12 | **STRATEGIC MODULE** | Deterministic self-unhook |
| C13 | **LEGACY** | Classic luck self-unhook invalidated |
| C14 | **ROLE SPECIALIZATION** | Self-sustain |
| C15 | **MECHANIC-CENTERED BUILD** | Haste stacking |
| G01 | **META** | Confirmed major archetype |
| G02 | **META SUBTYPE** | Toolbox specialization |
| G03 | **META SUBTYPE** | Critical-generator control |
| G04 | **ROLE SPECIALIZATION** | Cooperative repair |
| G05 | **MECHANIC-CENTERED BUILD** | Manual Hyperfocus |
| G06 | **LEGACY** | Classic Stake Out–Hyperfocus engine |
| G07 | **EMERGING / EXPERIMENTAL** | Steadfast generator zone |
| G08 | **EMERGING / EXPERIMENTAL** | Road Life hybrid |
| G09 | **META SUBTYPE** | Rescue→repair conversion |
| G10 | **EMERGING / EXPERIMENTAL** | Objective→reset hybrid |
| A01 | **ROLE SPECIALIZATION** | Hook rescue/post-unhook reset |
| A02 | **STRATEGIC MODULE** | Anti-camp timing |
| A03 | **ROLE SPECIALIZATION** | Healer/triage |
| A04 | **EMERGING / EXPERIMENTAL** | Hook-state-scaled triage |
| A05 | **ROLE SPECIALIZATION** | Protection-hit play |
| A06 | **ROLE SPECIALIZATION** | Hook trade/bodyblock |
| A07 | **STRATEGIC MODULE** | Endgame rescue |
| P01 | **ROLE SPECIALIZATION** | Flashlight saving |
| P02 | **ROLE SPECIALIZATION** | Flashbang saving |
| P03 | **ROLE SPECIALIZATION** | Sabotage |
| P04 | **ROLE SPECIALIZATION** | Carry interference |
| P05 | **NICHE STRATEGY** | Pallet saves |
| P06 | **NICHE STRATEGY** | Self carry/wiggle escape |
| I01 | **STRATEGIC MODULE** | Solo-Q information package |
| I02 | **MECHANIC-CENTERED BUILD** | Killer tracking |
| I03 | **STRATEGIC MODULE** | Teammate information |
| I04 | **STRATEGIC MODULE** | Objective routing |
| I05 | **EMERGING / EXPERIMENTAL** | Chase broadcasting |
| R01 | **EMERGING / EXPERIMENTAL** | Chest economy |
| R02 | **EMERGING / EXPERIMENTAL** | Pharmacy Med-Kit economy |
| R03 | **MECHANIC-CENTERED BUILD** | Item recursion |
| R04 | **MECHANIC-CENTERED BUILD** | Boon network |
| R05 | **NICHE STRATEGY** | Totem hunter |
| R06 | **NICHE STRATEGY** | Invocation |
| R07 | **NICHE STRATEGY** | Locker utility |
| R08 | **NICHE STRATEGY** | Misdirection |
| R09 | **EMERGING / EXPERIMENTAL** | Obsession/aggro-info |
| R10 | **STRATEGIC MODULE** | Endgame insurance |
| X01 | **GENERALIST SHELL** | Solo construction philosophy |
| X02 | **GENERALIST SHELL** | SWF team-allocation philosophy |

No meaningful Stage 1.5 strategy needs outright **REMOVE** status. The catalog is explicitly meant to represent recognizable playstyles, not merely A/S-tier choices. C13 and G06 should remain searchable precisely because players will continue encountering stale historical guides.

### Legacy audit

| Old advice | Status | Stage 2 verdict |
|---|---|---|
| Old Windows pallet+window builds | **MECHANICALLY INVALID in old form** | Windows no longer supplies the old continuous pallet/window network |
| Stake Out + Hyperfocus | **MECHANICALLY INVALID as the classic synergy** | Stake Out special checks no longer activate other Skill-Check perks |
| Classic Slippery Meat luck build | **MECHANICALLY INVALID as old archetype** | Slippery Meat now accelerates other Survivors' unhook and adds post-unhook Haste |
| Old Sole Survivor gate/hatch shell | **OUTDATED** | 10.2 reworked it into Down to the Last with a new token/team-gate/hatch structure |
| Old Knock Out anti-slug assumptions | **MECHANICALLY INVALID** | Knock Out is now a pallet-drop/Hindered perk |

All five conclusions come directly from the live 10.2 notes rather than historical guides. citeturn15search0turn13search0

The Windows change is especially important. Behaviour explicitly states that its former learning function was moved toward Dark Sense, while Five Moves Ahead is being specialized around pallets. Old guides treating current Windows as a permanent live pallet atlas should carry an **OUTDATED PRE-10.2** warning. citeturn13search0

### Recommended website role taxonomy

The proposed taxonomy is directionally good but currently mixes **jobs**, **strategic goals** and **methods**. I recommend:

**Roles:**  
Chase, Generator, Rescue, Healing, Protection, Pickup Denial, Information, Self-Sustain, Recovery, Endgame, Utility.

**Merge or remove as top-level roles:**  
“Team Support” should be a broad UI group rather than a role because Rescue, Healing, Protection and Information already explain *how* support occurs.  
“Sabotage” should be a **role subtype/tag beneath Pickup Denial**, not equal to Pickup Denial.  
“Stealth” is better as a strategic style/tag than a team role.

**Strategic Modules:**  
Anti-Tunnel, Anti-Slug, Anti-Camp, Hook-State Transfer, Objective Routing, Chase Information, Endgame Insurance, Item Recursion.

**Add:** **Post-Unhook Reset** as a module. It is sufficiently different from general Healing and captures We'll Make It/Babysitter/related play more cleanly.

**Mechanic / archetype tags:**  
Exhaustion, Vault, Window, Pallet, Aura Reading, Skill Check, Toolbox, Med-Kit, Flashlight, Flashbang, Chest, Boon, Totem, Invocation, Locker, Haste, Obsession, Misdirection, Item.

**Add:** `Great Skill Check`, `Carry`, `Hook`, `Broken`, `Recovery`, and `Rummage`.  
**Merge:** generic `Item` remains a broad umbrella, but do not use it in place of Toolbox/Med-Kit/Flashlight.  
**Rename:** `Pallet` → `Pallet Resource` when used strategically, retaining plain `Pallet` as the mechanic tag.

**Tactics:**  
Pre-run, Bodyblock, Hook Trade, Chase Shadowing, Split Generators, Commit Generator, Heal Under Hook, Pickup Bait, Pallet Save, Carry Escort.

This avoids the taxonomy error of presenting “Bodyblocking,” “Aura Reading” and “Generator Specialist” as if they exist at the same conceptual level.

### Website filter recommendation

For a compact mobile interface:

| Filter | Visibility | Reason |
|---|---|---|
| Environment: Solo / SWF | **DEFAULT** | Largest strategic divergence |
| Power Tier | **DEFAULT** | Primary browsing need |
| Primary Role | **DEFAULT** | Compact and understandable |
| Classification | **DEFAULT** | Separates meta from niche/module |
| Skill Level | **RECOMMENDED OPTIONAL** | Important for saver/Hyperfocus/chase builds |
| Item Required | **RECOMMENDED OPTIONAL** | Critical for toolbox/light builds |
| Module | **RECOMMENDED OPTIONAL** | Anti-tunnel, anti-slug, etc. |
| Mechanic tags | **ADVANCED** | Too many for mobile default |
| Map Dependence | **ADVANCED** | Useful for specialists |
| Coordination Dependence | **ADVANCED** | Important, but Solo/SWF already exposes much of it |
| Prevalence | **ADVANCED** | Risk of users mistaking popularity for power |
| Evidence Confidence | **ADVANCED** | Essential for research users, secondary for casual browsing |
| Patch Volatility | **ADVANCED** | Research/meta-history feature |
| Individual perk tags | **HIDDEN / SEARCH-ONLY** | Too granular |
| Specific Killer matchup | **HIDDEN / SEARCH-ONLY** | Better on detail pages |

**Recommended preset:** confirmed metas, A/S modules, robust generalist shells, exclude legacy.

**Solo Q preset:** Solo score weighting, X01, C09, I01, G03/G01/G02, C02, I04 and A01 promoted.

**SWF preset:** X02, G01/G02/G03, C11, C01/C02, A01, G04 and coordinated save roles promoted.

**All:** every current catalog entry except legacy unless “include legacy” is toggled.

**Custom:** exposes classification, module, mechanic, item, skill, map dependence and evidence confidence.

### Permanent pages versus catalog-only

**Permanent major-meta pages:**  
Chase Extension / Loop Specialist  
Generator Pressure Specialist

**Permanent strategically important pages despite not being independent metas:**  
Anti-Tunnel  
Anti-Slug / Recovery  
Critical-Generator / Three-Gen Breaker  
Toolbox Generator Specialist  
Hook-State Transfer  
Hook Rescue / Post-Unhook Reset  
Solo-Q Information  
Flashlight Save  
Flashbang Save  
Sabotage / Hook Denial  
Solo-Q Generalist philosophy  
Coordinated SWF team construction

**Catalog pages with experimental labels:**  
Boon: Steadfast  
Road Life  
Chest Scavenger  
Pharmacy  
Do No Harm triage  
Salvation's Cry  
Obsession/Aggro-Info  
Fruits of Your Labor

**Catalog-only niche:**  
Invocation, Locker Utility, Misdirection, Pallet Save, Carry-Escape, Totem Hunter, Fragile-Pallet Restoration.

**Legacy/history pages:**  
Classic Stake Out–Hyperfocus  
Classic Slippery Meat luck  
Old Windows resource-map shell  
Old Sole Survivor shell  
Old Knock Out anti-slug interpretation

## Website-ready meta records

The structured records below cover the **two final ranked independent metas**. String perk IDs are normalized slugs; a production site should map them to its canonical perk database IDs.

```json
{
  "id": "M1",
  "catalogId": "C01",
  "name": "Chase Extension / Loop Specialist",
  "alternateNames": ["Chase Specialist", "Looper", "Runner"],
  "classification": "CONFIRMED_MAJOR_META_ARCHETYPE",
  "parentId": "chase-survival",
  "shortDescription": "Prioritizes extending committed Killer chases to convert Killer time into team objective tempo.",
  "longDescription": "A strategic archetype that allocates perks, routing decisions, map resources and risk tolerance around making Killer pursuit inefficient. Strongest when chase time is reliably converted into generator or rescue progress rather than when four perk slots are simply labeled as chase perks.",

  "primaryRoles": ["Chase"],
  "secondaryRoles": ["Pressure Absorption", "Map Resource Management", "Team Tempo"],
  "modules": ["Anti-Tunnel", "Chase Information"],
  "mechanics": ["Exhaustion", "Vault", "Window", "Pallet", "Haste"],
  "tags": ["runner", "looping", "high-skill"],

  "soloTier": "A",
  "soloScore": 79,
  "soloRating5": 4.0,

  "swfTier": "A",
  "swfScore": 86,
  "swfRating5": 4.5,

  "environmentBias": "Slightly SWF Favored",

  "skillFloor": 3,
  "skillCeiling": 5,

  "consistency": 8,
  "ceiling": 9,
  "independence": 8,
  "coordinationScaling": 8,
  "matchupCoverage": 8,
  "mapCoverage": 8,
  "tempoEfficiency": 9,
  "slotEfficiency": 8,
  "recoveryValue": 6,
  "snowballValue": 7,
  "counterplayResilience": 7,
  "executionReliability": 7,

  "opportunityCost": 3,
  "mapDependence": "MEDIUM",

  "prevalence": "Common ecosystem; pure specialist prevalence unknown post-10.2",
  "trend": "Re-forming",
  "patchVolatility": "MEDIUM_HIGH",

  "mechanicsConfidence": "HIGH",
  "prevalenceConfidence": "MEDIUM",
  "powerConfidence": "MEDIUM",
  "soloConfidence": "MEDIUM",
  "swfConfidence": "MEDIUM",
  "buildConfidence": "MEDIUM",

  "corePerkIds": [
    "lithe",
    "finesse",
    "resilience",
    "windows-of-opportunity",
    "five-moves-ahead"
  ],
  "supportingPerkIds": [
    "sprint-burst",
    "dead-hard",
    "dark-sense"
  ],
  "flexPerkIds": [
    "decisive-strike",
    "deja-vu",
    "kindred",
    "iron-will"
  ],
  "trapOrOutdatedPerkIds": [
    "old-windows-resource-map-shell"
  ],

  "soloBuild": [
    "lithe",
    "resilience",
    "finesse",
    "decisive-strike"
  ],
  "swfBuild": [
    "sprint-burst-or-dead-hard",
    "finesse",
    "resilience",
    "five-moves-ahead"
  ],
  "beginnerBuild": [
    "lithe",
    "windows-of-opportunity",
    "resilience",
    "kindred"
  ],
  "highSkillBuild": [
    "dead-hard",
    "finesse",
    "five-moves-ahead",
    "resilience"
  ],

  "recommendedItems": ["Med-Kit", "Flexible / None"],
  "recommendedAddons": ["Healing-efficiency or charge add-ons as available"],

  "bestAgainst": [
    "Tile-respecting basic-attack Killers",
    "Killers that must commit significant travel time to conventional loops"
  ],
  "weakAgainst": [
    "Tile-bypassing powers",
    "Strong ranged zoning",
    "Killers able to abandon chase and immediately pressure another target"
  ],
  "killerPerkCounters": [
    "Nothing but Misery",
    "Superior Anatomy",
    "Unbound"
  ],

  "synergisticMetaIds": ["M2"],
  "competingMetaIds": ["M2"],
  "counterMetaIds": [],

  "commonMistakes": [
    "Using four chase slots when two or three would suffice",
    "Forcing the Killer to chase instead of doing objectives",
    "Burning strong pallets too early",
    "Remaining injured for Resilience when healing is strategically superior"
  ],
  "failureModes": [
    "Killer refuses chase",
    "Poor map geometry",
    "Anti-loop matchup",
    "Team fails to convert chase time into objectives"
  ],

  "soloAnalysis": "Highly independent mechanically, but the user cannot guarantee random teammates convert a long chase into productive labor.",
  "swfAnalysis": "Role assignment lets the team deliberately convert the strongest runner's chase into three-player objective tempo.",
  "currentMetaAnalysis": "Confirmed meta archetype, but optimal construction is usually a 2+2 or 3+1 hybrid rather than a four-perk pure chase stack.",
  "futureOutlook": "Rating is sensitive to how the Windows/Five Moves Ahead/Dark Sense redistribution settles after 10.2.",

  "evidenceNotes": [
    "Official 10.2 mechanics are high confidence.",
    "Usage evidence is transitional and dominated by pre-10.2 matches."
  ],
  "researchFlags": [
    "NEEDS_14_DAY_CLEAN_10_2_SAMPLE",
    "WINDOWS_REWORK_SETTLING",
    "NO_CAUSAL_OUTCOME_DATA"
  ]
}
```

Current mechanics in this record—particularly Windows, Five Moves Ahead and the Killer anti-vault changes—come from Behaviour's live 10.2 notes; the broad chase ecosystem is supported by transitional Lithe/Resilience usage, not clean post-10.2 outcome evidence. citeturn13search0turn17search2turn18search1

```json
{
  "id": "M2",
  "catalogId": "G01",
  "name": "Generator Pressure Specialist",
  "alternateNames": ["Gen Specialist", "Objective Specialist", "Generator Pressure"],
  "classification": "CONFIRMED_MAJOR_META_ARCHETYPE",
  "parentId": "generator-objective",
  "shortDescription": "Prioritizes critical generator selection, high repair uptime and concentrated item resources to advance the Survivor win condition efficiently.",
  "longDescription": "A strategic archetype in which generator routing, perk selection, item charges and team labor are deliberately allocated to finishing the generators that matter most. Its strongest modern form emphasizes critical-generator control and toolbox burst rather than indiscriminate stacking of repair-speed modifiers.",

  "primaryRoles": ["Generator"],
  "secondaryRoles": ["Objective Routing", "Three-Gen Prevention", "Resource Allocation"],
  "modules": ["Objective Routing", "Item Recursion", "Personal Safety"],
  "mechanics": ["Repair", "Toolbox", "Skill Check", "Item", "Aura Reading"],
  "tags": ["objective", "critical-gen", "toolbox"],

  "soloTier": "A",
  "soloScore": 84,
  "soloRating5": 4.25,

  "swfTier": "S",
  "swfScore": 92,
  "swfRating5": 4.75,

  "environmentBias": "SWF Favored",

  "skillFloor": 2,
  "skillCeiling": 4,

  "consistency": 9,
  "ceiling": 9,
  "independence": 9,
  "coordinationScaling": 9,
  "matchupCoverage": 9,
  "mapCoverage": 8,
  "tempoEfficiency": 10,
  "slotEfficiency": 8,
  "recoveryValue": 5,
  "snowballValue": 9,
  "counterplayResilience": 7,
  "executionReliability": 8,

  "opportunityCost": 3,
  "mapDependence": "LOW_MEDIUM",

  "prevalence": "Common broad objective ecosystem; pure specialist prevalence unknown post-10.2",
  "trend": "Stable parent archetype / re-forming subtypes",
  "patchVolatility": "MEDIUM",

  "mechanicsConfidence": "HIGH",
  "prevalenceConfidence": "MEDIUM",
  "powerConfidence": "MEDIUM",
  "soloConfidence": "MEDIUM",
  "swfConfidence": "MEDIUM_HIGH",
  "buildConfidence": "MEDIUM",

  "corePerkIds": [
    "deja-vu"
  ],
  "supportingPerkIds": [
    "built-to-last",
    "resilience",
    "friendly-competition",
    "hyperfocus"
  ],
  "flexPerkIds": [
    "lithe",
    "sprint-burst",
    "decisive-strike",
    "kindred"
  ],
  "trapOrOutdatedPerkIds": [
    "stake-out-as-hyperfocus-automation",
    "four-redundant-repair-speed-modifiers"
  ],

  "soloBuild": [
    "deja-vu",
    "built-to-last",
    "resilience",
    "lithe"
  ],
  "swfBuild": [
    "deja-vu",
    "built-to-last",
    "friendly-competition",
    "resilience-or-safety-flex"
  ],
  "beginnerBuild": [
    "deja-vu",
    "resilience",
    "lithe",
    "kindred"
  ],
  "highSkillBuild": [
    "deja-vu",
    "hyperfocus",
    "built-to-last",
    "mobility-or-anti-tunnel-flex"
  ],

  "recommendedItems": [
    "Engineer's Toolbox",
    "Commodious Toolbox"
  ],
  "recommendedAddons": [
    "Wire Spool",
    "Socket Swivels",
    "Brand New Part where resource cost is acceptable"
  ],

  "bestAgainst": [
    "Lower-mobility Killers",
    "Killers forced to spend significant time traversing between objectives",
    "Defendable generator clusters that can be broken with concentrated burst"
  ],
  "weakAgainst": [
    "Extreme mobility",
    "Repeated generator displacement",
    "Early tunneling of the item carrier"
  ],
  "killerPerkCounters": [
    "Distressing",
    "Scourge Hook: Monstrous Shrine",
    "Undone",
    "other generator interruption or regression effects"
  ],

  "synergisticMetaIds": ["M1"],
  "competingMetaIds": ["M1"],
  "counterMetaIds": [],

  "commonMistakes": [
    "Repairing the nearest rather than strategically important generator",
    "Spending toolbox charges on low-priority early generators",
    "Stacking redundant repair-speed perks into diminishing returns",
    "Ignoring necessary rescues because of role identity",
    "Using old Stake Out–Hyperfocus advice"
  ],
  "failureModes": [
    "Specialist becomes primary chase target",
    "Poor generator macro",
    "Toolbox resource wasted",
    "Final generator cluster is accidentally created by teammates"
  ],

  "soloAnalysis": "Very strong because generator progress is always useful, but a Solo specialist needs at least one safety mechanism and cannot control teammate generator selection.",
  "swfAnalysis": "S-tier because communication enables critical-generator assignment, toolbox protection, deliberate co-repair triggers and efficient team labor distribution.",
  "currentMetaAnalysis": "Best confirmed individual specialist archetype in Stage 2. Toolbox/critical-gen variants outrank raw perk-speed stacking.",
  "futureOutlook": "Likely to remain strategically central even if individual repair perks change because the archetype is rooted in the primary objective rather than one interaction.",

  "evidenceNotes": [
    "Official 10.2 mechanics are high confidence.",
    "Deja Vu usage and other prevalence figures are transitional.",
    "No clean post-10.2 causal escape-rate dataset is available."
  ],
  "researchFlags": [
    "NEEDS_14_DAY_CLEAN_10_2_SAMPLE",
    "HYPERFOCUS_REOPTIMIZATION",
    "FRIENDLY_COMPETITION_RECHECK"
  ]
}
```

Déjà Vu's present mixed-window usage is 19.42%; Hyperfocus is 5.09%; Built to Last is 2.62%. Toolbox stats and add-ons support the item-centered branch, while 9.6 DR explicitly excludes add-on modifiers. citeturn18search2turn18search0turn17search5turn16search0turn14search1

## Final synthesis and research debt

### Final answers

**Strongest Survivor meta in Solo Q:** **Generator Pressure Specialist, among actual major meta archetypes — A, 84.** However, the **strongest Solo-Q construction overall is X01 Solo-Q Generalist — S, 90**, which is a philosophy rather than a major meta archetype. The distinction is intentional.

**Strongest Survivor meta in coordinated SWF:** **Generator Pressure Specialist — S, 92**, particularly its G02 Toolbox and G03 Critical-Generator branches. At the team-construction level, X02 coordinated flex optimization scores slightly higher at 93, but it is not an individual archetype.

**Strategy gaining most from voice:** **carry/pickup interference**, especially Breakout/bodyblock specialization, closely followed by Hook-State Transfer and sabotage. Their success depends heavily on timing another player's down/carry state rather than only on personal execution.

**Strategy losing most in Solo Q:** dedicated carry-interference/save roles. Their opportunity cost becomes difficult to control without knowing exactly when a down is coming.

**Are specialist builds stronger than generalists?** **Not in the simplistic four-specialist-perks sense.** Solo Q favors generalist/2+2 construction. Coordinated SWF favors **team-distributed role specialization with individually hybrid loadouts**.

**Overrated by popularity:** individual common perks should not be equated with archetypes. In particular, pre-10.2 Windows popularity cannot be carried forward because its live function has changed. Raw prevalence of Lithe, Resilience or DS also does not prove that “chase-only” or “anti-tunnel-only” builds dominate. citeturn17search2turn18search1turn17search3turn13search0

**Underrated:** critical-generator routing; thoughtful toolbox burst; hook-state transfer in coordinated SWF; manual Hyperfocus for genuinely skilled Great-check players.

**Most strategically important 10.2 changes:** the **Stake Out interaction break**, **Windows/Five Moves Ahead/Dark Sense redistribution**, **Shoulder the Burden cost and team-use behavior**, **major chest-perk buffs**, **Road Life rework**, support/healing buffs, and **Survivor Intent System**. citeturn13search0turn15search0

**Is Rescue-and-Reset genuinely meta?** **No, not as one major archetype.** It is a strong parent support family containing A01 rescue/reset, A03 healing, C11 hook-state transfer, A02 anti-camp and A07 endgame rescue.

**Is Pickup Interception genuinely meta?** **No as one archetype.** It is a strategically important parent family with several separate specialist branches. Its strongest SWF subtype in this model is P02 Flashbang Save at A 79, but that is not sufficient to elevate the entire family.

**Is Generator specialization stronger with Toolboxes than perk-speed stacking?** **Yes, provisionally.** Toolboxes create concentrated burst and resource decisions; add-on modifiers are exempt from DR, while several same-type perk modifiers are progressively discounted. The most defensible modern generator specialist is **critical-gen routing + toolbox economy + safety**, not four numerical repair modifiers. citeturn14search1turn16search0

**Is Manual Hyperfocus still competitive?** **Yes, but only as B-tier high-skill specialization on current evidence.** Hyperfocus itself is mechanically intact and has 5.09% transitional usage. The old Stake Out consistency engine is gone. citeturn18search0turn13search0

**Is chest economy real?** **Real strategy: yes. Proven competitive meta: no.** The 10.2 changes are large enough that R01/R02 deserve experimental pages immediately, but no clean post-patch outcome evidence demonstrates that chest time beats bringing resources from the lobby and repairing. Pharmacy/Plunderer need controlled testing. citeturn15search0turn11search3

**Are Boons competitive enough for prominent meta representation?** **Not yet.** Steadfast is mechanically significant and Boon infrastructure improved, but setup, spatial dependence, snuffing and 10.2 Killer Totem counters keep the family below major-meta status. Give Boons prominent **Strategy Catalog** representation, not top-level meta placement. citeturn14search2turn15search0

**Does Intent meaningfully change Solo-Q construction?** **Moderately, not fundamentally.** It reduces the need to buy every basic coordination function with perks, but cannot replace continuous voice, exact positions or rich role discussion. The best Solo architecture remains mobility + objective/information + survival + flex. citeturn15search0

**Modules close to mandatory:** no single perk is universally mandatory. At the functional level, **one reliable personal chase/mobility answer and one tunnel/survival contingency are close to mandatory considerations in Solo Q**, while coordinated teams can distribute some insurance instead of giving every member an identical package. DS's 16.5% mixed-window usage supports the importance of anti-tunnel insurance, but not literal mandatory status. citeturn17search3

**Permanent site pages:** C01/M1, G01/M2, G02, G03, C09, C10, C11, A01, I01, P01, P02, P03, X01, X02.

**Catalog-only:** lower-impact specialist and mechanic builds such as pallet restoration, full Haste stacking, Totem Hunter, Locker Utility, Invocation, misdirection and carry-escape.

**Experimental:** G07 Steadfast, G08 Road Life, G10 Fruits, A04 Do No Harm, I05 Salvation's Cry, R01 chest economy, R02 Pharmacy and R09 Obsession/Aggro-Info.

**Legacy/outdated:** G06 classic Stake Out–Hyperfocus, C13 classic Slippery Meat luck, old Windows all-resource shell, old Sole Survivor shells and old Knock Out anti-slug advice. citeturn13search0turn15search0

### Evidence-confidence summary

| Finding | Mechanics | Prevalence | Power | Solo | SWF | Build optimization |
|---|---|---|---|---|---|---|
| C01 Chase meta classification | High | Medium | Medium | Medium | Medium | Medium |
| G01 Generator meta classification | High | Medium | Medium | Medium | Medium | Medium |
| M3 demotion to parent family | High | Medium | Medium | Medium | Medium | Medium |
| M4 demotion to parent family | High | Low | Low-Medium | Low | Medium | Low |
| C09 Anti-Tunnel as module | High | Medium | Medium | Medium | Medium | Medium |
| C11 Hook-State Transfer | High | Low | Low | Low | Low-Medium | Low |
| G05 Manual Hyperfocus | High | Medium* | Low | Low | Low | Low |
| G06 Stakefocus legacy ruling | **High** | Irrelevant | **High classification confidence** | High | High | High |
| G07 Steadfast | High | Low | Low | Low | Low | Low |
| G08 Road Life | High | Low | Low | Low | Low | Low |
| R01/R02 Chest economy | High | Low post-10.2 | Low | Low | Low | Low |
| Intent System effect | High mechanics | Unknown adoption | Low | Low | Low | Low |

\*Hyperfocus prevalence itself is known only from a mixed-window sample, not clean 10.2.

### Research debt and recheck list

| Question | Why unresolved | Missing evidence | What resolves it | Recheck condition |
|---|---|---|---|---|
| Does new Windows retain high usage? | Old implementation dominates current rolling window | Clean 10.2 pick/co-use data | 14-day patch-pure sample | **After October 20, 2026**, assuming no intervening balance hotfix |
| Which perk inherits old Windows' pallet-routing function? | Five Moves Ahead and Dark Sense changed simultaneously | Clean co-use + player behavior | Patch-pure usage and build clustering | 14 clean 10.2 days |
| Is Manual Hyperfocus actually competitive without Stake Out? | Mechanics are clear; outcomes are not | Controlled repair timing and high-skill match data | Great-check simulations + live outcomes | Controlled gameplay test and 10.2 build data |
| Is Friendly Competition part of optimal SWF gen pressure? | New values have one day of live exposure | Team-level activation/use data | Controlled duo/SWF tests | 10.2 tournament/high-level sample |
| Is Toolbox specialization truly superior to additional safety slots? | No causal public outcome dataset | Controlled matched-skill builds | A/B trials by team composition | Controlled gameplay study |
| Does Shoulder the Burden justify one or two team slots? | Final live implementation differs from PTB | Coordinated SWF outcome data | Hook-state survival/elimination timing | High-level 4-SWF data |
| Is Rescue-and-Reset strong enough to re-promote later? | Several support perks changed together | Role-level post-10.2 outcomes | Unhook→heal tempo and escape outcome | 2–4 weeks clean live play |
| Does Pharmacy beat bringing a Med-Kit? | Transaction was radically buffed | Chest travel/open/rummage opportunity cost | Controlled time-to-value testing | **Requires controlled gameplay testing** |
| Does Plunderer's create positive team resource EV? | Rarity/time gains not yet measured in live macro | Generated-item distribution and use data | Trials comparing chest player vs normal repair | 14–28 clean days + testing |
| Is Boon: Steadfast actually competitive? | Local 10% bonus looks strong but Totem location is variable | Map-by-map uptime/snuff data | Zone uptime, gens covered, Killer counter frequency | Larger post-10.2 sample |
| Does Road Life save more team time than a universal perk? | Requires injured Great checks and later self-heal | Activation rate and completed-heal timing | Controlled Solo tests | 10.2-only Road Life data |
| How much does Intent reduce Kindred/Bond-type demand? | Usage immediately after launch is unknowable | Solo-specific perk change and rescue duplication rates | Before/after Solo telemetry | 2–4 weeks after 10.2 |
| Does Flashbang reliably outperform flashlight saving? | Public data show co-use, not save success | Attempt, success, and shadowing-time rates | Event-level pickup-save telemetry | Controlled saver dataset |
| Is permanent saver role efficient in elite SWF? | No reliable current 10.2 competitive dataset surfaced | Tournament/public high-MMR labor allocation | Objective time vs hook denial accounting | Next meaningful 10.2 competitive sample |
| Does anti-tunnel remain as valuable after team hook-state redistribution? | Interaction is coordination-dependent | Tunnel incidence + Shoulder usage | Target-survival analysis | Clean 10.2 high-MMR/SWF data |
| Is X01 still the strongest Solo construction after players learn Intent? | Intent may change information-slot opportunity cost | Solo-only long-window build outcomes | Clean post-adaptation data | Recheck after **four weeks** of 10.2 |
| Will a 10.2.x hotfix materially alter these ranks? | Several mechanics are extremely new | Official future patch notes | Behaviour hotfix/balance release | **Immediately on any 10.2.1+ balance patch** |

The main Stage 2 conclusion is therefore deliberately narrower than the Stage 1 hypothesis set:

**Dead by Daylight 10.2.0 has two well-supported major individual Survivor meta archetypes: Chase Extension and Generator Pressure. Generator Pressure is the stronger coordinated specialist; Chase remains a major but Killer-agency-limited strategy. Pickup Interception and Rescue-and-Reset are better modeled as parent families of distinct specialist roles and modules. Solo Q is best approached through a generalist 2+2/3+1 construction rather than maximal specialization, while coordinated SWF derives its real advantage from distributing specialized responsibilities across four flexible individual builds.**

That conclusion is supported strongly at the **mechanics/classification level**, but the exact numerical rankings—particularly for Road Life, Steadfast, chest economy, Shoulder the Burden and the new chase-information ecosystem—remain provisional until genuinely clean post-10.2 data exist. Calling the present mixed 14-day statistics “the 10.2 meta” would be false precision. citeturn11search13turn15search0